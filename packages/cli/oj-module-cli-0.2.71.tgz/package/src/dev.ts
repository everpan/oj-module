/**
 * `ojm dev` —— 全栈开发服务器（设计 §4）。
 *
 * 职责是「装配」：按工程布局解析各协作方（shell dist、oj、mock、watch），
 * 组装一个 http server。具体能力各自独立：
 *   - 静态/SPA/注入     → static-handler.ts
 *   - HTML 变换加载     → html-transform.ts（web.config.ts 的 htmlTransform）
 *   - /api 反代与 SSE   → dev-proxy.ts
 *   - oj 子进程生命周期 → oj.ts
 *   - 布局探测          → layout.ts
 *   - 工程 mock 约定    → dev-mock.ts
 *
 * 两种形态（按 config.yaml 是否存在自动判定）：
 *   全栈   /api/* 反代 oj（oj 自带热更，ojm 不重启它），模块源码变更 → 重建 → SSE 刷新
 *   纯前端 /api/* 走工程 mock（mock/*.mock.mjs 约定，未命中 404），行为与历史版本一致
 *
 * 测试经 DevOptions 注入桩（shell dist / 重建函数 / ojStarter）。
 */

import type { ContractMockRoute } from "./contract/mock";
import type { MockRoute } from "./dev-mock";
import type { OjProcess } from "./oj";
import { Buffer } from "node:buffer";
import { spawn } from "node:child_process";
import { existsSync, watch } from "node:fs";
import http from "node:http";

import { join, resolve } from "node:path";
import process from "node:process";
import readline from "node:readline";
import { syncAliasPaths } from "./alias-paths";
import { buildModules, materializeInstallerVersions } from "./build";
import { loadContractMocks, resolveMock } from "./contract/mock";
import { loadProjectMocks, mockStatusCode } from "./dev-mock";
import { createReloadHub, proxyApi, proxyWsUpgrade, sseScript } from "./dev-proxy";
import { mergeConfigForDev } from "./dev-secrets";
import { loadHtmlTransform } from "./html-transform";
import { resolveConfigPath, resolveLayout } from "./layout";
import { resolveCdnLayout } from "./market/cdn-layout";
import { triggerFactoryConverge } from "./market/factory-converge";
import { startOj } from "./oj";
import { requireModuleRootCapability } from "./oj-caps";
import { ensureDevCert } from "./oj-cert";
import { readOjApiPrefix, readOjPort, readOjServerField } from "./oj-config";
import { isPortOccupied } from "./port-check";
import { createStaticHandler, decodeReqPath, listenOnFreePort } from "./static-handler";
import { resolveShellDist } from "./versions";

const DEFAULT_PORT = 5174;

export interface DevOptions {
	port?: number
	/** 注入桩 shell dist（测试）；默认解析 cli 内置 shell-dist */
	shellDist?: string
	/** 注入重建函数（测试）；默认 buildModules（不合并全站，产物只写模块） */
	buildModulesFn?: (projectRoot: string) => Promise<unknown>
	/** 注入桩 oj（测试）；默认 startOj；纯前端工程不调用。第三参为目录（→ --api-path）或已拼好的旗标数组（→ --module-root） */
	ojStarter?: (configPath: string, base: string, apiSource: string | string[]) => OjProcess
	/** 强制纯前端形态（不起 oj，/api 走 mock） */
	frontendOnly?: boolean
	/** 启用 Vite 风格快捷键（默认仅 TTY 启用；测试可强制开） */
	keymap?: boolean
	/** 注入键盘输入流（测试）；默认 process.stdin */
	inputStream?: NodeJS.ReadStream
	/** 注入浏览器打开实现（测试）；默认按平台 spawn open/xdg-open */
	openBrowser?: (url: string) => void
}

export async function devServer(projectRoot: string, opts: DevOptions = {}): Promise<http.Server> {
	const layout = resolveLayout(projectRoot);
	const shellDist = opts.shellDist ?? resolveShellDist();
	const localDist = layout.distDir;
	const build = opts.buildModulesFn ?? ((root: string) => buildModules(root));

	// 1) 先把本地模块构建一次
	console.log("[ojm] 构建本地模块…");
	await build(projectRoot);

	// 1a) dev 形态（platform.root: src）不经 oj build，没有 release 双落点——这里补第三落点：
	// dist/api/versions.json 是方案安装器 C2-09 peerRuntime 比对的真源（B-11 与 manifests.yaml
	// 同层），缺失则随站 bundle 收敛被 fail-closed 永久拒装（2026-11-07 /tmp/ojm-vv/drill 实锤）。
	if (!materializeInstallerVersions(layout.apiDist))
		console.warn("[ojm] ⚠️ 内置宿主 versions.json 缺失（shell-dist 未构建？）：方案安装将被 C2-09 fail-closed 拒绝。");

	// 别名投影跟着模块清单走：dev 是「新增模块 → 立刻写 #/<新模块>/…」的主循环，
	// 不刷新 paths 的话编辑器要把这条 import 报成 any/TS2307，直到下次 build。内容未变不写盘。
	syncAliasPaths(projectRoot);

	// 工程 mock（可选约定 mock/*.mock.mjs）：纯前端形态的 /api 边界
	const mocks: MockRoute[] = await loadProjectMocks(projectRoot);
	// 契约 mock（AC-D14）：手写精确匹配优先，契约 pattern 兜底示例值；装载失败不崩 dev
	let contractMocks: ContractMockRoute[] = [];
	try {
		contractMocks = await loadContractMocks(projectRoot);
	}
	catch (error) {
		console.error(`[ojm-api] 契约 mock 装载失败（不影响 dev 启动）：${error instanceof Error ? error.message : String(error)}`);
	}

	// htmlTransform（web.config.ts，可选）先于起进程校验：配置坏了不该留下 oj 孤儿
	const transform = await loadHtmlTransform(projectRoot);

	// 2) oj 后端（工程有 config.yaml 时全栈形态；桩可注入）
	const configPath = resolveConfigPath(projectRoot);
	let oj: OjProcess | undefined;
	let ojTarget: string | undefined;
	// 反代前缀跟随 config 的 mounts:（api 挂载 prefix；F2：改前缀后硬编码 /api 会静默失效）
	let apiBase = "/api";
	if (!opts.frontendOnly && existsSync(configPath)) {
		// dev 读源码树（保存即热更，不经产物）：module-root 布局给 `--module-root <root>/src`
		// （oj 递归发现 manifest.yaml），历史布局给 `--api-path <root>/api/src`——两者互斥。
		const moduleRoot = layout.kind === "module-root";
		if (moduleRoot)
			requireModuleRootCapability(projectRoot);
		const apiSource: string | string[] = moduleRoot && layout.moduleRoot
			? ["--module-root", layout.moduleRoot]
			: resolve(projectRoot, "api/src");
		apiBase = readOjApiPrefix(configPath);
		// 后端端口预检：被占用（通常上次 ojm dev 未正常退出、遗留 oj 孤儿进程仍在跑）
		// 直接禁止启动并给清晰指引，避免 oj 健康检查超时后才以晦涩信息失败。
		const backendPort = readOjPort(configPath);
		const backendHost = readOjServerField(configPath, "host") || "127.0.0.1";
		if (await isPortOccupied(backendPort, backendHost)) {
			throw new Error(
				`[ojm] 后端 API 端口 ${backendPort} 已被占用，已禁止启动 ojm dev。\n`
				+ "        原因通常是：上一次 ojm dev 未正常退出，遗留的 oj 进程仍在占用该端口。\n"
				+ "        （oj 后端默认端口 9778；若 config.yaml 的 server.port 改过则为对应值。）\n\n"
				+ "        请先结束占用该端口的进程，再重新运行 ojm dev：\n"
				+ `          macOS / Linux： lsof -ti tcp:${backendPort} | xargs kill -9\n`
				+ `          Windows：        netstat -ano | findstr :${backendPort}  找到 PID 后  taskkill /PID <PID> /F\n\n`
				+ "        已停止启动，未留下新的 oj 孤儿进程。",
			);
		}
		// 开发态本地密钥/凭据自动供给（方案 A'）：供给本机 secrets 密钥 + dev jwt_secret，
		// 深合并 tracked config.yaml 与 gitignored config.local.yaml → .ojm-tmp-config.yaml。
		// tracked 里的 ENC[...] 仅作 prod 资产，dev 完全忽略；非 jwt 的 ENC 解不开则清晰报错
		// （红线，防用 dev 随机密钥重封破坏已加密数据）。合并产物与 config.yaml 同目录，oj
		// 相对路径解析不变。
		const effectiveConfigPath = mergeConfigForDev(projectRoot, configPath);
		await ensureDevCert(effectiveConfigPath);
		const fallbackStarter = (cfg: string, b: string, apiSrc: string | string[]) => startOj(cfg, b, apiSrc);
		const starter: NonNullable<DevOptions["ojStarter"]> = opts.ojStarter ?? fallbackStarter;
		oj = starter(effectiveConfigPath, apiBase, apiSource);
		try {
			await oj.ready; // 失败人话报错（stderr 尾部），fail-fast
		}
		catch (error) {
			// F3：ready 拒绝必须先回收子进程，否则 oj 孤儿化继续占端口
			await oj.stop().catch(() => {});
			throw error;
		}
		ojTarget = `http://127.0.0.1:${oj.port}`;
		// 出厂即装（支柱三）：后端就绪后 fire-and-forget 触发一次随站 bundle 收敛
		// （login → index riding 收敛，幂等；服务端 isolate 无定时器，只能 riding 请求）。
		// 失败吞咽——不阻断 dev 启动，首个真实请求对账兜底。
		void triggerFactoryConverge({ port: oj.port, apiBase, log: console.log });
	}

	const hub = createReloadHub();

	// /cdn 反代（feature：market_cdn_url 可为相对路径 = 本站点自供）：config 有 /cdn 挂载
	// 才反代到 oj；无挂载（旧模板/手改工程）或纯前端形态 → 回落静态，行为不变
	let cdnPrefix: string | null = null;
	try {
		cdnPrefix = resolveCdnLayout(projectRoot).prefix;
	}
	catch {
		cdnPrefix = null;
	}

	// 3) 静态半边（dev：模块产物优先，shell dist 兜底；no-store；注入刷新通道）
	// hostRoots 钉死 shell dist：ojm build 的合并残留不得反向遮蔽宿主（F11）
	// transform 来自 web.config.ts（可选）：按路由改写 title/OG，先于 reload 注入
	const serveStatic = createStaticHandler({
		roots: [localDist, shellDist],
		hostRoots: [shellDist],
		reload: { script: sseScript(), handler: hub.handler },
		noStore: true,
		transform,
	});

	const server = http.createServer((req, res) => {
		const urlPath = decodeReqPath(req.url ?? "/");
		if (urlPath === null) {
			res.writeHead(400, { "content-type": "text/plain" });
			res.end("400 Bad Request: malformed URL encoding");
			return;
		}
		// API 前缀跟随 config 的 mounts:（api 挂载 prefix）：全栈形态反代 oj；纯前端形态走工程 mock（历史行为不变）
		if (urlPath.startsWith(`${apiBase}/`)) {
			if (ojTarget) {
				void proxyApi(ojTarget)(req, res);
				return;
			}
			const apiRel = urlPath.replace(/^(\.\.[/\\])+/, "");
			const respond = resolveMock(mocks, contractMocks, req.method ?? "get", apiRel.slice(apiBase.length));
			if (!respond) {
				res.writeHead(404, { "content-type": "application/json; charset=utf-8" });
				// AC-D16：信封键为 msg（oj 形态）
				res.end(JSON.stringify({ code: 404, msg: `No mock for ${req.method} ${apiRel}`, data: null }));
				return;
			}
			const chunks: Buffer[] = [];
			req.on("data", chunk => chunks.push(chunk));
			req.on("end", () => {
				let body: Record<string, unknown> = {};
				try {
					body = JSON.parse(Buffer.concat(chunks).toString() || "{}");
				}
				catch {
					// 非 JSON 请求体按空 body 交给 mock 处理
				}
				const payload = respond({
					body,
					query: new URLSearchParams((req.url ?? "").split("?")[1] ?? ""),
				});
				res.writeHead(mockStatusCode(payload), { "content-type": "application/json; charset=utf-8" });
				res.end(JSON.stringify(payload));
			});
			return;
		}

		// 相对基址 CDN（/cdn）：站点自供挂载直发 oj（不剥前缀），否则静态层会回落成 index.html
		if (cdnPrefix !== null && ojTarget !== undefined && (urlPath === cdnPrefix || urlPath.startsWith(`${cdnPrefix}/`))) {
			void proxyApi(ojTarget)(req, res);
			return;
		}

		serveStatic(req, res);
	});

	// WebSocket 升级走独立事件通道（M5b，协作编辑器 /api/realtime/ws）：
	// proxyApi 是纯 HTTP 反代，Node 把协议升级单发 upgrade 事件，不隧道化则 dev 形态
	// 下 WS 永远握不上手。仅隧道 API 前缀；其余 upgrade 一律掐断。
	server.on("upgrade", (req, socket, head) => {
		const urlPath = decodeReqPath(req.url ?? "/");
		if (!ojTarget || urlPath === null || !urlPath.startsWith(`${apiBase}/`)) {
			socket.destroy();
			return;
		}
		proxyWsUpgrade(ojTarget)(req, socket, head);
	});

	// 终端 Ctrl+C / `kill`（SIGINT / SIGTERM）终止 dev 进程时，后端 oj 必须随之消亡：
	// 起一个统一优雅停机，先停 oj 再退出；并打印后端终止信息。
	// 终端 Ctrl-C 是进程组信号：外层 bin 转发一份 + 组送达一份，内层会收到
	// 两个 SIGINT——once 首次触发即摘除，第二个走默认动作杀死本进程，
	// shutdownDev 跑不完（与 preview 同根因，2026-10-19 冒烟实测）。on +
	// 幂等守卫吞掉重复信号。
	let shuttingDown = false;
	const shutdown = () => {
		if (shuttingDown)
			return;
		shuttingDown = true;
		void shutdownDev(server, oj, hub);
	};
	// 兜底：dev 进程以任何非优雅路径退出（未走 SIGINT/SIGTERM，如未捕获异常）时，
	// 同步强杀 oj，确保它不孤儿化继续占端口（shutdownDev 已停则 kill 为 no-op）。
	const killOjOnExit = () => {
		oj?.kill?.();
	};
	process.on("SIGINT", shutdown);
	process.on("SIGTERM", shutdown);
	process.once("exit", killOjOnExit);

	// 退出回收：server 关闭 → SSE 通道 + oj 子进程一并回收，并摘除本实例注册的
	// 进程级信号/exit handler。devServer 可在同一进程被多次调用（编程式 / 测试），
	// 不摘除会累积闭包、触发 MaxListenersExceededWarning（与 preview 的 stop 同款）。
	server.on("close", () => {
		hub.close();
		void oj?.stop();
		process.removeListener("SIGINT", shutdown);
		process.removeListener("SIGTERM", shutdown);
		process.removeListener("exit", killOjOnExit);
	});

	// 端口被占用时自动顺延，避免 `EADDRINUSE` 直接让 `pnpm dev` 以非零码退出
	const actualPort = await listenOnFreePort(server, opts.port ?? DEFAULT_PORT);
	console.log(`\n[ojm] 开发服务器已启动：http://localhost:${actualPort}`);

	if (ojTarget)
		console.log(`[ojm] oj 后端已就绪：${apiBase} → ${ojTarget}（api.ts 保存即热更）`);
	else
		console.log("[ojm] 纯前端形态（无 config.yaml）：/api 由 mock/ 提供");

	console.log("[ojm] 宿主来自 @oj-module/cli 内置 shell-dist（importmap 单例），模块来自本地 dist/");

	if (!ojTarget && mocks.length)
		console.log(`[ojm] 工程 mock：${mocks.length} 条路由（mock/ 目录，重启生效）`);

	console.log(`[ojm] 修改 ${layout.modulesSrc} 下的源码会触发重建并自动刷新浏览器。\n`);

	// 4) 监听模块源码（watchTarget 纯源码目录，永不落产物 → 无自触发循环）
	const { createContractRegen } = await import("./contract/watch");
	// 评审 F2：契约重生成后同步重建契约 mock 表——否则 client 按新 schema
	// 校验、mock 按旧 schema 出数，dev 期必现假「契约违例」且需重启恢复
	const regenContracts = createContractRegen(projectRoot, {
		onRegenerated: (result) => {
			if (result.written.length > 0)
				console.log(`[ojm-api] 契约产物已更新 ${result.written.length} 个文件——模块重建将自动触发。`);
			loadContractMocks(projectRoot).then(
				(routes) => {
					contractMocks = routes;
				},
				(error: unknown) => {
					console.error(`[ojm-api] 契约 mock 表重载失败（沿用旧表）：${error instanceof Error ? error.message : String(error)}`);
				},
			);
		},
	});
	let timer: NodeJS.Timeout | null = null;
	const trigger = () => {
		if (timer)
			clearTimeout(timer);
		timer = setTimeout(async () => {
			try {
				console.log("[ojm] 检测到模块源码变更，重建中…");
				await build(projectRoot);
				hub.broadcast();
				console.log("[ojm] 重建完成，已通知浏览器刷新。");
			}
			catch (err) {
				console.error("[ojm] 重建失败：", err);
			}
		}, 300);
	};
	try {
		watch(layout.watchTarget, { recursive: true }, () => {
			// 契约产物（__client）由 regenContracts 落 web 树 → 二次触发本 watch 走重建
			trigger();
		});
	}
	catch {
		// 某些平台不支持 recursive，退化为不自动重建（手动 ojm build 仍可用）
	}
	// uni-dev 契约源在 api/src（不在模块 watch 范围内）。新流水线（oj v0.1.73）：
	// contract.ts 已退役，dev 改 handler `.schema`/`.response` 后按约定手动重跑
	// `oj openapi -o openapi.json`——监听工程根该文件变化触发 __client 重生成
	// （落 web 树 → 二次触发上方 watch 走重建）。
	try {
		const specPath = join(projectRoot, "openapi.json");
		if (existsSync(specPath))
			watch(specPath, () => regenContracts());
	}
	catch {
		// 同上：平台不支持时退化为手动 ojm api
	}

	// Vite 风格快捷键：r 热更新 / h 帮助 / c 清屏 / o 打开浏览器 / q 退出。
	// 仅 TTY 默认启用（管道/CI 下不抢 stdin）；测试可经 keymap + inputStream 强制。
	const keymapEnabled = opts.keymap ?? (process.stdin.isTTY ?? false);
	if (keymapEnabled) {
		const footerText = "快捷键：r 热更新 · h 帮助 · c 清屏 · o 打开浏览器 · q 退出";
		const footer = pinFooter(`[ojm] ${footerText}`);
		setupDevKeymap({
			server,
			oj,
			hub,
			port: actualPort,
			input: opts.inputStream,
			openBrowser: opts.openBrowser,
			clearScreen: footer ? () => footer.clear() : undefined,
			onReload: () => {
				void trigger();
			},
			onQuit: shutdown,
		});
		// 非 TTY（pinFooter 拒绝）回退一次性打印，行为与历史一致
		if (!footer)
			console.log(`[ojm] ${footerText}`);
	}

	return server;
}

/**
 * dev 进程优雅停机：前端（dev server）终止 → 关闭 SSE 通道 → 停止后端 oj → 退出。
 * 抽出独立函数便于单测（注入 exit/log，避免真杀测试进程）。
 * 顺序关键：SSE 连接永不自然结束，server.close 必须在 hub 销毁客户端之后。
 */
export async function shutdownDev(
	server: http.Server,
	oj: OjProcess | undefined,
	hub: { close: () => void },
	deps: { exit?: (code?: number) => void, log?: (msg: string) => void } = {},
): Promise<void> {
	const exit = deps.exit ?? ((code?: number) => process.exit(code));
	const log = deps.log ?? ((msg: string) => console.log(msg));
	log("\n[ojm] 前端服务已停止，正在终止后端 oj…");
	// 顺序：先销毁 SSE 客户端，再关 server（否则 server.close 永不回调）
	hub.close();
	await oj?.stop();
	log("[ojm] 后端 oj 已随前端一起终止。");
	server.close(() => exit(0));
	// 1.5s 内没关干净也强制退（oj.stop 内部另有 3s SIGKILL 兜底）
	setTimeout(exit, 1500, 0).unref();
}

/**
 * 快捷键提示常驻底栏：DECSTBM 把滚动区设为 1..rows-1，末行留给提示。
 * 之后本进程 console.log 与 oj 透传（均经 process.stdout.write）只在滚动区内滚动，
 * 末行由终端保持，无需逐条重绘。非 TTY / 行数不足返回 undefined（调用方回退一次性打印）。
 */
export interface PinnedFooter {
	/** 清屏：ED（\x1b[2J）保留滚动区（RIS \x1bc 会复位滚动区，禁用），随后重绘提示 */
	clear: () => void
	/** 恢复全屏滚动区并落光标到底行（进程退出/shell 接管前调用）；幂等 */
	stop: () => void
}

export function pinFooter(text: string, stream: NodeJS.WriteStream = process.stdout): PinnedFooter | undefined {
	if (!stream.isTTY || (stream.rows ?? 0) < 3)
		return undefined;
	const write = (s: string) => {
		stream.write(s);
	};
	const render = () => {
		const rows = stream.rows || 24;
		write(`\x1B[1;${rows - 1}r`); // 滚动区：首行 ~ 倒数第二行（DECSTBM 会把光标送回 1;1）
		write(`\x1B[${rows};1H\x1B[2K${text}`); // 末行清行后画常驻提示
		write(`\x1B[${rows - 1};1H`); // 光标回滚动区底行，后续输出照常滚动
	};
	render();
	const onResize = () => render();
	let stopped = false;
	const stop = () => {
		if (stopped)
			return;
		stopped = true;
		process.removeListener("SIGWINCH", onResize);
		process.removeListener("exit", stop);
		write("\x1B[r\x1B[999;1H\n"); // 恢复全屏滚动区，光标夹到底行避免 shell 提示符悬空
	};
	process.on("SIGWINCH", onResize);
	process.on("exit", stop);
	return {
		clear: () => {
			write("\x1B[2J");
			render();
		},
		stop,
	};
}

/**
 * Vite 风格 dev 快捷键（默认仅在 TTY 启用，见 devServer 内的 keymapEnabled 判定）。
 *   r  强制重建并热更新（复用 trigger）
 *   h  显示快捷键帮助
 *   c  清屏
 *   o  在浏览器打开 dev 地址
 *   q  退出（走 shutdownDev，后端 oj 一并终止）；Ctrl+C 等价
 * 抽出独立函数便于单测（注入 input/onReload/onQuit/openBrowser/log）。
 */
export interface DevKeymapDeps {
	server: http.Server
	oj: OjProcess | undefined
	hub: { close: () => void }
	port: number
	/**
	 * 键盘输入流：默认 `process.stdin`（TTY）；测试可注入任意 Readable（如 PassThrough）。
	 * 宽松成 ReadableStream + 可选 setRawMode：keypress 监听与非 TTY 路径都不依赖 TTY 方法，
	 * 而 `NodeJS.ReadStream` 强求 isTTY/setRawMode 等成员，注入流无法满足（TS2740）。
	 */
	input?: NodeJS.ReadableStream & { setRawMode?: (mode: boolean) => unknown }
	openBrowser?: (url: string) => void
	/** 清屏实现（默认 \x1Bc）；devServer 注入底栏版以保住滚动区 */
	clearScreen?: () => void
	onReload: () => void
	onQuit: () => void
	log?: (msg: string) => void
}

function defaultOpenBrowser(url: string): void {
	const args = process.platform === "darwin"
		? ["open", url]
		: process.platform === "win32"
			? ["cmd", "/c", "start", "", url]
			: ["xdg-open", url];
	spawn(args[0], args.slice(1), { stdio: "ignore", detached: true }).unref();
}

export function setupDevKeymap(deps: DevKeymapDeps): void {
	// 显式标注收敛 `??` 的联合类型（ReadStream ∩ 可选 setRawMode 的并集会让 .on 签名不可调和）
	type KeymapInput = NodeJS.ReadableStream & { setRawMode?: (mode: boolean) => unknown };
	const input: KeymapInput = deps.input ?? process.stdin;
	const log = deps.log ?? ((msg: string) => console.log(msg));
	const open = deps.openBrowser ?? defaultOpenBrowser;
	const url = `http://localhost:${deps.port}`;

	const help = () => {
		log("");
		log("  ojm dev 快捷键：");
		log("    r  强制重建并热更新      h  显示本帮助");
		log("    c  清屏                  o  在浏览器打开");
		log("    q  退出（后端 oj 一并终止）");
	};

	const onKey = (str: string, key: readline.Key | undefined) => {
		const k = (str || "").toLowerCase();
		// Ctrl+C 在 raw 模式下不触发 SIGINT，需在此显式退出
		if (key?.ctrl && (k === "c" || key.name === "c")) {
			deps.onQuit();
			return;
		}
		// 仅处理可打印单字符（箭头/功能键 str 为空，忽略）
		if (!k)
			return;
		if (k === "r") {
			log("[ojm] 手动热更新：重建中…");
			deps.onReload();
		}
		else if (k === "h") {
			help();
		}
		else if (k === "c") {
			if (deps.clearScreen)
				deps.clearScreen();
			else
				process.stdout.write("\x1Bc");
		}
		else if (k === "o") {
			open(url);
		}
		else if (k === "q") {
			deps.onQuit();
		}
	};

	readline.emitKeypressEvents(input);
	if (typeof input.setRawMode === "function") {
		try {
			input.setRawMode(true);
		}
		catch {
			// 非 TTY（注入流）忽略
		}
	}
	input.resume?.();
	input.on("keypress", onKey);

	const cleanup = () => {
		input.removeListener("keypress", onKey);
		if (typeof input.setRawMode === "function") {
			try {
				input.setRawMode(false);
			}
			catch {
				// 忽略
			}
		}
	};
	deps.server.on("close", cleanup);
	process.once("exit", cleanup);
}
