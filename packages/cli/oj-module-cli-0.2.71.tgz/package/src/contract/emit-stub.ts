import type { OjSchemaDiag } from "./emit-oj-schema";
import type { IrEndpoint } from "./ir";
import { createHash } from "node:crypto";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, posix, sep } from "node:path";
import { emitOjSchemaLine } from "./emit-oj-schema";
import { splitRoute, wirePrefixOf } from "./ir";
import { jsonSchemaToSample } from "./json-schema-sample";

/**
 * AC-D10 §9.1：handler stub 发射器 + 指纹幂等。
 *
 * 幂等规则（设计文档 §9 表格的代码化）：
 * - 文件不存在 → create
 * - 指纹匹配且内容一致 → skip（零写入，git diff 为空）
 * - 指纹匹配但契约已变 → update（无人劳动成果，覆盖安全）
 * - 指纹不匹配（人已编辑）→ skip + reason 指路 --check；工具永不写、永不删
 *
 * 指纹健壮性（评审 F6）：stub 模板按仓风格写死（tab/双引号/分号）天然
 * lint-clean，指纹直接哈希发射内容——不再依赖消费工程装了 ESLint
 * （cli 并未声明该依赖，真实工程里 `await import("eslint")` 即崩）。
 * eslintFix 注入缝保留给测试与特殊工程的自定义格式化。
 */

export interface StubWrite {
	filePath: string
	content: string
	action: "create" | "update" | "skip"
	reason?: string
	/** update 的纯前缀升级（旧 ram-api:stub → 新 ojm-api:stub，正文未变）：--check 不报过期 */
	prefixUpgrade?: boolean
}

export interface PlanStubOptions {
	/** oj api 源码根（如 "api/src"）；仅用于未提供 `apiRootOf` 时的路径拼接 */
	apiSrcDir: string
	/**
	 * 模块名 → 该模块 api 侧目录。module-root 布局传 `(m) => apiSrcOf(layout, m)`
	 * （`<src>/<m>/api`）——stub 必须落进模块的 api 侧，串到 `<src>/<m>/` 会被 oj 当成
	 * 模块根下的普通文件；历史布局缺省即 `<apiSrcDir>/<m>`。
	 */
	apiRootOf?: (module: string) => string
	/** 读已有文件（不存在返回 undefined）；缺省真实 fs */
	readFile?: (path: string) => string | undefined
	/** 格式化注入缝（测试/特殊工程）；缺省恒等——模板本身天然 lint-clean（F6） */
	eslintFix?: (code: string, filePath: string) => Promise<string>
	/** 收集 .schema 降级诊断（契约里 oj 表达不了的约束会记在这里，不静默丢） */
	diag?: OjSchemaDiag
	/**
	 * 已实现路由键（`"METHOD /abs/path"`，handler-scan 的 implementedRouteKeys 产出）。
	 * DDD reshape（oj v0.1.64 嵌套组）后 handler 可住在模块根单文件等非镜像位置——
	 * 这些端点跳过 stub 生成，否则镜像 stub 与真实 handler 双写同路由。
	 */
	implemented?: Set<string>
}

/** oj 方法名映射（DELETE → del）。OPTIONS 不在契约表达范围（runtime 白名单拒绝） */
const OJ_METHOD: Record<string, string> = {
	GET: "get",
	POST: "post",
	PUT: "put",
	DELETE: "del",
	PATCH: "patch",
	HEAD: "head",
};

/**
 * 指纹头前缀：新写用 `ojm-api:stub`；读兼容旧 `ram-api:stub`（存量生成物）——
 * 否则升级后旧 stub 会被判为「人工编辑」而永不随契约更新（R2）。
 */
const FINGERPRINT_RE = /^\/\/ (?:ojm|ram)-api:stub (.+) sha256:([0-9a-f]{64})\r?\n/;

/** 旧指纹头（存量产物）：仅前缀不同时判为可升级，不作内容过期 */
const LEGACY_FINGERPRINT_HEAD = /^\/\/ ram-api:stub /;

/** 哈希输入归一：LF + 行尾空白剔除（跨机器/lint 稳定） */
export function hashContent(body: string): string {
	const norm = body.replaceAll("\r\n", "\n").split("\n").map(l => l.replace(/[ \t]+$/, "")).join("\n");
	return createHash("sha256").update(norm).digest("hex");
}

/** 最小示例值源码生成：JSON Schema → 确定性示例值 → TS 字面量（JSON.stringify 即合法源码） */
function exampleSourceFromSchema(schema: unknown): string {
	return JSON.stringify(jsonSchemaToSample(schema));
}

function emitHandler(ep: IrEndpoint, diag?: OjSchemaDiag): string {
	const method = OJ_METHOD[ep.method];
	if (!method)
		throw new Error(`[ojm-api] stub 发射失败：端点 "${ep.name}" 方法 ${ep.method} 不在 oj 支持范围。`);
	const { tail } = splitRoute(ep.route);
	const body = ep.raw
		? "\t// TODO: raw 端点（二进制/流）——请自行实现响应写回\n\tjson.fail(501, \"not implemented\");"
		: `\tjson.ok(${ep.dataSchema ? exampleSourceFromSchema(ep.dataSchema) : ""});`;
	const routeLine = tail ? `${method}.route = "${tail}";\n` : "";
	// 入参契约（oj v0.1.44）：声明了就落到 handler 上，由 oj 在 JS 之前校验
	const schemaLine = emitOjSchemaLine(ep, method, diag);
	return `function ${method}(): void {
${body}
}
${routeLine}${schemaLine}`;
}

/** 同目录多端点归并一个 api.ts；方法按 HTTP 序排列保证字节稳定 */
const METHOD_ORDER = ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"];

function emitStubBody(endpoints: IrEndpoint[], diag?: OjSchemaDiag): string {
	const sorted = [...endpoints].sort((a, b) => METHOD_ORDER.indexOf(a.method) - METHOD_ORDER.indexOf(b.method));
	const handlers = sorted.map(ep => emitHandler(ep, diag)).join("\n");
	const names = sorted.map(ep => OJ_METHOD[ep.method]).join(", ");
	return `${handlers}export default { ${names} };\n`;
}

/** 纯计划不写盘：IR → 逐文件 StubWrite（create/update/skip + reason） */
export async function planStubWrites(ir: IrEndpoint[], opts: PlanStubOptions): Promise<StubWrite[]> {
	const readFile = opts.readFile ?? ((p: string) => {
		try {
			return readFileSync(p, "utf8");
		}
		catch {
			return undefined;
		}
	});
	const fix = opts.eslintFix ?? ((code: string) => Promise.resolve(code));

	// 按（模块段 + 目录镜像）分组 → 一个 api.ts
	// 已在别处（模块根嵌套组 / 其他文件）实现的端点不进 stub 计划。
	// 键保留模块与目录两段：落盘路径要经 `apiRootOf` 定位模块 api 根（module-root 布局
	// 多一层 `api`），不能只拼成一条相对串。
	const groups = new Map<string, { module: string, dir: string, endpoints: IrEndpoint[] }>();
	for (const ep of ir) {
		if (opts.implemented) {
			const ojFullAbs = (ep.apiPrefix + ep.route).replace(/\/{2,}/g, "/");
			const contractAbs = `${wirePrefixOf(ep)}${ep.route}`;
			if ([ojFullAbs, contractAbs].some(a => opts.implemented!.has(`${ep.method} ${a}`)))
				continue;
		}
		const module = ep.apiPrefix.replace(/^\//, "");
		const { dir } = splitRoute(ep.route);
		const key = `${module}\u0000${dir}`;
		const group = groups.get(key);
		if (group)
			group.endpoints.push(ep);
		else
			groups.set(key, { module, dir, endpoints: [ep] });
	}

	const writes: StubWrite[] = [];
	for (const [, { module, dir, endpoints }] of [...groups.entries()].sort()) {
		// filePath 统一 POSIX 分隔符：契约/manifest/指纹键都按 `/` 比对，Windows 上
		// path.join 会产出 `\`，导致落盘路径失配（stub 找不到、快照漂移）。
		// fs 侧 Windows 同样接受 `/`，无需回转分隔符。
		const apiRootRaw = opts.apiRootOf ? opts.apiRootOf(module) : posix.join(opts.apiSrcDir, module);
		const apiRoot = apiRootRaw.split(sep).join("/");
		const filePath = posix.join(apiRoot, dir, "api.ts");
		// 模板天然 lint-clean（F6）→ 直接哈希发射内容；注入缝仅供测试/特殊工程对齐
		const body = await fix(emitStubBody(endpoints, opts.diag), filePath);
		const fingerprint = `// ojm-api:stub ${endpoints.map(e => e.name).sort().join(",")} sha256:${hashContent(body)}\n`;
		const content = fingerprint + body;

		const existing = readFile(filePath);
		if (existing === undefined) {
			writes.push({ filePath, content, action: "create" });
			continue;
		}
		const match = FINGERPRINT_RE.exec(existing);
		if (!match || match[2] !== hashContent(existing.replace(FINGERPRINT_RE, ""))) {
			writes.push({
				filePath,
				content,
				action: "skip",
				reason: "文件已被人工编辑（指纹缺失或不匹配）——工具永不覆盖人的劳动成果；如契约新增 method 未实现，ojm api --check 会对账报出。",
			});
			continue;
		}
		if (toLf(existing) === toLf(content)) {
			writes.push({ filePath, content, action: "skip", reason: "契约未变，产物字节一致（零写入）" });
			continue;
		}
		// 仅指纹头前缀差异（旧 `ram-api:stub` → 新 `ojm-api:stub`），正文逐字节一致：
		// 升级而非契约变更。runApi 落盘刷头；--check 不得当过期误报（R2 平滑升级）。
		if (isPrefixOnlyUpgrade(existing, content)) {
			writes.push({
				filePath,
				content,
				action: "update",
				prefixUpgrade: true,
				reason: "仅指纹头前缀升级（ram-api:stub → ojm-api:stub），正文未变",
			});
			continue;
		}
		writes.push({ filePath, content, action: "update", reason: "指纹匹配（stub 未被人编辑），随契约变更更新" });
	}
	return writes;
}

/**
 * 旧指纹头（存量生成物）→ 换成新头后与期望内容一致 ⇔ 纯前缀升级。
 * 比较前统一 LF：Windows `core.autocrlf=true` 检出会把 stub 变成 CRLF，
 * 而指纹哈希本就按 LF 归一（hashContent）——若这里按字节比会误报「待更新」。
 */
function isPrefixOnlyUpgrade(existing: string, content: string): boolean {
	if (!LEGACY_FINGERPRINT_HEAD.test(existing))
		return false;
	return toLf(existing.replace(LEGACY_FINGERPRINT_HEAD, "// ojm-api:stub ")) === toLf(content);
}

/** 换行归一（CRLF → LF），供逐字节比较使用（与 hashContent 的归一保持一致） */
function toLf(text: string): string {
	return text.replaceAll("\r\n", "\n");
}

/** 落盘：仅 create/update 写文件（父目录递归创建）；skip 零写入 */
export function applyStubWrites(writes: StubWrite[], writeFile?: (path: string, content: string) => void): { created: number, updated: number, skipped: number } {
	const write = writeFile ?? ((p: string, content: string) => {
		mkdirSync(dirname(p), { recursive: true });
		writeFileSync(p, content);
	});
	let created = 0;
	let updated = 0;
	let skipped = 0;
	for (const w of writes) {
		if (w.action === "skip") {
			skipped++;
			continue;
		}
		write(w.filePath, w.content);
		if (w.action === "create")
			created++;
		else
			updated++;
	}
	return { created, updated, skipped };
}
