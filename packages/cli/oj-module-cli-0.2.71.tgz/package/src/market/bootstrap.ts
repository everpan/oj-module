/**
 * 隔离站点自举（T8）：`ojm market trial` / `walkthrough` 的地基。
 *
 * 目标：给你一个「别人家的站点」来试装——不碰你的工程、DB、信任库、端口。
 * 隔离六项各有落点：
 * - **端口**：临时根 config 写入空闲端口（startOj 从 config 读端口，故派生 config 是唯一真相）；
 * - **DB**：oj 的 sqlite 按 config 所在目录解析，临时根内自然隔离（dbPath 暴露供断言）；
 * - **密钥**：发布方 Ed25519 由公开 seed 经 SHA-256 派生（照 fixtures/sig 夹具手法），
 *   私钥只在内存，临时根内无 PEM（站点自己的开发证书走 mintDevCert，属站点身份）；
 * - **凭据**：隔离库是全新 seed，admin 口令即种子默认值，与真站点凭据零交集；
 * - **信任库**：`.solutions/trusted-keys.yaml` 只在安装器写入时生成，全新根内不存在；
 * - **CDN 目录**：临时根内 cdn/，由本模块自建（publish 落字节 + db-seed 直写 market_release
 *   目录行——DB 目录化后安装解析直读目录表，索引机制已退役，v4 §五内部通道）。
 *
 * 提库来源：`scripts/verify-solution-smoke/bootstrap-host.mjs`（同手法，脚本形态）；
 * 本文件是它的 cli 内嵌版（计划 §9.1：phase1 从这里提库而非重写）。
 */

import type { OjProcess } from "../oj";
import { Buffer } from "node:buffer";
import { createHash, createPrivateKey, randomBytes } from "node:crypto";
import { cpSync, existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import net from "node:net";
import { tmpdir } from "node:os";
import path from "node:path";

import process from "node:process";
import { fileURLToPath } from "node:url";
import { buildBackend } from "../build";
import { resolveLayout } from "../layout";
import { exportRawPublicKeyHex, fingerprintOfPublicKey } from "../lifecycle/sign";
import { startOj } from "../oj";
import { mintDevCert } from "../oj-cert";
import { resolveOjBin } from "../vendor";
import { seedMarketRelease } from "./db-seed";
import { parseFixtureSpec } from "./fixture";
import { publishPackage } from "./publish";

/** 种子管理员（隔离库全新 seed；与 templates seed.sql 一致） */
// 种子管理员 = superadmin：模板 seed 账号名=角色名（3d93063f 起 admin 被幂等解绑 superadmin
// 角色），写 market 安全设置要求 actor 持 superadmin 角色——用 admin 会 403（2026-10-23 演练实踩）。
const SEED_ADMIN_USER = "superadmin";
const SEED_ADMIN_PASS = "aA123456";

/** Ed25519 PKCS#8 DER 前缀（RFC 8410 固定头；与 gen-signed-fixtures.mjs 同一手法） */
const ED25519_PKCS8_PREFIX = "302e020100300506032b657004220420";

export interface IsolatedPublisher {
	keyId: string
	privateKeyPem: string
	publicKeyHex: string
	fingerprint: string
}

export interface IsolatedSite {
	/** 临时根（含 config.yaml / src/ / dist/api/ / bin/ / cdn/） */
	root: string
	port: number
	baseUrl: string
	apiBase: string
	cdnDir: string
	cdnBaseUrl: string
	/** sqlite 库路径（config 目录相对解析；断言隔离用） */
	dbPath: string
	/** 一次性发布方身份（私钥只在内存） */
	publisher: IsolatedPublisher
	/** 隔离库的种子管理员 */
	admin: { user: string, pass: string }
	/** 销毁隔离根与 oj 进程；幂等 */
	cleanup: () => Promise<void>
	/** 销毁清单（--keep 时给人看这里到底有什么） */
	teardownReport: () => string[]
	/**
	 * 重启隔离站点 oj serve（停当前进程，按同一派生 config 重新起站）。
	 * 用途：无守护形态安装会落 partial（vars/auth 等冻结段热改属 restart_pending，需进程
	 * 重启才激活）。walkthrough 在每次安装后置重启，模拟真实「部署 → 重启」时序，让模块真正
	 * 上线（路由/匿名端点注册），使后续深检/升级/重装断言落到活跃态而非空洞的 partial。
	 * token 仍有效（jwt_secret 落在 config 文件，重启不变）；DB 在同根，会话延续。
	 */
	restart: () => Promise<void>
}

export interface BootstrapOptions {
	/** 源工程（提供 bin/oj 与 cli 内置模板）；缺省 process.cwd() */
	projectRoot?: string
	/** 落进隔离 CDN 的 fixture；缺省 demo-solution@0.1.0 */
	fixture?: string
	/** 保留现场（cleanup 不删根，只打清单） */
	keep?: boolean
	/** 测试注入；缺省真 startOj */
	starter?: (configPath: string, base: string, apiSrc: string) => OjProcess
	/** 日志旁路（测试收集用） */
	onLog?: (line: string) => void
}

export async function bootstrapIsolatedSite(opts: BootstrapOptions = {}): Promise<IsolatedSite> {
	const projectRoot = opts.projectRoot ?? process.cwd();
	const log = (line: string) => (opts.onLog ?? ((l: string) => console.log(l)))(line);

	const ojBin = resolveOjBin(projectRoot);
	if (!existsSync(ojBin)) {
		throw new Error(
			`[ojm] 源工程未安装 oj 二进制：${ojBin}\n`
			+ "下一步：在源工程目录跑一次 `ojm vendor`（经 npm 包 @oj-bin/oj 下载），再重试。",
		);
	}

	const root = mkdtempSync(path.join(tmpdir(), "ojm-trial-"));
	// 新布局（`src/<name>/{api,web}`）：config.yaml 在隔离根，源码树根为 <root>/src，
	// 构建产物仍是扁平根 <root>/dist/api（与真实工程同形）。
	const srcDir = path.join(root, "src");
	const configPath = path.join(root, "config.yaml");
	const cdnDir = path.join(root, "cdn");
	const dbPath = path.join(root, "db.sqlite");

	// 1) 后端源码树 + config（模板由 cli 包内置，init 同源；与 cli→templates 依赖红线不冲突——那是运行期文件而非 import）
	const cliRoot = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
	const templateDir = path.join(cliRoot, "templates");
	if (!existsSync(path.join(templateDir, "config.yaml"))) {
		throw new Error(`[ojm] cli 内置模板缺失：${templateDir}（@oj-module/cli 安装不完整？）`);
	}
	// 只拷后端侧（`src/<name>/api`）：隔离站点不构建前端，web 源码拷过去只是噪音
	for (const entry of readdirSync(path.join(templateDir, "src"), { withFileTypes: true })) {
		const apiSide = path.join(templateDir, "src", entry.name, "api");
		if (entry.isDirectory() && existsSync(apiSide))
			cpSync(apiSide, path.join(srcDir, entry.name, "api"), { recursive: true });
	}
	writeFileSync(configPath, readFileSync(path.join(templateDir, "config.yaml"), "utf-8"), "utf-8");

	// 2) oj 二进制与插件（startOj 按 <root>/bin/oj[.exe] 解析；plugins 让 auth 插件可用）。
	// 跨平台：ojBin 在 Windows 为 bin/oj.exe、Linux/macOS 为 bin/oj——拷贝目标文件名必须
	// 与源一致（path.basename），否则 Windows 下落盘成无扩展名的 `oj`，后续 resolveOjBin
	// 按 bin/oj.exe 解析会找不到、后端构建检查也报「缺少 bin/oj.exe」（trial/walkthrough 隔离站点挂死）。
	mkdirSync(path.join(root, "bin"), { recursive: true });
	cpSync(ojBin, path.join(root, "bin", path.basename(ojBin)), { recursive: true });
	const versionMarker = path.join(projectRoot, "bin", ".oj-version");
	if (existsSync(versionMarker)) {
		cpSync(versionMarker, path.join(root, "bin", ".oj-version"));
	}
	const pluginsDir = path.join(projectRoot, "bin", "plugins");
	if (existsSync(pluginsDir)) {
		cpSync(pluginsDir, path.join(root, "bin", "plugins"), { recursive: true });
	}

	// 3) 派生 config：空闲端口 / 随机 jwt / CDN 挂载指绝对路径 / fs 段
	const port = await freePort();
	let cfg = readFileSync(configPath, "utf-8");
	cfg = cfg.replace("port: 9778", `port: ${port}`);
	if (!cfg.includes(`port: ${port}`)) {
		throw new Error(`[ojm] 模板 config 未含 端口: 9778 字面（模板结构变了？）：${configPath}`);
	}
	cfg = cfg.replace("__JWT_SECRET__", randomBytes(32).toString("hex"));
	// 站点对外地址：安装的相对市场基址（/cdn 本站点自供）与深检探针都靠它补全绝对 URL，
	// 服务端 REG-CS6 刻意不读请求头 Host（防伪造 Host 牵引出站），**缺即拒、不猜**。
	// 隔离站点的对外地址恒为它自己的 origin（端口本次随机派开），这里替部署侧填好。
	const originLine = `  canonical_origin: "http://127.0.0.1:${port}"`;
	if (cfg.includes("canonical_origin:")) {
		cfg = cfg.split("\n").map(line => (line.includes("canonical_origin:") ? originLine : line)).join("\n");
	}
	else {
		cfg = cfg.includes("\nvars:")
			? cfg.replace("\nvars:", `\nvars:\n${originLine}`)
			: `${cfg}\nvars:\n${originLine}`;
	}
	if (!cfg.includes(`http://127.0.0.1:${port}`)) {
		throw new Error(`[ojm] 模板 config 未含 vars 段（模板结构变了？）：${configPath}`);
	}
	// 最小 SPA 挂载：真实部署里前端路由（深检会逐条探活）由站点壳承接；没有 web 挂载时
	// 这些路径一律 404，深检会判成 anomaly。这里放一个 index.html 就够（不构建前端）。
	const siteDir = path.join(root, "site");
	mkdirSync(siteDir, { recursive: true });
	writeFileSync(path.join(siteDir, "index.html"), "<!doctype html><html><body>ojm trial site</body></html>\n", "utf-8");
	// 只改 /cdn 的 web 指向（保留其 headers 缓存头，Q8 yank 120s 设计不能丢），
	// 再把最小 SPA 挂载作为 /cdn 的同级兄弟追加在 headers 块之后（前缀特异性匹配，顺序无关）。
	cfg = cfg.replace("web: ./cdn", `web: ${cdnDir}`);
	cfg = cfg.replace(
		"      Cache-Control: 'max-age=60, stale-while-revalidate=60'",
		`      Cache-Control: 'max-age=60, stale-while-revalidate=60'\n  - prefix: /\n    web: ${siteDir}\n    spa: true`,
	);
	// 安装目标恒为 release 部署：装好的模块落在 dist/api，dev 形态（--api-path src）发现不了。
	// 故隔离站点以 dist 起站，platform.root 同步改写（oj 校验 root 必须是生效的 api 挂载目录）。
	// root 相对 **config 所在目录** 解析——config 在隔离根，产物在 <root>/dist/api，故不能写死
	// `dist`（那是 config 还在 api/ 时的旧口径），按布局取值。
	const apiDistRel = path.relative(root, resolveLayout(root).apiDist).split(path.sep).join("/");
	cfg = cfg.replace("  root: src", `  root: ${apiDistRel}`);
	// auth 守卫在装配期读 anonymous_paths，安装器注册的新匿名端点要重启才生效（首次安装 smoke 会 401）。
	// 隔离站点直接预置被测方案的探活路径——与 scripts/verify-solution-smoke/bootstrap-host.mjs 同手法，
	// 让 trial 验的是安装机制本身，而不是重启时序。
	const healthPath = `/${parseFixtureSpec(opts.fixture).name}/ping`;
	// 锚点行可能带行内注释与缩进（模板 config.yaml 的 /system/login-methods 即如此），
	// 故用 lookahead 容忍尾注释；命中第一个 anonymous_paths 列表项（auth 守卫读取的那个，
	// 与安装器 appendAnonymousPaths 同目标）即可——旧写法用 `$` 硬锚尾，注释使其失配导致预置
	// 静默失效，安装器随后自己补匿名路径 → auth 进 restart_pending → 无守护形态判 partial。
	const loginAnchor = /^(\s*)- \/system\/login-methods(?=\s*(?:#.*)?$)/m;
	if (loginAnchor.test(cfg) && !cfg.includes(`- ${healthPath}`))
		cfg = cfg.replace(loginAnchor, `$1- /system/login-methods\n$1- ${healthPath}`);
	// fs 段：模板自 0.2.13 起已自带（安装器落盘面）；旧模板没有时才补，避免重复键
	if (!/^fs:/m.test(cfg))
		cfg = `${cfg.trimEnd()}\nfs:\n  root: .\n  readonly: false\n`;
	writeFileSync(configPath, cfg, "utf-8");

	// 4) 站点开发证书（oj serve 无绕过开关；mintDevCert 落 config.yaml 同级的 config/ 三件套）
	await mintDevCert(path.join(root, "config"));

	// 5) 一次性发布方身份：seed 派生，私钥只在内存
	const keyId = "trial.publisher";
	const publisher = derivePublisherKey(randomBytes(16).toString("hex"));

	// 6) 隔离 CDN：落 fixture 包字节（publish 内部通道）——目录行在 oj 起站迁移后 seed（步骤 7b）
	mkdirSync(cdnDir, { recursive: true });
	const published = await publishPackage({ projectRoot: root, fixture: opts.fixture, id: keyId, privateKeyPem: publisher.privateKeyPem, registryId: "trial.registry" });

	// 7) 后端构建（dist/api + versions.json；安装与 reloading 都依赖它）
	await buildBackend(root);

	// 7b) 起 oj（starter 注入供测试）；ready 失败即整体作废，不留孤儿
	const starter = opts.starter ?? ((cfgPath: string, base: string, apiSrc: string) => startOj(cfgPath, base, apiSrc));
	let oj: OjProcess;
	try {
		oj = starter(configPath, "/api", resolveLayout(root).apiDist);
		await oj.ready;
	}
	catch (error) {
		rmSync(root, { recursive: true, force: true });
		throw error;
	}
	// 7c) 目录行 seed（站点内部通道，v4 §五）：oj serve 起站已应用迁移——直写 market_release，
	// 安装解析/index 卡片/releases 的目录真源；不走上传签名面（试车夹具不该依赖被测面之外
	// 的签名/信任库/限速）。CLI 是本库唯一写者（隔离场景无并发）。
	seedMarketRelease(dbPath, { tgzPath: published.tgzPath });
	log(`[ojm] 隔离站点就绪：http://127.0.0.1:${port}（根 ${root}，目录行已 seed）`);

	// 8) cleanup：停进程 → 按 keep 决定删不删根 → 摘信号；全程幂等
	let done = false;
	let cleanup: () => Promise<void>;
	const onSignal = () => {
		void cleanup();
	};
	cleanup = async () => {
		if (done) {
			return;
		}
		done = true;
		process.off("SIGINT", onSignal);
		process.off("SIGTERM", onSignal);
		await oj.stop().catch(() => {});
		if (opts.keep === true) {
			log(`[ojm] --keep：隔离根保留在 ${root}（内容见销毁清单）`);
			return;
		}
		rmSync(root, { recursive: true, force: true });
		log("[ojm] 隔离站点已销毁");
	};
	process.on("SIGINT", onSignal);
	process.on("SIGTERM", onSignal);

	// 重启：停当前进程后按同一派生 config 重新起站（激活冻结段）；cleanup 持有的是本作用域的
	// `oj` 变量引用，故重启后 cleanup 停的是新进程（闭包捕获变量，非值）。
	const restart = async () => {
		log("[ojm] 隔离站点重启 oj serve（激活冻结段 auth/vars）…");
		await oj.stop();
		oj = starter(configPath, "/api", resolveLayout(root).apiDist);
		await oj.ready;
		log(`[ojm] 隔离站点重启就绪：http://127.0.0.1:${port}（根 ${root}）`);
	};

	return {
		root,
		port,
		baseUrl: `http://127.0.0.1:${port}`,
		apiBase: "/api",
		cdnDir,
		cdnBaseUrl: `http://127.0.0.1:${port}/cdn`,
		dbPath,
		publisher: { keyId, privateKeyPem: publisher.privateKeyPem, publicKeyHex: publisher.publicKeyHex, fingerprint: fingerprintOfPublicKey(publisher.publicKeyHex) },
		admin: { user: SEED_ADMIN_USER, pass: SEED_ADMIN_PASS },
		cleanup,
		teardownReport: () => teardownReport(root, port),
		restart,
	};
}

/**
 * seed 派生一次性 Ed25519 身份（照 fixtures/sig 夹具手法：公开 seed → SHA-256 → PKCS#8 DER）。
 * 私钥只在内存；label 每次随机，故每次 trial 都是不同身份（不会与任何既有信任库条目撞）。
 * 导出供 walkthrough 的 neg-stranger op 派生「未登记 key」（DRY：不重写派生手法）。
 */
export function derivePublisherKey(label: string): { privateKeyPem: string, publicKeyHex: string } {
	const seed = createHash("sha256").update(`ojm-trial-publisher:${label}`).digest();
	const der = Buffer.concat([Buffer.from(ED25519_PKCS8_PREFIX, "hex"), seed]);
	const key = createPrivateKey({ key: der, format: "der", type: "pkcs8" });
	const privateKeyPem = key.export({ type: "pkcs8", format: "pem" }).toString();
	return { privateKeyPem, publicKeyHex: exportRawPublicKeyHex(privateKeyPem) };
}
/** 空闲端口：listen(0) 取端口后立刻归还（本地一次性使用，竞态可接受） */
function freePort(): Promise<number> {
	return new Promise((resolve, reject) => {
		const server = net.createServer();
		server.once("error", reject);
		server.listen(0, "127.0.0.1", () => {
			const address = server.address();
			const port = typeof address === "object" && address !== null ? address.port : 0;
			server.close(() => resolve(port));
		});
	});
}

/** 销毁清单：--keep 时告诉人这里到底有什么、怎么手动清 */
function teardownReport(root: string, port: number): string[] {
	const lines = [
		`隔离根：${root}`,
		"  config.yaml + config/ 证书 + db.sqlite   站点配置面",
		"  src/    后端模块源码树（src/<name>/api，拷自 cli 内置模板）",
		"  dist/api/  构建产物（安装目标）",
		"  bin/    oj 二进制与插件（拷贝自源工程）",
		"  cdn/    隔离 CDN（fixture 包 + .sig 旁车）",
		"  db.sqlite  含 market_release 目录行（seed 直写）",
		`监听端口：127.0.0.1:${port}（进程已停）`,
		`手动清理：rm -rf ${root}`,
	];
	return lines;
}
