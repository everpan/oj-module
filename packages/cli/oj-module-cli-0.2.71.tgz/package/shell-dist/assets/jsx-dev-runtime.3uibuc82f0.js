var __create=Object.create;var __defProp=Object.defineProperty;var __getOwnPropDesc=Object.getOwnPropertyDescriptor;var __getOwnPropNames=Object.getOwnPropertyNames;var __getProtoOf=Object.getPrototypeOf,__hasOwnProp=Object.prototype.hasOwnProperty;var __commonJS=(cb,mod)=>function(){try{return mod||(0,cb[__getOwnPropNames(cb)[0]])((mod={exports:{}}).exports,mod),mod.exports}catch(e){throw mod=0,e}};var __copyProps=(to,from,except,desc)=>{if(from&&typeof from=="object"||typeof from=="function")for(let key of __getOwnPropNames(from))!__hasOwnProp.call(to,key)&&key!==except&&__defProp(to,key,{get:()=>from[key],enumerable:!(desc=__getOwnPropDesc(from,key))||desc.enumerable});return to};var __toESM=(mod,isNodeMode,target)=>(target=mod!=null?__create(__getProtoOf(mod)):{},__copyProps(isNodeMode||!mod||!mod.__esModule?__defProp(target,"default",{value:mod,enumerable:!0}):target,mod));var require_react_jsx_dev_runtime_production=__commonJS({"../../node_modules/.pnpm/react@19.2.8/node_modules/react/cjs/react-jsx-dev-runtime.production.js"(exports){"use strict";var REACT_FRAGMENT_TYPE=Symbol.for("react.fragment");exports.Fragment=REACT_FRAGMENT_TYPE;exports.jsxDEV=void 0}});var require_jsx_dev_runtime=__commonJS({"../../node_modules/.pnpm/react@19.2.8/node_modules/react/jsx-dev-runtime.js"(exports,module){"use strict";module.exports=require_react_jsx_dev_runtime_production()}});var __m=__toESM(require_jsx_dev_runtime(),1),Fragment2=__m.Fragment,jsxDEV2=__m.jsxDEV,ojm_shim_jsx_dev_runtime_default=__m.default??__m;export{Fragment2 as Fragment,ojm_shim_jsx_dev_runtime_default as default,jsxDEV2 as jsxDEV};
/*! Bundled license information:

react/cjs/react-jsx-dev-runtime.production.js:
  (**
   * @license React
   * react-jsx-dev-runtime.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)
*/
