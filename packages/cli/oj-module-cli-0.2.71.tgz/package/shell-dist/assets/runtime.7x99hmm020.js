/* data-ojm-runtime-css: 产物自携带样式（偏差 3 修复），由 scripts/inline-css.mjs 注入 */
if (typeof document !== "undefined" && !document.querySelector("style[data-ojm-runtime-css]")) {
	const s = document.createElement("style");
	s.setAttribute("data-ojm-runtime-css", "");
	s.textContent = "@layer properties{@supports (((-webkit-hyphens:none)) and (not (margin-trim:inline))) or ((-moz-orient:inline) and (not (color:rgb(from red r g b)))){*,:before,:after,::backdrop{--tw-blur:initial;--tw-brightness:initial;--tw-contrast:initial;--tw-grayscale:initial;--tw-hue-rotate:initial;--tw-invert:initial;--tw-opacity:initial;--tw-saturate:initial;--tw-sepia:initial;--tw-drop-shadow:initial;--tw-drop-shadow-color:initial;--tw-drop-shadow-alpha:100%;--tw-drop-shadow-size:initial;--tw-translate-x:0;--tw-translate-y:0;--tw-translate-z:0;--tw-scale-x:1;--tw-scale-y:1;--tw-scale-z:1;--tw-rotate-x:initial;--tw-rotate-y:initial;--tw-rotate-z:initial;--tw-skew-x:initial;--tw-skew-y:initial;--tw-border-style:solid;--tw-leading:initial;--tw-font-weight:initial;--tw-tracking:initial;--tw-outline-style:solid;--tw-duration:initial;--tw-ease:initial;--tw-content:\"\"}}}@layer reset{html,body{width:100%;height:100%}input::-ms-clear{display:none}input::-ms-reveal{display:none}*,:before,:after{box-sizing:border-box}html{-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-ms-overflow-style:scrollbar;-webkit-tap-highlight-color:#0000;font-family:sans-serif;line-height:1.15}body{margin:0}[tabindex=\"-1\"]:focus{outline:none}hr{box-sizing:content-box;height:0;overflow:visible}h1,h2,h3,h4,h5,h6{margin-top:0;margin-bottom:.5em;font-weight:500}p{margin-top:0;margin-bottom:1em}abbr[title],abbr[data-original-title]{cursor:help;border-bottom:0;-webkit-text-decoration:underline dotted;text-decoration:underline dotted}address{font-style:normal;line-height:inherit;margin-bottom:1em}input[type=text],input[type=password],input[type=number],textarea{-webkit-appearance:none}ol,ul,dl{margin-top:0;margin-bottom:1em}ol ol,ul ul,ol ul,ul ol{margin-bottom:0}dt{font-weight:500}dd{margin-bottom:.5em;margin-left:0}blockquote{margin:0 0 1em}dfn{font-style:italic}b,strong{font-weight:bolder}small{font-size:80%}sub,sup{vertical-align:baseline;font-size:75%;line-height:0;position:relative}sub{bottom:-.25em}sup{top:-.5em}pre,code,kbd,samp{font-family:SFMono-Regular,Consolas,Liberation Mono,Menlo,Courier,monospace;font-size:1em}pre{margin-top:0;margin-bottom:1em;overflow:auto}figure{margin:0 0 1em}img{vertical-align:middle;border-style:none}a,area,button,[role=button],input:not([type=range]),label,select,summary,textarea{touch-action:manipulation}table{border-collapse:collapse}caption{text-align:left;caption-side:bottom;padding-top:.75em;padding-bottom:.3em}input,button,select,optgroup,textarea{color:inherit;font-size:inherit;font-family:inherit;line-height:inherit;margin:0}button,input{overflow:visible}button,select{text-transform:none}button,html [type=button],[type=reset],[type=submit]{-webkit-appearance:button}button::-moz-focus-inner{border-style:none;padding:0}[type=button]::-moz-focus-inner{border-style:none;padding:0}[type=reset]::-moz-focus-inner{border-style:none;padding:0}[type=submit]::-moz-focus-inner{border-style:none;padding:0}input[type=radio],input[type=checkbox]{box-sizing:border-box;padding:0}input[type=date],input[type=time],input[type=datetime-local],input[type=month]{-webkit-appearance:listbox}textarea{resize:vertical;overflow:auto}fieldset{border:0;min-width:0;margin:0;padding:0}legend{width:100%;max-width:100%;color:inherit;font-size:1.5em;line-height:inherit;white-space:normal;margin-bottom:.5em;padding:0;display:block}progress{vertical-align:baseline}[type=number]::-webkit-inner-spin-button{height:auto}[type=number]::-webkit-outer-spin-button{height:auto}[type=search]{outline-offset:-2px;-webkit-appearance:none}[type=search]::-webkit-search-cancel-button{-webkit-appearance:none}[type=search]::-webkit-search-decoration{-webkit-appearance:none}::-webkit-file-upload-button{font:inherit;-webkit-appearance:button}output{display:inline-block}summary{display:list-item}template{display:none}[hidden]{display:none!important}}@layer antd;@layer simplebar{[data-simplebar]{flex-flow:column wrap;place-content:flex-start;align-items:flex-start;position:relative}.simplebar-wrapper{width:inherit;height:inherit;max-width:inherit;max-height:inherit;overflow:hidden}.simplebar-mask{direction:inherit;z-index:0;margin:0;padding:0;position:absolute;inset:0;overflow:hidden;width:auto!important;height:auto!important}.simplebar-offset{-webkit-overflow-scrolling:touch;margin:0;padding:0;position:absolute;inset:0;direction:inherit!important;box-sizing:inherit!important;resize:none!important}.simplebar-content-wrapper{direction:inherit;scrollbar-width:none;-ms-overflow-style:none;width:auto;max-width:100%;height:100%;max-height:100%;display:block;position:relative;overflow:auto;box-sizing:border-box!important}.simplebar-content-wrapper::-webkit-scrollbar{width:0;height:0;display:none}.simplebar-hide-scrollbar::-webkit-scrollbar{width:0;height:0;display:none}.simplebar-content:after,.simplebar-content:before{content:\" \";display:table}.simplebar-placeholder{pointer-events:none;width:100%;max-width:100%;max-height:100%}.simplebar-height-auto-observer-wrapper{float:left;z-index:-1;pointer-events:none;flex-grow:inherit;flex-shrink:0;flex-basis:0;width:100%;max-width:1px;height:100%;max-height:1px;margin:0;padding:0;position:relative;overflow:hidden;box-sizing:inherit!important}.simplebar-height-auto-observer{box-sizing:inherit;opacity:0;pointer-events:none;z-index:-1;width:1000%;min-width:1px;height:1000%;min-height:1px;display:block;position:absolute;top:0;left:0;overflow:hidden}.simplebar-track{z-index:1;pointer-events:none;position:absolute;bottom:0;right:0;overflow:hidden}[data-simplebar].simplebar-dragging,[data-simplebar].simplebar-dragging .simplebar-content{pointer-events:none;-webkit-touch-callout:none;-webkit-user-select:none;user-select:none;-khtml-user-select:none}[data-simplebar].simplebar-dragging .simplebar-track{pointer-events:all}.simplebar-scrollbar{min-height:10px;position:absolute;left:0;right:0}.simplebar-scrollbar:before{content:\"\";opacity:0;background:#000;border-radius:7px;transition:opacity .2s linear .5s;position:absolute;left:2px;right:2px}.simplebar-scrollbar.simplebar-visible:before{opacity:.5;transition-duration:0s;transition-delay:0s}.simplebar-track.simplebar-vertical{width:11px;top:0}.simplebar-scrollbar:before{inset:2px}.simplebar-track.simplebar-horizontal{height:11px;left:0}.simplebar-track.simplebar-horizontal .simplebar-scrollbar{width:auto;min-width:10px;min-height:0;inset:0 auto 0 0}[data-simplebar-direction=rtl] .simplebar-track.simplebar-vertical{left:0;right:auto}.simplebar-dummy-scrollbar-size{opacity:0;visibility:hidden;direction:rtl;width:500px;height:500px;position:fixed;overflow:scroll hidden;-ms-overflow-style:scrollbar!important}.simplebar-dummy-scrollbar-size>div{width:200%;height:200%;margin:10px 0}.simplebar-hide-scrollbar{visibility:hidden;scrollbar-width:none;-ms-overflow-style:none;position:fixed;left:0;overflow-y:scroll}.simplebar-scrollbar:before{background-color:#909399}.simplebar-content{height:100%}}#root{height:100vh}img{max-width:100%;height:auto}html.color-blind-mode{--tw-invert:invert(100%);filter:var(--tw-blur,) var(--tw-brightness,) var(--tw-contrast,) var(--tw-grayscale,) var(--tw-hue-rotate,) var(--tw-invert,) var(--tw-saturate,) var(--tw-sepia,) var(--tw-drop-shadow,)}html.gray-mode{--tw-grayscale:grayscale(100%);filter:var(--tw-blur,) var(--tw-brightness,) var(--tw-contrast,) var(--tw-grayscale,) var(--tw-hue-rotate,) var(--tw-invert,) var(--tw-saturate,) var(--tw-sepia,) var(--tw-drop-shadow,)}@layer theme{:root,:host{--font-sans:-apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", \"Noto Sans\", Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\";--spacing:.25rem;--container-md:28rem;--text-xs:.75rem;--text-xs--line-height:calc(1 / .75);--text-sm:.875rem;--text-sm--line-height:calc(1.25 / .875);--text-lg:1.125rem;--text-lg--line-height:calc(1.75 / 1.125);--text-xl:1.25rem;--text-xl--line-height:calc(1.75 / 1.25);--text-2xl:1.5rem;--text-2xl--line-height:calc(2 / 1.5);--text-3xl:1.875rem;--text-3xl--line-height:calc(2.25 / 1.875);--font-weight-medium:500;--font-weight-semibold:600;--font-weight-bold:700;--tracking-tight:-.025em;--radius-sm:.25rem;--radius-md:.375rem;--radius-xl:.75rem;--ease-in:cubic-bezier(.4, 0, 1, 1);--animate-spin:spin 1s linear infinite;--default-transition-duration:.15s;--default-transition-timing-function:cubic-bezier(.4, 0, .2, 1);--animate-wiggle:wiggle 1s both;--animate-bounce-in-down-out-up:bounce-in-down-out-up 4s ease-in-out 0s infinite}}@layer base,components;@layer utilities{.visible{visibility:visible}.absolute{position:absolute}.fixed{position:fixed}.relative{position:relative}.static{position:static}.top-0{top:0}.top-1\\.5{top:calc(var(--spacing) * 1.5)}.top-2{top:calc(var(--spacing) * 2)}.top-3{top:calc(var(--spacing) * 3)}.right-2{right:calc(var(--spacing) * 2)}.right-3{right:calc(var(--spacing) * 3)}.right-4{right:calc(var(--spacing) * 4)}.bottom-0{bottom:0}.bottom-3{bottom:calc(var(--spacing) * 3)}.left-0{left:0}.left-1\\/2{left:50%}.left-3{left:calc(var(--spacing) * 3)}.z-10{z-index:10}.container{width:100%}@media (width>=480px){.container{max-width:480px}}@media (width>=576px){.container{max-width:576px}}@media (width>=768px){.container{max-width:768px}}@media (width>=992px){.container{max-width:992px}}@media (width>=1200px){.container{max-width:1200px}}@media (width>=1600px){.container{max-width:1600px}}.m-0{margin:0}.m-152{margin:calc(var(--spacing) * 152)}.mx-3{margin-inline:calc(var(--spacing) * 3)}.mx-4{margin-inline:calc(var(--spacing) * 4)}.mx-auto{margin-inline:auto}.my-0{margin-block:0}.my-1{margin-block:var(--spacing)}.my-4{margin-block:calc(var(--spacing) * 4)}.my-8{margin-block:calc(var(--spacing) * 8)}.mt-2{margin-top:calc(var(--spacing) * 2)}.mt-2\\.5{margin-top:calc(var(--spacing) * 2.5)}.mt-4{margin-top:calc(var(--spacing) * 4)}.mt-6{margin-top:calc(var(--spacing) * 6)}.mr-2{margin-right:calc(var(--spacing) * 2)}.mr-3{margin-right:calc(var(--spacing) * 3)}.mr-8{margin-right:calc(var(--spacing) * 8)}.mr-17{margin-right:calc(var(--spacing) * 17)}.mb-0{margin-bottom:0}.mb-2{margin-bottom:calc(var(--spacing) * 2)}.mb-3{margin-bottom:calc(var(--spacing) * 3)}.mb-6{margin-bottom:calc(var(--spacing) * 6)}.ml-1{margin-left:var(--spacing)}.ml-2{margin-left:calc(var(--spacing) * 2)}.ml-4{margin-left:calc(var(--spacing) * 4)}.box-border{box-sizing:border-box}.line-clamp-2{-webkit-line-clamp:2;-webkit-box-orient:vertical;display:-webkit-box;overflow:hidden}.block{display:block}.flex{display:flex}.hidden{display:none}.inline{display:inline}.inline-block{display:inline-block}.table{display:table}.aspect-square{aspect-ratio:1}.size-5{width:calc(var(--spacing) * 5);height:calc(var(--spacing) * 5)}.h-2{height:calc(var(--spacing) * 2)}.h-5{height:calc(var(--spacing) * 5)}.h-10{height:calc(var(--spacing) * 10)}.h-64{height:calc(var(--spacing) * 64)}.h-\\[0\\.63em\\]{height:.63em}.h-full{height:100%}.h-screen{height:100vh}.min-h-0{min-height:0}.min-h-10{min-height:calc(var(--spacing) * 10)}.w-1\\/3{width:33.3333%}.w-2{width:calc(var(--spacing) * 2)}.w-2\\/5{width:40%}.w-7\\/12{width:58.3333%}.w-10{width:calc(var(--spacing) * 10)}.w-11{width:calc(var(--spacing) * 11)}.w-12{width:calc(var(--spacing) * 12)}.w-40{width:calc(var(--spacing) * 40)}.w-72{width:calc(var(--spacing) * 72)}.w-full{width:100%}.max-w-90{max-width:calc(var(--spacing) * 90)}.min-w-0{min-width:0}.flex-1{flex:1}.flex-auto{flex:auto}.flex-shrink-0,.shrink-0{flex-shrink:0}.grow{flex-grow:1}.-translate-x-1\\/2{--tw-translate-x:calc(calc(1 / 2 * 100%) * -1);translate:var(--tw-translate-x) var(--tw-translate-y)}.scale-75{--tw-scale-x:75%;--tw-scale-y:75%;--tw-scale-z:75%;scale:var(--tw-scale-x) var(--tw-scale-y)}.transform{transform:var(--tw-rotate-x,) var(--tw-rotate-y,) var(--tw-rotate-z,) var(--tw-skew-x,) var(--tw-skew-y,)}.animate-spin{animation:var(--animate-spin)}.cursor-help{cursor:help}.cursor-pointer{cursor:pointer}.list-none{list-style-type:none}.flex-col{flex-direction:column}.flex-row-reverse{flex-direction:row-reverse}.flex-wrap{flex-wrap:wrap}.items-center{align-items:center}.justify-between{justify-content:space-between}.justify-center{justify-content:center}.justify-start{justify-content:flex-start}.gap-1{gap:var(--spacing)}.gap-2{gap:calc(var(--spacing) * 2)}.gap-3{gap:calc(var(--spacing) * 3)}.gap-5{gap:calc(var(--spacing) * 5)}.gap-x-3{column-gap:calc(var(--spacing) * 3)}.gap-y-5{row-gap:calc(var(--spacing) * 5)}.overflow-hidden{overflow:hidden}.overflow-x-auto{overflow-x:auto}.overflow-x-hidden{overflow-x:hidden}.overflow-y-auto{overflow-y:auto}.rounded{border-radius:.25rem}.rounded-full{border-radius:2147483647px}.rounded-md{border-radius:var(--radius-md)}.rounded-none{border-radius:0}.rounded-sm{border-radius:var(--radius-sm)}.rounded-r-xl{border-top-right-radius:var(--radius-xl);border-bottom-right-radius:var(--radius-xl)}.border{border-style:var(--tw-border-style);border-width:1px}.border-t{border-top-style:var(--tw-border-style);border-top-width:1px}.border-r{border-right-style:var(--tw-border-style);border-right-width:1px}.border-l{border-left-style:var(--tw-border-style);border-left-width:1px}.\\!border-none{--tw-border-style:none!important;border-style:none!important}.border-t-\\[\\#303030\\]{border-top-color:#303030}.border-t-colorBorderSecondary{border-top-color:var(--oo-colorBorderSecondary)}.border-r-\\[\\#303030\\]{border-right-color:#303030}.border-r-colorBorderSecondary{border-right-color:var(--oo-colorBorderSecondary)}.border-l-colorBorderSecondary{border-left-color:var(--oo-colorBorderSecondary)}.bg-\\[\\#F3F4F5\\]{background-color:#f3f4f5}.bg-blue-500\\/20{background-color:rgb(var(--oo-blue-5))}@supports (color:color-mix(in lab, red, red)){.bg-blue-500\\/20{background-color:color-mix(in oklab, rgb(var(--oo-blue-5)) 20%, transparent)}}.bg-blue-600{background-color:rgb(var(--oo-blue-6))}.bg-colorBgContainer{background-color:var(--oo-colorBgContainer)}.bg-colorBgLayout{background-color:var(--oo-colorBgLayout)}.bg-gray-100{background-color:#f5f5f5}.bg-gray-200{background-color:#f0f0f0}.bg-primary{background-color:rgb(var(--oo-colorPrimary))}.bg-primaryActive{background-color:rgb(var(--oo-colorPrimaryActive))}.object-cover{object-fit:cover}.p-0{padding:0}.p-1{padding:var(--spacing)}.p-2{padding:calc(var(--spacing) * 2)}.p-4{padding:calc(var(--spacing) * 4)}.px-0{padding-inline:0}.px-1{padding-inline:var(--spacing)}.px-1\\.5{padding-inline:calc(var(--spacing) * 1.5)}.px-2{padding-inline:calc(var(--spacing) * 2)}.px-2\\.75{padding-inline:calc(var(--spacing) * 2.75)}.px-3{padding-inline:calc(var(--spacing) * 3)}.px-4{padding-inline:calc(var(--spacing) * 4)}.px-6{padding-inline:calc(var(--spacing) * 6)}.px-9{padding-inline:calc(var(--spacing) * 9)}.px-10{padding-inline:calc(var(--spacing) * 10)}.px-\\[11px\\]{padding-inline:11px}.py-1{padding-block:var(--spacing)}.py-1\\.5{padding-block:calc(var(--spacing) * 1.5)}.py-2{padding-block:calc(var(--spacing) * 2)}.py-2\\.5{padding-block:calc(var(--spacing) * 2.5)}.py-4{padding-block:calc(var(--spacing) * 4)}.py-10{padding-block:calc(var(--spacing) * 10)}.pb-4{padding-bottom:calc(var(--spacing) * 4)}.pl-2{padding-left:calc(var(--spacing) * 2)}.text-center{text-align:center}.font-sans{font-family:var(--font-sans)}.text-3xl{font-size:var(--text-3xl);line-height:var(--tw-leading,var(--text-3xl--line-height))}.text-lg{font-size:var(--text-lg);line-height:var(--tw-leading,var(--text-lg--line-height))}.text-sm{font-size:var(--text-sm);line-height:var(--tw-leading,var(--text-sm--line-height))}.text-xl{font-size:var(--text-xl);line-height:var(--tw-leading,var(--text-xl--line-height))}.text-xs{font-size:var(--text-xs);line-height:var(--tw-leading,var(--text-xs--line-height))}.text-\\[4rem\\]{font-size:4rem}.leading-none{--tw-leading:1;line-height:1}.font-bold{--tw-font-weight:var(--font-weight-bold);font-weight:var(--font-weight-bold)}.font-medium{--tw-font-weight:var(--font-weight-medium);font-weight:var(--font-weight-medium)}.font-semibold{--tw-font-weight:var(--font-weight-semibold);font-weight:var(--font-weight-semibold)}.tracking-tight{--tw-tracking:var(--tracking-tight);letter-spacing:var(--tracking-tight)}.text-colorBgContainer{color:var(--oo-colorBgContainer)}.text-colorBgContainer\\!{color:var(--oo-colorBgContainer)!important}.text-colorText{color:var(--oo-colorText)}.text-colorText\\!{color:var(--oo-colorText)!important}.text-colorTextSecondary{color:var(--oo-colorTextSecondary)}.text-colorTextTertiary{color:var(--oo-colorTextTertiary)}.text-gray-500{color:#8c8c8c}.opacity-50{opacity:.5}.opacity-90{opacity:.9}.outline,.outline-1{outline-style:var(--tw-outline-style);outline-width:1px}.outline-2{outline-style:var(--tw-outline-style);outline-width:2px}.outline-blue-600{outline-color:rgb(var(--oo-blue-6))}.outline-gray-300{outline-color:#d9d9d9}.filter{filter:var(--tw-blur,) var(--tw-brightness,) var(--tw-contrast,) var(--tw-grayscale,) var(--tw-hue-rotate,) var(--tw-invert,) var(--tw-saturate,) var(--tw-sepia,) var(--tw-drop-shadow,)}.transition{transition-property:color,background-color,border-color,outline-color,text-decoration-color,fill,stroke,--tw-gradient-from,--tw-gradient-via,--tw-gradient-to,opacity,box-shadow,transform,translate,scale,rotate,filter,-webkit-backdrop-filter,backdrop-filter,display,content-visibility,overlay,pointer-events;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.transition-all{transition-property:all;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.duration-300{--tw-duration:.3s;transition-duration:.3s}.ease-in{--tw-ease:var(--ease-in);transition-timing-function:var(--ease-in)}@media (hover:hover){.group-hover\\:animate-wiggle:is(:where(.group):hover *){animation:var(--animate-wiggle)}.group-hover\\:opacity-100:is(:where(.group):hover *){opacity:1}}.before\\:absolute:before{content:var(--tw-content);position:absolute}.before\\:top-1\\/2:before{content:var(--tw-content);top:50%}.before\\:left-1\\/2:before{content:var(--tw-content);left:50%}.before\\:h-0:before{content:var(--tw-content);height:0}.before\\:w-0:before{content:var(--tw-content);width:0}.before\\:rounded-sm:before{content:var(--tw-content);border-radius:var(--radius-sm)}.before\\:opacity-0:before{content:var(--tw-content);opacity:0}.before\\:outline:before{content:var(--tw-content);outline-style:var(--tw-outline-style);outline-width:1px}.before\\:outline-2:before{content:var(--tw-content);outline-style:var(--tw-outline-style);outline-width:2px}.before\\:outline-transparent:before{content:var(--tw-content);outline-color:#0000}.before\\:transition-all:before{content:var(--tw-content);transition-property:all;transition-timing-function:var(--tw-ease,var(--default-transition-timing-function));transition-duration:var(--tw-duration,var(--default-transition-duration))}.before\\:duration-300:before{content:var(--tw-content);--tw-duration:.3s;transition-duration:.3s}.before\\:content-\\[\\'\\'\\]:before{--tw-content:\"\";content:var(--tw-content)}.last\\:mr-auto:last-child{margin-right:auto}@media (hover:hover){.hover\\:bg-gray-100:hover{background-color:#f5f5f5}.hover\\:text-colorText:hover{color:var(--oo-colorText)}}.before\\:hover\\:top-0:before{content:var(--tw-content)}@media (hover:hover){.before\\:hover\\:top-0:before:hover{top:0}}.before\\:hover\\:left-0:before{content:var(--tw-content)}@media (hover:hover){.before\\:hover\\:left-0:before:hover{left:0}}.before\\:hover\\:h-full:before{content:var(--tw-content)}@media (hover:hover){.before\\:hover\\:h-full:before:hover{height:100%}}.before\\:hover\\:w-full:before{content:var(--tw-content)}@media (hover:hover){.before\\:hover\\:w-full:before:hover{width:100%}}.before\\:hover\\:p-1:before{content:var(--tw-content)}@media (hover:hover){.before\\:hover\\:p-1:before:hover{padding:var(--spacing)}}.before\\:hover\\:opacity-100:before{content:var(--tw-content)}@media (hover:hover){.before\\:hover\\:opacity-100:before:hover{opacity:1}}.before\\:hover\\:outline-blue-600:before{content:var(--tw-content)}@media (hover:hover){.before\\:hover\\:outline-blue-600:before:hover{outline-color:rgb(var(--oo-blue-6))}}@media (prefers-reduced-motion:no-preference){.motion-safe\\:animate-bounce-in-down-out-up{animation:var(--animate-bounce-in-down-out-up)}}@media (width>=576px){.sm\\:mx-auto{margin-inline:auto}}@media (width>=768px){.md\\:mr-2\\.5{margin-right:calc(var(--spacing) * 2.5)}.md\\:block{display:block}.md\\:w-3\\/12{width:25%}.md\\:w-96{width:calc(var(--spacing) * 96)}.md\\:max-w-md{max-width:var(--container-md)}.md\\:bg-colorBgLayout{background-color:var(--oo-colorBgLayout)}.md\\:px-4{padding-inline:calc(var(--spacing) * 4)}.md\\:pb-0{padding-bottom:0}.md\\:text-sm{font-size:var(--text-sm);line-height:var(--tw-leading,var(--text-sm--line-height))}}@media (width>=992px){.lg\\:text-2xl{font-size:var(--text-2xl);line-height:var(--tw-leading,var(--text-2xl--line-height))}}@media (width>=1200px){.xl\\:w-2\\/12{width:16.6667%}.xl\\:px-8{padding-inline:calc(var(--spacing) * 8)}}.dark\\:bg-\\[\\#26313C\\]:where(.dark,.dark *){background-color:#26313c}.dark\\:bg-black:where(.dark,.dark *){background-color:#000}.dark\\:bg-gray-700:where(.dark,.dark *){background-color:#434343}.dark\\:outline-blue-700:where(.dark,.dark *){outline-color:rgb(var(--oo-blue-7))}.dark\\:outline-gray-700:where(.dark,.dark *){outline-color:#434343}@media (hover:hover){.dark\\:hover\\:bg-gray-700:where(.dark,.dark *):hover{background-color:#434343}}.dark\\:before\\:hover\\:outline-blue-700:where(.dark,.dark *):before{content:var(--tw-content)}@media (hover:hover){.dark\\:before\\:hover\\:outline-blue-700:where(.dark,.dark *):before:hover{outline-color:rgb(var(--oo-blue-7))}}.en-US\\:gap-y-3:where(:lang(en-US)){row-gap:calc(var(--spacing) * 3)}.en-US\\:text-\\[9rem\\]:where(:lang(en-US)){font-size:9rem}.zh-CN\\:hidden:where(:lang(zh-CN)){display:none}}@keyframes fade-in{0%{opacity:0}to{opacity:1}}@keyframes fade-out{0%{opacity:1}to{opacity:0}}@keyframes slide-in{0%{transform:translate(-30px)}to{transform:translate(0)}}@keyframes slide-out{0%{transform:translate(0)}to{transform:translate(30px)}}@keyframes slide-top-in{0%{transform:translateY(-10%)}to{transform:translateY(0)}}@keyframes slide-top-out{0%{transform:translateY(0)}to{transform:translateY(-10%)}}@keyframes slide-bottom-in{0%{transform:translateY(10%)}to{transform:translateY(0)}}@keyframes slide-bottom-out{0%{transform:translateY(0)}to{transform:translateY(10%)}}@keyframes fade-slide{0%{opacity:0;transform:translate(-30px)}50%{opacity:1}to{opacity:0;transform:translate(30px)}}@keyframes fade-up{0%{opacity:0;transform:translateY(10%)}50%{opacity:1}to{opacity:0;transform:translateY(-10%)}}@keyframes fade-down{0%{opacity:0;transform:translateY(-10%)}50%{opacity:1}to{opacity:0;transform:translateY(10%)}}.fade-slide{animation:3s linear infinite fade-slide}.fade{animation:3s linear infinite alternate fade-in}.fade-up{animation:3s infinite fade-up}.fade-down{animation:3s infinite fade-down}@keyframes zoom-in{0%{transform:scale(.8)}to{opacity:1;transform:scale(1)}}@keyframes zoom-out{0%{transform:scale(1)}to{opacity:1;transform:scale(1.25)}}@keyframes fade-zoom{0%{opacity:0;transform:scale(.8)}50%{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(1.25)}}.fade-zoom{animation:3s infinite fade-zoom}.keepalive-fade.active{animation:.3s ease-in-out fade-in}.keepalive-fade.inactive{animation:.3s ease-in-out fade-out}.keepalive-fade-slide.active{animation:.3s ease-in-out fade-in,.3s ease-in-out slide-in}.keepalive-fade-slide.inactive{animation:.3s ease-in-out fade-out,.3s ease-in-out slide-out}.keepalive-fade-up.active{animation:.3s ease-in-out fade-in,.3s ease-in-out slide-bottom-in}.keepalive-fade-up.inactive{animation:.3s ease-in-out fade-out,.3s ease-in-out slide-top-out}.keepalive-fade-down.active{animation:.3s ease-in-out fade-in,.3s ease-in-out slide-top-in}.keepalive-fade-down.inactive{animation:.3s ease-in-out fade-out,.3s ease-in-out slide-bottom-out}.keepalive-fade-zoom.active{animation:.3s ease-in-out zoom-in,.3s ease-in-out zoom-in}.keepalive-fade-zoom.inactive{animation:.3s ease-in-out zoom-out,.3s ease-in-out fade-out}@property --tw-blur{syntax:\"*\";inherits:false}@property --tw-brightness{syntax:\"*\";inherits:false}@property --tw-contrast{syntax:\"*\";inherits:false}@property --tw-grayscale{syntax:\"*\";inherits:false}@property --tw-hue-rotate{syntax:\"*\";inherits:false}@property --tw-invert{syntax:\"*\";inherits:false}@property --tw-opacity{syntax:\"*\";inherits:false}@property --tw-saturate{syntax:\"*\";inherits:false}@property --tw-sepia{syntax:\"*\";inherits:false}@property --tw-drop-shadow{syntax:\"*\";inherits:false}@property --tw-drop-shadow-color{syntax:\"*\";inherits:false}@property --tw-drop-shadow-alpha{syntax:\"<percentage>\";inherits:false;initial-value:100%}@property --tw-drop-shadow-size{syntax:\"*\";inherits:false}@property --tw-translate-x{syntax:\"*\";inherits:false;initial-value:0}@property --tw-translate-y{syntax:\"*\";inherits:false;initial-value:0}@property --tw-translate-z{syntax:\"*\";inherits:false;initial-value:0}@property --tw-scale-x{syntax:\"*\";inherits:false;initial-value:1}@property --tw-scale-y{syntax:\"*\";inherits:false;initial-value:1}@property --tw-scale-z{syntax:\"*\";inherits:false;initial-value:1}@property --tw-rotate-x{syntax:\"*\";inherits:false}@property --tw-rotate-y{syntax:\"*\";inherits:false}@property --tw-rotate-z{syntax:\"*\";inherits:false}@property --tw-skew-x{syntax:\"*\";inherits:false}@property --tw-skew-y{syntax:\"*\";inherits:false}@property --tw-border-style{syntax:\"*\";inherits:false;initial-value:solid}@property --tw-leading{syntax:\"*\";inherits:false}@property --tw-font-weight{syntax:\"*\";inherits:false}@property --tw-tracking{syntax:\"*\";inherits:false}@property --tw-outline-style{syntax:\"*\";inherits:false;initial-value:solid}@property --tw-duration{syntax:\"*\";inherits:false}@property --tw-ease{syntax:\"*\";inherits:false}@property --tw-content{syntax:\"*\";inherits:false;initial-value:\"\"}@keyframes spin{to{transform:rotate(360deg)}}@keyframes wiggle{0%,to{transform-origin:top}15%{transform:rotate(10deg)}30%{transform:rotate(-10deg)}45%{transform:rotate(5deg)}60%{transform:rotate(-5deg)}75%{transform:rotate(2deg)}}@keyframes bounce-in-down-out-up{0%{transform:translateY(0)}50%{transform:translateY(-20px)}to{transform:translateY(0)}}\n/*$vite$:1*/";
	document.head.appendChild(s);
}
import e from "ky";
import { create as t } from "zustand";
import { persist as n } from "zustand/middleware";
import { Link as r, Navigate as i, Outlet as a, createBrowserRouter as o, matchRoutes as s, useLocation as c, useMatches as l, useNavigate as u, useOutlet as d, useSearchParams as f } from "react-router";
import { ErrorBoundary as p, ErrorBoundary as m } from "react-error-boundary";
import { AntDesignOutlined as h, ApartmentOutlined as g, AppstoreOutlined as ee, ArrowDownOutlined as te, ArrowLeftOutlined as ne, ArrowUpOutlined as re, BellOutlined as ie, CloseOutlined as ae, CloudOutlined as oe, ContainerOutlined as se, CopyOutlined as ce, CopyrightOutlined as le, DownOutlined as ue, EnterOutlined as de, ExclamationCircleFilled as fe, EyeOutlined as pe, FileTextOutlined as me, FullscreenExitOutlined as he, FullscreenOutlined as ge, HomeOutlined as _e, LoadingOutlined as ve, LockOutlined as ye, LogoutOutlined as be, MenuFoldOutlined as xe, MenuOutlined as Se, MenuUnfoldOutlined as Ce, NodeExpandOutlined as we, QuestionCircleOutlined as Te, RedoOutlined as Ee, ReloadOutlined as De, RocketOutlined as Oe, SafetyOutlined as ke, SearchOutlined as Ae, SettingOutlined as je, SisternodeOutlined as Me, SubnodeOutlined as Ne, SwapOutlined as Pe, TeamOutlined as Fe, TranslationOutlined as Ie, UploadOutlined as Le, UserOutlined as Re, VerticalAlignBottomOutlined as ze, VerticalAlignMiddleOutlined as Be, VerticalAlignTopOutlined as Ve } from "@ant-design/icons";
import { App as He, Avatar as Ue, Badge as We, Breadcrumb as Ge, Button as Ke, Checkbox as qe, Col as Je, ColorPicker as Ye, ConfigProvider as Xe, Divider as Ze, Drawer as Qe, Dropdown as $e, Empty as et, FloatButton as tt, Form as nt, Grid as rt, Input as it, InputNumber as at, List as ot, Menu as st, Modal as ct, Popover as lt, Result as ut, Row as dt, Select as ft, Slider as pt, Space as mt, Spin as ht, Switch as gt, Tabs as _t, Tag as vt, Tooltip as yt, Tree as bt, Typography as xt, Upload as St, Watermark as Ct, message as wt, notification as Tt, theme as Et } from "antd";
import { Children as Dt, Suspense as Ot, cloneElement as kt, createElement as At, forwardRef as _, isValidElement as jt, lazy as Mt, use as Nt, useCallback as Pt, useEffect as v, useMemo as y, useRef as Ft, useState as It } from "react";
import { initReactI18next as Lt, useTranslation as b } from "react-i18next";
import { Fragment as x, jsx as S, jsxs as C } from "react/jsx-runtime";
import Rt from "antd/locale/en_US";
import zt from "antd/locale/zh_CN";
import Bt from "i18next";
import { clsx as Vt } from "clsx";
import { twMerge as Ht } from "tailwind-merge";
import { flushSync as Ut } from "react-dom";
import Wt from "nprogress";
import "nprogress/nprogress.css";
import { ThemeProvider as Gt, createUseStyles as Kt } from "react-jss";
import { useDebounceFn as qt, useFullscreen as Jt, useKeyPress as Yt, useLocalStorageState as Xt, useResponsive as Zt, useSize as Qt, useToggle as $t } from "ahooks";
import { useSpinDelay as en } from "spin-delay";
import tn from "simplebar-react";
import { KeepAlive as nn, useKeepAliveContext as rn, useKeepAliveRef as an } from "keepalive-for-react";
import { DndContext as on, PointerSensor as sn, closestCenter as cn, useSensor as ln } from "@dnd-kit/core";
import { SortableContext as un, horizontalListSortingStrategy as dn, useSortable as fn } from "@dnd-kit/sortable";
import { CSS as pn } from "@dnd-kit/utilities";
import { useShallow as mn } from "zustand/shallow";
import { ContractApiError as hn } from "@oj-module/runtime/contract/errors";
import gn from "antd-img-crop";
import { ProTable as _n } from "@ant-design/pro-components";
//#region \0rolldown/runtime.js
var vn = Object.defineProperty, w = (e, t, n) => () => {
	if (n) throw n[0];
	try {
		return e && (t = e(e = 0)), t;
	} catch (e) {
		throw n = [e], e;
	}
}, T = (e, t) => {
	let n = {};
	for (var r in e) vn(n, r, {
		get: e[r],
		enumerable: !0
	});
	return t || vn(n, Symbol.toStringTag, { value: "Module" }), n;
};
//#endregion
//#region src/store/api-provider.ts
function yn(e, t) {
	if (On) {
		console.warn(`[api] 重复的系统 API provider 忽略：已由模块 "${On.moduleName}" 提供，忽略 "${e}"（先到先得）。`);
		return;
	}
	On = {
		moduleName: e,
		provider: t
	};
}
function bn() {
	return On?.provider;
}
function xn(e, t) {
	if (kn) {
		console.warn(`[api] 重复的通知 provider 忽略：已由模块 "${kn.moduleName}" 提供，忽略 "${e}"（先到先得）。`);
		return;
	}
	kn = {
		moduleName: e,
		provider: t
	};
}
function Sn() {
	return kn?.provider;
}
function Cn(e, t) {
	if (An) {
		console.warn(`[api] 重复的上传 provider 忽略：已由模块 "${An.moduleName}" 提供，忽略 "${e}"（先到先得）。`);
		return;
	}
	An = {
		moduleName: e,
		provider: t
	};
}
function wn() {
	return An?.provider;
}
function Tn(e, t) {
	if (jn) {
		console.warn(`[api] 重复的动态路由 provider 忽略：已由模块 "${jn.moduleName}" 提供，忽略 "${e}"（先到先得）。`);
		return;
	}
	jn = {
		moduleName: e,
		provider: t
	};
}
function En() {
	return jn?.provider;
}
function Dn(e) {
	On?.moduleName === e && (On = void 0), kn?.moduleName === e && (kn = void 0), An?.moduleName === e && (An = void 0), jn?.moduleName === e && (jn = void 0);
}
var On, kn, An, jn, Mn = w((() => {}));
//#endregion
//#region src/api/notify/index.ts
Mn();
var Nn = "NotificationsBackendNotRegistered";
function Pn() {
	let e = Sn();
	if (!e || typeof e.push != "function" || typeof e.pushBroadcast != "function" || typeof e.del != "function") throw Error(`[notify] ${Nn}：未注册 notificationsApi provider 的发射方法（push/pushBroadcast/del）。`);
	return e;
}
var Fn = {
	push(e) {
		return Pn().push(e);
	},
	pushBroadcast(e) {
		return Pn().pushBroadcast(e);
	},
	del(e, t) {
		return Pn().del(e, t);
	}
};
//#endregion
//#region src/utils/site-base.ts
function In(e) {
	if (!e) return zn;
	let t = e.trim();
	if (!t || t === zn) return zn;
	let n = t.startsWith(zn) ? t : `${zn}${t}`;
	return n.endsWith(zn) ? n : `${n}${zn}`;
}
function Ln() {
	let e = globalThis.__OJ_BASE__;
	return In(typeof e == "string" ? e : "/");
}
function Rn(e, t = Ln()) {
	if (!e.startsWith(zn) || e.startsWith("//")) return e;
	let n = In(t);
	return n === zn || e.startsWith(n) ? e : `${n.slice(0, -1)}${e}`;
}
var zn, Bn = w((() => {
	zn = "/";
}));
//#endregion
//#region src/router/extra-info/route-path.ts
function Vn(e, t = Ln()) {
	return e === `${t}${Hn.slice(1)}`;
}
var Hn, Un, Wn, Gn, Kn, qn = w((() => {
	Bn(), Hn = "/login", Un = "/exception", Wn = `${Un}/403`, Gn = `${Un}/404`, Kn = `${Un}/500`, `${Un}`;
})), Jn = w((() => {
	qn();
})), Yn, Xn, Zn, Qn, $n = w((() => {
	Yn = "Authorization", Xn = "X-Lang", Zn = "auth/refresh", Qn = "auth/login";
})), er = w((() => {}));
//#endregion
//#region src/api/user/index.ts
function tr(e) {
	return {
		token: e?.access_token ?? "",
		refreshToken: e?.refresh_token ?? ""
	};
}
function nr(e) {
	let t = e.method === "ldap" ? "auth/ldap-login" : "auth/login";
	return M.post(t, { json: e }).json().then((e) => tr(e.data));
}
function rr(e) {
	return M.post("auth/logout", { json: { refresh_token: e?.refreshToken ?? "" } }).json().then(() => {});
}
function ir() {
	let e = En();
	return e ? e.fetchAsyncRoutes() : M.get("web/get-async-routes").json().then((e) => e.data ?? []);
}
function ar() {
	return M.get("web/user-info").json().then((e) => e.data);
}
function or(e) {
	return M.post(Zn, { json: { refresh_token: e.refreshToken } }).json().then((e) => tr(e.data));
}
var sr = w((() => {
	Mn(), Xv(), $n(), er();
})), cr, lr = w((() => {
	cr = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201022.7%20785.81'%3e%3cdefs%3e%3clinearGradient%20id='a'%20x1='678.2'%20x2='678.2'%20y1='821.79'%20y2='493.4'%20gradientTransform='rotate(-2.31%20725.2%20516.777)'%20gradientUnits='userSpaceOnUse'%3e%3cstop%20offset='0'%20stop-color='gray'%20stop-opacity='.25'/%3e%3cstop%20offset='.54'%20stop-color='gray'%20stop-opacity='.12'/%3e%3cstop%20offset='1'%20stop-color='gray'%20stop-opacity='.1'/%3e%3c/linearGradient%3e%3c/defs%3e%3cellipse%20cx='468.63'%20cy='660.88'%20fill='%236c63ff'%20opacity='.1'%20rx='425'%20ry='33'/%3e%3cg%20opacity='.1'%3e%3cpath%20fill='%233f3d56'%20d='M845.05%20472.84c-2.54-7.71-12.84-11.26-23-7.92a24.76%2024.76%200%200%200-4.23%201.83c-.65-.18-1.32-.34-2-.46a22.42%2022.42%200%200%200%20.63-6.79%2024.6%2024.6%200%200%200%2010.9-21.47%2024.63%2024.63%200%200%200%2010.86-21.47%2023.76%2023.76%200%200%200%208.23-9.32c4.9-9.7%202.87-20.6-4.54-24.35s-17.4%201.08-22.3%2010.78a23.69%2023.69%200%200%200-2.63%2012.15%2024.63%2024.63%200%200%200-10.86%2021.47%2024.63%2024.63%200%200%200-10.86%2021.47%2024.64%2024.64%200%200%200-10.9%2021.48%2023.76%2023.76%200%200%200-8.23%209.32%2025.46%2025.46%200%200%200-2.08%205.74%2021.18%2021.18%200%200%200-4.44-4.73%2025.38%2025.38%200%200%200-1-4.5c-3.34-10.17-12.3-16.37-20-13.83s-11.26%2012.83-7.92%2023a23.07%2023.07%200%200%200%207.56%2011.08%2025.38%2025.38%200%200%200%201%204.5c1.94%205.9%205.77%2010.46%2010.15%2012.75a23.23%2023.23%200%200%200-.83%203.9%2025.29%2025.29%200%200%200-7.54%2014.91%2025.27%2025.27%200%200%200-7.54%2014.92%2024.63%2024.63%200%200%200-5%206.81c-4.91%209.7-2.88%2020.61%204.53%2024.35s17.4-1.07%2022.31-10.78a24.62%2024.62%200%200%200%202.5-8.09%2025.29%2025.29%200%200%200%207.54-14.91%2025.27%2025.27%200%200%200%207.54-14.92%2025.21%2025.21%200%200%200%207.45-14.91%2025.21%2025.21%200%200%200%207.56-14.94%2024.11%2024.11%200%200%200%203.39-4%2023.46%2023.46%200%200%200%2012.27-.77%2024.76%2024.76%200%200%200%204.23-1.83%2023.2%2023.2%200%200%200%2013.42-.48c10.13-3.31%2016.36-12.27%2013.83-19.99Z'/%3e%3cg%20opacity='.1'%3e%3cpath%20d='M827.12%20442.44a21.5%2021.5%200%200%201-3.44%202.75%2023%2023%200%200%201-1.11%208.43%2026.18%2026.18%200%200%200%202.1-3.43%2024.64%2024.64%200%200%200%202.45-7.75ZM837.98%20420.97a21.5%2021.5%200%200%201-3.44%202.75%2023%2023%200%200%201-1.11%208.43%2025.65%2025.65%200%200%200%202.1-3.44%2024.85%2024.85%200%200%200%202.45-7.74ZM813.35%20412.98a21.91%2021.91%200%200%201%20.17-4.41%2024.93%2024.93%200%200%200-4.78%206.57%2025.63%2025.63%200%200%200-1.52%203.73%2022.75%2022.75%200%200%201%206.13-5.89ZM744.42%20542.91a23.59%2023.59%200%200%201%202.95-3.38%2022.92%2022.92%200%200%201%20.87-4%2025.09%2025.09%200%200%200-2.29%203.71%2025.59%2025.59%200%200%200-1.53%203.67ZM751.96%20528.01a23.59%2023.59%200%200%201%202.95-3.38%2023%2023%200%200%201%20.83-3.9%2025.68%2025.68%200%200%200-2.2%203.59%2026.76%2026.76%200%200%200-1.58%203.69ZM816.25%20463.91a20.82%2020.82%200%200%201-3.43%202.74%2022.45%2022.45%200%200%201-.63%206.79%2018.75%2018.75%200%200%201%202%20.46%2024.76%2024.76%200%200%201%204.23-1.83c10.18-3.34%2020.47.21%2023%207.92a11.68%2011.68%200%200%201%20.32%206c3.35-3.94%204.74-8.74%203.3-13.14-2.54-7.71-12.84-11.26-23-7.92a24.76%2024.76%200%200%200-4.23%201.83c-.65-.18-1.32-.34-2-.46.19-.8.33-1.59.44-2.39ZM740.7%20550.4a25.09%2025.09%200%200%200-2.29%203.71%2026.56%2026.56%200%200%200-1.54%203.74%2024.48%2024.48%200%200%201%203-3.4%2022.92%2022.92%200%200%201%20.83-4.05ZM802.44%20434.45a22%2022%200%200%201%20.17-4.41%2024.93%2024.93%200%200%200-4.78%206.57%2025.63%2025.63%200%200%200-1.52%203.73%2022.75%2022.75%200%200%201%206.13-5.89ZM786.75%20522.01a24.29%2024.29%200%200%201-1%204.38%2026.67%2026.67%200%200%200%202.09-3.44%2025.49%2025.49%200%200%200%201.63-4%2024.23%2024.23%200%200%201-2.72%203.06ZM771.67%20551.83a24.15%2024.15%200%200%201-1%204.38%2025.65%2025.65%200%200%200%202.1-3.44%2026.47%2026.47%200%200%200%201.63-4%2023.57%2023.57%200%200%201-2.73%203.06ZM779.21%20536.91a24.11%2024.11%200%200%201-1%204.38%2026.67%2026.67%200%200%200%202.14-3.38%2025.49%2025.49%200%200%200%201.63-4%2024.23%2024.23%200%200%201-2.77%203ZM794.29%20507.1a24%2024%200%200%201-1%204.37%2025.89%2025.89%200%200%200%202.09-3.43%2025.48%2025.48%200%200%200%201.64-4.07%2023.22%2023.22%200%200%201-2.73%203.13ZM744.92%20469.39c7.72-2.53%2016.68%203.66%2020%2013.83a25.68%2025.68%200%200%201%201%204.51%2021.18%2021.18%200%200%201%204.44%204.73%2025.53%2025.53%200%200%201%202.08-5.75c.35-.68.73-1.33%201.12-2a21.07%2021.07%200%200%200-4-4.18%2025.38%2025.38%200%200%200-1-4.5c-3.34-10.17-12.3-16.37-20-13.83-4.4%201.44-7.44%205.41-8.62%2010.43a11.69%2011.69%200%200%201%204.98-3.24ZM780.72%20477.39a21.85%2021.85%200%200%201%20.18-4.4%2024.73%2024.73%200%200%200-4.79%206.57%2025.07%2025.07%200%200%200-1.52%203.72%2023%2023%200%200%201%206.13-5.89ZM791.58%20455.91a21.85%2021.85%200%200%201%20.18-4.4%2024.52%2024.52%200%200%200-4.79%206.56%2025.63%2025.63%200%200%200-1.52%203.73%2022.75%2022.75%200%200%201%206.13-5.89ZM764.13%20566.74a24.25%2024.25%200%200%201-1%204.39%2025.73%2025.73%200%200%200%203.73-7.49%2023.57%2023.57%200%200%201-2.73%203.1Z'/%3e%3c/g%3e%3cpath%20fill='%233f3d56'%20d='M859.87%20373.62a23.68%2023.68%200%200%200%208.23-9.32c4.91-9.7%202.88-20.61-4.53-24.36s-17.4%201.08-22.31%2010.79a23.68%2023.68%200%200%200-2.62%2012.18%2024.63%2024.63%200%200%200-10.86%2021.47%2023.61%2023.61%200%200%200-8.23%209.32%2024.69%2024.69%200%200%200-1.51%203.69%2020.85%2020.85%200%200%201%2010.77-8%2012.24%2012.24%200%200%200%2015.54%207.84%2020.85%2020.85%200%200%201%200%2013.41%2025.48%2025.48%200%200%200%202.08-3.4%2023.68%2023.68%200%200%200%202.62-12.15%2024.57%2024.57%200%200%200%2010.86-21.47Z'/%3e%3cpath%20fill='%236c63ff'%20d='M979.23%20235.98a72%2072%200%200%200%208.72-4.83l-32.33-23.62%2038%2019.57a72.13%2072.13%200%200%200%2027-50.31l-64.58.66%2064.72-10.82a72%2072%200%201%200-142.58%2018.28%2072.09%2072.09%200%200%200-13.26%208l33.75%2046.93-40.52-41.08a72.08%2072.08%200%200%200-20.17%2065.61%2072%2072%200%201%200%20101.05%2051.1%2072%2072%200%200%200%2040.2-79.49Z'/%3e%3cpath%20d='M844.35%20217.66a71.77%2071.77%200%200%200-6.35%2046.71%2072%2072%200%201%200%20101.05%2051.1c14.13-6.56-91.08-105.02-94.7-97.81Z'%20opacity='.1'/%3e%3ccircle%20cx='925.49'%20cy='102.72'%20r='10.69'%20fill='%236c63ff'/%3e%3ccircle%20cx='987.93'%20cy='109.58'%20r='10.69'%20fill='%236c63ff'/%3e%3ccircle%20cx='1012.01'%20cy='205.64'%20r='10.69'%20fill='%236c63ff'/%3e%3ccircle%20cx='979.51'%20cy='253.61'%20r='10.69'%20fill='%236c63ff'/%3e%3ccircle%20cx='935.11'%20cy='353.24'%20r='10.69'%20fill='%236c63ff'/%3e%3ccircle%20cx='935.11'%20cy='353.24'%20r='10.69'%20opacity='.1'/%3e%3ccircle%20cx='836.39'%20cy='240.4'%20r='10.69'%20fill='%236c63ff'/%3e%3ccircle%20cx='836.39'%20cy='240.4'%20r='10.69'%20opacity='.1'/%3e%3cpath%20d='M824.99%20416.23c-7.11-3.59-9.26-13.76-5.11-23.14-.22.38-.43.77-.63%201.18-4.91%209.7-2.88%2020.6%204.53%2024.35s17.4-1.08%2022.3-10.78c.21-.4.39-.81.57-1.21-5.09%208.91-14.56%2013.2-21.66%209.6ZM814.43%20437.11c-7.1-3.59-9.26-13.76-5.1-23.15-.22.39-.44.78-.64%201.18-4.91%209.7-2.88%2020.61%204.53%2024.35s17.4-1.07%2022.31-10.78c.2-.4.39-.8.57-1.21-5.1%208.91-14.56%2013.2-21.67%209.61ZM803.87%20457.98c-7.1-3.59-9.26-13.76-5.1-23.14-.22.38-.44.77-.64%201.18-4.91%209.7-2.87%2020.6%204.54%2024.35s17.39-1.08%2022.3-10.78c.2-.4.39-.81.57-1.21-5.09%208.91-14.56%2013.2-21.67%209.6ZM793.35%20478.91c-7.11-3.59-9.26-13.76-5.11-23.14-.22.38-.43.77-.64%201.17-4.9%209.7-2.87%2020.61%204.54%2024.36s17.4-1.08%2022.3-10.79c.21-.4.39-.8.57-1.21-5.12%208.86-14.59%2013.15-21.66%209.61ZM782.76%20499.73c-7.11-3.59-9.26-13.76-5.11-23.14-.22.38-.43.77-.63%201.18-4.91%209.7-2.88%2020.6%204.53%2024.35s17.4-1.08%2022.31-10.78c.2-.4.39-.81.57-1.21-5.08%208.91-14.57%2013.2-21.67%209.6ZM772.2%20520.61c-7.1-3.59-9.26-13.76-5.1-23.14-.22.38-.44.77-.64%201.17-4.91%209.7-2.88%2020.61%204.54%2024.36s17.35-1.09%2022.35-10.79c.2-.4.39-.8.57-1.21-5.15%208.91-14.57%2013.2-21.72%209.61ZM761.64%20541.48c-7.1-3.59-9.26-13.76-5.1-23.14-.22.39-.43.77-.64%201.18-4.9%209.7-2.87%2020.6%204.54%2024.35s17.4-1.08%2022.3-10.78c.21-.4.39-.81.57-1.21-5.09%208.91-14.56%2013.2-21.67%209.6ZM751.09%20562.36c-7.11-3.59-9.26-13.76-5.11-23.14q-.33.57-.63%201.17c-4.91%209.7-2.88%2020.61%204.53%2024.36s17.4-1.08%2022.31-10.79c.2-.4.38-.8.56-1.21-5.09%208.91-14.56%2013.16-21.66%209.61Z'%20opacity='.1'/%3e%3cpath%20d='M744.15%20576.08c-7.1-3.6-9.26-13.76-5.1-23.15-.22.39-.44.78-.64%201.18-4.91%209.7-2.88%2020.61%204.53%2024.35s17.4-1.07%2022.31-10.78c.2-.4.39-.8.57-1.21-5.1%208.91-14.57%2013.2-21.67%209.61Z'%20opacity='.1'/%3e%3cpath%20fill='%236c63ff'%20d='M934.94%20483.17a37.4%2037.4%200%200%200%202-9.79%205.34%205.34%200%201%200-.81-10.62%2037.31%2037.31%200%200%200-19.64-25.31%205.344%205.344%200%201%200-9.54-4.82%205%205%200%200%200-.48%201.43%2037.49%2037.49%200%200%200-32.87%209.85%2037.64%2037.64%200%200%200-9.82-.29l-4.33%2019.71-.26-19a37.42%2037.42%200%201%200%2020%2072%205.28%205.28%200%200%200%202.25%202.16%205.34%205.34%200%200%200%207.32-6.88%2037.35%2037.35%200%200%200%204.8-3.92%2037.45%2037.45%200%200%200%2039.31-19.83l-20.15-3.39Z'/%3e%3cpath%20d='M903.81%20492.74c-7.44-9.82-12-21.45-17.25-32.61a136.38%20136.38%200%200%200-7.07-13.36l-3.94-4.59c-.66.56-1.32%201.14-2%201.75a37.64%2037.64%200%200%200-9.82-.29l-4.33%2019.71-.26-19a37.42%2037.42%200%201%200%2020%2072%205.28%205.28%200%200%200%202.25%202.16%205.34%205.34%200%200%200%207.32-6.88%2037.35%2037.35%200%200%200%204.8-3.92%2037.49%2037.49%200%200%200%2022.44-3.32%2052.71%2052.71%200%200%201-12.14-11.65Z'%20opacity='.1'/%3e%3cpath%20fill='%236c63ff'%20d='M772.06%20450.54a5.34%205.34%200%200%200-4.78-7.75%2037.37%2037.37%200%200%200-11.7-20.83%2037.52%2037.52%200%200%200%201.1-11.7l-19.65-3.35%2019.08-1.2a38%2038%200%200%200-1.41-5.28%205.46%205.46%200%200%200%201.76-2%205.35%205.35%200%200%200-6.59-7.44%2037.42%2037.42%200%200%200-66.79%2030.92%205.25%205.25%200%200%200-2.66%202.5%205.34%205.34%200%200%200%206.75%207.37%2037.53%2037.53%200%200%200%207.09%208.65%2037.4%2037.4%200%200%200%201.74%2023.76l26.35-6.84-23.5%2012.36a37.42%2037.42%200%200%200%2068.91-16.26%205.33%205.33%200%200%200%204.3-2.91Z'/%3e%3cpath%20d='M772.06%20450.54a5.34%205.34%200%200%200-4.78-7.75%2037.37%2037.37%200%200%200-11.7-20.83c.16-.63.3-1.25.42-1.88a13.18%2013.18%200%200%200-1.93%201.71c-3.55%203.89-5.37%209.12-8.88%2013.05-4.14%204.64-10.34%207.06-16.53%207.71s-12.42-.3-18.53-1.49c-5.06-1-10.19-2.16-15.32-1.67-.5%200-1%20.11-1.46.19.3.29.6.58.91.86A37.4%2037.4%200%200%200%20696%20464.2l26.35-6.85-23.5%2012.36a37.42%2037.42%200%200%200%2068.91-16.26%205.33%205.33%200%200%200%204.3-2.91Z'%20opacity='.1'/%3e%3c/g%3e%3cg%20opacity='.1'%3e%3cpath%20fill='%233f3d56'%20d='M89.49%20511.24c1.28-3.89%206.47-5.68%2011.59-4a12.78%2012.78%200%200%201%202.13.92c.33-.09.67-.17%201-.23a11.26%2011.26%200%200%201-.32-3.42%2012.46%2012.46%200%200%201-5.47-10.82%2011.92%2011.92%200%200%201-4.14-4.69%2012%2012%200%200%201-1.33-6.12%2012%2012%200%200%201-4.14-4.7c-2.46-4.88-1.46-10.37%202.29-12.27s8.77.55%2011.24%205.43a12%2012%200%200%201%201.32%206.13%2012.37%2012.37%200%200%201%205.47%2010.81%2012.4%2012.4%200%200%201%205.47%2010.82%2012.37%2012.37%200%200%201%205.47%2010.81%2012%2012%200%200%201%204.15%204.7%2012.66%2012.66%200%200%201%201%202.9%2010.66%2010.66%200%200%201%202.23-2.39%2012.58%2012.58%200%200%201%20.52-2.27c1.69-5.12%206.2-8.24%2010.09-7s5.67%206.47%204%2011.59a11.67%2011.67%200%200%201-3.81%205.59%2012.67%2012.67%200%200%201-.52%202.26%2011.1%2011.1%200%200%201-5.11%206.42%2012.84%2012.84%200%200%201%20.42%202%2012.57%2012.57%200%200%201%202.53%203.43%2012.32%2012.32%200%200%201%201.26%204.08%2012.55%2012.55%200%200%201%202.54%203.43%2012.39%2012.39%200%200%201%201.26%204.08%2012.45%2012.45%200%200%201%202.54%203.44c2.47%204.88%201.45%2010.38-2.28%2012.26s-8.77-.54-11.24-5.43a12.48%2012.48%200%200%201-1.26-4.08%2012.7%2012.7%200%200%201-3.8-7.51%2012.7%2012.7%200%200%201-3.8-7.51%2012.6%2012.6%200%200%201-2.54-3.43%2012.73%2012.73%200%200%201-1.26-4.08%2012.57%2012.57%200%200%201-2.53-3.43%2012.32%2012.32%200%200%201-1.26-4.08%2011.63%2011.63%200%200%201-1.71-2%2011.9%2011.9%200%200%201-6.18-.38%2013.29%2013.29%200%200%201-2.14-.93%2011.61%2011.61%200%200%201-6.75-.24c-5.07-1.69-8.2-6.2-6.93-10.09Z'/%3e%3cg%20opacity='.1'%3e%3cpath%20d='M98.52%20495.91a10.72%2010.72%200%200%200%201.74%201.39%2011.31%2011.31%200%200%200%20.56%204.24%2011.93%2011.93%200%200%201-1.06-1.73%2012.46%2012.46%200%200%201-1.24-3.9ZM93.05%20485.11a11.21%2011.21%200%200%200%201.74%201.38%2011.39%2011.39%200%200%200%20.56%204.25%2012.7%2012.7%200%200%201-2.3-5.63ZM105.48%20481.08a11.11%2011.11%200%200%200-.08-2.22%2012.66%2012.66%200%200%201%202.41%203.31%2013%2013%200%200%201%20.76%201.88%2011.42%2011.42%200%200%200-3.09-2.97ZM140.18%20546.54a11.65%2011.65%200%200%200-1.48-1.7%2012.4%2012.4%200%200%200-.44-2%2013.23%2013.23%200%200%201%201.15%201.86%2013%2013%200%200%201%20.77%201.84ZM136.35%20539.03a11.65%2011.65%200%200%200-1.48-1.7%2011.75%2011.75%200%200%200-.42-2%2012.67%2012.67%200%200%201%201.88%203.68ZM104%20506.75a10.11%2010.11%200%200%200%201.73%201.37%2010.9%2010.9%200%200%200%20.32%203.42%2010%2010%200%200%200-1%20.23%2013.26%2013.26%200%200%200-2.14-.92c-5.12-1.68-10.31.11-11.58%204a5.82%205.82%200%200%200-.17%203%206.93%206.93%200%200%201-1.66-6.61c1.28-3.89%206.47-5.68%2011.59-4a12.78%2012.78%200%200%201%202.13.92c.33-.09.67-.17%201-.23a10.32%2010.32%200%200%201-.22-1.18ZM142.06%20550.31a12.79%2012.79%200%200%201%201.15%201.87%2013%2013%200%200%201%20.77%201.88%2011.74%2011.74%200%200%200-1.48-1.71%2012.4%2012.4%200%200%200-.44-2.04ZM110.95%20491.91a11.08%2011.08%200%200%200-.08-2.22%2012.49%2012.49%200%200%201%202.41%203.31%2012.87%2012.87%200%200%201%20.76%201.87%2011.38%2011.38%200%200%200-3.09-2.96ZM118.86%20536.01a11.94%2011.94%200%200%200%20.49%202.2%2012.63%2012.63%200%200%201-1.88-3.77%2011.72%2011.72%200%200%200%201.39%201.57ZM126.45%20551.03a12.66%2012.66%200%200%200%20.5%202.2%2011.93%2011.93%200%200%201-1.06-1.73%2012.88%2012.88%200%200%201-.82-2%2013%2013%200%200%200%201.38%201.53ZM122.66%20543.52a11.94%2011.94%200%200%200%20.49%202.2%2012.88%2012.88%200%200%201-1.06-1.73%2012.6%2012.6%200%200%201-.82-2%2011.72%2011.72%200%200%200%201.39%201.53ZM115.06%20528.49a11.86%2011.86%200%200%200%20.49%202.21%2012.44%2012.44%200%200%201-1-1.73%2012.23%2012.23%200%200%201-.83-2%2011.13%2011.13%200%200%200%201.34%201.52ZM139.93%20509.5c-3.89-1.28-8.4%201.84-10.08%207a12.58%2012.58%200%200%200-.52%202.27%2010.63%2010.63%200%200%200-2.24%202.38%2012.83%2012.83%200%200%200-1.05-2.9c-.17-.34-.36-.67-.56-1a10.63%2010.63%200%200%201%202-2.1%2012.58%2012.58%200%200%201%20.52-2.27c1.69-5.12%206.2-8.24%2010.09-7a6.93%206.93%200%200%201%204.34%205.26%205.93%205.93%200%200%200-2.5-1.64ZM121.89%20513.53a11.11%2011.11%200%200%200-.08-2.22%2012.49%2012.49%200%200%201%202.41%203.31%2013%2013%200%200%201%20.76%201.88%2011.28%2011.28%200%200%200-3.09-2.97ZM116.42%20502.71a11.13%2011.13%200%200%200-.08-2.22%2012.83%2012.83%200%200%201%202.41%203.31%2013%2013%200%200%201%20.76%201.88%2011.42%2011.42%200%200%200-3.09-2.97ZM130.25%20558.54a11.9%2011.9%200%200%200%20.5%202.21%2012.61%2012.61%200%200%201-1.06-1.74%2012.88%2012.88%200%200%201-.82-2%2013%2013%200%200%200%201.38%201.53Z'/%3e%3c/g%3e%3cpath%20fill='%233f3d56'%20d='M82.02%20461.25a11.92%2011.92%200%200%201-4.14-4.69c-2.47-4.89-1.45-10.38%202.28-12.27s8.77.54%2011.24%205.43a11.93%2011.93%200%200%201%201.32%206.12%2012.4%2012.4%200%200%201%205.47%2010.82%2012%2012%200%200%201%204.15%204.69%2013.23%2013.23%200%200%201%20.76%201.86%2010.57%2010.57%200%200%200-5.43-4%206.16%206.16%200%200%201-7.83%204%2010.52%2010.52%200%200%200%200%206.75%2013.19%2013.19%200%200%201-1-1.71%2012%2012%200%200%201-1.33-6.12%2012.43%2012.43%200%200%201-5.47-10.82Z'/%3e%3cpath%20fill='%236c63ff'%20d='M21.9%20391.91a36.81%2036.81%200%200%201-4.39-2.43l16.28-11.9-19.14%209.85a36.34%2036.34%200%200%201-13.59-25.34l32.54.34-32.61-5.46a36.29%2036.29%200%201%201%2071.81%209.2%2036.73%2036.73%200%200%201%206.68%204l-17%2023.64%2020.41-20.68a36.32%2036.32%200%200%201%2010.16%2033.05%2036.29%2036.29%200%201%201-50.9%2025.74%2036.28%2036.28%200%200%201-20.25-40Z'/%3e%3cpath%20d='M89.85%20382.69a36.12%2036.12%200%200%201%203.2%2023.53%2036.29%2036.29%200%201%201-50.9%2025.74c-7.13-3.31%2045.87-52.9%2047.7-49.27Z'%20opacity='.1'/%3e%3ccircle%20cx='48.97'%20cy='324.78'%20r='5.39'%20fill='%236c63ff'/%3e%3ccircle%20cx='17.51'%20cy='328.24'%20r='5.39'%20fill='%236c63ff'/%3e%3ccircle%20cx='5.39'%20cy='376.63'%20r='5.39'%20fill='%236c63ff'/%3e%3ccircle%20cx='21.76'%20cy='400.8'%20r='5.39'%20fill='%236c63ff'/%3e%3ccircle%20cx='44.12'%20cy='450.99'%20r='5.39'%20fill='%236c63ff'/%3e%3ccircle%20cx='44.12'%20cy='450.99'%20r='5.39'%20opacity='.1'/%3e%3ccircle%20cx='93.85'%20cy='394.14'%20r='5.39'%20fill='%236c63ff'/%3e%3ccircle%20cx='93.85'%20cy='394.14'%20r='5.39'%20opacity='.1'/%3e%3cpath%20d='M99.6%20482.72c3.58-1.81%204.66-6.93%202.57-11.66.11.2.22.39.32.59%202.47%204.89%201.45%2010.38-2.29%2012.27s-8.76-.54-11.23-5.43c-.1-.2-.2-.4-.29-.61%202.57%204.49%207.34%206.65%2010.92%204.84ZM104.91%20493.24c3.58-1.81%204.67-6.94%202.58-11.66.11.19.22.39.32.59%202.47%204.89%201.45%2010.38-2.29%2012.27s-8.76-.54-11.23-5.43c-.11-.2-.2-.41-.29-.61%202.57%204.51%207.35%206.65%2010.91%204.84ZM110.23%20503.75c3.58-1.81%204.67-6.93%202.57-11.66.12.2.22.39.33.6%202.47%204.88%201.44%2010.38-2.29%2012.26s-8.76-.54-11.23-5.43c-.11-.2-.2-.4-.29-.61%202.56%204.49%207.33%206.65%2010.91%204.84ZM115.55%20514.27c3.58-1.81%204.67-6.93%202.57-11.66.11.19.22.39.32.59%202.48%204.89%201.45%2010.38-2.28%2012.27s-8.77-.54-11.24-5.43c-.1-.2-.19-.41-.28-.61%202.56%204.48%207.33%206.65%2010.91%204.84ZM120.87%20524.78c3.58-1.81%204.66-6.93%202.57-11.65.11.19.22.39.32.59%202.47%204.89%201.45%2010.38-2.28%2012.27s-8.77-.55-11.24-5.43c-.1-.21-.19-.41-.29-.61%202.57%204.48%207.34%206.64%2010.92%204.83ZM126.19%20535.3c3.58-1.81%204.66-6.93%202.57-11.66.11.2.22.39.32.59%202.47%204.89%201.45%2010.38-2.28%2012.27s-8.77-.54-11.24-5.43c-.1-.2-.2-.4-.29-.61%202.57%204.45%207.34%206.65%2010.92%204.84ZM131.51%20545.82c3.57-1.81%204.66-6.94%202.57-11.66.11.19.22.39.32.59%202.47%204.89%201.45%2010.38-2.29%2012.27s-8.76-.55-11.23-5.43c-.1-.21-.2-.41-.29-.61%202.57%204.48%207.34%206.65%2010.92%204.84ZM136.82%20556.33c3.58-1.81%204.67-6.93%202.57-11.66.12.2.22.39.33.6%202.47%204.88%201.44%2010.38-2.29%2012.26s-8.76-.54-11.23-5.43c-.11-.2-.2-.4-.29-.61%202.57%204.49%207.33%206.65%2010.91%204.84Z'%20opacity='.1'/%3e%3cpath%20d='M140.35%20563.24c3.58-1.81%204.66-6.93%202.57-11.66.11.2.22.39.32.6%202.47%204.88%201.45%2010.38-2.28%2012.26s-8.77-.54-11.24-5.43c-.1-.2-.2-.4-.29-.61%202.54%204.51%207.31%206.65%2010.92%204.84Z'%20opacity='.1'/%3e%3cpath%20fill='%236c63ff'%20d='M44.21%20516.44a18.57%2018.57%200%200%201-1-4.93%202.69%202.69%200%201%201%20.41-5.35%2018.82%2018.82%200%200%201%209.89-12.75%202.694%202.694%200%201%201%204.81-2.43%202.44%202.44%200%200%201%20.24.72%2018.92%2018.92%200%200%201%2016.56%205%2018.68%2018.68%200%200%201%205-.14l2.18%209.92.05-9.57a18.85%2018.85%200%201%201-10.08%2036.29%202.76%202.76%200%200%201-1.13%201.09%202.7%202.7%200%200%201-3.7-3.47%2018.84%2018.84%200%200%201-2.41-2%2018.87%2018.87%200%200%201-19.8-10l10.15-1.71Z'/%3e%3cpath%20d='M59.89%20521.26c3.75-5%206.05-10.8%208.69-16.42a66.7%2066.7%200%200%201%203.56-6.74l2-2.31c.34.29.67.58%201%20.88a18.68%2018.68%200%200%201%205-.14l2.18%209.92.03-9.54a18.85%2018.85%200%201%201-10.08%2036.29%202.76%202.76%200%200%201-1.13%201.09%202.7%202.7%200%200%201-3.7-3.47%2018.84%2018.84%200%200%201-2.41-2%2019%2019%200%200%201-11.31-1.67%2026.59%2026.59%200%200%200%206.17-5.89Z'%20opacity='.1'/%3e%3cpath%20fill='%236c63ff'%20d='M126.26%20500a2.68%202.68%200%200%201%201.19-3.61%202.64%202.64%200%200%201%201.22-.29%2018.85%2018.85%200%200%201%205.89-10.5%2018.71%2018.71%200%200%201-.55-5.89l9.89-1.66-9.61-.61a18.65%2018.65%200%200%201%20.72-2.66%202.64%202.64%200%200%201-.89-1%202.7%202.7%200%200%201%203.32-3.75%2018.63%2018.63%200%200%201%206.87-5.93%2018.84%2018.84%200%200%201%2026.77%2021.5%202.69%202.69%200%200%201%20.16%204.87%202.7%202.7%200%200%201-2.22.1%2018.74%2018.74%200%200%201-3.57%204.34%2018.9%2018.9%200%200%201-.87%2012l-13.23-3.48%2011.83%206.23a18.86%2018.86%200%200%201-32.83-1.54%2019.11%2019.11%200%200%201-1.94-6.65%202.67%202.67%200%200%201-2.15-1.47Z'/%3e%3cpath%20d='M126.26%20500a2.68%202.68%200%200%201%201.19-3.61%202.64%202.64%200%200%201%201.22-.29%2018.85%2018.85%200%200%201%205.89-10.5c-.08-.31-.15-.63-.21-.94a7.27%207.27%200%200%201%201%20.86c1.79%202%202.71%204.59%204.47%206.57a12.91%2012.91%200%200%200%208.33%203.89%2031.54%2031.54%200%200%200%209.33-.75%2027.35%2027.35%200%200%201%207.72-.85l.74.1-.46.43a18.9%2018.9%200%200%201-.87%2012l-13.26-3.48%2011.83%206.23a18.86%2018.86%200%200%201-32.83-1.54%2019.11%2019.11%200%200%201-1.94-6.65%202.67%202.67%200%200%201-2.15-1.47Z'%20opacity='.1'/%3e%3c/g%3e%3cpath%20fill='%236c63ff'%20d='M346.35%2051.91a20.23%2020.23%200%200%200-11.74%201.28%2017.32%2017.32%200%200%201-14.1%200%2019.76%2019.76%200%200%200-16.58.33%2010.28%2010.28%200%200%201-4.77%201.19c-6.72%200-12.31-6.77-13.47-15.7a13.07%2013.07%200%200%200%203.36-3.62c3.94-6.35%2010-10.43%2016.89-10.43s12.89%204%2016.83%2010.31a13%2013%200%200%200%2011.16%206.14h.18c5.3-.03%209.93%204.26%2012.24%2010.5Z'%20opacity='.1'/%3e%3cpath%20fill='%236c63ff'%20d='m366.77%2023.91-10.86%206.89%206.59-12a10.74%2010.74%200%200%200-6.57-2.34h-.17a12.89%2012.89%200%200%201-2.25-.17l-3.69%202.34%201.58-2.87a13.19%2013.19%200%200%201-6.44-4.85l-6.61%204.13%204.16-7.57C338.66%202.84%20333.46%200%20327.75%200c-6.85%200-13%204.08-16.9%2010.43a12.62%2012.62%200%200%201-11.17%206h-.33c-7.56%200-13.7%208.57-13.7%2019.16s6.14%2019.15%2013.7%2019.15a10.28%2010.28%200%200%200%204.77-1.19%2019.72%2019.72%200%200%201%2016.58-.32%2017.37%2017.37%200%200%200%2014.1%200%2019.75%2019.75%200%200%201%2016.43.32%2010.35%2010.35%200%200%200%204.72%201.16c7.57%200%2013.7-8.57%2013.7-19.15a24.36%2024.36%200%200%200-2.88-11.65ZM120.35%20190.45a29%2029%200%200%200-16.77%201.82%2024.71%2024.71%200%200%201-20.14-.05%2028.22%2028.22%200%200%200-23.68.47%2014.75%2014.75%200%200%201-6.82%201.7c-9.6%200-17.59-9.67-19.25-22.43a18.41%2018.41%200%200%200%204.8-5.17c5.63-9.07%2014.35-14.9%2024.14-14.9s18.4%205.76%2024%2014.73a18.52%2018.52%200%200%200%2016%208.77h.25c7.58-.01%2014.2%206.12%2017.47%2015.06Z'%20opacity='.1'/%3e%3cpath%20fill='%236c63ff'%20d='m149.55%20150.4-15.52%209.84%209.42-17.13a15.34%2015.34%200%200%200-9.39-3.35h-.25a18.16%2018.16%200%200%201-3.22-.24l-5.24%203.39%202.26-4.1a18.7%2018.7%200%200%201-9.2-7l-9.42%206%205.93-10.9c-5.51-6.61-12.93-10.66-21.09-10.66-9.79%200-18.51%205.82-24.14%2014.89a18.05%2018.05%200%200%201-16%208.61h-.53c-10.81%200-19.57%2012.25-19.57%2027.37s8.76%2027.37%2019.57%2027.37a14.61%2014.61%200%200%200%206.82-1.71%2028.22%2028.22%200%200%201%2023.68-.46%2024.71%2024.71%200%200%200%2020.14.05%2028.25%2028.25%200%200%201%2023.48.45%2014.65%2014.65%200%200%200%206.74%201.67c10.81%200%2019.57-12.26%2019.57-27.37a34.76%2034.76%200%200%200-4.04-16.72ZM747.97%2090.91a20.24%2020.24%200%200%201%2011.74%201.28%2017.29%2017.29%200%200%200%2014.09%200%2019.76%2019.76%200%200%201%2016.58.33%2010.31%2010.31%200%200%200%204.77%201.19c6.72%200%2012.32-6.77%2013.48-15.7a12.93%2012.93%200%200%201-3.36-3.62c-3.92-6.37-10.05-10.48-16.92-10.48s-12.88%204-16.82%2010.31a13%2013%200%200%201-11.18%206.17h-.17c-5.32-.01-9.96%204.28-12.21%2010.52Z'%20opacity='.1'/%3e%3cpath%20fill='%236c63ff'%20d='m727.49%2062.91%2010.86%206.87-6.6-12a10.76%2010.76%200%200%201%206.57-2.34h.18a13%2013%200%200%200%202.25-.17l3.68%202.34-1.58-2.87a13.21%2013.21%200%200%200%206.5-4.83l6.59%204.18-4.17-7.57c3.86-4.63%209-7.47%2014.77-7.47%206.85%200%2013%204.08%2016.9%2010.43a12.61%2012.61%200%200%200%2011.17%206h.36c7.57%200%2013.7%208.57%2013.7%2019.16s-6.13%2019.15-13.7%2019.15a10.34%2010.34%200%200%201-4.77-1.19%2019.72%2019.72%200%200%200-16.58-.32%2017.35%2017.35%200%200%201-14.09%200%2019.77%2019.77%200%200%200-16.44.32%2010.32%2010.32%200%200%201-4.72%201.16c-7.56%200-13.7-8.57-13.7-19.15a24.36%2024.36%200%200%201%202.82-11.7Z'%20opacity='.1'/%3e%3cellipse%20cx='615.63'%20cy='756.88'%20fill='%236c63ff'%20opacity='.1'%20rx='115'%20ry='20'/%3e%3cpath%20fill='%23d0d2d5'%20d='m555.44%20661.88-178.19-2.29.53-4.57%208.61-75.39h156.49l11.51%2075.39.88%205.72.17%201.14z'/%3e%3cpath%20d='M555.27%20660.74h-88.92l-89.1-1.15.53-4.57h176.61l.88%205.72z'%20opacity='.1'/%3e%3cpath%20fill='%23d0d2d5'%20d='M347.55%20656.17H584v5.71H347.55z'/%3e%3cpath%20fill='%233f3d56'%20d='M809.59%20126.83a14.87%2014.87%200%200%200-14.8-14.92H134.47a14.87%2014.87%200%200%200-14.8%2014.94V527.1h689.92Z'/%3e%3cpath%20fill='%23d0d2d5'%20d='M119.67%20523.1v46.88a14.8%2014.8%200%200%200%2014.8%2014.8h660.32a14.8%2014.8%200%200%200%2014.8-14.8V523.1Z'/%3e%3cpath%20fill='%23fff'%20d='M148.23%20137.01h636.23v359.81H148.23z'/%3e%3cpath%20fill='%236c63ff'%20d='M468.06%20566.99a15.4%2015.4%200%200%200%2012.13-5.89%2016.06%2016.06%200%200%200%201.2-1.76l-8.47-1.43%209.15.06a15.42%2015.42%200%200%200%20.29-12.21l-12.27%206.36%2011.32-8.32a15.42%2015.42%200%201%200-25.47%2017.26%2015.4%2015.4%200%200%200%2012.12%205.93Z'/%3e%3cpath%20d='m483.48%20584.77%2071.09%2071.4-10.91-71.4h-60.18z'%20opacity='.1'/%3e%3cpath%20fill='%23444053'%20d='M147.73%20137.05h636.92v21.02H147.73z'%20opacity='.1'/%3e%3crect%20width='191.9'%20height='12.79'%20x='368.87'%20y='140.71'%20fill='%236c63ff'%20opacity='.3'%20rx='.58'/%3e%3cpath%20fill='%233f3d56'%20d='M555.07%20148.43h-.47l-.17-.15a3.89%203.89%200%200%200%20.9-2.49%203.78%203.78%200%201%200-3.77%203.81%203.9%203.9%200%200%200%202.49-.91l.17.15v.47l2.93%202.93.87-.88Zm-3.51%200a2.64%202.64%200%201%201%202.63-2.64%202.62%202.62%200%200%201-2.63%202.64Z'/%3e%3ccircle%20cx='159.18'%20cy='147.56'%20r='3.85'%20fill='%23fa5959'%20opacity='.8'/%3e%3ccircle%20cx='169.77'%20cy='147.56'%20r='3.85'%20fill='%23fed253'%20opacity='.8'/%3e%3ccircle%20cx='180.37'%20cy='147.56'%20r='3.85'%20fill='%238ccf4d'%20opacity='.8'/%3e%3cpath%20fill='%236c63ff'%20d='M500.05%20291.4c-8.73-11.6-21.38-18.92-35.46-18.92s-26.73%207.32-35.46%2018.92a38.39%2038.39%200%200%200%208.4%2012.65%2038.28%2038.28%200%200%200%2062.52-12.65Z'/%3e%3cpath%20fill='%236c63ff'%20d='M424.52%20298.19a9.17%209.17%200%200%201-1.76-1%207.06%207.06%200%200%201-1.94-2.51%207.18%207.18%200%201%200-11.72%201.74%208%208%200%200%200%201.7%201.37%204.94%204.94%200%200%201%201.91%202%2014.44%2014.44%200%200%200%203.32%204.36%2029%2029%200%200%200%204.55%203.2%2066.31%2066.31%200%200%200-3.74%2019.56%2027.05%2027.05%200%200%200-7.62%201.23%2012.29%2012.29%200%200%200-3.53%201.76%208.48%208.48%200%200%200-.87-.06%207.19%207.19%200%201%200%206.73%209.72%204.59%204.59%200%200%201%203.71-3%2016.75%2016.75%200%200%201%201.85-.12%2064.4%2064.4%200%200%200%208.55%2026.67c-4.24%203.29-6.85%206.88-7.95%2010.86a3%203%200%200%200-.57.41%206.81%206.81%200%200%200-.84.78%207.18%207.18%200%201%200%2012.05%202.35%204.71%204.71%200%200%201%201.17-5.08c.48-.45%201-.93%201.7-1.46%208.11%209.47%2017.76%2015.54%2029.81%2016.26v-64.25c-15.93-.87-29.81-11.24-36.51-24.79Zm99.83%2031.72a7.93%207.93%200%200%200-.87.06%2013.56%2013.56%200%200%200-3.53-1.76%2026.86%2026.86%200%200%200-7.62-1.23%2067.76%2067.76%200%200%200-3.74-19.55%2029%2029%200%200%200%204.55-3.2%2015.58%2015.58%200%200%200%203.44-4.57%204.22%204.22%200%200%201%201.77-1.75%207.18%207.18%200%201%200-10-3.17%206.82%206.82%200%200%201-1.94%202.51%2018.85%2018.85%200%200%201-1.76%201.29c-6.7%2013.54-20.57%2023.62-36.48%2024.49v64.31c12-.72%2021.71-6.82%2029.81-16.26.63.5%201.16.95%201.61%201.37a4.86%204.86%200%200%201%201.26%205.23%207.18%207.18%200%201%200%2012.08-2.33%206.81%206.81%200%200%200-.84-.78c-.33-.26-.57-.41-.57-.41-1.1-4-3.7-7.57-8-10.86a64.4%2064.4%200%200%200%208.55-26.67%2015.9%2015.9%200%200%201%201.77.12%204.8%204.8%200%200%201%203.85%203%207.18%207.18%200%200%200%2013.85-2.18%207.29%207.29%200%200%200-7.19-7.66Z'/%3e%3cpath%20fill='url(%23a)'%20d='M769.65%20802.31a9.56%209.56%200%200%200-2.17-2.41c-4.37-4.13-6.4-10.19-7.48-16.13s-1.39-12-3.12-17.81a58.74%2058.74%200%200%200-3.52-8.67c-1-2.14-2.26-6.33-4.09-7.83a2.7%202.7%200%200%200-1.26-.61%2014.85%2014.85%200%200%200-3.62-4.82c-2.86-2.59-6.35-4.65-8.26-8a18%2018%200%200%200-1.93-3.29c-1.29-1.42-3.33-2-4.52-3.5-1.55-1.94-1.2-4.72-1-7.19s0-5.43-2.14-6.73c-1.28-.79-2.93-.71-4.26-1.41-2-1-2.79-3.52-2.75-5.77s.74-4.44.92-6.69c.56-7.16-4.16-14.28-2.34-21.22.69-2.63%202.27-4.91%203.44-7.36a15.37%2015.37%200%200%200%201-2.54%2035.73%2035.73%200%200%200%209.74%202.35c-5.51-12.36-4.11-26.72-6.68-40l.33-.45a20.84%2020.84%200%200%200%204.22-11.86c0-4.94-2.31-9.56-3.35-14.4-.89-4.11-.85-8.41-2-12.45a37.65%2037.65%200%200%200-3.16-7.22q-1.87-3.47-3.93-6.83-1.92-6.36-3.85-12.72c-1.8-5.95-3.65-12-7.15-17.14-1.28-1.88-1.67-5.7-3.64-6.84a8.81%208.81%200%200%200-5.2-.91c-2.78-1.56-5.22-3.81-5.57-6.89a6.68%206.68%200%200%201%20.2-2h.34c4.4-.4%206.63-4.28%208.92-7.68%203.7-5.5%202.29-12.94%200-19.2a13%2013%200%200%200-3-5.29c-3.21-3-8.29-2.34-12.43-3.79-1.39-.48-2.69-1.21-4.11-1.55-2.75-.64-5.63.26-8.15%201.53s-4.87%202.91-7.51%203.91-5.9%201.79-6.55%204.5a5%205%200%200%200%20.22%202.73%2010.18%2010.18%200%200%200%203.09%204.46%2017.81%2017.81%200%200%200%2010.87%2024.82%2051.01%2051.01%200%200%201%202.12%203.73c1.16%202.24%202.14%204.88%201.74%207.28a22.45%2022.45%200%200%200-2%202.45c-2.87%204-4.5%208.69-6%2013.37a141.65%20141.65%200%200%200-4.83%2018.27c-2.44%205.19-5.42%2010.15-7.19%2015.6a35.21%2035.21%200%200%201-9.38-1.26l-8.44-1.91c-2.94-.67-6-1.39-8.3-3.33-1.22-1-2.17-2.33-3.41-3.32s-3.73-2.15-5.09-1.33a4%204%200%200%200-.69.53c-1.24-2.51-2.42-5-3.86-7.43-2.07-3.4-5.15-6.51-9.05-7.16a9.21%209.21%200%200%200-6.79%201.58c-2.28%201.62-3.71%205-2%207.28a13.29%2013.29%200%200%200%201.39%201.42%2029.2%2029.2%200%200%201%203.09%204.29%2021.91%2021.91%200%200%200%2013.49%208.76l-.35%201c-.71%202.08-2.22%204.59-1.84%206.75l37.54%2012.85a23.13%2023.13%200%200%200%207.56%201.67%2012.21%2012.21%200%200%200%203-.4v2c.1%2013.19-2%2026.29-2.39%2039.47-.07%202.41%200%205%201.52%206.88%201.7%202.06%204.72%202.47%207.35%202q.95-.16%201.86-.42a69.33%2069.33%200%200%201%201.92%2010.11l2.48%2017.86a27.14%2027.14%200%200%201%20.39%205.54c-.29%204.19-2.5%207.94-4.1%2011.81s-2.55%208.5-.45%2012.12c.66%201.12%201.57%202.07%202.16%203.23a13.14%2013.14%200%200%201%201%205.68q.23%208.08.44%2016.18a1.83%201.83%200%200%200-1.26.25c-2.08%201.62-1.85%209.33-2%2011.72-.16%204%200%208.08-.22%2012.12a72.22%2072.22%200%200%201-2.61%2016.09%2010.29%2010.29%200%200%201-2.29%204.61%209.74%209.74%200%200%201-4.07%202.11%2046.49%2046.49%200%200%201-15.41%202.1c-2.11-.07-4.31-.27-6.27.53s-3.54%203-2.83%205c.61%201.68%202.46%202.48%204.13%203.11a65.53%2065.53%200%200%201%2011%205.06%2029.74%2029.74%200%200%200%204.25%202.41%2021.91%2021.91%200%200%200%204.38%201.08l17.73%203.06c3.63.62%208%201%2010.31-2%201.25-1.62%201.43-3.82%201.37-5.88-.1-4-.9-8.07-.38-12.07a37.14%2037.14%200%200%201%201.86-6.93q2.65-7.87%205.32-15.73c1.78-5.26%203.58-10.57%204.27-16.09.25-2%20.23-4.28-1.3-5.53a3.54%203.54%200%200%200-1.32-.68c-.06-4.82-.69-9.65-.42-14.47.07-1.2.19-2.4.29-3.61a17.61%2017.61%200%200%201%202.47%202.92c1.71%202.68%202.34%206.22%204.95%208%202.22%201.52%205.51%201.44%207.07%203.64a10.26%2010.26%200%200%201%201.12%202.71%2019.32%2019.32%200%200%200%204%206.35%2032%2032%200%200%200%202.47%206.34q2.21%204.67%204.4%209.31a108.59%20108.59%200%200%200%205%209.77%2027.55%2027.55%200%200%201%203.35%206.46c1.41%204.94-.89%2010.36-4.53%2014s-8.44%205.73-13.17%207.68a3.71%203.71%200%200%200-1.34.8%202.59%202.59%200%200%200-.61%201.74c0%202.31%201.9%204.29%204.08%205a15.26%2015.26%200%200%200%206.83.25c12.78-1.55%2025.52-4.67%2036.82-10.88a13%2013%200%200%200%204.39-3.39%205.13%205.13%200%200%200%20.73-5.21Z'%20transform='translate(-88.65%20-57.09)'/%3e%3cpath%20fill='%232f2e41'%20d='M626.99%20520.97q3.2%204.91%206%2010.06a37%2037%200%200%201%203.17%207.17c1.16%204%201.13%208.27%202%2012.35%201%204.8%203.34%209.38%203.34%2014.3a20.56%2020.56%200%200%201-4.22%2011.76%2055.82%2055.82%200%200%201-8.82%209.1%20187.62%20187.62%200%200%201-12.48-61.21c-.1-2.9-.12-5.89.94-8.6.65-1.7%203.77-6.36%205.78-4.53.73.67.92%203.69%201.37%204.7a36.13%2036.13%200%200%200%202.92%204.9Z'/%3e%3cpath%20d='M626.99%20520.97q3.2%204.91%206%2010.06a37%2037%200%200%201%203.17%207.17c1.16%204%201.13%208.27%202%2012.35%201%204.8%203.34%209.38%203.34%2014.3a20.56%2020.56%200%200%201-4.22%2011.76%2055.82%2055.82%200%200%201-8.82%209.1%20187.62%20187.62%200%200%201-12.48-61.21c-.1-2.9-.12-5.89.94-8.6.65-1.7%203.77-6.36%205.78-4.53.73.67.92%203.69%201.37%204.7a36.13%2036.13%200%200%200%202.92%204.9Z'%20opacity='.1'/%3e%3cpath%20fill='%23d0d2d5'%20d='M363.35%20384.54c-7.91%207.9-8.86%2011.38-13.61%2012.95s-21.84%2010.42-16.47%2020.23l14.44%209.54.42.28%202.21%206.64-21.84%2038.88s-36-16.46-39.53%207.89-1.29%2031-2.24%2044%20.31%2016.76-2.86%2016.76-4.42-8.54-4.42-8.54-.2-.39-.55-1.12c-4.71-9.79-36.68-81.66%2014.53-131.06%200%200%2023.72-1.56%2029.43-28.76%203.94-18.8%2017.72-17.18%2026.88-13.35a30.38%2030.38%200%200%201%208.22%204.83%2040.48%2040.48%200%200%201%205.89%207c2.61%204.12%204.03%209.29-.5%2013.83Z'/%3e%3cpath%20d='m348.13%20427.54%202.21%206.64-21.84%2038.88s-36-16.46-39.53%207.89-1.29%2031-2.24%2044%20.31%2016.76-2.86%2016.76-4.42-8.54-4.42-8.54-.2-.39-.55-1.12c-1.59-12.16-9.65-83.29%2019.57-79.51%200%200%2023.71%2011.08%2027.5%206.66%203-3.5%2016.32-23.63%2021.74-31.89ZM363.85%20370.65l-14.44%2016.41s-16.77%2022.44-20.25%2021.49a16.23%2016.23%200%200%200-3.17-.37%206.16%206.16%200%200%201-4-10.38c5.72-6%2016.26-17.39%2016.95-19.92s7.4-13.62%2010.76-19.05a30.38%2030.38%200%200%201%208.22%204.83%2040.48%2040.48%200%200%201%205.93%206.99Z'%20opacity='.1'/%3e%3cpath%20fill='%23454b69'%20d='M772.41%20606.74c-2.45%204.9-15%2023.28-20.49%2031.31l-2.57%203.78s-1%206.64-17.39-1.59-401.48-170.72-401.48-170.72l-2.61-7.84%2019-28.45L768.94%20596.3s6.64%204.11%203.47%2010.44Z'/%3e%3cpath%20d='m751.92%20638.05-2.57%203.78s-1%206.64-17.39-1.59-401.48-170.72-401.48-170.72l-2.61-7.84Z'%20opacity='.1'/%3e%3cpath%20fill='%23fbbebe'%20d='M519.64%20531.91c-3.91-.64-8.25-.33-11.29%202.21a9.29%209.29%200%200%200-3.24%206.16c-.26%202.77%201.35%206.06%204.13%206.27a13.17%2013.17%200%200%200%202-.13%2029.89%2029.89%200%200%201%205.24.44%2021.39%2021.39%200%200%200%2018.23-7.36c2.39-3-.76-4.3-3.58-4.9-3.86-.82-7.63-2.07-11.49-2.69Z'/%3e%3cpath%20fill='%233f3d56'%20d='m586.52%20622.22%202.48%2017.62a26.84%2026.84%200%200%201%20.38%205.51c-.29%204.15-2.5%207.87-4.09%2011.71s-2.56%208.44-.45%2012c.65%201.11%201.56%202.06%202.15%203.21a12.92%2012.92%200%200%201%201%205.63l.68%2025a157.33%20157.33%200%200%200%2023.18-.13%201.29%201.29%200%200%200%20.84-.26%201.36%201.36%200%200%200%20.29-.91c.34-5.85-.68-11.71-.35-17.56.12-2.14.42-4.27.46-6.42.12-8.71-4.18-17.24-2.88-25.85a57%2057%200%200%201%201.6-6.43c4.11-15%203.24-30.76%202.33-46.25a1.09%201.09%200%200%200-.2-.7%201.06%201.06%200%200%200-.54-.29%2028.45%2028.45%200%200%200-25.78%204.9c-1.09.88-3.84%201.73-4.56%202.78-1%201.46.31%202.92.89%204.47a56.89%2056.89%200%200%201%202.57%2011.97Z'/%3e%3cpath%20d='m586.52%20622.22%202.48%2017.62a26.84%2026.84%200%200%201%20.38%205.51c-.29%204.15-2.5%207.87-4.09%2011.71s-2.56%208.44-.45%2012c.65%201.11%201.56%202.06%202.15%203.21a12.92%2012.92%200%200%201%201%205.63l.68%2025a157.33%20157.33%200%200%200%2023.18-.13%201.29%201.29%200%200%200%20.84-.26%201.36%201.36%200%200%200%20.29-.91c.34-5.85-.68-11.71-.35-17.56.12-2.14.42-4.27.46-6.42.12-8.71-4.18-17.24-2.88-25.85a57%2057%200%200%201%201.6-6.43c4.11-15%203.24-30.76%202.33-46.25a1.09%201.09%200%200%200-.2-.7%201.06%201.06%200%200%200-.54-.29%2028.45%2028.45%200%200%200-25.78%204.9c-1.09.88-3.84%201.73-4.56%202.78-1%201.46.31%202.92.89%204.47a56.89%2056.89%200%200%201%202.57%2011.97Z'%20opacity='.1'/%3e%3cpath%20fill='%233f3d56'%20d='M632.89%20616.91c-1.17%202.43-2.74%204.69-3.44%207.3-1.82%206.89%202.89%2014%202.33%2021.06-.18%202.23-.87%204.4-.92%206.63s.77%204.71%202.75%205.74c1.33.68%203%20.61%204.25%201.39%202.11%201.29%202.35%204.22%202.14%206.68s-.56%205.21%201%207.13c1.19%201.49%203.23%202.07%204.51%203.48a17.17%2017.17%200%200%201%201.93%203.26c1.91%203.34%205.4%205.38%208.26%208s5.28%206.46%204%2010.09c-.94%202.66-3.58%204.3-6.12%205.55a64.93%2064.93%200%200%201-14.57%205.15%203.52%203.52%200%200%201-1.67.09%203.57%203.57%200%200%201-1.46-1c-2.95-2.89-6-5.92-7.36-9.81a10.07%2010.07%200%200%200-1.12-2.68c-1.56-2.19-4.85-2.11-7.07-3.62-2.6-1.77-3.23-5.28-4.93-7.93s-4.19-4.23-6-6.56c-3.06-3.88-3.81-9.06-6-13.49-.93-1.88-2.12-3.64-2.86-5.6a30.58%2030.58%200%200%201-1.37-7.24c-1.41-11.68-5-23.44-2.74-35%20.5-2.54%201.27-5%201.59-7.62.55-4.53-.32-9.17.35-13.69a3.77%203.77%200%200%201%201.51-2.91%204%204%200%200%201%201.72-.35%20117.28%20117.28%200%200%201%2017.78.4c3%20.29%206.36.9%208.16%203.35%201.53%202.1%201.45%204.91%201.94%207.46.61%203.14%202.2%204.85%203.87%207.31s.77%204.89-.46%207.43Z'/%3e%3cpath%20fill='%232f2e41'%20d='M609.82%20698.17c1.58%200%203.33-.1%204.55.9%201.52%201.25%201.54%203.54%201.3%205.49-.7%205.48-2.49%2010.75-4.28%2016l-5.32%2015.61a36.65%2036.65%200%200%200-1.86%206.88c-.52%204%20.28%208%20.38%2012%200%202-.13%204.22-1.38%205.83-2.26%202.91-6.67%202.57-10.3%202l-17.71-3a21.07%2021.07%200%200%201-4.38-1.07%2030.61%2030.61%200%200%201-4.25-2.39%2065.42%2065.42%200%200%200-11-5c-1.66-.62-3.52-1.41-4.12-3.08-.71-2%20.87-4.2%202.83-5s4.15-.6%206.27-.54a47%2047%200%200%200%2015.4-2.08%209.74%209.74%200%200%200%204.06-2.1%2010%2010%200%200%200%202.34-4.71%2070.17%2070.17%200%200%200%202.68-16c.21-4%20.07-8%20.23-12%20.1-2.37-.13-10%201.95-11.63%201.59-1.22%208.13%202.15%2010.28%202.64a50%2050%200%200%200%2012.33%201.25ZM668.16%20709.29c1.73%205.73%202%2011.79%203.12%2017.68s3.1%2011.9%207.47%2016a9.87%209.87%200%200%201%202.17%202.4%205.06%205.06%200%200%201-.75%205.23%2013.13%2013.13%200%200%201-4.39%203.37c-11.29%206.16-24%209.27-36.81%2010.81a15.51%2015.51%200%200%201-6.82-.25c-2.18-.74-4.11-2.7-4.07-5a2.55%202.55%200%200%201%20.6-1.73%203.73%203.73%200%200%201%201.35-.79c4.72-1.94%209.51-4.05%2013.16-7.63s5.94-9%204.53-13.86a27.42%2027.42%200%200%200-3.37-6.41%20108.35%20108.35%200%200%201-5-9.69l-4.4-9.23c-1.29-2.7-2.59-5.48-2.81-8.46a40.6%2040.6%200%200%200%2016.22-2.6%2025.51%2025.51%200%200%200%206.67-4c1.7-1.42%203.25-4.07%205.54-2.22%201.84%201.48%203%205.65%204.08%207.76a57%2057%200%200%201%203.51%208.62Z'/%3e%3cpath%20fill='%23fbbebe'%20d='M603.68%20480.1c.44%203.84%204.16%206.37%207.71%207.89l-22.47%207.17c1.45-2.78.28-6.18-1.16-9a50.93%2050.93%200%200%200-4-6.41c-.22-.31-.47-.7-.31-1.06a1.12%201.12%200%200%201%20.63-.49c4.62-2.06%209.38-4.19%2014.43-4.94%201.46-.21%204.22-.79%205.31.69s-.35%204.38-.14%206.15Z'/%3e%3cpath%20d='M603.68%20480.1c.44%203.84%204.16%206.37%207.71%207.89l-22.47%207.17c1.45-2.78.28-6.18-1.16-9a50.93%2050.93%200%200%200-4-6.41c-.22-.31-.47-.7-.31-1.06a1.12%201.12%200%200%201%20.63-.49c4.62-2.06%209.38-4.19%2014.43-4.94%201.46-.21%204.22-.79%205.31.69s-.35%204.38-.14%206.15Z'%20opacity='.1'/%3e%3ccircle%20cx='590.62'%20cy='465.59'%20r='17.62'%20fill='%23fbbebe'/%3e%3cpath%20fill='%232f2e41'%20d='M575.35%20610.59c1.71%202.05%204.72%202.45%207.35%202%206.15-1%2011.18-5.53%2017.2-7.16%207.38-2%2015.19.57%2022.16%203.72s13.9%207%2021.52%207.54c-6.89-15.36-2.95-33.84-9.54-49.33-1.61-3.79-3.86-7.44-4.22-11.54-.45-5.09%202.09-10%202.48-15.06.36-4.51-1-9-2.3-13.3l-4.82-15.84c-1.8-5.91-3.65-11.92-7.14-17-1.29-1.87-1.68-5.66-3.64-6.79-4.28-2.47-10.77.64-15.41.81s-8.87%203.47-11.58%207.2c-2.87%203.94-4.5%208.63-6%2013.27a126.15%20126.15%200%200%200-5.33%2021.23c-.15%201.08-.28%202.16-.38%203.25-1%2010.27.46%2020.6.54%2030.92v.07c.1%2013.09-2%2026.1-2.39%2039.18-.04%202.39.02%205%201.5%206.83Z'/%3e%3cpath%20d='M576.27%20564.52c3.45-.87%206.57-3.1%209.25-5.54a38.67%2038.67%200%200%200%206.14-7%2049.86%2049.86%200%200%200%205.29-11.07%20129.36%20129.36%200%200%200%207-32.27c.26-3%20.34-6.22-1.45-8.6a7.24%207.24%200%200%200-8.75-2.12c-2.36%201.15-3.89%203.48-5.31%205.71-2.81%204.42-5.64%208.9-7.45%2013.82-.8%202.18-1.39%204.42-2.17%206.61a61%2061%200%200%201-2.74%206.33c-.15%201.08-.28%202.16-.38%203.25-.93%2010.27.49%2020.56.57%2030.88Z'%20opacity='.1'/%3e%3cpath%20fill='%232f2e41'%20d='M602.45%20498.11c1.79%202.38%201.71%205.63%201.46%208.59a129.18%20129.18%200%200%201-7%2032.27%2049.43%2049.43%200%200%201-5.29%2011.16%2039.07%2039.07%200%200%201-6.14%207c-3.4%203.1-7.54%205.87-12.15%205.91a23.16%2023.16%200%200%201-7.56-1.65l-37.55-12.78c-.38-2.14%201.13-4.64%201.84-6.7l2-5.93c.57-1.64%201.23-3.41%202.72-4.3s3.85.33%205.09%201.32%202.18%202.29%203.4%203.3c2.31%201.92%205.36%202.64%208.3%203.3l8.43%201.89a35.2%2035.2%200%200%200%209.38%201.25c2.35-7.18%206.82-13.5%209.35-20.62.78-2.18%201.37-4.43%202.18-6.61%201.8-4.92%204.64-9.39%207.45-13.82%201.41-2.22%202.94-4.55%205.31-5.71a7.23%207.23%200%200%201%208.78%202.13ZM596.24%20469.57a8.89%208.89%200%200%200-1.06-3.3%202.77%202.77%200%200%200-3-1.32c-1.76.55-2.35%203.27-4.19%203.36-1.24.06-2.13-1.2-2.52-2.38s-.6-2.53-1.53-3.36a5.7%205.7%200%200%200-2.18-1c-4.27-1.35-8.68-3.84-10.1-8.09a4.84%204.84%200%200%201-.23-2.71c.65-2.69%204-3.5%206.55-4.47s5-2.63%207.5-3.89%205.4-2.15%208.15-1.51a42.47%2042.47%200%200%201%204.11%201.53c4.14%201.44%209.21.77%2012.42%203.76a12.83%2012.83%200%200%201%203%205.24c2.24%206.22%203.66%2013.6-.05%2019.06-2.29%203.37-4.51%207.22-8.91%207.63-5.12.43-7.15-4.21-7.96-8.55Z'/%3e%3cg%20opacity='.1'%3e%3cpath%20d='M588.42%20463.81c-.39-1.18-.6-2.53-1.52-3.36a5.7%205.7%200%200%200-2.18-1c-4.28-1.35-8.68-3.84-10.11-8.09a4.93%204.93%200%200%201-.22-2.71%203.39%203.39%200%200%201%20.53-1.19c-1.63.71-3.05%201.65-3.45%203.31a4.84%204.84%200%200%200%20.23%202.71c1.42%204.25%205.83%206.74%2010.1%208.09a5.7%205.7%200%200%201%202.18%201c.93.83%201.13%202.17%201.53%203.36s1.28%202.44%202.52%202.38%201.84-1.19%202.63-2.14c-1.09-.14-1.88-1.26-2.24-2.36ZM607.14%20475.97c-5.14.47-7.17-4.21-8-8.52a8.7%208.7%200%200%200-1-3.3%202.78%202.78%200%200%200-3-1.32%205.32%205.32%200%200%200-2.21%202%203%203%200%200%201%202.26%201.4%208.89%208.89%200%200%201%201.06%203.3c.81%204.31%202.84%209%208%208.52a8.25%208.25%200%200%200%205.28-2.74%207.46%207.46%200%200%201-2.39.66Z'/%3e%3c/g%3e%3cellipse%20cx='813.11'%20cy='655.78'%20fill='%236c63ff'%20rx='32.29'%20ry='6.21'/%3e%3cellipse%20cx='812.57'%20cy='653.14'%20fill='%233f3d56'%20rx='3.76'%20ry='4.92'/%3e%3cellipse%20cx='812.57'%20cy='647.12'%20fill='%233f3d56'%20rx='3.76'%20ry='4.92'/%3e%3cellipse%20cx='812.57'%20cy='641.11'%20fill='%233f3d56'%20rx='3.76'%20ry='4.92'/%3e%3cellipse%20cx='812.57'%20cy='635.09'%20fill='%233f3d56'%20rx='3.76'%20ry='4.92'/%3e%3cellipse%20cx='812.57'%20cy='629.07'%20fill='%233f3d56'%20rx='3.76'%20ry='4.92'/%3e%3cellipse%20cx='812.57'%20cy='623.06'%20fill='%233f3d56'%20rx='3.76'%20ry='4.92'/%3e%3cellipse%20cx='812.57'%20cy='617.04'%20fill='%233f3d56'%20rx='3.76'%20ry='4.92'/%3e%3cpath%20fill='%236c63ff'%20d='M826.64%20575.91a18.19%2018.19%200%200%200%201.4-2.06l-9.88-1.62%2010.69.07a18.11%2018.11%200%200%200%20.34-14.27l-14.34%207.44%2013.22-9.72a18%2018%200%201%200-29.72%2020.16%2017.92%2017.92%200%200%200-2.06%203.28l12.83%206.67-13.68-4.59a18%2018%200%200%200%202.91%2016.88%2018%2018%200%201%200%2028.31%200%2018%2018%200%200%200%200-22.27Z'/%3e%3cpath%20d='M794.47%20587.01a17.91%2017.91%200%200%200%203.88%2011.14%2018%2018%200%201%200%2028.31%200c2.39-3.07-32.19-13.16-32.19-11.14Z'%20opacity='.1'/%3e%3cellipse%20cx='148.42'%20cy='776.87'%20fill='%236c63ff'%20rx='46.49'%20ry='8.94'/%3e%3cellipse%20cx='147.64'%20cy='773.07'%20fill='%233f3d56'%20rx='5.41'%20ry='7.09'/%3e%3cellipse%20cx='147.64'%20cy='764.41'%20fill='%233f3d56'%20rx='5.41'%20ry='7.09'/%3e%3cellipse%20cx='147.64'%20cy='755.75'%20fill='%233f3d56'%20rx='5.41'%20ry='7.09'/%3e%3cellipse%20cx='147.64'%20cy='747.09'%20fill='%233f3d56'%20rx='5.41'%20ry='7.09'/%3e%3cellipse%20cx='147.64'%20cy='738.43'%20fill='%233f3d56'%20rx='5.41'%20ry='7.09'/%3e%3cellipse%20cx='147.64'%20cy='729.76'%20fill='%233f3d56'%20rx='5.41'%20ry='7.09'/%3e%3cellipse%20cx='147.64'%20cy='721.1'%20fill='%233f3d56'%20rx='5.41'%20ry='7.09'/%3e%3cpath%20fill='%236c63ff'%20d='M167.9%20661.84a27.23%2027.23%200%200%200%202-3l-14.22-2.34%2015.38.12a26%2026%200%200%200%20.49-20.55l-20.62%2010.74%2019-14a25.93%2025.93%200%201%200-42.83%2029%2025.83%2025.83%200%200%200-3%204.72l18.47%209.6-19.69-6.61a25.93%2025.93%200%200%200%204.26%2024.39%2025.93%2025.93%200%201%200%2040.76%200%2025.92%2025.92%200%200%200%200-32.06Z'/%3e%3cpath%20d='M121.59%20677.91a25.85%2025.85%200%200%200%205.55%2016%2025.93%2025.93%200%201%200%2040.76%200c3.45-4.42-46.31-18.95-46.31-16Z'%20opacity='.1'/%3e%3c/svg%3e";
})), ur, dr, fr, pr, mr = w((() => {
	ur = "side-navigation", dr = "top-navigation", fr = "two-column-navigation", pr = "mixed-navigation";
}));
//#endregion
//#region src/utils/get-app-info/index.ts
function hr() {
	return {
		pkg: {
			name: "@oj-module/runtime",
			version: "0.2.71",
			license: "MIT"
		},
		lastBuildTime: "2026-11-07 11:30:02"
	};
}
var gr = w((() => {}));
//#endregion
//#region src/utils/get-app-namespace/index.ts
function _r(e) {
	return `${`react-antd-admin-${hr().pkg.version || "unknown"}-prod`}-${e}`;
}
var vr = w((() => {
	gr();
})), yr, E, D = w((() => {
	mr(), vr(), yr = {
		watermark: !1,
		watermarkContent: "react-antd-admin",
		enableBackTopButton: !0,
		pageLayout: "layout-right",
		enableBackendAccess: !0,
		enableFrontendAceess: !1,
		language: "zh-CN",
		enableDynamicTitle: !0,
		enableCheckUpdates: !0,
		checkUpdatesInterval: 1,
		theme: "auto",
		colorBlindMode: !1,
		colorGrayMode: !1,
		themeRadius: 6,
		builtinTheme: "blue",
		themeColorPrimary: "#1677ff",
		transitionProgress: !0,
		transitionLoading: !0,
		transitionEnable: !0,
		transitionName: "fade-slide",
		navigationStyle: ur,
		tabbarEnable: !0,
		tabbarShowIcon: !0,
		tabbarPersist: !0,
		tabbarDraggable: !0,
		tabbarStyleType: "chrome",
		tabbarShowMore: !0,
		tabbarShowMaximize: !0,
		sidebarEnable: !0,
		sidebarWidth: 210,
		sideCollapsedWidth: 56,
		sidebarCollapsed: !1,
		sidebarCollapseShowTitle: !0,
		sidebarExtraCollapsedWidth: 48,
		firstColumnWidthInTwoColumnNavigation: 80,
		sidebarTheme: "light",
		accordion: !0,
		enableFooter: !0,
		fixedFooter: !0,
		companyName: "Omni Solution",
		companyWebsite: "http://github.com/everpan",
		copyrightDate: "2026",
		ICPNumber: "",
		ICPLink: ""
	}, E = t()(n((e) => ({
		...yr,
		setPreferences: (...t) => {
			if (t.length === 1) {
				let n = t[0];
				e(() => ({ ...n }));
			} else if (t.length === 2) {
				let [n, r] = t;
				e(() => ({ [n]: r }));
			}
		},
		changeSiteTheme: (t) => {
			e(() => ({ theme: t }));
		},
		changeLanguage: (t) => {
			e(() => ({ language: t }));
		},
		reset: () => {
			e(() => ({ ...yr }));
		}
	}), { name: _r("preferences") }));
}));
//#endregion
//#region src/components/page-error/index.tsx
function br({ error: e, resetErrorBoundary: t }) {
	let n = u(), { t: r } = b(), i = E((e) => e.enableDynamicTitle);
	return v(() => {
		i && (document.title = r("exception.pageErrorTitle"));
	}, [i, r]), /* @__PURE__ */ S(ut, {
		status: "error",
		icon: /* @__PURE__ */ S("div", {
			className: "w-7/12 md:w-3/12 xl:w-2/12 inline-block",
			children: /* @__PURE__ */ S("img", {
				src: cr,
				alt: "",
				className: "w-full"
			})
		}),
		title: e?.message ?? r("exception.pageErrorTitle"),
		extra: /* @__PURE__ */ C(mt, {
			size: 20,
			children: [/* @__PURE__ */ S(Ke, {
				icon: /* @__PURE__ */ S(ne, {}),
				type: "primary",
				onClick: () => {
					t(), n(xr);
				},
				children: r("common.backHome")
			}), /* @__PURE__ */ S(Ke, {
				icon: /* @__PURE__ */ S(De, { rotate: 90 }),
				onClick: () => {
					location.reload();
				},
				children: r("common.refresh")
			})]
		}),
		children: /* @__PURE__ */ S(xt.Paragraph, {
			type: "warning",
			className: "text-center",
			children: e?.stack
		})
	});
}
var xr, Sr = w((() => {
	lr(), D(), {VITE_BASE_HOME_PATH: xr} = { VITE_BASE_HOME_PATH: "/home" };
}));
//#endregion
//#region src/utils/is-dark-theme/index.ts
function Cr(e) {
	let t = e === "dark";
	return e === "auto" && (t = window.matchMedia("(prefers-color-scheme: dark)").matches), t;
}
var wr = w((() => {}));
//#endregion
//#region src/utils/is-light-theme/index.ts
function Tr(e) {
	let t = e === "light";
	return e === "auto" && (t = window.matchMedia("(prefers-color-scheme: light)").matches), t;
}
var Er = w((() => {}));
//#endregion
//#region src/hooks/use-preferences/index.ts
function Dr() {
	let e = E(), { theme: t } = e, n = y(() => Object.entries(yr).every(([t, n]) => e[t] === n), [e]);
	return {
		...e,
		isDefault: n,
		isDark: Cr(t),
		isLight: Tr(t)
	};
}
var Or = w((() => {
	D(), wr(), Er();
})), kr, Ar, jr, Mr, Nr, Pr, Fr, Ir, Lr, Rr, zr, Br, Vr, Hr, Ur, Wr, Gr, Kr, qr, Jr, Yr, Xr, Zr, Qr, $r, ei, ti, ni, ri, ii, ai, oi, si, ci = w((() => {
	kr = "欢迎回来", Ar = "请输入帐户信息开始管理项目", jr = "开箱即用的中后台管理系统", Mr = "简单、轻量、易于使用", Nr = {
		alignLeft: "左对齐",
		alignCenter: "居中对齐",
		alignRight: "右对齐"
	}, Pr = "用户名", Fr = "密码", Ir = "登录", Lr = "登录中...", Rr = "登录成功", zr = "验证码登录", Br = "忘记密码", Vr = "{{ count }} 秒后重试", Hr = "验证码", Ur = "手机号码", Wr = "手机号登录", Gr = "获取验证码", Kr = "{{ second }} 秒后重新获取", qr = "输入您的电子邮件，我们将向您发送重置密码的连接", Jr = "邮箱", Yr = "发送重置链接", Xr = "退出登录", Zr = "注册", Qr = "已有账号？", $r = "去登录", ei = "去注册", ti = "还没有账号？", ni = "确认密码", ri = "确认退出登录吗？", ii = "我已阅读并同意《<0>隐私政策</0>》和《<1>服务条款</1>》", ai = "隐私政策", oi = "服务条款", si = {
		welcomeBack: kr,
		loginDescription: Ar,
		pageTitle: jr,
		pageDescription: Mr,
		layout: Nr,
		username: Pr,
		password: Fr,
		login: Ir,
		loginInProgress: Lr,
		loginSuccess: Rr,
		codeLogin: zr,
		forgotPassword: Br,
		retryAfterText: Vr,
		code: Hr,
		mobile: Ur,
		mobileLogin: Wr,
		sendCode: Gr,
		sendText: Kr,
		forgotPasswordSubtitle: qr,
		email: Jr,
		sendResetLink: Yr,
		logout: Xr,
		register: Zr,
		alreadyHaveAnAccount: Qr,
		goToLogin: $r,
		goToRegister: ei,
		noAccountYet: ti,
		confirmPassword: ni,
		logoutConfirm: ri,
		agree: ii,
		privacyPolicy: ai,
		termsOfService: oi
	};
})), li, ui, di, fi, pi, mi, hi, gi, _i, vi, yi, bi, xi, Si, Ci, wi, Ti, Ei, Di, Oi, ki, Ai, ji, Mi, Ni, Pi, Fi, Ii, Li, Ri, zi, Bi, Vi, Hi, Ui, Wi, Gi, Ki, qi, Ji, Yi, Xi, Zi, Qi, $i, ea, ta, na, ra, ia, aa, oa, sa, ca, la, ua, da, fa, pa, ma, ha, ga, _a = w((() => {
	li = "资源正在加载中...", ui = "返回", di = "返回首页", fi = "警告", pi = "确认", mi = "失败", hi = "成功", gi = "删除成功", _i = "确认删除吗？", vi = "查看", yi = "编辑", bi = "错误", xi = "序号", Si = "上传", Ci = "更换头像", wi = "{{name}} 上传成功", Ti = "{{name}} 上传失败", Ei = "暂无数据", Di = "操作", Oi = "新增", ki = "添加成功", Ai = "返回首页", ji = "批量删除", Mi = "取消", Ni = "关闭", Pi = "勾选", Fi = "展开列", Ii = "列设置", Li = "配置", Ri = "请输入关键词搜索", zi = "修改", Bi = "修改成功", Vi = "请检查输入的值是否合法", Hi = "刷新", Ui = "重置", Wi = "搜索", Gi = "提示", Ki = "确定执行本次操作?", qi = "触发", Ji = "更新", Yi = "更新成功", Xi = "个人中心", Zi = "名称", Qi = "标识", $i = "状态", ea = "启用", ta = "停用", na = "激活", ra = "禁用", ia = "创建时间", aa = "更新时间", oa = "备注", sa = "仅演示，操作后不生效", ca = "共 {{total}} 条", la = "展开所有", ua = "折叠所有", da = "选择所有", fa = "取消所有", pa = "共 {total} 条", ma = "保存", ha = "删除失败", ga = {
		appLoading: li,
		back: ui,
		backHome: di,
		warning: fi,
		confirm: pi,
		delete: "删除",
		fail: mi,
		success: hi,
		deleteSuccess: gi,
		confirmDelete: _i,
		view: vi,
		edit: yi,
		error: bi,
		index: xi,
		upload: Si,
		avatarChange: Ci,
		uploadSuccess: wi,
		uploadFailed: Ti,
		noData: Ei,
		action: Di,
		add: Oi,
		addSuccess: ki,
		backToHome: Ai,
		batchDelete: ji,
		cancel: Mi,
		close: Ni,
		check: Pi,
		expandColumn: Fi,
		columnSetting: Ii,
		config: Li,
		keywordSearch: Ri,
		modify: zi,
		modifySuccess: Bi,
		pleaseCheckValue: Vi,
		refresh: Hi,
		reset: Ui,
		search: Wi,
		switch: "切换",
		tip: Gi,
		tipMessage: Ki,
		trigger: qi,
		update: Ji,
		updateSuccess: Yi,
		userCenter: Xi,
		yes: "是",
		no: "否",
		name: Zi,
		id: Qi,
		status: $i,
		enabled: ea,
		deactivated: ta,
		activated: na,
		disabled: ra,
		createTime: ia,
		updateTime: aa,
		remark: oa,
		demoOnly: sa,
		pagination: ca,
		expandAll: la,
		collapseAll: ua,
		checkAll: da,
		cancelAll: fa,
		total: pa,
		save: ma,
		deleteFailed: ha
	};
})), va, ya, ba, xa, Sa, Ca = w((() => {
	va = "抱歉，您访问的页面不存在。", ya = "未知组件", ba = "抱歉，当前路由没有对应的组件，请联系开发人员。", xa = "槽糕！出错了！", Sa = {
		notFoundTitle: "404",
		notFoundSubTitle: va,
		unknownComponentTitle: ya,
		unknownComponentSubTitle: ba,
		pageErrorTitle: xa
	};
})), wa, Ta, Ea, Da, Oa, ka, Aa, ja, Ma, Na, Pa, Fa, Ia, La = w((() => {
	wa = "必填项", Ta = "只支持 {{length}} 个字符", Ea = {
		required: "请输入用户名",
		invalid: "4 到 16 位，支持字母、数字、下划线和减号"
	}, Da = {
		required: "请输入密码",
		invalid: "8-16 位必须包含字母和数字"
	}, Oa = { required: "请输入验证码" }, ka = {
		required: "请输入手机号码",
		invalid: "手机号码格式错误"
	}, Aa = {
		required: "请输入座机号码",
		invalid: "座机号码格式错误"
	}, ja = {
		required: "请输入邮箱",
		invalid: "邮箱格式错误"
	}, Ma = {
		required: "请再次输入密码",
		invalid: "两次输入的密码不一致"
	}, Na = { required: "请同意隐私政策和条款" }, Pa = {
		required: "请输入字母或数字",
		invalid: "请输入字母或数字"
	}, Fa = {
		required: "请输入统一社会信用代码",
		invalid: "请输入正确的统一社会信用代码"
	}, Ia = {
		required: wa,
		length: Ta,
		username: Ea,
		password: Da,
		code: Oa,
		mobile: ka,
		telephone: Aa,
		email: ja,
		confirmPassword: Ma,
		agree: Na,
		alphanumeric: Pa,
		unifiedSocialCreditCode: Fa
	};
})), Ra, za, Ba, Va, Ha, Ua, Wa, Ga, Ka, qa, Ja, Ya, Xa, Za = w((() => {
	Ra = "偏好设置", za = "复制偏好设置", Ba = "复制成功", Va = "复制成功，请在 `src/store/preferences/index.ts` 内进行覆盖", Ha = "清空缓存 & 退出登录", Ua = {
		title: "主题",
		followSystem: "跟随系统",
		light: "浅色",
		dark: "深色",
		colorBlindMode: "色弱模式",
		grayMode: "灰色模式",
		radius: "圆角",
		builtin: {
			title: "内置主题",
			red: "薄暮",
			volcano: "火山",
			orange: "日暮",
			gold: "金盏花",
			yellow: "日出",
			lime: "青柠",
			green: "极光绿",
			cyan: "明青",
			blue: "拂晓蓝",
			geekblue: "极客蓝",
			purple: "酱紫",
			magenta: "法式洋红",
			gray: "中性灰",
			custom: "自定义"
		}
	}, Wa = {
		title: "布局",
		topNavigation: "顶部导航",
		topNavigationTip: "菜单在顶部位置",
		sideNavigation: "侧边导航",
		sideNavigationTip: "菜单在侧边位置",
		twoColumnNavigation: "双列导航",
		twoColumnNavigationTip: "垂直双列菜单在侧边位置",
		mixedNavigation: "混合导航",
		mixedNavigationTip: "一级导航在顶部，二级导航在侧边"
	}, Ga = {
		title: "侧边栏",
		width: "宽度",
		enable: "显示侧边栏",
		collapsedWidth: "折叠菜单宽度",
		collapsed: "折叠菜单",
		collapsedShowTitle: "折叠显示菜单名",
		firstColumnWidthInTwoColumnNavigation: "双列导航第一列宽度",
		sidebarTheme: "侧边栏主题",
		accordion: "手风琴菜单",
		autoActivateChild: "自动激活子菜单",
		autoActivateChildTip: "点击顶层菜单时,自动激活第一个子菜单或者上一次激活的子菜单",
		expandOnHover: "鼠标悬停展开",
		expandOnHoverTip: "鼠标在折叠区域悬浮时，`启用`则展开当前子菜单，`禁用`则展开整个侧边栏"
	}, Ka = {
		title: "标签栏",
		enable: "启用标签栏",
		icon: "显示标签栏图标",
		showMore: "显示更多按钮",
		showMaximize: "显示最大化按钮",
		persist: "持久化标签页",
		draggable: "启动拖拽排序",
		styleType: {
			title: "标签页风格",
			chrome: "谷歌",
			card: "卡片",
			plain: "朴素",
			brisk: "轻快"
		},
		contextMenu: {
			refresh: "重新加载",
			close: "关闭",
			pin: "固定",
			unpin: "取消固定",
			closeLeft: "关闭左侧标签页",
			closeRight: "关闭右侧标签页",
			closeOthers: "关闭其它标签页",
			closeAll: "关闭全部标签页",
			openInNewWindow: "在新窗口打开",
			maximize: "最大化",
			restoreMaximize: "还原"
		}
	}, qa = {
		title: "动画",
		loading: "页面切换 Loading",
		transition: "页面切换动画",
		progress: "页面切换进度条"
	}, Ja = {
		title: "通用",
		language: "语言",
		dynamicTitle: "动态标题",
		watermark: "水印",
		watermarkTip: "水印外号网站牛皮癣，不推荐使用",
		watermarkContent: "水印内容",
		enableCheckUpdate: "定时检查更新",
		enableBackTopButton: "显示返回顶部按钮"
	}, Ya = {
		title: "底栏",
		showFooter: "显示底栏",
		fixedFooter: "固定底栏",
		companyName: "公司名称",
		companyWebsite: "公司官网",
		copyrightDate: "版权年份",
		ICPNumber: "ICP 备案号",
		ICPLink: "ICP 备案链接"
	}, Xa = {
		title: Ra,
		copyPreferences: za,
		copyPreferencesSuccessTitle: Ba,
		copyPreferencesSuccess: Va,
		clearAndLogout: Ha,
		theme: Ua,
		layout: Wa,
		sidebar: Ga,
		tabbar: Ka,
		animation: qa,
		general: Ja,
		footer: Ya
	};
})), Qa, $a, eo, to, no, ro, io, ao, oo, so, co, lo, uo, fo, po, mo = w((() => {
	Qa = "文档", $a = "问题 & 帮助", eo = "设置", to = "是否退出登录？", no = "查看所有消息", ro = "通知", io = {
		notice: "通知",
		pm: "私信",
		mention: "@我"
	}, ao = "全部标记为已读", oo = "清空", so = "系统版本更新通知", co = "检测到系统有新版本发布，是否立即刷新页面？", lo = "立即刷新", uo = "稍后再说", fo = {
		placeholder: "输入关键字搜索菜单（支持拼音）",
		title: "搜索",
		select: "选择",
		navigate: "导航",
		close: "关闭",
		noResults: "未找到搜索结果",
		noRecent: "没有搜索历史",
		total: "共 {{total}} 项"
	}, po = {
		document: Qa,
		qa: $a,
		setting: eo,
		logoutTip: to,
		viewAll: no,
		notifications: ro,
		notiCategory: io,
		markAllAsRead: ao,
		clearNotifications: oo,
		versionMonitorTitle: so,
		versionMonitorContent: co,
		versionMonitorConfirm: lo,
		versionMonitorCancel: uo,
		search: fo
	};
})), ho, go, _o, vo, yo, bo, xo, So, Co, wo, To, Eo, Do, Oo, ko, Ao, jo, Mo, No, Po, Fo, Io, Lo, Ro, zo, Bo, Vo, Ho, Uo, Wo, Go, Ko, qo, Jo = w((() => {
	ho = "Welcome Back", go = "Login to your account", _o = "Out-of-the-box Admin System", vo = "A simple, lightweight, and easy-to-use", yo = {
		alignLeft: "Align Left",
		alignCenter: "Align Center",
		alignRight: "Align Right"
	}, bo = "Username", xo = "Password", So = "Login", Co = "Login in progress ...", wo = "Login Successful", To = "Code Login", Eo = "Forgot Password", Do = "{{ count }} seconds later you can try again", Oo = "Security code", ko = "Mobile", Ao = "Mobile Login", jo = "Get Security code", Mo = "Resend in {{ second }} s", No = "Enter your email and we'll send you instructions to reset your password", Po = "Email", Fo = "Send Reset Link", Io = "Logout", Lo = "Register", Ro = "Already have an account?", zo = "Go to Login", Bo = "Go to Register", Vo = "No account yet?", Ho = "Confirm Password", Uo = "Are you sure to logout?", Wo = "I have read and agree to <0>Privacy Policy</0> and <1>Terms of Service</1>", Go = "Privacy Policy", Ko = "Terms of Service", qo = {
		welcomeBack: ho,
		loginDescription: go,
		pageTitle: _o,
		pageDescription: vo,
		layout: yo,
		username: bo,
		password: xo,
		login: So,
		loginInProgress: Co,
		loginSuccess: wo,
		codeLogin: To,
		forgotPassword: Eo,
		retryAfterText: Do,
		code: Oo,
		mobile: ko,
		mobileLogin: Ao,
		sendCode: jo,
		sendText: Mo,
		forgotPasswordSubtitle: No,
		email: Po,
		sendResetLink: Fo,
		logout: Io,
		register: Lo,
		alreadyHaveAnAccount: Ro,
		goToLogin: zo,
		goToRegister: Bo,
		noAccountYet: Vo,
		confirmPassword: Ho,
		logoutConfirm: Uo,
		agree: Wo,
		privacyPolicy: Go,
		termsOfService: Ko
	};
})), Yo, Xo, Zo, Qo, $o, es, ts, ns, rs, is, as, os, ss, cs, ls, us, ds, fs, ps, ms, hs, gs, _s, vs, ys, bs, xs, Ss, Cs, ws, Ts, Es, Ds, Os, ks, As, js, Ms, Ns, Ps, Fs, Is, Ls, Rs, zs, Bs, Vs, Hs, Us, Ws, Gs, Ks, qs, Js, Ys, Xs, Zs, Qs, $s, ec = w((() => {
	Yo = "Loading Resources...", Xo = "Back", Zo = "Back to Home", Qo = "Warning", $o = "Confirm", es = "Fail", ts = "Success", ns = "Deleted successfully", rs = "Are you sure to delete?", is = "View", as = "Edit", os = "Error", ss = "Index", cs = "Upload", ls = "Change Avatar", us = "{{name}} uploaded successfully", ds = "{{name}} upload failed", fs = "No data", ps = "Action", ms = "Added successfully", hs = "Back to Home", gs = "Batch Delete", _s = "Cancel", vs = "Close", ys = "Check", bs = "Expand Column", xs = "Column Setting", Ss = "Config", Cs = "Please enter keywords to search", ws = "Modify", Ts = "Modified successfully", Es = "Please check if the input value is valid", Ds = "Refresh", Os = "Reset", ks = "Search", As = "Confirm to perform this operation?", js = "Trigger", Ms = "Update", Ns = "Updated successfully", Ps = "User Center", Fs = "Name", Is = "Status", Ls = "Enabled", Rs = "Deactivated", zs = "Activated", Bs = "Disabled", Vs = "Creation Time", Hs = "Update Time", Us = "Remark", Ws = "Demo only, operations do not take effect", Gs = "Total {{total}} items", Ks = "Expand All", qs = "Collapse All", Js = "Check All", Ys = "Cancel All", Xs = "Total {total}", Zs = "Save", Qs = "Delete failed", $s = {
		appLoading: Yo,
		back: Xo,
		backHome: Zo,
		warning: Qo,
		confirm: $o,
		delete: "Delete",
		fail: es,
		success: ts,
		deleteSuccess: ns,
		confirmDelete: rs,
		view: is,
		edit: as,
		error: os,
		index: ss,
		upload: cs,
		avatarChange: ls,
		uploadSuccess: us,
		uploadFailed: ds,
		noData: fs,
		action: ps,
		add: "Add",
		addSuccess: ms,
		backToHome: hs,
		batchDelete: gs,
		cancel: _s,
		close: vs,
		check: ys,
		expandColumn: bs,
		columnSetting: xs,
		config: Ss,
		keywordSearch: Cs,
		modify: ws,
		modifySuccess: Ts,
		pleaseCheckValue: Es,
		refresh: Ds,
		reset: Os,
		search: ks,
		switch: "Switch",
		tip: "Tip",
		tipMessage: As,
		trigger: js,
		update: Ms,
		updateSuccess: Ns,
		userCenter: Ps,
		yes: "Yes",
		no: "No",
		name: Fs,
		id: "Id",
		status: Is,
		enabled: Ls,
		deactivated: Rs,
		activated: zs,
		disabled: Bs,
		createTime: Vs,
		updateTime: Hs,
		remark: Us,
		demoOnly: Ws,
		pagination: Gs,
		expandAll: Ks,
		collapseAll: qs,
		checkAll: Js,
		cancelAll: Ys,
		total: Xs,
		save: Zs,
		deleteFailed: Qs
	};
})), tc, nc, rc, ic, ac, oc = w((() => {
	tc = "Sorry, the page you visited does not exist.", nc = "Unknown Component", rc = "Sorry, the current route has no corresponding component, please contact the developer.", ic = "Oops! Something went wrong!", ac = {
		notFoundTitle: "404",
		notFoundSubTitle: tc,
		unknownComponentTitle: nc,
		unknownComponentSubTitle: rc,
		pageErrorTitle: ic
	};
})), sc, cc, lc, uc, dc, fc, pc, mc, hc, gc, _c, vc, yc, bc = w((() => {
	sc = "Please input", cc = "Only supports {{length}} characters", lc = {
		required: "Please enter your username",
		invalid: "Please enter a username of 4 to 16 characters, supporting letters, numbers, underscores, and hyphens"
	}, uc = {
		required: "Please enter your password",
		invalid: "The password is 8-16 characters and must contain letters and numbers"
	}, dc = { required: "Please enter the security code" }, fc = {
		required: "Please enter your mobile number",
		invalid: "The phone number format is incorrect"
	}, pc = {
		required: "Please enter your telephone number",
		invalid: "The telephone number format is incorrect"
	}, mc = {
		required: "Please enter your email",
		invalid: "The email format is incorrect"
	}, hc = {
		required: "Please enter the password again",
		invalid: "The password does not match"
	}, gc = { required: "Please agree to the privacy policy and terms of service" }, _c = {
		required: "Please enter letters or numbers",
		invalid: "Please enter only letters or numbers"
	}, vc = {
		required: "Please enter the Unified Social Credit Code",
		invalid: "Please enter a valid Unified Social Credit Code"
	}, yc = {
		required: sc,
		length: cc,
		username: lc,
		password: uc,
		code: dc,
		mobile: fc,
		telephone: pc,
		email: mc,
		confirmPassword: hc,
		agree: gc,
		alphanumeric: _c,
		unifiedSocialCreditCode: vc
	};
})), xc, Sc, Cc, wc, Tc, Ec, Dc, Oc, kc, Ac, jc, Mc, Nc, Pc = w((() => {
	xc = "Preferences", Sc = "Copy Preferences", Cc = "Copy successful", wc = "Copy successful, please override in `src/store/preferences/index.ts`", Tc = "Clear Cache & Logout", Ec = {
		title: "Theme",
		followSystem: "Follow System",
		light: "Light",
		dark: "Dark",
		colorBlindMode: "Color Blind Mode",
		grayMode: "Gray Mode",
		radius: "Radius",
		builtin: {
			title: "Built-in",
			red: "Dust Red",
			volcano: "Volcano",
			orange: "Sunset Orange",
			gold: "Calendula Gold",
			yellow: "Sunrise Yellow",
			lime: "Lime",
			green: "Polar Green",
			cyan: "Cyan",
			blue: "DayBreak Blue",
			geekblue: "Geek Blue",
			purple: "Golden Purple",
			magenta: "Magenta",
			gray: "Gray",
			custom: "Custom"
		}
	}, Dc = {
		title: "Layout",
		topNavigation: "Top Navigation",
		topNavigationTip: "Menu at the top position",
		sideNavigation: "Side Navigation",
		sideNavigationTip: "Menu at the side position",
		twoColumnNavigation: "Two Column Navigation",
		twoColumnNavigationTip: "Vertical two-column menu at the side position",
		mixedNavigation: "Mixed Navigation",
		mixedNavigationTip: "Primary navigation at the top, secondary navigation at the side"
	}, Oc = {
		title: "Sidebar",
		width: "Width",
		enable: "Show Sidebar",
		collapsedWidth: "Collpase Menu Width",
		collapsed: "Collpase Menu",
		collapsedShowTitle: "Show Menu Title",
		firstColumnWidthInTwoColumnNavigation: "First Column Width in Two-Column Navigation",
		sidebarTheme: "Sidebar Theme",
		accordion: "Accordion Menu",
		autoActivateChild: "Auto Activate SubMenu",
		autoActivateChildTip: "`Enabled` to automatically activate the submenu while click menu.",
		expandOnHover: "Expand On Hover",
		expandOnHoverTip: "When the mouse hovers over menu, \n `Enabled` to expand children menus \n `Disabled` to expand whole sidebar."
	}, kc = {
		title: "Tabbar",
		enable: "Enable Tab Bar",
		icon: "Show Tabbar Icon",
		showMore: "Show More Button",
		showMaximize: "Show Maximize Button",
		persist: "Persist Tabs",
		draggable: "Enable Draggable Sort",
		styleType: {
			title: "Tabs Style",
			chrome: "Chrome",
			card: "Card",
			plain: "Plain",
			brisk: "Brisk"
		},
		contextMenu: {
			refresh: "Refresh",
			close: "Close",
			pin: "Pin",
			unpin: "Unpin",
			closeLeft: "Close Left Tabs",
			closeRight: "Close Right Tabs",
			closeOthers: "Close Other Tabs",
			closeAll: "Close All Tabs",
			openInNewWindow: "Open in New Window",
			maximize: "Maximize",
			restoreMaximize: "Restore"
		}
	}, Ac = {
		title: "Animation",
		loading: "Page Loading",
		transition: "Page Transition",
		progress: "Page Progress"
	}, jc = {
		title: "General",
		language: "Language",
		dynamicTitle: "Dynamic Title",
		watermark: "Watermark",
		watermarkTip: "Watermark nickname website psoriasis, not recommended",
		watermarkContent: "Watermark Content",
		enableCheckUpdate: "Check Update",
		enableBackTopButton: "Back Top Button"
	}, Mc = {
		title: "Footer",
		showFooter: "Show Footer",
		fixedFooter: "Fixed Footer",
		companyName: "Company Name",
		companyWebsite: "Company Website",
		copyrightDate: "Copyright Date",
		ICPNumber: "ICP Number",
		ICPLink: "ICP Link"
	}, Nc = {
		title: xc,
		copyPreferences: Sc,
		copyPreferencesSuccessTitle: Cc,
		copyPreferencesSuccess: wc,
		clearAndLogout: Tc,
		theme: Ec,
		layout: Dc,
		sidebar: Oc,
		tabbar: kc,
		animation: Ac,
		general: jc,
		footer: Mc
	};
})), Fc, Ic, Lc, Rc, zc, Bc, Vc, Hc, Uc, Wc, Gc, Kc, qc, Jc, Yc = w((() => {
	Fc = "Document", Ic = "Settings", Lc = "Do you want to logout?", Rc = "View All Messages", zc = "Notifications", Bc = {
		notice: "Notice",
		pm: "Direct",
		mention: "Mentions"
	}, Vc = "Make All as Read", Hc = "Clear", Uc = "System Version Update Notification", Wc = "A new version of the system has been detected, do you want to refresh the page now?", Gc = "Refresh Now", Kc = "Later", qc = {
		placeholder: "Enter keyword to search menu",
		title: "Search",
		select: "Select",
		navigate: "Navigate",
		close: "Close",
		noResults: "No Search Results Found",
		noRecent: "No Search History",
		total: "Total {{total}} items"
	}, Jc = {
		document: Fc,
		qa: "Q&A",
		setting: Ic,
		logoutTip: Lc,
		viewAll: Rc,
		notifications: zc,
		notiCategory: Bc,
		markAllAsRead: Vc,
		clearNotifications: Hc,
		versionMonitorTitle: Uc,
		versionMonitorContent: Wc,
		versionMonitorConfirm: Gc,
		versionMonitorCancel: Kc,
		search: qc
	};
}));
//#endregion
//#region src/locales/helper.ts
function Xc() {
	return Qc(/* @__PURE__ */ Object.assign({
		"./zh-CN/authority.json": si,
		"./zh-CN/common.json": ga,
		"./zh-CN/exception.json": Sa,
		"./zh-CN/form.json": Ia,
		"./zh-CN/preferences.json": Xa,
		"./zh-CN/widgets.json": po
	}));
}
function Zc() {
	return Qc(/* @__PURE__ */ Object.assign({
		"./en-US/authority.json": qo,
		"./en-US/common.json": $s,
		"./en-US/exception.json": ac,
		"./en-US/form.json": yc,
		"./en-US/preferences.json": Nc,
		"./en-US/widgets.json": Jc
	}));
}
function Qc(e) {
	let t = {};
	for (let n in e) {
		let r = e[n], i = n?.split("/"), a = i[i?.length - 1];
		if (!a) continue;
		let o = a.split(".json")[0];
		o && (t[o] = r);
	}
	return t;
}
var $c = w((() => {
	ci(), _a(), Ca(), La(), Za(), mo(), Jo(), ec(), oc(), bc(), Pc(), Yc();
}));
//#endregion
//#region src/locales/t.tsx
function el(e) {
	return e;
}
var tl = w((() => {}));
//#endregion
//#region src/locales/index.ts
function nl() {
	Bt.isInitialized || (ol.init(al), Bt.on("languageChanged", (e) => {
		document.documentElement.lang = e;
	}));
}
var rl, il, al, ol, sl = w((() => {
	$c(), tl(), rl = {
		"zh-CN": zt,
		"en-US": Rt
	}, il = {
		"zh-CN": { translation: Xc() },
		"en-US": { translation: Zc() }
	}, al = {
		lng: "zh-CN",
		resources: il,
		saveMissing: !1,
		missingKeyHandler: async (e, t, n) => {}
	}, ol = Bt.use(Lt);
})), cl = /* @__PURE__ */ T({ default: () => ll });
function ll() {
	let { t: e } = b();
	return /* @__PURE__ */ S("div", {
		className: "p-4 dark:bg-black",
		children: /* @__PURE__ */ S(xt.Title, {
			level: 1,
			children: e("authority.privacyPolicy")
		})
	});
}
var ul = w((() => {})), dl = /* @__PURE__ */ T({ default: () => pl }), fl, pl, ml = w((() => {
	sl(), fl = Mt(() => Promise.resolve().then(() => (ul(), cl))), pl = [{
		path: "/privacy-policy",
		Component: a,
		handle: {
			hideInMenu: !0,
			title: el("authority.privacyPolicy")
		},
		children: [{
			index: !0,
			Component: fl,
			handle: { title: el("authority.privacyPolicy") }
		}]
	}];
})), hl = /* @__PURE__ */ T({ default: () => gl });
function gl() {
	let { t: e } = b();
	return /* @__PURE__ */ S("div", {
		className: "p-4 dark:bg-black",
		children: /* @__PURE__ */ S(xt.Title, {
			level: 1,
			children: /* @__PURE__ */ S(x, { children: e("authority.termsOfService") })
		})
	});
}
var _l = w((() => {})), vl = /* @__PURE__ */ T({ default: () => bl }), yl, bl, xl = w((() => {
	sl(), yl = Mt(() => Promise.resolve().then(() => (_l(), hl))), bl = [{
		path: "/terms-of-service",
		Component: a,
		handle: {
			hideInMenu: !0,
			title: el("authority.termsOfService")
		},
		children: [{
			index: !0,
			Component: yl,
			handle: { title: el("authority.termsOfService") }
		}]
	}];
}));
//#endregion
//#region src/router/utils/ascending.ts
function Sl(e) {
	let t = e.map((e, t) => ({
		...e,
		handle: {
			...e.handle,
			order: e?.handle?.order ?? t + 2
		}
	})), n = (e, t) => {
		let n = (e.handle.order ?? 0) - (t.handle.order ?? 0);
		return n === 0 ? (e.path ?? "").localeCompare(t.path ?? "") : n;
	};
	return [...t.filter((e) => (e.handle.order ?? 0) >= 0).sort(n), ...t.filter((e) => (e.handle.order ?? 0) < 0).sort(n)];
}
var Cl = w((() => {}));
//#endregion
//#region src/router/utils/add-route-id-by-path.ts
function wl(e, t = "") {
	return e.map((e) => {
		let n = e.path && !e.path.startsWith("/") ? `${t.replace(/\/+$/, "")}/${e.path}` : e.path, r = {
			...e,
			id: e.index ? `${t}/` : n
		};
		return r.children && r.children.length > 0 && (r.children = wl(r.children, n ?? t)), r;
	});
}
var Tl = w((() => {}));
//#endregion
//#region src/router/utils/merge-route-modules.tsx
function El(...e) {
	return e.flatMap((e) => Object.keys(e).reduce((t, n) => {
		let r = e[n].default ?? {}, i = Array.isArray(r) ? [...r] : [r];
		return [...t, ...wl(i)];
	}, []));
}
var Dl = w((() => {
	Tl();
}));
//#endregion
//#region src/utils/tree/index.ts
function Ol(e, t, n, r) {
	if (!Array.isArray(e)) return console.warn("data must be an array"), [];
	let i = {
		id: t || "id",
		parentId: n || "parentId",
		childrenList: r || "children"
	}, a = {}, o = {}, s = [];
	for (let t of e) {
		let e = t[i.parentId];
		a[e] ??= [], o[t[i.id]] = t, a[e].push(t);
	}
	for (let t of e) o[t[i.parentId]] ?? s.push(t);
	for (let e of s) c(e);
	function c(e) {
		if (a[e[i.id]] !== null && (e[i.childrenList] = a[e[i.id]]), e[i.childrenList]) for (let t of e[i.childrenList]) c(t);
	}
	return s;
}
function kl(e, t, n) {
	let r = [], { childProps: i } = n || { childProps: "children" }, a = (e) => {
		let n = t(e);
		r.push(n);
		let o = e?.[i];
		if (o && o.length > 0) for (let e of o) a(e);
	};
	for (let t of e) a(t);
	return r.filter(Boolean);
}
function Al(e, t, n) {
	let { childProps: r } = n || { childProps: "children" }, i = (e) => e.filter((e) => t(e) ? (e[r] && (e[r] = i(e[r])), !0) : !1);
	return i(e);
}
function jl(e, t, n) {
	let { childProps: r } = n || { childProps: "children" };
	return e.map((e) => {
		let i = t(e);
		return i[r] && (i[r] = jl(i[r], t, n)), i;
	});
}
var Ml = w((() => {})), Nl, Pl = w((() => {
	Nl = "data:image/svg+xml,%3csvg%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%201024%201024'%20version='1.1'%20%3e%3cpath%20fill='%232466F8'%20d='m589.09%20205.63-20.05-.58-21.9-.42c-3.867-23.067-7.8-41.467-11.8-55.2A1363.569%201363.569%200%200%200%20521%20103.28c-1.42-4.29-4.22-7.94-9.26-5.24-2.4%201.28-3.88%206.09-4.7%208.51a711.111%20711.111%200%200%200-25.67%2098.01l-24.34.62a590.52%20590.52%200%200%200-18.78.5c-.6.027-.713-.457-.34-1.45l11.51-32.69c1.827-2.22%203.053-4.05%203.68-5.49%202.173-4.993%204.84-12.147%208-21.46a356.454%20356.454%200%200%201%2010-20.48%20307.167%20307.167%200%200%201%2015.51-26.19%2018.07%2018.07%200%200%200%202.78-3.04%205310.178%205310.178%200%200%201%2015.19-21.06c.873-1.207%201.72-2.863%202.54-4.97l4.85-5.89a1.088%201.088%200%200%201%201.65-.05c2.34%202.56%204.55%205.17%206.63%207.83%2030.86%2039.42%2053.82%2086.63%2068.84%20134.89Z'%20/%3e%3cpath%20fill='%231350CE'%20d='M507.12%2068.85c-.82%202.107-1.667%203.763-2.54%204.97a5295.54%205295.54%200%200%200-15.19%2021.06%2018.073%2018.073%200%200%201-2.78%203.04%20302.356%20302.356%200%200%201%2020.51-29.07ZM547.14%20204.63l-8.71-.17-22.72-.23a.753.753%200%200%201-.75-.76c.113-21.313.21-42.72.29-64.22.007-2.58-.03-5.113-.11-7.6a.567.567%200%200%200-.48-.53l-.33-.04a.864.864%200%200%200-.893.49.83.83%200%200%200-.077.35l.19%2070.87c.007%201.027-.503%201.543-1.53%201.55l-30.65.22a711.111%20711.111%200%200%201%2025.67-98.01c.82-2.42%202.3-7.23%204.7-8.51%205.04-2.7%207.84.95%209.26%205.24%205.053%2015.3%209.833%2030.683%2014.34%2046.15%204%2013.733%207.933%2032.133%2011.8%2055.2Z'%20/%3e%3cpath%20fill='%232466F8'%20d='m630.36%20116.34%207.13.05a.761.761%200%200%201%20.76.75l.05%204.86a.768.768%200%200%201-.216.54.735.735%200%200%201-.244.168.744.744%200%200%201-.29.062l-7.17.12a.763.763%200%200%200-.75.74l-.13%207.26a.762.762%200%200%201-.76.74l-4.71-.04a.761.761%200%200%201-.76-.75l-.16-7.32a.76.76%200%200%200-.75-.74l-7.72-.13a.762.762%200%200%201-.75-.76l.04-4.58a.758.758%200%200%201%20.74-.76l7.75-.18a.76.76%200%200%200%20.74-.75l.13-7.47a.763.763%200%200%201%20.222-.518.763.763%200%200%201%20.518-.222l4.57-.08a.756.756%200%200%201%20.77.74l.24%207.54a.758.758%200%200%200%20.75.73Z'%20/%3e%3cpath%20fill='%23C3E1FB'%20d='m321.54%20115.71-.86%2024.67a1.442%201.442%200%200%201-.481%201.033%201.445%201.445%200%200%201-1.079.367l-3.91-.3a1.45%201.45%200%200%201-1.33-1.61l2.8-24.49a1.448%201.448%200%200%201%201.53-1.28l1.96.11a1.452%201.452%200%200%201%201.37%201.5ZM300.62%20138.61c.76.893.7%201.723-.18%202.49-.16.14-.343.24-.55.3-1.413.447-2.617.183-3.61-.79-3.84-3.747-7.547-7.913-11.12-12.5-.747-.953-.67-1.84.23-2.66l.59-.52c1.133-1.027%202.193-.957%203.18.21l11.46%2013.47ZM350.817%20124.654l-.044-.041a1.51%201.51%200%200%200-2.134.086l-13.522%2014.654a1.51%201.51%200%200%200%20.086%202.134l.044.04a1.51%201.51%200%200%200%202.134-.085l13.522-14.655a1.509%201.509%200%200%200-.086-2.133ZM538.43%20204.46a176.559%20176.559%200%200%200-7.06%2035.2c-15.36-6.18-29.653-4.83-42.88%204.05-8.507%205.707-14.293%2013.71-17.36%2024.01.82-9.247%201.81-17.19%202.97-23.83%202.66-15.23%204.85-25.94%204.89-38.19%200-.327-.163-.49-.49-.49l-21.47-.03%2024.34-.62%2030.65-.22c1.027-.007%201.537-.523%201.53-1.55l-.19-70.87a.83.83%200%200%201%20.293-.637.867.867%200%200%201%20.677-.203l.33.04c.13.021.249.085.336.181.088.097.138.22.144.349.08%202.487.117%205.02.11%207.6-.08%2021.5-.177%2042.907-.29%2064.22a.758.758%200%200%200%20.216.537.74.74%200%200%200%20.534.223l22.72.23Zm-23.42%201.811a.592.592%200%200%200-.175-.424.596.596%200%200%200-.423-.177h-.04a.604.604%200%200%200-.556.369.625.625%200%200%200-.046.23l-.04%2023.38a.592.592%200%200%200%20.175.424.596.596%200%200%200%20.424.177h.04a.603.603%200%200%200%20.601-.599l.04-23.38ZM346.62%20162.53c-19.7%203.49-39.15%206.11-58.33%2012.08%201.067-13.76%207.783-23.153%2020.15-28.18%2015.04-6.12%2031.37%201.93%2038.18%2016.1Z'%20/%3e%3cpath%20fill='%231350CE'%20d='m449.42%20171.54%2011.68-26.95c-3.16%209.313-5.827%2016.467-8%2021.46-.627%201.44-1.853%203.27-3.68%205.49Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M346.62%20162.53c5.63%2012.98%202.84%2028.49-8.53%2037.59-3.16%202.527-5.82%206.253-7.98%2011.18a94.737%2094.737%200%200%200-23.38-1.22c-2.653-4.32-6.117-8.797-10.39-13.43-5.633-6.1-8.317-13.447-8.05-22.04%2019.18-5.97%2038.63-8.59%2058.33-12.08Zm-21.369%205.362a.627.627%200%200%200-.505-.485.651.651%200%200%200-.245.005l-.039.009a.627.627%200%200%200-.485.505.637.637%200%200%200%20.004.246l1.508%206.856a.622.622%200%200%200%20.276.395.63.63%200%200%200%20.475.085l.039-.009a.646.646%200%200%200%20.225-.098.64.64%200%200%200%20.26-.407.651.651%200%200%200-.005-.245l-1.508-6.857Zm6.299%2018.018-1.58-5.33a.15.15%200%200%200-.18-.11l-.06.02c-.267.079-.439.438-.479.999-.039.56.058%201.277.269%201.991l.07.23c.211.713.519%201.365.856%201.815.337.45.677.66.944.585l.06-.02a.153.153%200%200%200%20.086-.07.156.156%200%200%200%20.014-.11Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='m324.501%20167.412-.04.009a.631.631%200%200%200-.48.75l1.508%206.857a.63.63%200%200%200%20.751.48l.039-.009a.631.631%200%200%200%20.48-.75l-1.508-6.857a.63.63%200%200%200-.75-.48ZM331.55%20185.91a.156.156%200%200%201-.014.11.157.157%200%200%201-.086.07l-.06.02c-.267.075-.607-.135-.944-.585-.338-.45-.645-1.102-.856-1.815l-.07-.23c-.211-.714-.308-1.431-.269-1.991.04-.561.212-.92.479-.999l.06-.02a.15.15%200%200%201%20.18.11l1.58%205.33Z'%20/%3e%3cpath%20fill='%23E3F1FB'%20d='M437.91%20204.23c-.373.993-.26%201.477.34%201.45a590.52%20590.52%200%200%201%2018.78-.5l21.47.03c.327%200%20.49.163.49.49-.04%2012.25-2.23%2022.96-4.89%2038.19-1.16%206.64-2.15%2014.583-2.97%2023.83a44.296%2044.296%200%200%200-1.48%2015.27c-2.92%208.3-2.21%2015.57-3.04%2023.7-2.51%2024.55-1.48%2048-2.83%2071.97-.28%204.867-1.447%209.19-3.5%2012.97-1.1%202.027-1.787%203.893-2.06%205.6a39.305%2039.305%200%200%200-.47%205.72c-.127%2010.533-.35%2021.233-.67%2032.1-.133%204.38.65%208.057%202.35%2011.03%202.23%203.89%203.37%208.08%203.47%2012.32.147%205.64.21%2011.353.19%2017.14a.91.91%200%200%201-.42.77%207.666%207.666%200%200%201-2.68%201.16c-.46.1-.497.287-.11.56a15.31%2015.31%200%200%201%202.52%202.19c.38.407.357.43-.07.07a4.965%204.965%200%200%201-.89-.98.242.242%200%200%200-.164-.102.232.232%200%200%200-.098.007.23.23%200%200%200-.088.045l-.21.16c-.013.013-.007.037.02.07l3.41%204.21c.233.287.343.613.33.98a462.086%20462.086%200%200%200-.24%2032.19c.33%2012.07-.28%2024.05-.54%2035.99-.073%203.293-.75%206.497-2.03%209.61-.127.313-.357.47-.69.47l-25.85.16-23.53.3c-1.06.013-1.59-.51-1.59-1.57v-30.62l-.16-29.21c.653-9.34.97-20.423.95-33.25-.04-27.253-.073-53.363-.1-78.33-.02-13.49.27-26.52%201.5-40.08%202.367-26.167%204.24-43.837%205.62-53.01%201.713-11.42%203.557-22.86%205.53-34.32%201.207-7.007%202.483-13.543%203.83-19.61%202.93-13.16%205.4-27.21%2010.57-39.17Zm17.615%2051.558a.558.558%200%200%200-.087-.428.569.569%200%200%200-.363-.241l-.059-.011a.569.569%200%200%200-.669.451l-1.312%206.753a.558.558%200%200%200%20.087.428.569.569%200%200%200%20.363.241l.059.011a.569.569%200%200%200%20.669-.451l1.312-6.753Zm-2.116%2011.991a.556.556%200%200%200-.106-.408.547.547%200%200%200-.362-.214l-.04-.005a.55.55%200%200%200-.621.468l-1.409%2010.021a.556.556%200%200%200%20.106.408.547.547%200%200%200%20.362.214l.04.005a.55.55%200%200%200%20.621-.468l1.409-10.021Zm-2.098%2015.063a.496.496%200%200%200-.453-.544l-.04-.003a.51.51%200%200%200-.194.02.511.511%200%200%200-.294.245.517.517%200%200%200-.055.187l-1.086%2011.931a.496.496%200%200%200%20.453.543l.04.004a.51.51%200%200%200%20.194-.02.511.511%200%200%200%20.294-.245.516.516%200%200%200%20.055-.188l1.086-11.93Zm-7.131%2089.408c1.153-4.127%201.8-8.05%201.94-11.77.19-5.37%201.37-10.9%201.07-16.28-.26-4.747.033-9.233.88-13.46a.675.675%200%200%200-.108-.508.666.666%200%200%200-.442-.272l-.27-.05a.362.362%200%200%200-.284.079.367.367%200%200%200-.136.261c-.6%209.287-1.187%2018.877-1.76%2028.77-.193%203.333-.79%207.55-1.79%2012.65a.54.54%200%200%200%20.43.63l.31.05a.136.136%200%200%200%20.096-.019.152.152%200%200%200%20.064-.081Zm-2.17%208.65c-.76.75-.92%201.92-1.15%202.96-.14.6-.013.663.38.19.767-.913%201.21-1.873%201.33-2.88.073-.627-.113-.717-.56-.27Zm-3.87%2040.91c-1.39-5.35-1.95-11.84-1.93-17.36.027-5.353%201.287-10.683%203.78-15.99.073-.167.027-.287-.14-.36l-.24-.1a.459.459%200%200%200-.6.24c-1.993%204.72-3.197%209.137-3.61%2013.25-.92%209.107.31%2018.313%203.69%2027.62a317.845%20317.845%200%200%200%204%2010.39c.12.3.33.39.63.27l.29-.12a.294.294%200%200%200%20.171-.164.296.296%200%200%200-.001-.236%20117.817%20117.817%200%200%201-6.04-17.44Zm11.22%2033.11c-.61-1.5-.86-3.11-1.53-4.63-.293-.673-.513-.647-.66.08-.14.713-.077%201.443.19%202.19a121.008%20121.008%200%200%200%207.28%2016.43c.053.1.14.147.26.14l.56-.03c.313-.02.397-.17.25-.45a150.77%20150.77%200%200%201-6.35-13.73Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='m547.14%20204.63%2021.9.42c12.18%2012.41%2015.08%2026.24%2015.64%2043.01.52%2015.407.283%2031.93-.71%2049.57-.02.393-.213.52-.58.38-2.28-.88-4.517-1.18-6.71-.9-7.51.93-7.93%207.99-7.9%2014.12.03%208.61-.88%2019.74%2011.72%2018.57.427-.033.673.16.74.58%203.29%2020.55%204.83%2041.28%203.88%2061.89-1.64%2035.5-2.52%2070.7-.94%20106.33.54%2012.273%202.647%2023.633%206.32%2034.08l.58%202.82a16.04%2016.04%200%200%201-4.9-.66c-4.28-1.28-8.547-2.61-12.8-3.99-2.713-.88-4.78-2.27-6.2-4.17a25.709%2025.709%200%200%200-4.19-4.38c-1.69-1.39-1.76-5.5-1.84-7.56%201.287.82%202.263%202.013%202.93%203.58.133.3.35.387.65.26l4.39-1.8c-.28-2.747-1.08-5.487-2.4-8.22.273-1.133-.267-1.903-1.62-2.31a.908.908%200%200%201-.63-.62l-.52-1.54c.687-4.693-.12-7.147-2.42-7.36l3.55-4.32%2012.6-11.31c.893-.807.74-1.207-.46-1.2-3.113.027-6.313.087-9.6.18-1.95.05-3.78-.54-5.31-1.82-7.527-6.32-14.627-12.63-21.3-18.93a33.503%2033.503%200%200%200-6.06-4.55.911.911%200%200%200-1.3.43l-.63%201.51c-.133-.887-.08-1.683.16-2.39a.806.806%200%200%201%20.69-.56l10.38-1.29%2013.99-.35c.347-.007.59-.17.73-.49%201.833-4.073%203.267-8.093%204.3-12.06%206.05-23.19-3.33-45.13-24.04-56.84a139.339%20139.339%200%200%200-7.2-25.95c1.707-.06%202.347-.443%201.92-1.15%201.867-11.04%203.94-22.253%206.22-33.64.487-2.433.787-5.66.9-9.68%2024.41-21.41%2019.59-58.45-9.7-72.66a176.559%20176.559%200%200%201%207.06-35.2l8.71.17Zm15.15%20249.89%2014.84%2012.76c.147.127.21.093.19-.1a.457.457%200%200%200-.15-.32%20126.16%20126.16%200%200%200-14.88-12.34c-.467-.807-.94-1.18-1.42-1.12-.313.04-.35.163-.11.37.46.393.97.643%201.53.75Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M589.09%20205.63a542.245%20542.245%200%200%200%204.46%2016.66c2.067%207.3%203.553%2012.85%204.46%2016.65a618.388%20618.388%200%200%201%2012.7%2072.13l-9.32-.19a6.808%206.808%200%200%200-1.56.16c-.973.227-1.297.693-.97%201.4.033.08.097.12.19.12l10.68-.28a.805.805%200%200%201%20.74.4l.31.48c.14.313.233.677.28%201.09a714.75%20714.75%200%200%201%204.55%2060.75c.507%2015.953.413%2042.203-.28%2078.75-.12%206.38.063%2022.313.55%2047.8l.14%2026.24c.007%201.007-.487%201.577-1.48%201.71l-4.31.6c-.973.133-1.523-.287-1.65-1.26-1.29-9.73-6.32-14.16-16.11-10.55-3.66%201.36-3.5%205.6-1.73%208.4-.38%201.193-.507%202.067-.38%202.62l.14%203.37c-3.673-10.447-5.78-21.807-6.32-34.08-1.58-35.63-.7-70.83.94-106.33.95-20.61-.59-41.34-3.88-61.89-.067-.42-.313-.613-.74-.58-12.6%201.17-11.69-9.96-11.72-18.57-.03-6.13.39-13.19%207.9-14.12%202.193-.28%204.43.02%206.71.9.367.14.56.013.58-.38.993-17.64%201.23-34.163.71-49.57-.56-16.77-3.46-30.6-15.64-43.01l20.05.58Zm5.93%20106.08a.687.687%200%200%200-.379-.655.69.69%200%200%200-.256-.068l-10.378-.671a.67.67%200%200%200-.493.168.673.673%200%200%200-.23.467l-.004.06a.673.673%200%200%200%20.168.492.684.684%200%200%200%20.467.23l10.378.671a.67.67%200%200%200%20.493-.168.673.673%200%200%200%20.23-.467l.004-.059Zm-2.5%2085.31c.733-9.707.537-18.987-.59-27.84a241.99%20241.99%200%200%200-2.48-15.38c-.073-.387-.257-.447-.55-.18l-.19.18a1.256%201.256%200%200%200-.39%201.18c3.12%2015.96%203.937%2031.907%202.45%2047.84a1.293%201.293%200%200%200%20.47%201.14l.23.2a.373.373%200%200%200%20.39.057.366.366%200%200%200%20.22-.327c.113-2.14.26-4.43.44-6.87ZM514.411%20205.67h-.04a.6.6%200%200%200-.601.599l-.04%2023.38a.6.6%200%200%200%20.599.601h.04a.6.6%200%200%200%20.601-.599l.04-23.38a.6.6%200%200%200-.599-.601ZM330.11%20211.3l-1.93%204.89-19.66.14-1.79-6.25a94.737%2094.737%200%200%201%2023.38%201.22Z'%20/%3e%3cpath%20fill='%231350CE'%20d='m308.52%20216.33%2019.66-.14c1.487%202.08%201.61%204.29.37%206.63-.14.26-.197.54-.17.84.2%202.64%201.76%205.5-2.18%206.49a1.585%201.585%200%200%200-1.19%201.4c-.18%201.79-.3%203.69-1.69%205.01-3.17%203.02-12.14%202.36-11.39-3.96.133-1.093-.35-1.707-1.45-1.84-2.78-.34-.78-3.12-2.75-4.57a1.67%201.67%200%200%201-.41-2.27c.8-1.22.94-2.523.42-3.91-.45-1.18-.19-2.87.78-3.68Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='M639.61%20229.09c.453-.073.813.057%201.08.39a.594.594%200%200%201%20.11.516.598.598%200%200%201-.34.404c-.5.227-.913.133-1.24-.28a.663.663%200%200%201-.092-.629.636.636%200%200%201%20.482-.401Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M658.19%20229.41c.52-.433.983-.437%201.39-.01a.413.413%200%200%201%20.119.322.465.465%200%200%201-.159.318c-.493.42-.947.45-1.36.09a.479.479%200%200%201-.163-.362.468.468%200%200%201%20.173-.358Z'%20/%3e%3cpath%20fill='%231350CE'%20d='M531.37%20239.66c29.29%2014.21%2034.11%2051.25%209.7%2072.66-26.57%2022.38-68.51%205.78-71.42-29.33a44.296%2044.296%200%200%201%201.48-15.27c3.067-10.3%208.853-18.303%2017.36-24.01%2013.227-8.88%2027.52-10.23%2042.88-4.05Zm-16.21%201.96a1.771%201.771%200%200%200-3.022-1.252%201.775%201.775%200%200%200%200%202.504%201.775%201.775%200%200%200%202.504%200c.332-.332.518-.783.518-1.252Zm9.038-.1a1.333%201.333%200%200%200-1.278-1.38l-1.499-.057a1.327%201.327%200%200%200-1.38%201.277l-.039%201a1.336%201.336%200%200%200%20.774%201.259c.158.073.33.114.504.121l1.499.057a1.327%201.327%200%200%200%201.38-1.278l.039-.999Zm-17.266.133a1.707%201.707%200%200%200-.617-1.146%201.698%201.698%200%200%200-1.246-.374l-.916.093a1.708%201.708%200%200%200-1.145.617%201.698%201.698%200%200%200-.374%201.246l.034.338a1.713%201.713%200%200%200%20.617%201.146%201.698%201.698%200%200%200%201.246.374l.916-.093a1.708%201.708%200%200%200%201.145-.617%201.698%201.698%200%200%200%20.374-1.246l-.034-.338Zm8.688%2070.007c11.28-1.673%2019.57-6.69%2024.87-15.05%203.707-5.847%205.477-12.17%205.31-18.97-.193-8.24-3.457-15.637-9.79-22.19-.88-.96-2.08-1.917-3.6-2.87-5.073-3.187-10.693-5.12-16.86-5.8-5.44-.6-10.893.393-16.36%202.98-9.29%204.4-17.42%2014.39-18.53%2025.47-.81%208.21.59%2015.04%205.59%2022.06%207.173%2010.073%2016.963%2014.863%2029.37%2014.37Zm.75%205.47a2.34%202.34%200%201%200-4.679-.002%202.34%202.34%200%200%200%204.679.002Z'%20/%3e%3cpath%20fill='%23E3F1FB'%20d='M513.39%20243.39a1.77%201.77%200%201%200%20.001-3.539%201.77%201.77%200%200%200-.001%203.539ZM522.92%20240.14l-1.499-.057a1.33%201.33%200%200%200-1.38%201.278l-.039.999a1.33%201.33%200%200%200%201.278%201.38l1.499.057a1.33%201.33%200%200%200%201.38-1.278l.039-.999a1.33%201.33%200%200%200-1.278-1.38ZM505.069%20240.133l-.916.093a1.7%201.7%200%200%200-1.519%201.863l.034.338a1.7%201.7%200%200%200%201.863%201.52l.916-.093a1.7%201.7%200%200%200%201.519-1.863l-.034-.338a1.7%201.7%200%200%200-1.863-1.52Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='m455.075%20255.119-.059-.011a.57.57%200%200%200-.669.451l-1.312%206.753a.57.57%200%200%200%20.45.669l.059.011a.57.57%200%200%200%20.669-.451l1.312-6.753a.57.57%200%200%200-.45-.669ZM452.941%20267.157l-.04-.005a.549.549%200%200%200-.621.468l-1.409%2010.021a.552.552%200%200%200%20.468.622l.04.005a.55.55%200%200%200%20.621-.468l1.409-10.021a.552.552%200%200%200-.468-.622ZM807.3%20276.08c-4.93%201.58-6.19%204.61-6.29%209.48-.007.333.157.527.49.58a18.789%2018.789%200%200%201%207.31%202.9c-9.5-4.13-21.47-1.09-25.38%209.2-2.013%205.307-1.723%2010.483.87%2015.53%204.26%208.3%2014.81%2010.74%2023.46%207.77-4.02%2011.85-2.14%2024.65%202.61%2036.02l-6.73%2011.87a.515.515%200%200%201-.44.252.51.51%200%200%201-.44-.252c-6.127-10.787-11.733-21.373-16.82-31.76-3.947-8.053-7.117-16.173-9.51-24.36-.687-2.333-1.113-5.24-1.28-8.72-.38-7.753%202.147-14.45%207.58-20.09%206.513-6.767%2014.703-9.573%2024.57-8.42Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='M807.3%20276.08c11.593%201.707%2019.6%207.97%2024.02%2018.79%202.567%206.287%202.837%2012.54.81%2018.76-1.627%205-3.94%2010.427-6.94%2016.28a823.682%20823.682%200%200%201-14.82%2027.65c-4.75-11.37-6.63-24.17-2.61-36.02%2012.9-6.09%2013.43-25.64%201.05-32.5a18.789%2018.789%200%200%200-7.31-2.9c-.333-.053-.497-.247-.49-.58.1-4.87%201.36-7.9%206.29-9.48Z'%20/%3e%3cpath%20fill='%232466F8'%20d='m716.95%20290.22.03%204.42a.831.831%200%200%201-.81.83l-6.97.2a.83.83%200%200%200-.81.81l-.18%207.1a.829.829%200%200%201-.82.81l-4.38.04a.83.83%200%200%201-.84-.81l-.18-7.08a.828.828%200%200%200-.8-.8l-7.54-.24a.828.828%200%200%201-.81-.83l-.02-4.24a.831.831%200%200%201%20.79-.83l7.55-.33a.828.828%200%200%200%20.79-.81l.12-7.07a.828.828%200%200%201%20.83-.82l4.39-.01a.833.833%200%200%201%20.83.8l.23%207.12a.83.83%200%200%200%20.82.8l6.97.12a.832.832%200%200%201%20.81.82Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='m450.858%20282.298-.04-.003a.5.5%200%200%200-.543.452l-1.086%2011.931a.5.5%200%200%200%20.453.543l.04.004a.5.5%200%200%200%20.543-.453l1.086-11.93a.501.501%200%200%200-.453-.544Z'%20/%3e%3cpath%20fill='%23C3E1FB'%20d='M469.65%20282.99c2.91%2035.11%2044.85%2051.71%2071.42%2029.33-.113%204.02-.413%207.247-.9%209.68-2.28%2011.387-4.353%2022.6-6.22%2033.64l-31.73-.41a.533.533%200%200%200-.335.114.518.518%200%200%200-.185.296l-.06.26a.527.527%200%200%200%20.285.59c.07.033.147.051.225.05l29.88.25c3.233%208.4%205.633%2017.05%207.2%2025.95-8.047-4.32-16.54-6.497-25.48-6.53-15.247-.053-28.047%205.49-38.4%2016.63-6.547%207.047-10.67%2014.853-12.37%2023.42-3.74%2018.86%201.533%2034.813%2015.82%2047.86-1.393%202.793-2.067%206.35-2.02%2010.67.067%206.3.173%2012.71.32%2019.23.06%202.82.623%205.75%201.69%208.79.14.387.41.61.81.67l5.52.83c.4.06.63-.11.69-.51%202.03-14.28%202.61-26.06-5.89-38.65%209.747%208.033%2020.857%2012.087%2033.33%2012.16%205.653.04%2011.317-.227%2016.99-.8.333-.033.52-.213.56-.54l.64-5.45.23%208.82c.007.333.117.63.33.89%206.807%208.293%2014.987%2014.867%2024.54%2019.72.287.147.557.12.81-.08.393-.32.813-.503%201.26-.55.373.873%201.027.823%201.96-.15a1.119%201.119%200%200%201%201.92.61c.213%201.42.7%202.857%201.46%204.31l.52%201.54c.1.313.31.52.63.62%201.353.407%201.893%201.177%201.62%202.31-.48-.713-1.037-1.12-1.67-1.22-.38-.06-.623.093-.73.46-.893%202.96-1.047%205.92-.46%208.88a.967.967%200%200%200%20.22.453.97.97%200%200%200%20.922.307.966.966%200%200%200%20.448-.23c.647-.593%201.87-.737%203.67-.43l-4.39%201.8c-.3.127-.517.04-.65-.26-.667-1.567-1.643-2.76-2.93-3.58a37.563%2037.563%200%200%201-1.22-2.63c-.273-.667-.153-.753.36-.26.087.08.15.187.19.32.16.567.213.557.16-.03a.83.83%200%200%200-.39-.64%202.851%202.851%200%200%201-.56-.5%20148.715%20148.715%200%200%201-3.06-3.66c-.467-.213-.39-.713.23-1.5.213-.273.277-.58.19-.92l-.55-2.11a.776.776%200%200%200-.499-.532.759.759%200%200%200-.711.122%2014.89%2014.89%200%200%201-4.58%202.5%201.43%201.43%200%200%201-1.228-.164%201.416%201.416%200%200%201-.632-1.066c-.09-1.12-.87-1.84-1.77-2.39-4.98-2.993-9.933-6.497-14.86-10.51-1.013-.827-1.787-1.967-2.32-3.42-.08-.233-.21-.263-.39-.09l-3.33%203.16c-1.58.213-3.14.323-4.68.33-10.72.053-19.977.21-27.77.47-.287.007-.42.147-.4.42.027.307.193.46.5.46l31.36-.08c-.687%201.793-1.107%203.423-1.26%204.89-.16%201.493.263%202.927%201.27%204.3.94%201.28%202.01%202.427%203.21%203.44%204.073%2019.213%204.507%2038.453%201.3%2057.72-.053.32-.243.493-.57.52l-5.35.42-88.5-.21%2025.85-.16c.333%200%20.563-.157.69-.47%201.28-3.113%201.957-6.317%202.03-9.61.26-11.94.87-23.92.54-35.99a462.086%20462.086%200%200%201%20.24-32.19%201.426%201.426%200%200%200-.33-.98l-3.41-4.21c-.027-.033-.033-.057-.02-.07l.21-.16a.23.23%200%200%201%20.088-.045.232.232%200%200%201%20.191.027.242.242%200%200%201%20.071.068c.253.367.55.693.89.98.427.36.45.337.07-.07a15.31%2015.31%200%200%200-2.52-2.19c-.387-.273-.35-.46.11-.56a7.666%207.666%200%200%200%202.68-1.16.91.91%200%200%200%20.42-.77c.02-5.787-.043-11.5-.19-17.14-.1-4.24-1.24-8.43-3.47-12.32-1.7-2.973-2.483-6.65-2.35-11.03.32-10.867.543-21.567.67-32.1.02-1.953.177-3.86.47-5.72.273-1.707.96-3.573%202.06-5.6%202.053-3.78%203.22-8.103%203.5-12.97%201.35-23.97.32-47.42%202.83-71.97.83-8.13.12-15.4%203.04-23.7Zm24.622%2049.592a.478.478%200%200%200-.366-.571l-9.263-2.02a.479.479%200%200%200-.571.367l-.004.02a.478.478%200%200%200%20.366.571l9.263%202.02a.479.479%200%200%200%20.571-.367l.004-.02Zm39.927-.694a.52.52%200%200%200-.601-.423l-6.523%201.126a.524.524%200%200%200-.424.601l.01.059a.524.524%200%200%200%20.601.424l6.523-1.126a.524.524%200%200%200%20.424-.601l-.01-.06Zm-37.689.772c-.593.047-.617.183-.07.41%201.173.487%202.467.737%203.88.75.113%200%20.21-.04.29-.12a.449.449%200%200%200%20.13-.27c.027-.34-.127-.54-.46-.6-1.18-.207-2.437-.263-3.77-.17Zm26.38%201.175a.653.653%200%200%200-.655-.646l-17.459.122a.649.649%200%200%200-.646.655v.039a.653.653%200%200%200%20.655.646l17.46-.122a.648.648%200%200%200%20.645-.654v-.04Zm-30.86%2021.998c0-.096-.096-.191-.282-.28-.187-.09-.461-.171-.806-.24a10.974%2010.974%200%200%200-1.206-.162%2017.542%2017.542%200%200%200-1.423-.061c-.987-.003-1.934.07-2.632.205-.698.134-1.09.318-1.091.512%200%20.096.096.191.282.28.187.09.461.171.806.24.345.069.755.124%201.206.162.451.039.935.059%201.424.061.986.003%201.933-.07%202.631-.205.698-.134%201.09-.318%201.091-.512Zm-23.027%20131.286c.033-.039.023-.115-.03-.222a2.318%202.318%200%200%200-.281-.406%206.87%206.87%200%200%200-.488-.528%2011.675%2011.675%200%200%200-1.28-1.094%207.29%207.29%200%200%200-.598-.399%202.324%202.324%200%200%200-.445-.214c-.114-.035-.191-.034-.224.005s-.023.115.03.222c.054.108.149.246.281.406.132.161.298.34.488.528a11.675%2011.675%200%200%200%201.28%201.094c.216.158.419.294.598.399.179.105.33.178.445.214.114.035.191.034.224-.005Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='M808.81%20289.04c12.38%206.86%2011.85%2026.41-1.05%2032.5-8.65%202.97-19.2.53-23.46-7.77-2.593-5.047-2.883-10.223-.87-15.53%203.91-10.29%2015.88-13.33%2025.38-9.2Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='m248%20308.57-3.06.97c-.32.1-.583.28-.79.54-2.12%202.61-4.28%206.52.07%208.47l3%201.35a28.726%2028.726%200%200%200-8.51.51c-10.31%202.17-14.51%2012.25-12.1%2021.89%202.44%209.75%2011.99%2014.92%2021.85%2012.56.073%208.58.53%2016.517%201.37%2023.81.447%203.813%201.437%207.76%202.97%2011.84l-5.89%2010.4a.7.7%200%200%201-1.22-.01%20559.035%20559.035%200%200%201-15.9-30.76c-4.247-8.853-7.597-17.183-10.05-24.99-5.8-18.51%208.86-37.78%2028.26-36.58Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='M248%20308.57c8.867.44%2016%203.68%2021.4%209.72%209.05%2010.11%208.71%2021.96%203.73%2033.84-3.46%208.22-10.237%2021.013-20.33%2038.38-1.533-4.08-2.523-8.027-2.97-11.84-.84-7.293-1.297-15.23-1.37-23.81%205.92-1.9%209.853-5.567%2011.8-11%203.57-9.96-1.94-22.36-13.04-23.96l-3-1.35c-4.35-1.95-2.19-5.86-.07-8.47.207-.26.47-.44.79-.54l3.06-.97Z'%20/%3e%3cpath%20fill='%23C3E1FB'%20d='m594.385%20310.987-10.378-.671a.68.68%200%200%200-.723.635l-.004.059a.68.68%200%200%200%20.635.723l10.378.671a.68.68%200%200%200%20.723-.635l.004-.06a.68.68%200%200%200-.635-.722Z'%20/%3e%3cpath%20fill='%23E3F1FB'%20d='M610.71%20311.07c-.1.5-.077%201.197.07%202.09l-.31-.48a.805.805%200%200%200-.74-.4l-10.68.28c-.093%200-.157-.04-.19-.12-.327-.707-.003-1.173.97-1.4a6.808%206.808%200%200%201%201.56-.16l9.32.19Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='M514.03%20319.47a2.34%202.34%200%201%200%200-4.68%202.34%202.34%200%200%200%200%204.68ZM247.22%20319.9c11.1%201.6%2016.61%2014%2013.04%2023.96-1.947%205.433-5.88%209.1-11.8%2011-9.86%202.36-19.41-2.81-21.85-12.56-2.41-9.64%201.79-19.72%2012.1-21.89a28.726%2028.726%200%200%201%208.51-.51Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M444.18%20372.25a.152.152%200%200%201-.064.081.136.136%200%200%201-.096.019l-.31-.05a.54.54%200%200%201-.43-.63c1-5.1%201.597-9.317%201.79-12.65.573-9.893%201.16-19.483%201.76-28.77a.367.367%200%200%201%20.42-.34l.27.05a.657.657%200%200%201%20.548.515.675.675%200%200%201%20.002.265c-.847%204.227-1.14%208.713-.88%2013.46.3%205.38-.88%2010.91-1.07%2016.28-.14%203.72-.787%207.643-1.94%2011.77Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='m493.906%20332.011-9.263-2.02a.48.48%200%200%200-.571.367l-.004.02a.48.48%200%200%200%20.366.571l9.263%202.019a.479.479%200%200%200%20.571-.366l.004-.02a.479.479%200%200%200-.366-.571ZM533.598%20331.465l-6.523%201.126a.52.52%200%200%200-.424.601l.01.059a.52.52%200%200%200%20.601.424l6.523-1.126a.52.52%200%200%200%20.424-.601l-.01-.059a.52.52%200%200%200-.601-.424ZM496.51%20332.66c1.333-.093%202.59-.037%203.77.17.333.06.487.26.46.6a.449.449%200%200%201-.13.27.396.396%200%200%201-.29.12c-1.413-.013-2.707-.263-3.88-.75-.547-.227-.523-.363.07-.41Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='m522.235%20333.189-17.459.122a.65.65%200%200%200-.646.654v.04a.651.651%200%200%200%20.655.646l17.459-.122a.651.651%200%200%200%20.646-.655v-.04a.65.65%200%200%200-.655-.645ZM374.85%20348.59c-.54.007-.813.31-.82.91a88.492%2088.492%200%200%200%20.93%2013.86c.087.607.073%201.36-.04%202.26-.18%201.36.093%202.11.82%202.25-.227.86-.89%201.263-1.99%201.21-2.673-.113-4.437-.13-5.29-.05l-5.45.09c-2.573.38-5.167.82-7.78%201.32-2.48.48-6.03.14-6.16-3.16-.193-4.753-.34-9.343-.44-13.77-.08-3.23%204.43-3.38%206.71-3.49%204.987-.26%209.767-.847%2014.34-1.76a6.132%206.132%200%200%200%202.35-1%20.973.973%200%200%201%20.94-.13c.587.2%201.213.687%201.88%201.46Zm-13.741%2013.226c.468.311%201.208.172%202.057-.388.849-.559%201.737-1.493%202.47-2.595.362-.546.676-1.116.922-1.68a7.513%207.513%200%200%200%20.513-1.602c.093-.495.101-.931.026-1.282-.076-.351-.234-.611-.466-.765-.468-.311-1.208-.172-2.057.387-.849.56-1.737%201.493-2.47%202.596a11.111%2011.111%200%200%200-.922%201.68%207.495%207.495%200%200%200-.513%201.602c-.093.495-.101.931-.026%201.282.076.351.234.611.466.765Z'%20/%3e%3cpath%20fill='%23478FFF'%20d='M375.74%20367.87c-.727-.14-1-.89-.82-2.25.113-.9.127-1.653.04-2.26a88.492%2088.492%200%200%201-.93-13.86c.007-.6.28-.903.82-.91.88%206.3%201.177%2012.727.89%2019.28Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='M362.104%20356.487c-1.525%202.295-1.971%204.681-.995%205.329.975.648%203.002-.687%204.527-2.983%201.525-2.295%201.971-4.681.995-5.329-.975-.648-3.002.687-4.527%202.983Z'%20/%3e%3cpath%20fill='%23C3E1FB'%20d='M592.52%20397.02c-.18%202.44-.327%204.73-.44%206.87a.367.367%200%200%201-.22.327.373.373%200%200%201-.39-.057l-.23-.2a1.285%201.285%200%200%201-.378-.508%201.31%201.31%200%200%201-.092-.632c1.487-15.933.67-31.88-2.45-47.84a1.256%201.256%200%200%201%20.39-1.18l.19-.18c.293-.267.477-.207.55.18a241.99%20241.99%200%200%201%202.48%2015.38c1.127%208.853%201.323%2018.133.59%2027.84Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='M488.307%20356.55c2.055.007%203.722-.314%203.723-.717.001-.403-1.663-.736-3.717-.743-2.055-.007-3.722.314-3.723.717-.001.403%201.663.736%203.717.743Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M533.95%20355.64c.427.707-.213%201.09-1.92%201.15l-29.88-.25a.514.514%200%200%201-.508-.405.548.548%200%200%201-.002-.235l.06-.26a.518.518%200%200%201%20.185-.296.533.533%200%200%201%20.335-.114l31.73.41Z'%20/%3e%3cpath%20fill='%23FE6D04'%20d='M368.46%20369.03c-.21%204.73-1.98%206.87-4.14%2010.32-.62.987-.907%203.033-.86%206.14-3.527-.56-5.407-1.817-5.64-3.77%203.19-4.23%205.98-6.56%205.19-12.6l5.45-.09Z'%20/%3e%3cpath%20fill='%231350CE'%20d='M539.23%20382.74c20.71%2011.71%2030.09%2033.65%2024.04%2056.84-1.033%203.967-2.467%207.987-4.3%2012.06-.14.32-.383.483-.73.49l-13.99.35-.95-.21c-.353-.073-.443-.27-.27-.59%202.76-4.953%204.6-8.607%205.52-10.96%205.44-13.88%203.49-26.61-5.85-38.19-1.147-1.413-2.597-2.76-4.35-4.04-5.433-4.28-11.117-6.98-17.05-8.1-15.6-2.95-31.26%203.15-40.25%2016.58-5.89%208.8-7.71%2020.84-4.25%2030.51%205.9%2016.5%2020.75%2026.66%2038.31%2026.58%205.907-.207%2011.8-1.683%2017.68-4.43l-1.35%2010.89-.64%205.45c-.04.327-.227.507-.56.54-5.673.573-11.337.84-16.99.8-12.473-.073-23.583-4.127-33.33-12.16-.207-.313-.58-.657-1.12-1.03-14.287-13.047-19.56-29-15.82-47.86%201.7-8.567%205.823-16.373%2012.37-23.42%2010.353-11.14%2023.153-16.683%2038.4-16.63%208.94.033%2017.433%202.21%2025.48%206.53Zm-23.891-.839a1.353%201.353%200%200%200-.365-.975%201.353%201.353%200%200%200-.947-.431l-1.359-.048a1.355%201.355%200%200%200-.975.365%201.351%201.351%200%200%200-.432.947l-.04%201.139a1.355%201.355%200%200%200%20.365.975%201.351%201.351%200%200%200%20.947.432l1.359.048a1.355%201.355%200%200%200%20.975-.365%201.351%201.351%200%200%200%20.432-.947l.04-1.14Zm-10.329.869c-.153-.66-.427-1.153-.82-1.48a1.21%201.21%200%200%200-.866-.279c-.315.022-.61.165-.824.399-1.033%201.147-1.007%202.287.08%203.42a1.467%201.467%200%200%200%201.06.45c1.293-.007%201.75-.843%201.37-2.51Zm20.16.36c0-.536-.213-1.05-.592-1.428a2.017%202.017%200%200%200-2.856%200%202.017%202.017%200%200%200%200%202.856%202.017%202.017%200%200%200%202.856%200c.379-.378.592-.892.592-1.428Zm-9.34%2088.26a2.154%202.154%200%200%200-.633-1.527%202.154%202.154%200%200%200-3.054%200%202.16%202.16%200%201%200%203.687%201.527Z'%20/%3e%3cpath%20fill='%23E3F1FB'%20d='m514.027%20380.495-1.359-.048a1.36%201.36%200%200%200-1.407%201.312l-.04%201.14a1.36%201.36%200%200%200%201.312%201.406l1.359.048a1.36%201.36%200%200%200%201.407-1.312l.04-1.139a1.36%201.36%200%200%200-1.312-1.407Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M440.86%20383.86c.23-1.04.39-2.21%201.15-2.96.447-.447.633-.357.56.27-.12%201.007-.563%201.967-1.33%202.88-.393.473-.52.41-.38-.19Z'%20/%3e%3cpath%20fill='%23E3F1FB'%20d='M505.01%20382.77c.38%201.667-.077%202.503-1.37%202.51a1.467%201.467%200%200%201-1.06-.45c-1.087-1.133-1.113-2.273-.08-3.42.214-.234.509-.377.824-.399a1.21%201.21%200%200%201%20.866.279c.393.327.667.82.82%201.48Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='M523.15%20385.15a2.02%202.02%200%201%200%20.001-4.039%202.02%202.02%200%200%200-.001%204.039Z'%20/%3e%3cpath%20fill='%23C3E1FB'%20d='M357.82%20381.72c.233%201.953%202.113%203.21%205.64%203.77-1.627%206.387-4.18%2012.55-7.66%2018.49-1.57%202.69-3.53%204.75-5.16%207.37a.323.323%200%200%200-.028.297.355.355%200%200%200%20.228.203l.7.19c-8.13%203.85-8.64%2010.61-11.03%2017.89-6.12-2.51-15.63-4.38-18.6%203.53-.153.393-.027.53.38.41%206.8-1.953%2013.617-2.01%2020.45-.17.36-1.12.967-2.22%201.82-3.3-1.973%207.173-1.797%2013.52.53%2019.04%202.113%204.993%203.413%209.113%203.9%2012.36l-32.53%2011.19c-.88.147-1.263-.443-1.15-1.77.04-.467.193-1.09.46-1.87%203.147-9.187%204.637-18.443%204.47-27.77%201.073-1.327%201.25-2.94.53-4.84-.993-2.607-1.493-4.853-1.5-6.74a54.474%2054.474%200%200%201%20.83-9.72c.85-4.74%201.07-7.96%206.01-8.88%201.86-.347%203.787-.87%205.78-1.57l2.43-.1c1.24-.37%202.43-.51%203.4-1.44%201.42-1.36%202.72-2.54%203.75-4.27a404.819%20404.819%200%200%201%209.77-15.8c1.907-2.947%204.1-5.113%206.58-6.5Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M438.14%20421.81a117.817%20117.817%200%200%200%206.04%2017.44.297.297%200%200%201-.17.4l-.29.12c-.3.12-.51.03-.63-.27a317.845%20317.845%200%200%201-4-10.39c-3.38-9.307-4.61-18.513-3.69-27.62.413-4.113%201.617-8.53%203.61-13.25a.457.457%200%200%201%20.6-.24l.24.1c.167.073.213.193.14.36-2.493%205.307-3.753%2010.637-3.78%2015.99-.02%205.52.54%2012.01%201.93%2017.36Z'%20/%3e%3cpath%20fill='%231350CE'%20d='M335.25%20392.24c-.547%204.52-2.64%207.873-6.28%2010.06-1.22.73-2.63%201.02-3.91%201.53a1.782%201.782%200%200%200-.8%202.647c.199.294.481.521.81.653l6.82%202.7c-1.993.7-3.92%201.223-5.78%201.57-4.94.92-5.16%204.14-6.01%208.88a54.474%2054.474%200%200%200-.83%209.72c.007%201.887.507%204.133%201.5%206.74.72%201.9.543%203.513-.53%204.84a135.477%20135.477%200%200%201-6.9-7.67c-2.09-2.52-.34-4.39.53-6.77a1.134%201.134%200%200%200-.12-1.01c-1.673-2.593-2.617-4.977-2.83-7.15a669.752%20669.752%200%200%201-1.55-19.33c-.2-2.97-.56-8.94%204.04-8.28.79.11%201.61.67%202.32.72.34.013.65-.07.93-.25%201.7-1.127%203.227-1.903%204.58-2.33%206.167-1.933%2010.837-1.023%2014.01%202.73Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='M538.35%20398.49a1551.767%201551.767%200%200%201-23.24%2065.57c-17.56.08-32.41-10.08-38.31-26.58-3.46-9.67-1.64-21.71%204.25-30.51%208.99-13.43%2024.65-19.53%2040.25-16.58%205.933%201.12%2011.617%203.82%2017.05%208.1Z'%20/%3e%3cpath%20fill='%23FE6D04'%20d='M335.25%20392.24a27.536%2027.536%200%200%201%204.78%2010.47c.207.913.067%201.63-.42%202.15a44.844%2044.844%200%200%201-5.29%204.87l-2.43.1-6.82-2.7a1.776%201.776%200%200%201-1.117-1.647%201.778%201.778%200%200%201%201.107-1.653c1.28-.51%202.69-.8%203.91-1.53%203.64-2.187%205.733-5.54%206.28-10.06ZM373.79%20408.1c-2.16-1.78-2.727-3.797-1.7-6.05%202.92-1.88%207.15-4.15%2010.61-4.17%203.453-.027%203.75.93.89%202.87-3.047%202.067-5.743%204.313-8.09%206.74-.34.36-.91.563-1.71.61Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M538.35%20398.49c1.753%201.28%203.203%202.627%204.35%204.04%209.34%2011.58%2011.29%2024.31%205.85%2038.19-.92%202.353-2.76%206.007-5.52%2010.96-.173.32-.083.517.27.59l.95.21-10.38%201.29a.806.806%200%200%200-.69.56c-.24.707-.293%201.503-.16%202.39.133.54.127%201.063-.02%201.57l-.21%201.34c-5.88%202.747-11.773%204.223-17.68%204.43a1551.767%201551.767%200%200%200%2023.24-65.57Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M372.09%20402.05c-1.027%202.253-.46%204.27%201.7%206.05-.46%204.51-8.33%209.24-11.94%2012.19-2.12%201.74-4.6%202.88-7%204.26-.027.013-1.677%201.093-4.95%203.24-1.76%201.16-3.54%202.03-5.34%202.61-.853%201.08-1.46%202.18-1.82%203.3-.453-1.587-1.197-2.843-2.23-3.77%202.39-7.28%202.9-14.04%2011.03-17.89a92.62%2092.62%200%200%200%206.07-3.68c4.58-3.02%209.407-5.123%2014.48-6.31Z'%20/%3e%3cpath%20fill='%231350CE'%20d='M686.83%20439.95c-1.027-.38-1.783-.917-2.27-1.61-.693-.987-1.613-1.287-2.76-.9l-7.8%202.62c-4.4-2.22-6.537-5.54-6.41-9.96.09-3.31%203.32-4.47%203.32-7.73a1.216%201.216%200%200%200-1.077-1.209%201.232%201.232%200%200%200-.583.069c-.907.347-1.783.52-2.63.52a1.223%201.223%200%200%201-.97-.42l-8.38-9.22c.167-2.333%201.093-3.703%202.78-4.11%2011.78-2.85%2016.56%206.68%2019.55%2015.99.26.83%201.07%202.53%201.6%203.22%203.17%204.09%205.82%207.72%205.63%2012.74Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='m657.27%20412.11%208.38%209.22c.26.287.583.427.97.42.847%200%201.723-.173%202.63-.52a1.234%201.234%200%200%201%201.52.574c.092.175.14.369.14.566%200%203.26-3.23%204.42-3.32%207.73-.127%204.42%202.01%207.74%206.41%209.96-2.9%202.22-6.343%203.33-10.33%203.33-3.94-.007-5.997-1.957-6.17-5.85l1.3-2.87a2.216%202.216%200%200%200-.45-2.49c-.76-.75-1.53-1.76-1.83-2.85-1.607-5.853-1.357-11.593.75-17.22Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M340.51%20429.93c1.033.927%201.777%202.183%202.23%203.77-6.833-1.84-13.65-1.783-20.45.17-.407.12-.533-.017-.38-.41%202.97-7.91%2012.48-6.04%2018.6-3.53Z'%20/%3e%3cpath%20fill='%23C3E1FB'%20d='M686.83%20439.95c.58%202.127.87%204.477.87%207.05a398.86%20398.86%200%200%201-.38%2017.97c-.073%201.54.52%203.773%201.78%206.7%201.493%203.487%203.52%207.37%206.08%2011.65.673%201.127.627%202.197-.14%203.21-12.087%203.013-24.26%204.397-36.52%204.15a.985.985%200%200%200-.83.39l-.67.85.69-18.9c.047-1.12.603-1.51%201.67-1.17a5.68%205.68%200%200%200%201.71.27c.527-.007.79-.273.79-.8v-3.46c0-.58-.29-.89-.87-.93l-4.24-.29-3.71-.83-3.87-23.03%208.31-5.24c.173%203.893%202.23%205.843%206.17%205.85%203.987%200%207.43-1.11%2010.33-3.33l7.8-2.62c1.147-.387%202.067-.087%202.76.9.487.693%201.243%201.23%202.27%201.61Zm-10.39%2026.12a5.72%205.72%200%200%200-1.37.29c-.48.173-.467.307.04.4%201.413.253%202.743.317%203.99.19.533-.06.847-.353.94-.88.6-3.38.87-6.77.81-10.17a.444.444%200%200%200-.132-.305.444.444%200%200%200-.308-.125h-.28c-.433.007-.687.223-.76.65l-1.35%208.49a1.75%201.75%200%200%201-1.58%201.46Zm9.92%201.33c-2.14%206.81-6.75%207.82-12.79%209.68-.293.087-.433.283-.42.59.007.153.063.29.17.41.18.213.413.327.7.34%207.21.43%2014.67-1.69%2012.81-10.99-.127-.62-.283-.63-.47-.03Z'%20/%3e%3cpath%20fill='%231350CE'%20d='m649.19%20442.78%203.87%2023.03c-.413.407-1.057.573-1.93.5-.347-.027-.513.133-.5.48.02.487.25.87.69%201.15.84.54%201.65%201.043%202.43%201.51l1.51%202.6a.708.708%200%200%201%20.009.715.734.734%200%200%201-.619.375c-8.74.16-17.21.213-25.41.16-4.62-.04-6.01-6.76-6.72-10.32-1.1-5.5-2.25-11.09-3.45-16.77a24.775%2024.775%200%200%201-.5-3.82c-.027-.447.183-.67.63-.67%209.367.033%2018.467.097%2027.3.19.887.007%201.783.297%202.69.87Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='M788.42%20457.33c.96%202.1%206.14%203.44%208.22%203.62%203.03.26%204.97-3.95%208.2-2.09%204.27%202.45%208.13%206.7%2010.86%2010.63%202.12%203.04-1.91%206.36-3.82%208.46a1.867%201.867%200%200%200-.45%201.63c.46%202.25%201.52%206.81%204.53%207.09%203.13.29%207.2-.57%207.92%203.58.873%204.993.98%209.97.32%2014.93-.63%204.77-8.75%201.96-10.58%205.27-.853%201.533-1.437%203.09-1.75%204.67-.96%204.82%207.27%206.46%203.92%2011.56-2.28%203.48-5.103%206.69-8.47%209.63-1.97%201.73-4.8%203.3-7.04.97-2.88-2.98-7.33-1.42-10.46.11-3.87%201.88.42%208.79-5.08%209.82-4.26.81-11.61%201.65-15.74-.47-3.84-1.96%200-7.43-4.19-9.68-1.813-.967-3.71-1.483-5.69-1.55-3.41-.11-5.77%204.32-9.31%202.08-4.5-2.847-8.05-6.637-10.65-11.37-3.06-5.6%208.45-7.18%203.02-15.07-.94-1.38-1.98-2.52-3.8-2.54-3.68-.02-7.16-.1-7.42-4.79-.233-4.26-.197-8.03.11-11.31.54-5.9%203.48-5.37%208.2-5.46%203.11-.07%205.99-7.18%203.71-9.31-3-2.8-5.79-5.43-2.41-9.59a70.63%2070.63%200%200%201%207.77-8.11c1.96-1.75%204.4-1.96%206.5-.44%203.44%202.49%206.2%201.59%2010.02-.35%202.32-1.18%202.21-4.55%202.5-6.8.38-2.96%204.05-3.39%206.47-3.5%204.153-.193%207.837-.05%2011.05.43%201.56.24%202.43%201.65%202.51%203.16.093%201.887.437%203.483%201.03%204.79Zm-6.485%2057.204a16.605%2016.605%200%200%200%2010.176-7.853c2.22-3.894%202.818-8.538%201.663-12.91a17.315%2017.315%200%200%200-2.899-5.982%2017.072%2017.072%200%200%200-4.924-4.421%2016.732%2016.732%200%200%200-6.198-2.185%2016.494%2016.494%200%200%200-6.528.383c-4.295%201.134-7.956%203.959-10.176%207.853-2.22%203.894-2.818%208.538-1.663%2012.91a17.324%2017.324%200%200%200%202.899%205.982%2017.072%2017.072%200%200%200%204.924%204.421%2016.732%2016.732%200%200%200%206.198%202.185c2.183.309%204.402.179%206.528-.383Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M449.36%20454.92a150.77%20150.77%200%200%200%206.35%2013.73c.147.28.063.43-.25.45l-.56.03c-.12.007-.207-.04-.26-.14a121.008%20121.008%200%200%201-7.28-16.43c-.267-.747-.33-1.477-.19-2.19.147-.727.367-.753.66-.08.67%201.52.92%203.13%201.53%204.63ZM562.29%20454.52a3.273%203.273%200%200%201-1.53-.75c-.24-.207-.203-.33.11-.37.48-.06.953.313%201.42%201.12Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='M562.29%20454.52a126.16%20126.16%200%200%201%2014.88%2012.34.457.457%200%200%201%20.15.32c.02.193-.043.227-.19.1l-14.84-12.76Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='M565.08%20492.41c-12.347-7.44-22.95-16.76-31.81-27.96a1.39%201.39%200%200%201-.31-.89l.04-5.27c.147-.507.153-1.03.02-1.57l.63-1.51a.904.904%200%200%201%20.553-.51c.123-.041.253-.055.382-.041a.911.911%200%200%201%20.365.121%2033.503%2033.503%200%200%201%206.06%204.55c6.673%206.3%2013.773%2012.61%2021.3%2018.93%201.53%201.28%203.36%201.87%205.31%201.82%203.287-.093%206.487-.153%209.6-.18%201.2-.007%201.353.393.46%201.2l-12.6%2011.31Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M676.44%20466.07a1.75%201.75%200%200%200%201.58-1.46l1.35-8.49c.073-.427.327-.643.76-.65h.28c.115%200%20.225.045.308.125.082.081.129.19.132.305.06%203.4-.21%206.79-.81%2010.17-.093.527-.407.82-.94.88-1.247.127-2.577.063-3.99-.19-.507-.093-.52-.227-.04-.4a5.72%205.72%200%200%201%201.37-.29Z'%20/%3e%3cpath%20fill='%23E3F1FB'%20d='m533%20458.29-.04%205.27c0%20.333.103.63.31.89%208.86%2011.2%2019.463%2020.52%2031.81%2027.96l-3.55%204.32-2.92%202.59c-.447.047-.867.23-1.26.55a.699.699%200%200%201-.81.08c-9.553-4.853-17.733-11.427-24.54-19.72a1.415%201.415%200%200%201-.33-.89l-.23-8.82%201.35-10.89.21-1.34Z'%20/%3e%3cpath%20fill='%232466F8'%20d='M348.99%20461.8c-.8%201.467-.737%203.13.19%204.99.447.887%201.02%201.45%201.72%201.69a85.72%2085.72%200%200%200%204.42%2020.51c-.533-.02-.703.563-.51%201.75.633%203.96%201.05%207.94%201.25%2011.94.187%203.66-.09%207.63-.83%2011.91a390.047%20390.047%200%200%201-7.2%2033l-7.54.29c-.827-2.213-1.273-4.923-1.34-8.13-.1-5.333-.147-10.763-.14-16.29.013-6.367-.42-11.07-1.3-14.11-1.52-5.233-3.45-9.743-5.79-13.53-2.73-4.41-6.85-8.4-10.52-12.23-2.507-2.613-4.153-6.147-4.94-10.6l32.53-11.19Z'%20/%3e%3cpath%20fill='%23E3F1FB'%20d='M478.8%20464.12c.54.373.913.717%201.12%201.03%208.5%2012.59%207.92%2024.37%205.89%2038.65-.06.4-.29.57-.69.51l-5.52-.83c-.4-.06-.67-.283-.81-.67-1.067-3.04-1.63-5.97-1.69-8.79-.147-6.52-.253-12.93-.32-19.23-.047-4.32.627-7.877%202.02-10.67Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='m653.06%20465.81%203.71.83c.893.287%201.977.35%203.25.19.217-.027.438-.002.644.073a1.374%201.374%200%200%201%20.866%201.577l-.54%202.43a.973.973%200%200%201-.569.689.985.985%200%200%201-.891-.059c-1.827-1.1-3.753-1.797-5.78-2.09-.78-.467-1.59-.97-2.43-1.51-.44-.28-.67-.663-.69-1.15-.013-.347.153-.507.5-.48.873.073%201.517-.093%201.93-.5Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M673.57%20477.08c6.04-1.86%2010.65-2.87%2012.79-9.68.187-.6.343-.59.47.03%201.86%209.3-5.6%2011.42-12.81%2010.99a.933.933%200%200%201-.7-.34.645.645%200%200%201-.17-.41c-.013-.307.127-.503.42-.59Z'%20/%3e%3cpath%20fill='%231350CE'%20d='M350.9%20468.48c7.773%201.82%2015.923%204.23%2024.45%207.23%201.53.53%202.22%201.08%202.55%202.78a289.363%20289.363%200%200%201%204.5%2033.39c-3.027.233-5.38.907-7.06%202.02-.64.073-1.02-.14-1.14-.64-2.02-8.55-4.49-16.9-5.69-25.44-.073-.5-.36-.713-.86-.64l-12.33%201.81a85.72%2085.72%200%200%201-4.42-20.51Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='M513.67%20473.55a2.16%202.16%200%201%200%200-4.32%202.16%202.16%200%200%200%200%204.32ZM761.386%20502.329c2.405%209.104%2011.605%2014.568%2020.549%2012.205%208.944-2.363%2014.245-11.659%2011.839-20.763-2.405-9.104-11.605-14.568-20.549-12.205-8.944%202.363-14.245%2011.659-11.839%2020.763Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M467.077%20485.987c.924.789%201.786%201.296%201.926%201.132.14-.164-.496-.937-1.42-1.726-.924-.789-1.786-1.296-1.926-1.132-.14.164.496.936%201.42%201.726Z'%20/%3e%3cpath%20fill='%232466F8'%20d='M695.04%20486.53c.79%2013.23-2.99%2027.33-5.57%2039.72-.613%202.973-.44%206.977.52%2012.01.933%204.873%203.34%2013.97%207.22%2027.29.133.467.29%201.533.47%203.2-2.273.413-4.12%201.083-5.54%202.01-.82.407-1.453.153-1.9-.76-3.353-6.84-7.027-15.08-11.02-24.72-3.73-8.99-5.68-18.13-7.91-27.51-.373-1.58-.937-1.65-1.69-.21-3.567%206.86-7.397%2014.14-11.49%2021.84a36.643%2036.643%200%200%200-1.93%204.25c-.213.587-.103%201.107.33%201.56l37.88%2039.19-3.1%202.04c-.747.047-1.853.49-3.32%201.33-1.08.613-2.49.88-4.23.8-4.9-.24-9.76%202.14-13.27%205.42-2.067%201.927-3.7%204.66-4.9%208.2a253.253%20253.253%200%200%200-4.01%2012.93c-3.107%2011.027-7.08%2024.21-11.92%2039.55a.485.485%200%200%201-.41.35.739.739%200%200%201-.27-.01c-.307-.087-.46-.287-.46-.6a916.14%20916.14%200%200%200-.38-18.96c-.33-11.18%202.46-21.31%205.45-31.92.098-.338.305-.636.59-.85%204.3-3.22%209.34-4.61%206.58-11.65-1.727-4.4-4.547-9.06-8.46-13.98-.88-1.1-2.38-1.63-2.86-2.7a1.136%201.136%200%200%201%20.09-1.17l2.9-4.32a1.394%201.394%200%200%200%20.206-1.066%201.409%201.409%200%200%200-.626-.894l-3.25-2.07a1.516%201.516%200%200%201-.64-.8c-2.213-6.167-3.633-12.083-4.26-17.75-.84-7.62-3.21-11.68-10.66-14.13a1.49%201.49%200%200%201-.86-.71c-3.387-6.02-5.47-12.547-6.25-19.58a726.105%20726.105%200%200%201%2015.89%2016.17%2025.981%2025.981%200%200%201%202.9%203.65.492.492%200%200%200%20.716.109.493.493%200%200%200%20.154-.219c4.673-13.313%208.43-26.53%2011.27-39.65l.67-.85a.985.985%200%200%201%20.83-.39c12.26.247%2024.433-1.137%2036.52-4.15Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='m375.34%20513.9%203.67%2017.35c.747-.907%201.167-.547%201.26%201.08a118.948%20118.948%200%200%200-9.87%209.3%201200.971%201200.971%200%200%201-18.2%2018.79c-1.46%201.413-3.06%202.09-4.8%202.03a1.307%201.307%200%200%201-.528-.136%201.306%201.306%200%200%201-.684-.82%201.332%201.332%200%200%201-.038-.544l1.88-13.36a390.047%20390.047%200%200%200%207.2-33c.74-4.28%201.017-8.25.83-11.91-.2-4-.617-7.98-1.25-11.94-.193-1.187-.023-1.77.51-1.75l12.33-1.81c.5-.073.787.14.86.64%201.2%208.54%203.67%2016.89%205.69%2025.44.12.5.5.713%201.14.64Z'%20/%3e%3cpath%20fill='%232466F8'%20d='M556.63%20507.34c-.8%202.273-1.777%203.927-2.93%204.96-1.793.527-4.197.853-7.21.98-7.78.33-12.39-4.29-18.08-8.63a19.893%2019.893%200%200%201-3.21-3.44c-1.007-1.373-1.43-2.807-1.27-4.3.153-1.467.573-3.097%201.26-4.89-.027-.227.303-.76.99-1.6l3.33-3.16c.18-.173.31-.143.39.09.533%201.453%201.307%202.593%202.32%203.42%204.927%204.013%209.88%207.517%2014.86%2010.51.9.55%201.68%201.27%201.77%202.39.018.214.084.421.194.605a1.41%201.41%200%200%200%201.033.684c.213.028.429.008.633-.059a14.89%2014.89%200%200%200%204.58-2.5.759.759%200%200%201%20.711-.122.771.771%200%200%201%20.499.532l.55%202.11c.087.34.023.647-.19.92-.62.787-.697%201.287-.23%201.5Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='M526.18%20490.42c-.687.84-1.017%201.373-.99%201.6l-31.36.08c-.307%200-.473-.153-.5-.46-.02-.273.113-.413.4-.42%207.793-.26%2017.05-.417%2027.77-.47%201.54-.007%203.1-.117%204.68-.33ZM563.95%20504.09c-.76-1.453-1.247-2.89-1.46-4.31a1.116%201.116%200%200%200-.769-.906%201.13%201.13%200%200%200-1.151.296c-.933.973-1.587%201.023-1.96.15l2.92-2.59c2.3.213%203.107%202.667%202.42%207.36Z'%20/%3e%3cpath%20fill='%232466F8'%20d='m242.93%20512.83-7.52-.17a.763.763%200%200%201-.518-.222.763.763%200%200%201-.222-.518l-.11-4.09a.757.757%200%200%201%20.71-.78l7.5-.45a.762.762%200%200%200%20.72-.74l.18-7.3a.758.758%200%200%201%20.76-.74l4.7-.02a.761.761%200%200%201%20.76.75l.08%207.23a.761.761%200%200%200%20.75.75l7.23.08a.762.762%200%200%201%20.75.76l-.02%204.72a.758.758%200%200%201-.74.76l-7.3.16a.763.763%200%200%200-.74.72l-.45%207.49a.761.761%200%200%201-.77.71l-4.1-.1a.763.763%200%200%201-.518-.222.763.763%200%200%201-.222-.518l-.16-7.51a.762.762%200%200%200-.75-.75Z'%20/%3e%3cpath%20fill='%231350CE'%20d='m615.88%20501.55%2010.21%2010.31c.78%207.033%202.863%2013.56%206.25%2019.58.193.347.48.583.86.71%207.45%202.45%209.82%206.51%2010.66%2014.13.627%205.667%202.047%2011.583%204.26%2017.75.12.34.333.607.64.8l3.25%202.07a1.409%201.409%200%200%201%20.632%201.449%201.394%201.394%200%200%201-.212.511l-2.9%204.32a1.136%201.136%200%200%200-.09%201.17c.48%201.07%201.98%201.6%202.86%202.7%203.913%204.92%206.733%209.58%208.46%2013.98%202.76%207.04-2.28%208.43-6.58%2011.65a1.633%201.633%200%200%200-.59.85c-2.99%2010.61-5.78%2020.74-5.45%2031.92.193%206.373.32%2012.693.38%2018.96%200%20.313.153.513.46.6.087.02.177.023.27.01a.485.485%200%200%200%20.41-.35c4.84-15.34%208.813-28.523%2011.92-39.55a253.253%20253.253%200%200%201%204.01-12.93c1.2-3.54%202.833-6.273%204.9-8.2%203.51-3.28%208.37-5.66%2013.27-5.42%201.74.08%203.15-.187%204.23-.8%201.467-.84%202.573-1.283%203.32-1.33-2.127%201.36-4.047%202.413-5.76%203.16-1.76.767-1.69%201.293.21%201.58.393.06%201.14.023%202.24-.11%203.867-.447%207.697-1.1%2011.49-1.96%207.02%206.213%2013.34%2012.95%2018.96%2020.21%202%202.587%203.82%205.443%205.46%208.57-.933%202.58-1.797%204.383-2.59%205.41-1.86%202.4-4.14%203.18-6.61%204.31a1.518%201.518%200%200%200-.89%201.43c.15%205.65-.58%2011.38.99%2016.89%201.33%204.72%203.61%209.38%205.73%2013.9%203.57%207.62%203.2%2014.7-3.9%2020.36-2.87%202.29-7.72%203.72-11.47%204.91a3.835%203.835%200%200%200-2.49%202.49c-7.95%2024.94-16.01%2052.66-23.86%2078.72-.54%201.78-.983%203.54-1.33%205.28-.253%201.267.207%203.45%201.38%206.55A498.054%20498.054%200%200%200%20685%20793.5c1.107%202.647%201.7%205.713%201.78%209.2l-2.23-1.68-11.64-8.89c.067-.2-.12-.383-.56-.55a.556.556%200%200%200-.618.162.58.58%200%200%200-.112.198l-46.54%20152.4c-3.033%208.187-5.647%2016.743-7.84%2025.67l-9.51.21%206.99-24.19c.273-.947-.08-1.42-1.06-1.42l-42.41.15c-.333%200-.617.12-.85.36-.52.527-.777%201.257-.77%202.19l-6.89%2022.91-9.19.07-.14-.26a.723.723%200%200%201-.05-.54l2.28-7.57%204.26-15.65%209.33-29.9%2012.87-42.25%205.82-18.91%201.31-4.55%2031.26-100a1.442%201.442%200%200%200-.47-1.56l-33.67-27.21-.16-10.31c3.867.04%207.73.07%2011.59.09%203.22.02%205.627-.23%207.22-.75%204.2-1.36%208.02-4.54%209.61-8.78.973-2.593%201.47-4.57%201.49-5.93.053-2.653.067-5.25.04-7.79-.027-2.413.16-4.92.56-7.52.58-3.8.767-7.75.56-11.85a.831.831%200%200%200-.48-.75c-.367-.187-.837-.163-1.41.07.093-2.193.647-3.353%201.66-3.48%201.8-3.76%201.277-7.49-1.57-11.19-.133-1.453-.193-3.437-.18-5.95.007-3.153.043-6.347.11-9.58.06-2.58.82-4.91%202.1-7.12%204.153-7.167%208.407-13.74%2012.76-19.72%204.33-5.95%207.82-11.4%208.67-18.87.033-.3-.09-.5-.37-.6-.22-.087-.36-.183-.42-.29l.1-.99c2.487%201.107%205.047%201.5%207.68%201.18a2.301%202.301%200%200%200%202.01-2.45c-.293-3.86.123-7.783%201.25-11.77a2.305%202.305%200%200%200-.846-2.475%202.284%202.284%200%200%200-.834-.385l-4.38-1.03a.815.815%200%200%200-.708.164.802.802%200%200%200-.292.666c.127%202.707.29%205.303.49%207.79.2%202.453-.873%203.89-3.22%204.31-1.113.34-2.143-.12-3.09-1.38-4.71-6.28-8.89-12.38-11.73-19.77a115.154%20115.154%200%200%200-4.35-9.93c-1.127-2.267-2.273-3.54-3.44-3.82-5.18-1.233-8.987-4.2-11.42-8.9l-3.69-6.35-.13-2.26%202.36-2.39a.676.676%200%200%200%20.173-.663.684.684%200%200%200-.493-.477c-3.09-.76-2.67-3-2.68-5.49a.75.75%200%200%200-1.26-.54%204.496%204.496%200%200%200-1.23%201.99c-.26.887-.85%201.317-1.77%201.29-2.44-.067-4.403-.467-5.89-1.2-1.77-2.8-1.93-7.04%201.73-8.4%209.79-3.61%2014.82.82%2016.11%2010.55.127.973.677%201.393%201.65%201.26l4.31-.6c.993-.133%201.487-.703%201.48-1.71l-.14-26.24Zm20.05%20177.15c-2.03%203.04-.8%205.72-1.79%208.71-.107.32-.303.567-.59.74-1.453.9-2.917%201.74-4.39%202.52-.7.367-.963%201.037-.79%202.01a.722.722%200%200%200%20.79.59c2.45-.28%205.31.08%207.44-1.42a21.577%2021.577%200%200%201%205.25-2.69%202.271%202.271%200%200%200%201.46-2.69c-.38-1.54-1.1-3.03-2.16-4.47-.06-3.15-1.79-6.4-5.22-3.3Zm40.6%2062.36c.58-1.693.23-1.913-1.05-.66-3.28%203.19-7.08%204.07-11.21%205.63a.785.785%200%200%200-.45%201.03c1.8%204.25%203.19%209.56%205.55%2013.82a.526.526%200%200%200%20.471.266.534.534%200%200%200%20.459-.286c.3-.593.553-1.257.76-1.99%201.807-6.48%203.63-12.417%205.47-17.81Zm-27.54%2029.91c4.373.3%208.64.277%2012.8-.07a1.02%201.02%200%200%200%20.8-1.53c-1-1.76-2.03-3.54-2.71-5.44-2.24-6.253-4.88-12.183-7.92-17.79a11.786%2011.786%200%200%200-2.31-2.98.635.635%200%200%200-.691-.124.643.643%200%200%200-.389.584c-.067%206.473-.023%2013.19.13%2020.15a43.013%2043.013%200%200%201-.35%206.42.679.679%200%200%200%20.151.529.694.694%200%200%200%20.489.251Zm-19.51-14.15a.584.584%200%200%200-.763.037.589.589%200%200%200-.147.233l-4.49%2013.13a.588.588%200%200%200-.022.27.588.588%200%200%200%20.309.426.574.574%200%200%200%20.263.064l21.05-.12a.58.58%200%200%200%20.36-1.04l-16.56-13Zm33.73%2025.46a10.821%2010.821%200%200%201-3.33-1.79c-.87-.68-1.87-.62-2.91-.61-11.42.173-22.993.203-34.72.09a1.16%201.16%200%200%200-1.12.81l-10.02%2031.7a.641.641%200%200%200%20.325.77c.091.046.192.07.295.07h42.02a1.841%201.841%200%200%200%201.76-1.3l8.64-27.93c.28-.907-.033-1.51-.94-1.81Zm-21.86%2073.83a.704.704%200%200%200%20.66-.49l10.06-32.05a.701.701%200%200%200-.67-.91l-42.9-.07a.699.699%200%200%200-.66.49l-10.06%2032.06a.693.693%200%200%200%20.101.621.692.692%200%200%200%20.559.289l42.91.06ZM589.65%20882l-4.3%2013.85a.864.864%200%200%200%20.126.771.871.871%200%200%200%20.694.359l4.9.08%2037.41.01a1.24%201.24%200%200%200%20.73-.239c.211-.155.365-.373.44-.621l9.31-30.25a.783.783%200%200%200-.119-.698.792.792%200%200%200-.631-.322l-42.37-.08a1.15%201.15%200%200%200-1.1.81L589.65%20882Zm19.21%2053.85%207.74-.07c.301%200%20.595-.097.838-.277.243-.18.422-.433.512-.723l8.63-27.93a.778.778%200%200%200-.397-.928.77.77%200%200%200-.353-.082l-29.57.11-12.83-.1c-.847-.007-1.393.393-1.64%201.2l-8.59%2027.77a.74.74%200%200%200%20.11.647.715.715%200%200%200%20.58.293l34.97.09Z'%20/%3e%3cpath%20fill='%232466F8'%20d='m410.17%20531.21-.35-1.79c-.14-.707-.26-.703-.36.01-.08.567-.373.973-.88%201.22a1.283%201.283%200%200%200-.52.45c-4.05%206.33-8.25%2012.55-11.68%2019.28a2746.648%202746.648%200%200%200-9.23%2018.27c-3.46%206.92-7.05%2014.95-9.08%2021.62-.913%203.007-1.37%205.71-1.37%208.11.02%2056.113-.017%20112.227-.11%20168.34%200%20.68.25%201.783.75%203.31-24.34%2019.927-40.91%2033.547-49.71%2040.86-3.6%202.993-7.037%205.39-10.31%207.19l-6.63%201.05c-7.93-.06-14.29-5.56-15.54-13.26-.14-.88-.207-3.797-.2-8.75.12-58.06.103-112.767-.05-164.12-.01-5.61%204.5-12.2%208.01-17.3%204.44-6.44%208.69-12.03%2012.75-16.77a362.858%20362.858%200%200%201%2030.77-31.86%20861.407%20861.407%200%200%201%2011.07-5.8c.193-.1.273-.24.24-.42-.067-.307-.25-.427-.55-.36-1.813.387-3.477.363-4.99-.07a1200.971%201200.971%200%200%200%2018.2-18.79c3.14-3.313%206.43-6.413%209.87-9.3l12.06-10.22c.253-.213.417-.483.49-.81l.56-2.58L410.01%20502l.16%2029.21Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M553.7%20512.3c.08%203.98.623%208.023%201.63%2012.13%201.5%206.09%205.39%209.5%2010.17%2013.47%201.45%201.21%203.86%202.62%205.3%203.04%204.72%201.367%209.46%202.787%2014.22%204.26-6.19-.01-11.42.9-14.17%206.9a364.293%20364.293%200%200%201-5%2010.43.925.925%200%200%201-.82.53l-8%20.3-33.24-.05%205.35-.42c.327-.027.517-.2.57-.52%203.207-19.267%202.773-38.507-1.3-57.72%205.69%204.34%2010.3%208.96%2018.08%208.63%203.013-.127%205.417-.453%207.21-.98Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='M566.72%20508.56c1.32%202.733%202.12%205.473%202.4%208.22-1.8-.307-3.023-.163-3.67.43a.962.962%200%200%201-1.59-.53c-.587-2.96-.433-5.92.46-8.88.107-.367.35-.52.73-.46.633.1%201.19.507%201.67%201.22Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='M561.15%20514.74c.08%202.06.15%206.17%201.84%207.56a25.709%2025.709%200%200%201%204.19%204.38c1.42%201.9%203.487%203.29%206.2%204.17%204.253%201.38%208.52%202.71%2012.8%203.99a16.04%2016.04%200%200%200%204.9.66c1.687%203.12%204.213%204.06%207.58%202.82%201.19-.44%201.81-1.37%203-1.89l3.69%206.35c-.733%202.427-2.523%203.723-5.37%203.89-2.133.127-5.09-.067-8.87-.58l-6.09-.89c-4.76-1.473-9.5-2.893-14.22-4.26-1.44-.42-3.85-1.83-5.3-3.04-4.78-3.97-8.67-7.38-10.17-13.47-1.007-4.107-1.55-8.15-1.63-12.13%201.153-1.033%202.13-2.687%202.93-4.96a148.715%20148.715%200%200%200%203.06%203.66c.167.193.353.36.56.5a.83.83%200%200%201%20.39.64c.053.587%200%20.597-.16.03a.696.696%200%200%200-.19-.32c-.513-.493-.633-.407-.36.26.333.807.74%201.683%201.22%202.63Z'%20/%3e%3cpath%20fill='%23FE6D04'%20d='m382.4%20511.88-.3%2010.77a1.423%201.423%200%200%200%20.995%201.4c.196.061.402.078.605.05l3.02-.38c1.453.147%201.317.87-.41%202.17-.713.533-1.24.943-1.58%201.23a47.296%2047.296%200%200%201-5.72%204.13l-3.67-17.35c1.68-1.113%204.033-1.787%207.06-2.02Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='M692.14%20570.76c-.24%201.2-.043%202.46.59%203.78%201.093%202.26%201.92%203.943%202.48%205.05.48.953.733%201.77.76%202.45.047%201.48-.473%202.267-1.56%202.36l-37.88-39.19c-.433-.453-.543-.973-.33-1.56.5-1.34%201.143-2.757%201.93-4.25%204.093-7.7%207.923-14.98%2011.49-21.84.753-1.44%201.317-1.37%201.69.21%202.23%209.38%204.18%2018.52%207.91%2027.51%203.993%209.64%207.667%2017.88%2011.02%2024.72.447.913%201.08%201.167%201.9.76Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='m393.38%20518.72-.56%202.58a1.442%201.442%200%200%201-.49.81l-12.06%2010.22c-.093-1.627-.513-1.987-1.26-1.08a47.296%2047.296%200%200%200%205.72-4.13c.34-.287.867-.697%201.58-1.23%201.727-1.3%201.863-2.023.41-2.17%202.307-.907%204.527-2.573%206.66-5Z'%20/%3e%3cpath%20fill='%23E3F1FB'%20d='M601.53%20534.17c-.673-.887-.987-2.083-.94-3.59a1.192%201.192%200%200%200-.706-1.124%201.163%201.163%200%200%200-.454-.096l-9.07-.05c-.127-.553%200-1.427.38-2.62%201.487.733%203.45%201.133%205.89%201.2.92.027%201.51-.403%201.77-1.29a4.496%204.496%200%200%201%201.23-1.99.747.747%200%200%201%20.806-.139.75.75%200%200%201%20.454.679c.01%202.49-.41%204.73%202.68%205.49a.684.684%200%200%201%20.493.477.69.69%200%200%201-.173.663l-2.36%202.39Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='m601.53%20534.17.13%202.26c-1.19.52-1.81%201.45-3%201.89-3.367%201.24-5.893.3-7.58-2.82l-.58-2.82-.14-3.37%209.07.05a1.163%201.163%200%200%201%20.835.363%201.192%201.192%200%200%201%20.325.857c-.047%201.507.267%202.703.94%203.59Z'%20/%3e%3cpath%20fill='%231350CE'%20d='M410.17%20531.21v30.62c0%201.06.53%201.583%201.59%201.57l23.53-.3%2088.5.21%2033.24.05%2041.28.14c.298%200%20.584.119.795.33.212.212.332.5.335.8%200%20.627-.307.96-.92%201a91.202%2091.202%200%200%201-7.02.19c-10.047-.087-20.18-.04-30.4.14l-26.9-.02-53.76.12h-.22l-22.64.01-46.71-.11a.661.661%200%200%200-.67.67l-.08%2097.69a.76.76%200%200%200%20.76.76l59.65-.06%207.01.09%2017.61-.07c.553-.007.827-.283.82-.83a2650.092%202650.092%200%200%201-.09-44.28c.033-5.827%202.413-10.507%207.14-14.04%201.61-1.2%203.8-1.79%205.75-2.52a1.507%201.507%200%200%200%20.97-1.41l-.09-21.05c0-.607.303-.917.91-.93l4.23-.09c.64-.013.96.303.96.95l-.02%2020.84c-.96%202.72-1.43%205.91-1.41%209.57.113%2019.947.077%2052.613-.11%2098-.013%203.64.087%2011.493.3%2023.56.07%203.86-.49%207.53-1.13%2011.22a1.224%201.224%200%200%200%20.21.93c3.01%204.29%203.53%2013.65%202.51%2018.69-.64%203.18-1.25%206.28-1.22%209.56.04%204.267-.05%208.647-.27%2013.14-.02.347-.203.537-.55.57l-2.64.23c-8.3-1.06-15.41-7.42-15.38-16.2.033-12.647.057-25.433.07-38.36a.972.972%200%200%200-.593-.89.962.962%200%200%200-.367-.07c-11.847.087-23.813.107-35.9.06-.307%200-.82.133-1.54.4l-17.75-.25a1.048%201.048%200%200%201-1.03-1.06l.13-9.33a.451.451%200%200%200-.74-.36l-60.98%2048.94c-.5-1.527-.75-2.63-.75-3.31.093-56.113.13-112.227.11-168.34%200-2.4.457-5.103%201.37-8.11%202.03-6.67%205.62-14.7%209.08-21.62a2746.648%202746.648%200%200%201%209.23-18.27c3.43-6.73%207.63-12.95%2011.68-19.28.131-.196.311-.352.52-.45.507-.247.8-.653.88-1.22.1-.713.22-.717.36-.01l.35%201.79Zm84.96%20136.86h-84.55a.541.541%200%200%200-.54.56c.22%207.447.247%2014.477.08%2021.09-.23%209.6%201.49%2016.96%2010.43%2021.04%201.16.527%202.37.8%203.63.82%2023.767.34%2047.513.363%2071.24.07a.592.592%200%200%200%20.424-.179.612.612%200%200%200%20.176-.431l-.08-42.16a.81.81%200%200%200-.81-.81Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='m585.02%20545.2%206.09.89a77.383%2077.383%200%200%200%204.47%206.32c2.25%202.87%203.26%205.7%203.88%209.18a235.344%20235.344%200%200%200%206.53%2027.09%201.767%201.767%200%200%200%201.32%201.22l9.5%202.03-5.68-.42-4-1.18c-8.607%204.273-16.143%209.337-22.61%2015.19-2.62%202.36-4.41%205.47-2.12%208.07%205.26%205.98%2010.473%2011.973%2015.64%2017.98%201%201.5%202.33%202.65%202.74%204.43.54%202.37.23%204.89.58%207.37a176.313%20176.313%200%200%200%204.08%2020.6.646.646%200%200%201-.332.736.61.61%200%200%201-.278.064l-40.04.25%2010.95-.91c.093-.007.153-.057.18-.15a.69.69%200%200%200-.01-.35.635.635%200%200%200-.35-.4c-5.46-2.44-5.43-8.36-5.5-13.63-.12-8.547-.293-17.11-.52-25.69-.047-1.573-.63-4.343-1.75-8.31-1.38-4.89-.34-10.24-.5-15.3-.267-8.793-.337-18.62-.21-29.48.033-2.92-1.96-4.533-5.98-4.84%2010.22-.18%2020.353-.227%2030.4-.14a91.202%2091.202%200%200%200%207.02-.19c.613-.04.92-.373.92-1a1.15%201.15%200%200%200-.334-.8%201.129%201.129%200%200%200-.796-.33l-41.28-.14%208-.3a.925.925%200%200%200%20.82-.53%20364.293%20364.293%200%200%200%205-10.43c2.75-6%207.98-6.91%2014.17-6.9Z'%20/%3e%3cpath%20fill='%23C3E1FB'%20d='M605.35%20542.78c2.433%204.7%206.24%207.667%2011.42%208.9%201.167.28%202.313%201.553%203.44%203.82a115.154%20115.154%200%200%201%204.35%209.93c2.84%207.39%207.02%2013.49%2011.73%2019.77.947%201.26%201.977%201.72%203.09%201.38-.927%201.487-1.31%202.82-1.15%204l-.1.99c-.76.873-1.783%201.373-3.07%201.5-6.213.227-12.297-.153-18.25-1.14l-9.5-2.03a1.764%201.764%200%200%201-1.32-1.22%20235.344%20235.344%200%200%201-6.53-27.09c-.62-3.48-1.63-6.31-3.88-9.18a77.383%2077.383%200%200%201-4.47-6.32c3.78.513%206.737.707%208.87.58%202.847-.167%204.637-1.463%205.37-3.89Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='m348.03%20547.59-1.88%2013.36c-.025.182-.012.367.038.544a1.333%201.333%200%200%200%20.684.82c.164.082.344.128.528.136%201.74.06%203.34-.617%204.8-2.03%201.513.433%203.177.457%204.99.07.3-.067.483.053.55.36.033.18-.047.32-.24.42a861.407%20861.407%200%200%200-11.07%205.8l-3.82.64a1.665%201.665%200%200%201-1.364-.389%201.652%201.652%200%200%201-.566-1.301c.05-1.81.93-2.89.95-4.74a69.623%2069.623%200%200%200-1.14-13.4l7.54-.29Z'%20/%3e%3cpath%20fill='%23E3F1FB'%20d='M457.58%20566.07c.22%201.913.277%203.94.17%206.08-.113%202.073-.18%204.09-.2%206.05-.093%207.967-.09%2016.127.01%2024.48.07%205.72%201.84%2010.99%208.6%2010.94%209.15-.07%208.99-8.7%209.12-15.86.18-10.113.047-20.27-.4-30.47-.013-.32.137-.5.45-.54l4.89-.69h.22l6.95.33c.333.013.563.177.69.49%206.62%2016.99%207.97%2033.48%207.46%2051.47-.42%2014.93.04%2030.1-.13%2044.95a1.323%201.323%200%200%201-.373.903%201.305%201.305%200%200%201-.887.397c-6.093.273-12.197.21-18.31-.19a.817.817%200%200%201-.54-.251.794.794%200%200%201-.22-.549l-.18-28.92c.14-4.88.187-10%20.14-15.36-.007-.827-.49-1.387-1.45-1.68a.931.931%200%200%200-.57.02c-.707.233-1.063.72-1.07%201.46-.087%2012.28-.113%2024.313-.08%2036.1a35.92%2035.92%200%200%201-1.34%209.79l-59.65.06a.756.756%200%200%201-.537-.223.756.756%200%200%201-.223-.537l.08-97.69a.676.676%200%200%201%20.414-.622.661.661%200%200%201%20.256-.048l46.71.11Z'%20/%3e%3cpath%20fill='%23C3E1FB'%20d='m480.22%20566.06-4.89.69c-.313.04-.463.22-.45.54.447%2010.2.58%2020.357.4%2030.47-.13%207.16.03%2015.79-9.12%2015.86-6.76.05-8.53-5.22-8.6-10.94-.1-8.353-.103-16.513-.01-24.48.02-1.96.087-3.977.2-6.05.107-2.14.05-4.167-.17-6.08l22.64-.01ZM534.2%20565.94c3.613%208.547%205.31%2017.833%205.09%2027.86-.12%205.327-.123%2017.37-.01%2036.13.06%209.85-2.08%2022.49-2.84%2034.97l-5.57-.01a.41.41%200%200%201-.41-.41c-.1-13.247-.037-26.827.19-40.74.067-4.42-.29-7.733-1.07-9.94-1.8-5.1-6.84-9.69-12.5-10.41-.527-.067-.877-.22-1.05-.46-.213-.307-.313-.723-.3-1.25l.02-20.84c0-.647-.32-.963-.96-.95l-4.23.09c-.607.013-.91.323-.91.93l.09%2021.05a1.512%201.512%200%200%201-.97%201.41c-1.95.73-4.14%201.32-5.75%202.52-4.727%203.533-7.107%208.213-7.14%2014.04-.093%2014.913-.063%2029.673.09%2044.28.007.547-.267.823-.82.83l-17.61.07c-.947.093-1.773-.03-2.48-.37-.307-.147-.457-.387-.45-.72l.29-29.33.18%2028.92c0%20.204.078.4.219.549a.822.822%200%200%200%20.541.251c6.113.4%2012.217.463%2018.31.19.335-.013.653-.155.887-.397.235-.242.368-.565.373-.903.17-14.85-.29-30.02.13-44.95.51-17.99-.84-34.48-7.46-51.47-.127-.313-.357-.477-.69-.49l-6.95-.33%2053.76-.12Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M561.1%20565.96c4.02.307%206.013%201.92%205.98%204.84-.127%2010.86-.057%2020.687.21%2029.48.16%205.06-.88%2010.41.5%2015.3%201.12%203.967%201.703%206.737%201.75%208.31.227%208.58.4%2017.143.52%2025.69.07%205.27.04%2011.19%205.5%2013.63.173.08.29.213.35.4a.69.69%200%200%201%20.01.35c-.027.093-.087.143-.18.15l-10.95.91-28.35-.12c.76-12.48%202.9-25.12%202.84-34.97-.113-18.76-.11-30.803.01-36.13.22-10.027-1.477-19.313-5.09-27.86l26.9.02Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='M697.68%20568.75c.847%205.913%202.863%2011.54%206.05%2016.88a1.277%201.277%200%200%201%20.075%201.173%201.26%201.26%200%200%201-.915.727c-1.487.28-2.62.807-3.4%201.58-3.793.86-7.623%201.513-11.49%201.96-1.1.133-1.847.17-2.24.11-1.9-.287-1.97-.813-.21-1.58%201.713-.747%203.633-1.8%205.76-3.16l3.1-2.04c1.087-.093%201.607-.88%201.56-2.36-.027-.68-.28-1.497-.76-2.45-.56-1.107-1.387-2.79-2.48-5.05-.633-1.32-.83-2.58-.59-3.78%201.42-.927%203.267-1.597%205.54-2.01Z'%20/%3e%3cpath%20fill='%23FE6D04'%20d='M638.23%20590.58c-.16-1.18.223-2.513%201.15-4%202.347-.42%203.42-1.857%203.22-4.31a234.24%20234.24%200%200%201-.49-7.79.803.803%200%200%201%20.292-.666.797.797%200%200%201%20.708-.164l4.38%201.03a2.296%202.296%200%200%201%201.68%202.86c-1.127%203.987-1.543%207.91-1.25%2011.77a2.298%202.298%200%200%201-2.01%202.45c-2.633.32-5.193-.073-7.68-1.18Z'%20/%3e%3cpath%20fill='%231350CE'%20d='M607.13%20590.33a421.81%20421.81%200%200%201-2.04%2016.86c-.38%202.667-1.85%204.013-4.41%204.04-1.033.007-1.763.423-2.19%201.25-.213.42-.16.803.16%201.15l3.14%203.32.61.81-1.2%2015.45c-.027.327-.197.433-.51.32-.947-.36-1.83-1.013-2.65-1.96-5.167-6.007-10.38-12-15.64-17.98-2.29-2.6-.5-5.71%202.12-8.07%206.467-5.853%2014.003-10.917%2022.61-15.19Z'%20/%3e%3cpath%20fill='%232466F8'%20d='M611.13%20591.51c2.22%201.147%204.743%201.74%207.57%201.78%203.273.04%206.54.22%209.8.54%202.267.22%204.453-.033%206.56-.76%201.287-.127%202.31-.627%203.07-1.5.06.107.2.203.42.29.28.1.403.3.37.6-.85%207.47-4.34%2012.92-8.67%2018.87-4.353%205.98-8.607%2012.553-12.76%2019.72-1.28%202.21-2.04%204.54-2.1%207.12a517.889%20517.889%200%200%200-.11%209.58c-.013%202.513.047%204.497.18%205.95-.493%203.733-.553%207.25-.18%2010.55.053.44.637.653%201.75.64-1.013.127-1.567%201.287-1.66%203.48-.007%204.133.047%208.34.16%2012.62.033%201.273-.29%201.99-.97%202.15l-4.05.39c-.48-.007-.76-.177-.84-.51a730.473%20730.473%200%200%200-3.28-13.99.888.888%200%200%200-.85-.68l-45.38-.31-29.05.25a.415.415%200%200%200-.297.126.435.435%200%200%200-.123.304l-.03%2042.3c0%20.313.133.547.4.7.193.113.41.147.65.1-.747.02-1.107.423-1.08%201.21a382.6%20382.6%200%200%201%20.12%2017.97c-.007.333.157.5.49.5l32.3.12-31.7.13a1.222%201.222%200%200%200-.873.364%201.216%201.216%200%200%200-.357.876l.07%2031.34.07%203.61c.227%203.393-.003%205.93-.69%207.61-3.34%208.127-9.553%2011.993-18.64%2011.6l2.64-.23c.347-.033.53-.223.55-.57.22-4.493.31-8.873.27-13.14-.03-3.28.58-6.38%201.22-9.56%201.02-5.04.5-14.4-2.51-18.69a1.228%201.228%200%200%201-.21-.93c.64-3.69%201.2-7.36%201.13-11.22-.213-12.067-.313-19.92-.3-23.56.187-45.387.223-78.053.11-98-.02-3.66.45-6.85%201.41-9.57-.013.527.087.943.3%201.25.173.24.523.393%201.05.46%205.66.72%2010.7%205.31%2012.5%2010.41.78%202.207%201.137%205.52%201.07%209.94-.227%2013.913-.29%2027.493-.19%2040.74a.41.41%200%200%200%20.41.41l5.57.01%2028.35.12%2040.04-.25a.61.61%200%200%200%20.499-.247.636.636%200%200%200%20.111-.553%20176.313%20176.313%200%200%201-4.08-20.6c-.35-2.48-.04-5-.58-7.37-.41-1.78-1.74-2.93-2.74-4.43.82.947%201.703%201.6%202.65%201.96.313.113.483.007.51-.32l1.2-15.45c1.027-1.393%201.473-3.387%201.34-5.98a.658.658%200%200%200-.6-.62c-1.547-.14-2.897.18-4.05.96a.826.826%200%200%200-.336.906.845.845%200%200%200%20.156.304l2.88%203.62-3.14-3.32c-.32-.347-.373-.73-.16-1.15.427-.827%201.157-1.243%202.19-1.25%202.56-.027%204.03-1.373%204.41-4.04a421.81%20421.81%200%200%200%202.04-16.86l4%201.18Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='M616.81%20591.93c5.953.987%2012.037%201.367%2018.25%201.14-2.107.727-4.293.98-6.56.76-3.26-.32-6.527-.5-9.8-.54-2.827-.04-5.35-.633-7.57-1.78l5.68.42ZM602.4%20617.76l-.61-.81-2.88-3.62a.835.835%200%200%201%20.18-1.21c1.153-.78%202.503-1.1%204.05-.96a.656.656%200%200%201%20.6.62c.133%202.593-.313%204.587-1.34%205.98Z'%20/%3e%3cpath%20fill='%23C3E1FB'%20d='M745.744%20617.546c1.002%201.875%203.236%202.637%204.989%201.7%201.754-.936%202.364-3.216%201.363-5.092-1.002-1.875-3.236-2.637-4.989-1.7-1.754.936-2.364%203.216-1.363%205.092Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='m474.9%20634.69-.29%2029.33c-.007.333.143.573.45.72.707.34%201.533.463%202.48.37l-7.01-.09a35.92%2035.92%200%200%200%201.34-9.79c-.033-11.787-.007-23.82.08-36.1.007-.74.363-1.227%201.07-1.46.2-.067.39-.073.57-.02.96.293%201.443.853%201.45%201.68.047%205.36%200%2010.48-.14%2015.36Z'%20/%3e%3cpath%20fill='%232466F8'%20d='M686.78%20802.7c-.08-3.487-.673-6.553-1.78-9.2a498.054%20498.054%200%200%201-6.13-15.36c-1.173-3.1-1.633-5.283-1.38-6.55.347-1.74.79-3.5%201.33-5.28%207.85-26.06%2015.91-53.78%2023.86-78.72a3.835%203.835%200%200%201%202.49-2.49c3.75-1.19%208.6-2.62%2011.47-4.91%207.1-5.66%207.47-12.74%203.9-20.36-2.12-4.52-4.4-9.18-5.73-13.9-1.57-5.51-.84-11.24-.99-16.89-.009-.299.07-.595.229-.849.158-.255.388-.457.661-.581%202.47-1.13%204.75-1.91%206.61-4.31.793-1.027%201.657-2.83%202.59-5.41%202.367%203.587%204.173%206.77%205.42%209.55.813%201.82%201.223%204.007%201.23%206.56.02%209.733-.017%2018.823-.11%2027.27-.08%207.79.05%2015.6.04%2023.32-.027%2037.233-.017%2074.467.03%20111.7.007%206.54-.423%2010.74-1.29%2012.6-4.01%208.58-13.57%2012.72-22.3%208.81-1.94-.86-4.543-2.617-7.81-5.27a604.809%20604.809%200%200%200-12.34-9.73Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M615.46%20653.7c2.847%203.7%203.37%207.43%201.57%2011.19-1.113.013-1.697-.2-1.75-.64-.373-3.3-.313-6.817.18-10.55Z'%20/%3e%3cpath%20fill='%23478FFF'%20d='M738.04%20673.51a4.4%204.4%200%201%200%200-8.8%204.4%204.4%200%200%200%200%208.8Z'%20/%3e%3cpath%20fill='%23C3E1FB'%20d='M410.58%20668.07h84.55a.81.81%200%200%201%20.81.81l.08%2042.16a.612.612%200%200%201-.176.431.592.592%200%200%201-.424.179c-23.727.293-47.473.27-71.24-.07a9.033%209.033%200%200%201-3.63-.82c-8.94-4.08-10.66-11.44-10.43-21.04.167-6.613.14-13.643-.08-21.09a.533.533%200%200%201%20.329-.517.545.545%200%200%201%20.211-.043ZM560.16%20668.04c4.033%205.167%206.22%2010.877%206.56%2017.13.46%208.48-.56%2017.07-.19%2026.6l-34.82.05a.903.903%200%200%201-.65-.1.755.755%200%200%201-.4-.7l.03-42.3c0-.114.044-.223.123-.304a.415.415%200%200%201%20.297-.126l29.05-.25Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M610.51%20683.53c-.54%201.22-1.11%202.43-1.24%203.76-.373%203.64-1.86%206.543-4.46%208.71a2.172%202.172%200%200%200-.7%201.12c-.313%201.26-.04%201.85.82%201.77%202.09-.19%203.53.08%204.88-1.73.241-.326.58-.57.97-.7%201.16-.387%202.1-.963%202.82-1.73.653-.7%201.033-1.753%201.14-3.16.213-2.913.153-5.723-.18-8.43.68-.16%201.003-.877.97-2.15-.113-4.28-.167-8.487-.16-12.62.573-.233%201.043-.257%201.41-.07.307.16.467.41.48.75.207%204.1.02%208.05-.56%2011.85-.4%202.6-.587%205.107-.56%207.52.027%202.54.013%205.137-.04%207.79-.02%201.36-.517%203.337-1.49%205.93-1.59%204.24-5.41%207.42-9.61%208.78-1.593.52-4%20.77-7.22.75-3.86-.02-7.723-.05-11.59-.09l-18.21.22-1.45-.03c-.37-9.53.65-18.12.19-26.6-.34-6.253-2.527-11.963-6.56-17.13l45.38.31a.889.889%200%200%201%20.85.68c1.127%204.6%202.22%209.263%203.28%2013.99.08.333.36.503.84.51Z'%20/%3e%3cpath%20fill='%232466F8'%20d='m867.89%20678.5-.03%204.67a.706.706%200%200%201-.7.71l-7.48.1a.712.712%200%200%200-.7.69l-.21%207.5a.707.707%200%200%201-.71.69l-4.53-.04a.713.713%200%200%201-.7-.69l-.17-7.48a.713.713%200%200%200-.7-.69l-7.48-.04a.71.71%200%200%201-.71-.7l-.04-4.68a.73.73%200%200%201%20.05-.273.726.726%200%200%201%20.379-.389.705.705%200%200%201%20.271-.058l7.52-.07a.713.713%200%200%200%20.7-.69l.21-7.45a.707.707%200%200%201%20.71-.69l4.54-.04a.73.73%200%200%201%20.273.05.726.726%200%200%201%20.389.379.705.705%200%200%201%20.058.271l.17%207.46a.707.707%200%200%200%20.71.69l7.47.06a.71.71%200%200%201%20.71.71Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='M641.15%20682c-1.227-1.807-2.967-2.907-5.22-3.3%203.43-3.1%205.16.15%205.22%203.3Z'%20/%3e%3cpath%20fill='%231350CE'%20d='M825.97%20694.34a616.914%20616.914%200%200%200-9.69-7.56c-2.2-1.68-3.973-1.46-5.32.66-2.467%203.88-3.977%208.243-4.53%2013.09-.367.08-.717.007-1.05-.22a1.046%201.046%200%200%201-.46-.88c.02-1.347.34-2.653.96-3.92a1.152%201.152%200%200%200-.05-1.11%201.84%201.84%200%200%200-.72-.69c-.807-.427-1.233-1.097-1.28-2.01-.227-4.267%201.44-7.59%205-9.97%206.29-4.2%2018.97-6.31%2021.19%204.06.82%203.807-.53%206.657-4.05%208.55Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='M278.97%20688.61a4.99%204.99%200%201%200%200-9.98%204.99%204.99%200%200%200%200%209.98Z'%20/%3e%3cpath%20fill='%23FE6D04'%20d='M635.93%20678.7c2.253.393%203.993%201.493%205.22%203.3%201.06%201.44%201.78%202.93%202.16%204.47a2.27%202.27%200%200%201-1.46%202.69%2021.577%2021.577%200%200%200-5.25%202.69c-2.13%201.5-4.99%201.14-7.44%201.42a.717.717%200%200%201-.79-.59c-.173-.973.09-1.643.79-2.01a74.919%2074.919%200%200%200%204.39-2.52c.287-.173.483-.42.59-.74.99-2.99-.24-5.67%201.79-8.71Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='M614.56%20683.14c.333%202.707.393%205.517.18%208.43-.107%201.407-.487%202.46-1.14%203.16-.72.767-1.66%201.343-2.82%201.73-.39.13-.729.374-.97.7-1.35%201.81-2.79%201.54-4.88%201.73-.86.08-1.133-.51-.82-1.77.111-.436.355-.827.7-1.12%202.6-2.167%204.087-5.07%204.46-8.71.13-1.33.7-2.54%201.24-3.76l4.05-.39ZM825.97%20694.34c-.8%202.567-1.99%204.837-3.57%206.81-.767.96-2.423%202.787-4.97%205.48-3.367%202.147-6.46%201.163-9.28-2.95l-1.72-3.15c.553-4.847%202.063-9.21%204.53-13.09%201.347-2.12%203.12-2.34%205.32-.66a616.914%20616.914%200%200%201%209.69%207.56Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M256.684%20699.16c-.233.656.048%201.353.625%201.558.578.204%201.235-.161%201.467-.817.233-.656-.048-1.354-.625-1.559-.578-.204-1.235.162-1.467.818Z'%20/%3e%3cpath%20fill='%23C3E1FB'%20d='M817.43%20706.63c.34.5%201.01.79%202.01.87.927.073%201.61.21%202.05.41%204.81%202.15%206.38%206.65%207.7%2011.41l-14.79.57a3.595%203.595%200%200%200-3.19%202.23l-7.69%2018.6c-.673.3-1.01.69-1.01%201.17-2.44.67-3.86%201.94-2.99%204.63-.693%201.013-.797%202.053-.31%203.12.147.327.4.49.76.49l36.5.11-4.72.74a.479.479%200%200%200-.24.84c3.733%203.3%205.457%206.873%205.17%2010.72-3.007.547-5.9.93-8.68%201.15a3386.26%203386.26%200%200%201-34.76%202.59l-.22%202.06c-.033.313-.093.32-.18.02-.64-2.25-1.14-4.34-.44-6.67a74.246%2074.246%200%200%200%202.18-9.33%202.254%202.254%200%200%200-.245-1.438%202.276%202.276%200%200%200-1.075-.992c-4.44-1.96-12.07-4.99-11.41-11.18.22-2.067.723-4.163%201.51-6.29%201.98-5.353%204.403-10.79%207.27-16.31%201.5-2.893%203.36-5.457%205.58-7.69%202.527-2.547%206.507-4.14%2011.94-4.78%202.82%204.113%205.913%205.097%209.28%202.95Z'%20/%3e%3cpath%20fill='%232466F8'%20d='m586.19%20711.58.16%2010.31c-.713%202.98-.877%205.937-.49%208.87a1.01%201.01%200%200%201-.233.782.999.999%200%200%201-.737.348l-15.84.3-1.52-.46a3.787%203.787%200%200%200%201.2-.7c.253-.227.38-.51.38-.85.07-6.9%201.33-13.06-1.13-18.38l18.21-.22Z'%20/%3e%3cpath%20fill='%231350CE'%20d='m566.53%20711.77%201.45.03c2.46%205.32%201.2%2011.48%201.13%2018.38%200%20.34-.127.623-.38.85a3.787%203.787%200%200%201-1.2.7l-3.99-.11-32.3-.12c-.333%200-.497-.167-.49-.5a382.6%20382.6%200%200%200-.12-17.97c-.027-.787.333-1.19%201.08-1.21l34.82-.05Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M255.798%20713.801c.412-.315.524-.862.249-1.222s-.833-.396-1.245-.08c-.412.315-.524.862-.249%201.222s.833.396%201.245.08Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='M280.81%20718.19a.92.92%200%200%201%20.457-.131.91.91%200%200%201%20.923.911c0%20.767-.323%201.2-.97%201.3a.817.817%200%200%201-.91-.58c-.187-.687-.02-1.187.5-1.5Z'%20/%3e%3cpath%20fill='%232466F8'%20d='m836.47%20750.24-36.5-.11c-.36%200-.613-.163-.76-.49-.487-1.067-.383-2.107.31-3.12%203.38.78%205.9-2.07%208.45-3.7a.492.492%200%200%200%20.091-.744.467.467%200%200%200-.241-.136c-1.2-.28-2.497-.323-3.89-.13-.5-.333-.637-.697-.41-1.09l7.69-18.6a3.596%203.596%200%200%201%203.19-2.23l14.79-.57c20.193-.2%2034.38-.44%2042.56-.72%202.267-.08%203.31.943%203.13%203.07-.6%206.88-1.723%2013.877-3.37%2020.99-.74%203.22-2.12%205.4-4.14%206.54-1.273.713-3.543%201.047-6.81%201-8.053-.113-16.083-.1-24.09.04Zm8.449-15.884c-.011-.663-.651-1.288-1.779-1.737-1.128-.449-2.651-.686-4.234-.659-.784.014-1.559.092-2.281.231a9.08%209.08%200%200%200-1.927.575c-.55.242-.985.525-1.279.834-.295.308-.444.636-.438.964.011.663.651%201.288%201.779%201.737%201.128.449%202.65.686%204.234.659a13.55%2013.55%200%200%200%202.281-.23%209.137%209.137%200%200%200%201.927-.576c.55-.242.985-.525%201.279-.834.295-.308.444-.636.438-.964Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='m586.35%20721.89%2033.67%2027.21a1.44%201.44%200%200%201%20.47%201.56l-31.26%20100c-.393-2.807-1.12-5.06-2.18-6.76-2.427-3.9-5.547-5.737-9.36-5.51-3.633.213-6.473%201.63-8.52%204.25-3.59%204.6-2.55%2011.99%202.55%2015.36%201.9%201.253%204.22%201.78%206.96%201.58%203-.22%206.08-1.677%209.24-4.37l-5.82%2018.91c-1.58-.68-3.17-1.41-4.77-2.19-5.04-2.467-10.177-2.983-15.41-1.55-10.81%202.96-18.22%2013.64-16.94%2024.97%201.16%2010.36%208.2%2018.52%2018.74%2020.22%201.78.287%203.617.553%205.51.8l-9.33%2029.9c-4.84-.94-7.44.55-11.44%203.5a1.13%201.13%200%200%201-.517.207%201.129%201.129%200%200%201-1.004-.394%201.118%201.118%200%200%201-.239-.503%203.997%203.997%200%200%201%20.13-1.91%202.587%202.587%200%200%201%201.08-1.42c6.66-4.23%2010.81-8.72%2010.51-16.94-.127-3.413-.92-6.2-2.38-8.36-1.76-2.607-3.913-4.6-6.46-5.98-2.41-1.31-5.31-1.48-7.97-2a.595.595%200%200%201-.366-.224.618.618%200%200%201-.124-.416c.32-4.507.28-9.047-.12-13.62-.66-7.38.13-15.19-.16-22.67a1.142%201.142%200%200%201%20.35-.863%201.135%201.135%200%200%201%20.88-.307c7.97.71%2010.21-4.71%2010.04-11.66-.1-4.013-.08-7.887.06-11.62.27-7.41-3.21-13.65-11.19-13.44-.413.013-.617-.187-.61-.6l.17-27.1c.007-.427.203-.72.59-.88%203.41-1.45%205.37-4.19%205.35-7.96a5584.64%205584.64%200%200%201-.1-32.76.66.66%200%200%200-.67-.66l-14.96.25-.07-3.61c.387-.66.7-.893.94-.7.37.305.831.477%201.31.49%204.24.12%208.413.097%2012.52-.07.347-.013.675-.156.92-.4.933-.953%202.027-1.473%203.28-1.56%204.307-.3%208.827-.467%2013.56-.5%204.82-.02%205.73-3.48%205.71-7.61-.04-7.253.003-14.517.13-21.79l15.84-.3a.999.999%200%200%200%20.97-1.13c-.387-2.933-.223-5.89.49-8.87Zm-24.99%2084.19c-6.53-1.92-15.2%201.44-15.81%209.18-.333%204.187-.47%208.287-.41%2012.3.027%202.02.563%203.667%201.61%204.94%204.127%205.033%209.267%206.473%2015.42%204.32%2013.71-4.79%2013.24-26.59-.81-30.74Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M511.42%20787.15c9.087.393%2015.3-3.473%2018.64-11.6.687-1.68.917-4.217.69-7.61l14.96-.25a.656.656%200%200%201%20.619.405.656.656%200%200%201%20.051.255c0%2010.433.033%2021.353.1%2032.76.02%203.77-1.94%206.51-5.35%207.96-.387.16-.583.453-.59.88l-.17%2027.1c-.007.413.197.613.61.6%207.98-.21%2011.46%206.03%2011.19%2013.44-.14%203.733-.16%207.607-.06%2011.62.17%206.95-2.07%2012.37-10.04%2011.66a1.135%201.135%200%200%200-.88.307%201.127%201.127%200%200%200-.35.863c.29%207.48-.5%2015.29.16%2022.67.4%204.573.44%209.113.12%2013.62a.601.601%200%200%200%20.49.64c2.66.52%205.56.69%207.97%202%202.547%201.38%204.7%203.373%206.46%205.98%201.46%202.16%202.253%204.947%202.38%208.36.3%208.22-3.85%2012.71-10.51%2016.94a2.584%202.584%200%200%200-1.08%201.42c-.2.653-.243%201.29-.13%201.91a1.118%201.118%200%200%200%201.76.69c4-2.95%206.6-4.44%2011.44-3.5l-4.26%2015.65c-.587-.827-2.073-1.123-4.46-.89-.333.033-.63-.06-.89-.28a15.595%2015.595%200%200%201-2.66-2.96c-5.22-7.53-18.14-8.95-26.54-8.09-5.527.567-10.297%202.9-14.31%207a1.584%201.584%200%200%201-1.001.47%201.562%201.562%200%200%201-1.059-.3c-5.38-3.947-11.313-5.19-17.8-3.73-3.13.7-6.22%202.66-8.25%205.2a.736.736%200%200%201-.65.267.743.743%200%200%201-.58-.397%2024.608%2024.608%200%200%200-4.43-6.1.827.827%200%200%201-.21-.87l.23-.79c.693-.287.987-.863.88-1.73-.14-1.12-.753-1.963-1.84-2.53-13.21-6.88-16.59-24.84-9.36-37.17%204.973-8.493%2012.537-13.487%2022.69-14.98a1.428%201.428%200%200%200%201.22-1.52c-.227-2.947-.257-5.667-.09-8.16.31-4.81%203.03-8.63%203.36-13.44.293-4.233.637-7.31%201.03-9.23%201.553-7.54%205.65-13.04%2012.29-16.5a1.017%201.017%200%200%200%20.54-.91c-.16-16.64-.087-34.023.22-52.15.02-.967-.443-1.35-1.39-1.15-.56.12-1.04.473-1.44%201.06a1.904%201.904%200%200%200-.33%201.1c.093%2014.06.183%2028.687.27%2043.88.03%205.06-2.12%207.23-6.1%209.89-3.73%202.49-8.01%202.74-11.82.55-2.83-1.62-2.29-5.05-2.3-7.73%201.4-15.13%201.7-30.43.15-45.52-.387-3.72-.763-7.437-1.13-11.15l.45-15.32%2014.57-.03c.427%200%20.697-.207.81-.62.273-1.02.137-1.84-.41-2.46a1.177%201.177%200%200%200-.92-.42l-10.48-.07c-1.86.02-3.39.21-5.17-.62-4.6-2.14-9.38-1.73-14.25-1.57-5.98.2-7.36-4.09-7.21-9%20.207-6.947.353-13.9.44-20.86.72-.267%201.233-.4%201.54-.4%2012.087.047%2024.053.027%2035.9-.06a.943.943%200%200%201%20.887.59.976.976%200%200%201%20.073.37c-.013%2012.927-.037%2025.713-.07%2038.36-.03%208.78%207.08%2015.14%2015.38%2016.2Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='m563.54%20731.62%203.99.11%201.52.46a948.472%20948.472%200%200%200-.13%2021.79c.02%204.13-.89%207.59-5.71%207.61-4.733.033-9.253.2-13.56.5-1.253.087-2.347.607-3.28%201.56a1.376%201.376%200%200%201-.92.4c-4.107.167-8.28.19-12.52.07a2.15%202.15%200%200%201-1.31-.49c-.24-.193-.553.04-.94.7l-.07-31.34a1.245%201.245%200%200%201%20.357-.876%201.22%201.22%200%200%201%20.873-.364l31.7-.13Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M838.994%20736.96c3.296-.058%205.949-1.224%205.925-2.604-.024-1.381-2.716-2.453-6.013-2.396-3.296.058-5.949%201.224-5.925%202.604.024%201.381%202.716%202.453%206.013%202.396Z'%20/%3e%3cpath%20fill='%232466F8'%20d='M676.53%20741.06c-1.84%205.393-3.663%2011.33-5.47%2017.81-.207.733-.46%201.397-.76%201.99a.534.534%200%200%201-.731.217.523.523%200%200%201-.199-.197c-2.36-4.26-3.75-9.57-5.55-13.82a.783.783%200%200%201%20.45-1.03c4.13-1.56%207.93-2.44%2011.21-5.63%201.28-1.253%201.63-1.033%201.05.66Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='M803.52%20740.72c-.227.393-.09.757.41%201.09l-1.42.08c0-.48.337-.87%201.01-1.17Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='M799.52%20746.52c-.87-2.69.55-3.96%202.99-4.63l1.42-.08c1.393-.193%202.69-.15%203.89.13a.473.473%200%200%201%20.365.384.495.495%200%200%201-.215.496c-2.55%201.63-5.07%204.48-8.45%203.7Z'%20/%3e%3cpath%20fill='%232466F8'%20d='M648.99%20770.97a.694.694%200%200%201-.49-.251.69.69%200%200%201-.15-.529c.28-2.193.397-4.333.35-6.42a623.972%20623.972%200%200%201-.13-20.15.64.64%200%200%201%201.08-.46%2011.786%2011.786%200%200%201%202.31%202.98c3.04%205.607%205.68%2011.537%207.92%2017.79.68%201.9%201.71%203.68%202.71%205.44a1.02%201.02%200%200%201-.8%201.53c-4.16.347-8.427.37-12.8.07Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M192%20774.89c-1.08%203.28-2.88%204.247-5.4%202.9a2688.613%202688.613%200%200%201-6.63-16.74c-1.56-3.97-3.69-7.59-4.22-11.76-.24-1.887.64-2.81%202.64-2.77.7.013%201.243.313%201.63.9%201.267%201.933%202.37%204.17%203.31%206.71.607%201.653%202.16%205.217%204.66%2010.69.47%201.02.54%202.31.98%203.21a108.21%20108.21%200%200%201%203.03%206.86Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='M836.41%20752.64a.542.542%200%200%201%20.18-.29%201.77%201.77%200%200%201%20.23-.176.36.36%200%200%201%20.16-.064l19.3.18c.56%200%20.81.28.75.84l-.04.35a.518.518%200%200%201-.53.47l-20.53-.26c-.327-.007-.457-.167-.39-.48a.86.86%200%200%201%20.27-.46c.127-.107.26-.117.4-.03.107.073.173.047.2-.08Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='m629.48%20756.82%2016.56%2013a.578.578%200%200%201-.02.934.58.58%200%200%201-.34.106l-21.05.12a.574.574%200%200%201-.468-.24.588.588%200%200%201-.104-.25.588.588%200%200%201%20.022-.27l4.49-13.13a.583.583%200%200%201%20.91-.27Z'%20/%3e%3cpath%20fill='%231350CE'%20d='m211.06%20771.05-2.55%209.07-.95-1.2c-.48-1.347-.067-2.393%201.24-3.14.287-.167.367-.403.24-.71a44.173%2044.173%200%200%200-1.41-3.15c-2.42-4.85%201.92-9.94%206.3-12.01%207.02-3.31%2017.53-2.41%2016.58%208.19-.14%201.546-.793%202.76-1.96%203.64-2.12%201.61-4.31%200-5.77-1.55a37.27%2037.27%200%200%200-4.58-4.09c-3.66-2.77-5.81%201.59-7.14%204.95Z'%20/%3e%3cpath%20fill='%232466F8'%20d='M836.68%20762.54c1.66%208.133%202.71%2015.203%203.15%2021.21%201.527%2020.78%201.807%2042.69.84%2065.73l-8.46.26-.47.07c-.32-.38-.497-.733-.53-1.06-2.32-24.01-5.19-45.63-13.61-67.87a6.345%206.345%200%200%200-1.02-1.76.548.548%200%200%200-.558-.194.55.55%200%200%200-.412.424%2072.203%2072.203%200%200%200-1.01%205.71%20590.439%20590.439%200%200%200-5.06%2058.19c-.06%201.607-.337%203.597-.83%205.97l-10.02-.13a2513.09%202513.09%200%200%201-1.2-31.09c-.2-6.36-.71-12.86-1.53-19.5l-1.9-20.57-.82-11.65a3386.26%203386.26%200%200%200%2034.76-2.59c2.78-.22%205.673-.603%208.68-1.15Z'%20/%3e%3cpath%20fill='%23E3F1FB'%20d='M480.33%20767.74c1.86-.267%203.09-.763%203.69-1.49.44-.533.4-1.237-.12-2.11l10.48.07c.367%200%20.673.14.92.42.547.62.683%201.44.41%202.46-.113.413-.383.62-.81.62l-14.57.03Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='M217.32%20783.96c-3.553-.4-6.49-1.68-8.81-3.84l2.55-9.07c.54-.207%201.393-1.023%202.56-2.45%202.69-3.3%205.81.55%207.69%202.46%201.04%201.06%201.94%201%203.01%201.69%201.5.96%201.697%202.093.59%203.4-2.03%202.39-4.68%206.75-7.59%207.81Z'%20/%3e%3cpath%20fill='%23C3E1FB'%20d='m207.56%20778.92.95%201.2c2.32%202.16%205.257%203.44%208.81%203.84a11.804%2011.804%200%200%200-.52%203.8c-1.187.14-1.923.607-2.21%201.4a300.326%20300.326%200%200%201-9.52%2023.14%201.842%201.842%200%200%200-.18.98c.027.293.103.57.23.83.5.98.2%201.493-.9%201.54-1.333.067-2.22.6-2.66%201.6a1.181%201.181%200%200%200%201.01%201.64c5.693.333%2011.523.247%2017.49-.26a.93.93%200%200%200%20.76-.47%205.046%205.046%200%200%200%20.69-1.98l2.68%201.43c.293.153.48.39.56.71l2.42%209.57-3.55%202.31c-4.427%201.033-9.757%201.673-15.99%201.92-8.12.327-15.183.14-21.19-.56-1.64-2.153-2.05-4.12-1.23-5.9a272.051%20272.051%200%200%201%205.22-10.69%202.269%202.269%200%200%200-.56-2.77c-3.74-3.16-7.403-7.757-10.99-13.79-2.34-3.93-1.18-8.06%203.06-10.15%201.933-.953%203.91-1.873%205.93-2.76%201.34-.587%201.693-1.54%201.06-2.86l-2.33-4.85c2.52%201.347%204.32.38%205.4-2.9l2.21%205.75a2.434%202.434%200%200%200%201.172%201.296%202.434%202.434%200%200%200%201.738.174c3.3-.9%206.593-1.547%209.88-1.94.42-.053.607-.47.56-1.25Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M766.95%20782.15a2.83%202.83%200%201%200%200-5.66%202.83%202.83%200%200%200%200%205.66ZM795.96%20798.5l-30.98%2076.42c-.127.307-.023.477.31.51.253.027.577-.033.97-.18a57.95%2057.95%200%200%200-10.51%2016.48c-1.1%202.6-2.217%205.2-3.35%207.8-.653%201.487-1.49%202.31-2.51%202.47-1.367.207-2.763.48-4.19.82%201.973-.893%203.233-2.023%203.78-3.39%202.92-7.333%206.083-15.617%209.49-24.85%202.06-5.593%204.52-11.763%207.38-18.51a838.7%20838.7%200%200%200%2010.3-25.47c1.96-5.08%204.44-9.73%206.41-14.75%202.327-5.92%204.68-11.997%207.06-18.23.22-.587.97-2.323%202.25-5.21%201.04-2.347%201.547-4.19%201.52-5.53-.053-2.967.003-5.95.17-8.95l1.9%2020.57Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='m831.74%20849.81.15%201.12.67%209.46c-.42.493-.647%201.103-.68%201.83.187-1.16-.147-1.943-1-2.35-5.667-2.727-11.573-4.04-17.72-3.94l-4.4-.18c-.34-.013-.497-.19-.47-.53l.42-6c.493-2.373.77-4.363.83-5.97a590.439%20590.439%200%200%201%205.06-58.19%2072.203%2072.203%200%200%201%201.01-5.71.546.546%200%200%201%20.412-.424.544.544%200%200%201%20.558.194c.447.553.787%201.14%201.02%201.76%208.42%2022.24%2011.29%2043.86%2013.61%2067.87.033.327.21.68.53%201.06ZM663.21%20782.28c.907.3%201.22.903.94%201.81l-8.64%2027.93a1.84%201.84%200%200%201-1.76%201.3h-42.02a.654.654%200%200%201-.643-.542.615.615%200%200%201%20.023-.298l10.02-31.7a1.165%201.165%200%200%201%201.12-.81c11.727.113%2023.3.083%2034.72-.09%201.04-.01%202.04-.07%202.91.61a10.821%2010.821%200%200%200%203.33%201.79Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M479.88%20783.06c.367%203.713.743%207.43%201.13%2011.15%201.55%2015.09%201.25%2030.39-.15%2045.52l-.03-5.05a.858.858%200%200%200-.88-.85c-3.13.05-6.47.38-9.42-.51-4.72-1.42-9.13-5.79-9.67-11.01-1.1-10.83%206.99-18.05%2017.61-16.94a1.18%201.18%200%200%200%20.932-.297%201.223%201.223%200%200%200%20.408-.903l.07-21.11Z'%20/%3e%3cpath%20fill='%23FE6D04'%20d='M425.78%20807.1c-2.353-.74-4.367-.713-6.04.08-4.04%204.05-8.57%208.33-10.04%2013.79-.67%202.49-.49%206.95-3.17%208.21-2.83%201.32-6.85%202.28-9.96%201.19-8.71-3.07-8.6-14.06-2.71-19.71%203.45-3.3%207.73-5.32%209.06-10.52.607-2.387%201.213-4.77%201.82-7.15%201.5-5.9%205.51-7.23%2011.36-6.9%202.5.14%204.967.33%207.4.57a1.476%201.476%200%200%201%201.271%201.075c.052.191.065.39.039.585-.44%203.32%201.2%205.77%201.35%209.01.147%203.073.02%206.33-.38%209.77Z'%20/%3e%3cpath%20fill='%231350CE'%20d='m216.8%20787.76%2042.71.13c.353%200%20.6.16.74.48a5.809%205.809%200%200%201%20.43%203.35c-.773%204.967-1.833%2010.143-3.18%2015.53-.83%203.31-2.15%207.76-6.3%207.89-10.073.3-18.64.387-25.7.26-1.573-.033-2.903.227-3.99.78a5.046%205.046%200%200%201-.69%201.98.93.93%200%200%201-.76.47c-5.967.507-11.797.593-17.49.26a1.185%201.185%200%200%201-.929-.559%201.173%201.173%200%200%201-.081-1.081c.44-1%201.327-1.533%202.66-1.6%201.1-.047%201.4-.56.9-1.54a2.37%202.37%200%200%201-.23-.83%201.842%201.842%200%200%201%20.18-.98%20300.326%20300.326%200%200%200%209.52-23.14c.287-.793%201.023-1.26%202.21-1.4Zm21.026%2013.991c-.017-.331-.334-.633-.88-.839-.546-.206-1.277-.3-2.031-.26a6.088%206.088%200%200%200-1.085.152%204.181%204.181%200%200%200-.909.319c-.258.13-.46.278-.596.437-.135.159-.2.325-.191.489.017.331.334.633.88.839.546.206%201.277.3%202.031.26a6.088%206.088%200%200%200%201.085-.152c.342-.081.651-.189.909-.319s.46-.278.596-.437c.135-.159.2-.325.191-.489Z'%20/%3e%3cpath%20fill='%23FE6D04'%20d='M459.27%20795.66c-.6-.773-1.427-1.437-2.48-1.99%202.013-3.1%205.033-4.907%209.06-5.42a.888.888%200%200%201%20.97.65c.273%201.053-.033%201.973-.92%202.76-2.213%201.973-4.423%203.307-6.63%204Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M684.55%20801.02c-.927.313-1.16.887-.7%201.72%201.193%202.14%202.193%204.16%203%206.06a6674.4%206674.4%200%200%201%2036.22%2086.44%20218.736%20218.736%200%200%200%203.77%208.65c1.293%202.793%202.597%205.633%203.91%208.52l-5.9%206.28a206.193%20206.193%200%200%200-6.12-15.92%207050.363%207050.363%200%200%200-5.73-13.19%2010589.56%2010589.56%200%200%200-32.9-78.91%20352.595%20352.595%200%200%201-7.19-18.54l11.64%208.89Z'%20/%3e%3cpath%20fill='%23C3E1FB'%20d='M456.79%20793.67c1.053.553%201.88%201.217%202.48%201.99.94.427%201.037%201.283.29%202.57-.74%201.28-1.58%202.39-2.52%203.33-6.933%206.92-15.217%2012.423-24.85%2016.51-2.973%201.26-4.89%203.673-5.75%207.24-.96%203.96-1.247%207.69-.86%2011.19.667%206.1%201.36%2012.187%202.08%2018.26-.193-.693-.58-.983-1.16-.87a91.216%2091.216%200%200%201-26%201.43c-3.94-.347-8.433-1.933-13.48-4.76.9-1.54%201.783-2.93%202.65-4.17%202.66-3.773%205.33-7.607%208.01-11.5.64-.94%202.13-2.07%203.27-2.21%202.84-.34%205.423-1.33%207.75-2.97.36-.251.613-.629.71-1.06.64-2.89%201.02-5.4%202.46-8.17%201.107-2.14%202.24-4.26%203.4-6.36%201.2-2.18%203.15-4.43%204.47-6.94%201.673-.793%203.687-.82%206.04-.08a41.503%2041.503%200%200%200%2013.04-5.04c5.78-3.433%2010.773-6.187%2014.98-8.26%201.247-.613%202.243-.657%202.99-.13Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='M795.96%20798.5c.82%206.64%201.33%2013.14%201.53%2019.5.34%2010.473.74%2020.837%201.2%2031.09l1.06%207.51-12.78%203.86c-8.02%203.407-14.923%208.337-20.71%2014.79-.393.147-.717.207-.97.18-.333-.033-.437-.203-.31-.51l30.98-76.42Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M235.045%20803.148c1.572-.082%202.817-.708%202.781-1.397-.036-.69-1.34-1.182-2.911-1.099-1.572.082-2.817.708-2.781%201.397.036.689%201.34%201.182%202.911%201.099ZM561.36%20806.08c14.05%204.15%2014.52%2025.95.81%2030.74-6.153%202.153-11.293.713-15.42-4.32-1.047-1.273-1.583-2.92-1.61-4.94-.06-4.013.077-8.113.41-12.3.61-7.74%209.28-11.1%2015.81-9.18Z'%20/%3e%3cpath%20fill='%23E3F1FB'%20d='M229.07%20817.12c1.9-.113%203.417-.07%204.55.13%201.88.333%201.867.547-.04.64-1.293.06-2.88-.017-4.76-.23-.013%200-.02-.007-.02-.02l.01-.25c.007-.167.093-.257.26-.27ZM317.32%20818.08c-1.633%201.367-2.703%202.547-3.21%203.54-2.45%204.77-4.98%209.45-7.05%2014.42a1853.475%201853.475%200%200%201-8.56%2020.25c-.447%201.047-1.05%203.063-1.81%206.05l-2.61-2.27a1.544%201.544%200%200%200-.88-.38l-2.17-.23c1.547-1.727%202.803-3.7%203.77-5.92%202.62-6.03%204.84-11.5%207.9-17.9%202.56-5.36%204.42-11.75%207.99-16.51l6.63-1.05Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='m641.35%20856.11-42.91-.06a.701.701%200%200%201-.66-.91l10.06-32.06a.696.696%200%200%201%20.66-.49l42.9.07a.698.698%200%200%201%20.693.585c.018.109.01.22-.023.325l-10.06%2032.05a.7.7%200%200%201-.66.49Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M227.17%20827.89c4.28%209.11%208.13%2018.32%2012.52%2027.64%201.373%202.913%202.467%205.567%203.28%207.96%202.03%205.95%204.79%2011.21%206.87%2017.02a104.727%20104.727%200%200%200%207.06%2015.59c.827%201.493%201.43%203.83%201.81%207.01a7.151%207.151%200%200%200-3.85.61c-2.373-4.347-3.84-7.25-4.4-8.71-2.73-7.16-6.16-14.05-8.76-21.1-1.59-4.32-3.8-8.31-5.48-12.68-1.433-3.76-2.827-7.447-4.18-11.06-1.87-4.97-4.29-9.73-6.35-14.67a.677.677%200%200%200-.391-.38.673.673%200%200%200-.539.03c-.093.047-.11.263-.05.65l-1.09-5.6%203.55-2.31Z'%20/%3e%3cpath%20fill='%231350CE'%20d='m223.62%20830.2%201.09%205.6a787.185%20787.185%200%200%200%2010.15%2067.01c-3.367-.04-6.26.47-8.68%201.53-.74-1.027-1.513-2.663-2.32-4.91-6.333-17.6-12.047-34.97-17.14-52.11-.393-1.327-.797-1.33-1.21-.01-3.59%2011.56-5.24%2023.81-6.34%2035.69-.427%204.68-.793%2011.973-1.1%2021.88-3.007-.5-5.837-.37-8.49.39-.247-.54-.41-1.217-.49-2.03-1.78-17.807-2.973-34.303-3.58-49.49-.28-6.993.03-14.39.93-22.19%206.007.7%2013.07.887%2021.19.56%206.233-.247%2011.563-.887%2015.99-1.92Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M257.5%20838.83a1.25%201.25%200%201%200%200-2.5%201.25%201.25%200%200%200%200%202.5ZM589.23%20850.66l-1.31%204.55c-3.16%202.693-6.24%204.15-9.24%204.37-2.74.2-5.06-.327-6.96-1.58-5.1-3.37-6.14-10.76-2.55-15.36%202.047-2.62%204.887-4.037%208.52-4.25%203.813-.227%206.933%201.61%209.36%205.51%201.06%201.7%201.787%203.953%202.18%206.76ZM438.494%20861.367c-3.454%2013.648%204.598%2027.457%2017.983%2030.844%2013.385%203.387%2027.036-4.931%2030.489-18.578%203.453-13.648-4.598-27.457-17.983-30.844-13.385-3.387-27.036%204.931-30.489%2018.578Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M739.713%20845.472c.592-.285.919-.835.729-1.228-.189-.393-.822-.481-1.415-.196-.592.285-.918.835-.729%201.228.189.393.822.481%201.415.196Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='M226.18%20904.34c.08.753-.073%201.353-.46%201.8-7.453-1.547-14.11-1.263-19.97.85-4.027%201.453-6.72%202.333-8.08%202.64l.4-4.75c.307-9.907.673-17.2%201.1-21.88%201.1-11.88%202.75-24.13%206.34-35.69.413-1.32.817-1.317%201.21.01%205.093%2017.14%2010.807%2034.51%2017.14%2052.11.807%202.247%201.58%203.883%202.32%204.91Z'%20/%3e%3cpath%20fill='%23FE6D04'%20d='m808.71%20849.22-.42%206c-.027.34.13.517.47.53l4.4.18-13.41.67-1.06-7.51%2010.02.13ZM840.67%20849.48c-.533%203.5-1.097%206.923-1.69%2010.27-.367%202.12.343%203.307%202.13%203.56%201.78.253%203.503.747%205.17%201.48l-12.88.13c-.353%200-.59-.163-.71-.49-.427-1.14-.47-2.487-.13-4.04l-.67-9.46c.333-.527.44-.923.32-1.19l8.46-.26Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='M832.21%20849.74c.12.267.013.663-.32%201.19l-.15-1.12.47-.07Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='M427.66%20854.76c-.793.953-1.197%201.753-1.21%202.4-1.193-.48-2.69-.597-4.49-.35-2.86.393-4.333.593-4.42.6a81.03%2081.03%200%200%201-26.92-2.95.997.997%200%200%200-.89.18l-.72.57c.407-.793-.257-2.343-1.99-4.65%205.047%202.827%209.54%204.413%2013.48%204.76%208.733.767%2017.4.29%2026-1.43.58-.113.967.177%201.16.87Z'%20/%3e%3cpath%20fill='%232466F8'%20d='M862.57%20866.8a6.49%206.49%200%201%200%200-12.98%206.49%206.49%200%200%200%200%2012.98Z'%20/%3e%3cpath%20fill='%23C3E1FB'%20d='M324.2%20865.06a5.58%205.58%200%201%200%200-11.16%205.58%205.58%200%200%200%200%2011.16Z'%20/%3e%3cpath%20fill='%232466F8'%20d='M426.45%20857.16c.727%209.733.737%2019.103.03%2028.11a237.877%20237.877%200%200%200%20.67%2043.85c.727%206.707%201.477%2013.413%202.25%2020.12.093.773.02%201.777-.22%203.01a6.734%206.734%200%200%200-3.86.07c-1.027.373-1.687-.023-1.98-1.19a1512.09%201512.09%200%200%200-7.13-26.98c-3.23-11.75-4.46-19.97-6.1-33.08-.48-3.207-1.09-6.11-1.83-8.71-.873-3.073-1.86-3.11-2.96-.11-1.053%202.86-1.867%206.523-2.44%2010.99l-3.53%2020.49-4.54%2024.04-2.04%2013.95c-.607.213-1.1.217-1.48.01a13.914%2013.914%200%200%200-3.58-1.37c-.62-.1-.887-.803-.8-2.11.293-4.313.363-8.267.21-11.86.353-22.24.453-44.12.3-65.64-.027-4.533.503-9.713%201.59-15.54l.72-.57a.982.982%200%200%201%20.89-.18%2081.03%2081.03%200%200%200%2026.92%202.95c.087-.007%201.56-.207%204.42-.6%201.8-.247%203.297-.13%204.49.35Z'%20/%3e%3cpath%20fill='%23478FFF'%20d='M813.16%20855.93c6.147-.1%2012.053%201.213%2017.72%203.94.853.407%201.187%201.19%201%202.35-.407%202.447.63%203.733%203.11%203.86%205.107.253%209.197.257%2012.27.01l-3.29.65c-.313.06-.45.247-.41.56%202.44%2021.1%202.79%2041.11%202.9%2064.46.073%2016.173-.15%2028.427-.67%2036.76-.027.367-.223.55-.59.55-7.08.007-14.087.237-21.02.69-.387.027-.393.093-.02.2.093.02.207.03.34.03%205.693-.18%2011.38-.077%2017.06.31l-54.77.05-32.73-.52c-1.18-.013-1.247-.29-.2-.83%207.45-3.82%207.81-10.47%207.63-17.9-.46-18.93-.64-38.41%201.03-57.4%201.5-17.04%2011.43-24.4%2024.45-33.24l12.78-3.86%2013.41-.67Z'%20/%3e%3cpath%20fill='%23C3E1FB'%20d='m291.03%20859.46%202.17.23c.333.033.627.16.88.38l2.61%202.27c2.34%204.973.697%208.417-4.93%2010.33l-5.28-2.34c-2.4-5.327-.883-8.95%204.55-10.87Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='M786.97%20860.46c-13.02%208.84-22.95%2016.2-24.45%2033.24-1.67%2018.99-1.49%2038.47-1.03%2057.4.18%207.43-.18%2014.08-7.63%2017.9-1.047.54-.98.817.2.83l32.73.52-106.82-.05a.805.805%200%200%201-.748-.5.805.805%200%200%201-.062-.31c-.113-13.687%205.267-24.113%2016.14-31.28%207.25-4.77%2013.93-5.28%2022.25-5.87.393-.027.653-.227.78-.6%201.553-4.8%203.727-9.15%206.52-13.05l5.9-6.28c4.6-4.187%209.583-7.383%2014.95-9.59a51.071%2051.071%200%200%201%204.19-.82c1.02-.16%201.857-.983%202.51-2.47%201.133-2.6%202.25-5.2%203.35-7.8a57.95%2057.95%200%200%201%2010.51-16.48c5.787-6.453%2012.69-11.383%2020.71-14.79Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='M832.56%20860.39c-.34%201.553-.297%202.9.13%204.04.12.327.357.49.71.49l12.88-.13c.913.147%201.397.703%201.45%201.67-.42-.1-.577-.223-.47-.37-3.073.247-7.163.243-12.27-.01-2.48-.127-3.517-1.413-3.11-3.86.033-.727.26-1.337.68-1.83Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='M591.07%20897.06c.527-4.56.567-7.523.12-8.89a44.157%2044.157%200%200%201-1.54-6.17l5.09-16.33a1.152%201.152%200%200%201%201.1-.81l42.37.08a.786.786%200%200%201%20.773.657.783.783%200%200%201-.023.363l-9.31%2030.25a1.203%201.203%200%200%201-.44.621%201.247%201.247%200%200%201-.73.239l-37.41-.01Z'%20/%3e%3cpath%20fill='%23377DFE'%20d='M847.26%20866.09c-.107.147.05.27.47.37%202.09%202.92%205.41%205.08%208.06%207.5%206.007%205.5%2010.723%2011.88%2014.15%2019.14a.654.654%200%200%200%20.495.372.659.659%200%200%200%20.585-.202c6.127-6.533%2013.72-9.52%2022.78-8.96l-.74.17c-.533.12-.537.263-.01.43%202.68.84%205.5.89%208.11%202.09%201.54.693%203.007%201.39%204.4%202.09%201.28.64%202.03%201.86%203.36%202.65%204.21%202.49%206.46%207.63%208.67%2011.9.034.065.086.12.148.159a.416.416%200%200%200%20.419.005.404.404%200%200%200%20.153-.154c.08-.147.097-.37.05-.67%203.77%209.19%201.31%2020.16-4.69%2027.7a.694.694%200%200%200-.126.629.689.689%200%200%200%20.446.461l2.33.8c1.533%201.5%203.403%202.697%205.61%203.59%202.62%208.53%203.8%2016.35-.3%2024.69a77.057%2077.057%200%200%201-4.37%207.73.858.858%200%200%201-.77.43c-8.44.06-16.887.117-25.34.17-2.653.013-6.107.393-10.36%201.14l-39.23-.02c-5.68-.387-11.367-.49-17.06-.31a1.65%201.65%200%200%201-.34-.03c-.373-.107-.367-.173.02-.2%206.933-.453%2013.94-.683%2021.02-.69.367%200%20.563-.183.59-.55.52-8.333.743-20.587.67-36.76-.11-23.35-.46-43.36-2.9-64.46-.04-.313.097-.5.41-.56l3.29-.65Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='m582.1%20874.12-12.87%2042.25c-1.893-.247-3.73-.513-5.51-.8-10.54-1.7-17.58-9.86-18.74-20.22-1.28-11.33%206.13-22.01%2016.94-24.97%205.233-1.433%2010.37-.917%2015.41%201.55%201.6.78%203.19%201.51%204.77%202.19Z'%20/%3e%3cpath%20fill='%23E3F1FB'%20d='M291.76%20872.67c-2.14%203.973-4.35%208.713-6.63%2014.22-5.507%2013.34-9.293%2022.637-11.36%2027.89-1.267%203.227-1.71%206.06-1.33%208.5-3.7-2.047-7.85-2.8-12.45-2.26%201.167-.353%202.417-.47%203.75-.35a1.007%201.007%200%200%200%20.84-.32c1.147-1.22%201.917-2.333%202.31-3.34%205.1-12.947%208.883-22.12%2011.35-27.52%203.833-8.387%206.58-14.773%208.24-19.16l5.28%202.34ZM410.11%20891.07c-2.433%202.22-4.843%202.943-7.23%202.17.573-4.467%201.387-8.13%202.44-10.99%201.1-3%202.087-2.963%202.96.11.74%202.6%201.35%205.503%201.83%208.71Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M589.65%20882a44.157%2044.157%200%200%200%201.54%206.17c.447%201.367.407%204.33-.12%208.89l-4.9-.08a.882.882%200%200%201-.39-.097.869.869%200%200%201-.43-1.033l4.3-13.85Z'%20/%3e%3cpath%20fill='%231350CE'%20d='M893.8%20884.31c11.96%201.32%2020.147%207.543%2024.56%2018.67.047.3.03.523-.05.67a.407.407%200%200%201-.72-.01c-2.21-4.27-4.46-9.41-8.67-11.9-1.33-.79-2.08-2.01-3.36-2.65-1.393-.7-2.86-1.397-4.4-2.09-2.61-1.2-5.43-1.25-8.11-2.09-.527-.167-.523-.31.01-.43l.74-.17Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='M426.48%20885.27c-.033%201.093.177%201.903.63%202.43.213.26.49.393.83.4%205.567.127%2010.553%202.48%2014.96%207.06%204.22%204.38%206.297%209.813%206.23%2016.3-.093%209.74-.12%2019.653-.08%2029.74.013%203.773-1.36%206.877-4.12%209.31a1.35%201.35%200%200%201-.87.35c-1.22.067-2.217.27-2.99.61-1.233.547-1.177.857.17.93.387.02.96.017%201.72-.01.333-.013.637-.12.91-.32l4.88-3.6c9.54.433%2015.6.523%2018.18.27%201.933-.187%202.647-.667%202.14-1.44.74.787%201.517%201.64%202.33%202.56.42.467.963.663%201.63.59l-.23.79c-.1.333-.03.623.21.87a24.608%2024.608%200%200%201%204.43%206.1.748.748%200%200%200%20.58.397.736.736%200%200%200%20.65-.267c2.03-2.54%205.12-4.5%208.25-5.2%206.487-1.46%2012.42-.217%2017.8%203.73.305.225.681.332%201.059.3a1.584%201.584%200%200%200%201.001-.47c4.013-4.1%208.783-6.433%2014.31-7%208.4-.86%2021.32.56%2026.54%208.09.76%201.1%201.647%202.087%202.66%202.96.26.22.557.313.89.28%202.387-.233%203.873.063%204.46.89l-2.28%207.57a.723.723%200%200%200%20.05.54l.14.26c-26.94-.253-53.873-.283-80.8-.09-14%20.09-29.34-.51-43-.4-11.527.093-21.443.117-29.75.07-14.04-.08-28.5.36-42.44.27-1.86-.013-2.71-.98-2.55-2.9.96-11.3%206.12-19.97%2015.48-26.01%205.013-3.233%2010.557-4.847%2016.63-4.84.153%203.593.083%207.547-.21%2011.86-.087%201.307.18%202.01.8%202.11l-.47.18c-.333.133-.49.38-.47.74.113%202.773-.317%205.513-1.29%208.22a1.458%201.458%200%200%200%20.089%201.188%201.47%201.47%200%200%200%20.941.732l2.02.5c.36.087.697.23%201.01.43%202.567%201.633%205.173%202.157%207.82%201.57%202.287-.513%202.323-1.16.11-1.94a21.69%2021.69%200%200%200-3.09-.83c-3.14-.59-4.01-4.18-3.37-6.92.32-1.367.907-2.203%201.76-2.51l2.04-13.95%204.28.4a.912.912%200%200%200%20.926-.546.908.908%200%200%200%20.074-.374c-.147-6.74.017-13.64.49-20.7a9.707%209.707%200%200%200-.01-1.59c-.153-1.787-.56-2.197-1.22-1.23l3.53-20.49c2.387.773%204.797.05%207.23-2.17%201.64%2013.11%202.87%2021.33%206.1%2033.08a1512.09%201512.09%200%200%201%207.13%2026.98c.293%201.167.953%201.563%201.98%201.19l-.61%209.74c-.02.367.137.627.47.78%203.893%201.753%207.423%202.217%2010.59%201.39a1.322%201.322%200%200%200%20.83-.66c.067-.12.117-.247.15-.38.18-.753-.117-1.137-.89-1.15-5.807-.08-8.033-3.343-6.68-9.79.24-1.233.313-2.237.22-3.01a2988.645%202988.645%200%200%201-2.25-20.12%20237.877%20237.877%200%200%201-.67-43.85Z'%20/%3e%3cpath%20fill='%23FE6D04'%20d='m234.86%20902.81.66%206.55c-3.62-.347-6.887-1.42-9.8-3.22.387-.447.54-1.047.46-1.8%202.42-1.06%205.313-1.57%208.68-1.53ZM258.71%20903.11c8.16%202.43%204.59%2014.2-2.59%2012.05-5.36-1.59-5.53-8.44-1.26-11.44a7.151%207.151%200%200%201%203.85-.61ZM198.07%20904.88l-.4%204.75c-.373.707-.93%201.293-1.67%201.76-1.5.487-2.927%201.15-4.28%201.99-.267.167-.557.193-.87.08l-1.27-8.19c2.653-.76%205.483-.89%208.49-.39Z'%20/%3e%3cpath%20fill='%23478FFF'%20d='M225.72%20906.14c2.913%201.8%206.18%202.873%209.8%203.22a144.11%20144.11%200%200%200%204.85%203.02c2.827%201.687%205.927%204.953%209.3%209.8-.8%2015.613-.75%2031.153.15%2046.62l-57.03%201.02-6.54.34c-1.267.067-1.86-.53-1.78-1.79l3.19-49.9c1.46-.953%202.603-2.13%203.43-3.53%201.59-1.54%203.34-1.43%204.91-3.55.74-.467%201.297-1.053%201.67-1.76%201.36-.307%204.053-1.187%208.08-2.64%205.86-2.113%2012.517-2.397%2019.97-.85Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M596.26%20905.95c5.627%202.84%209.633%206.68%2012.02%2011.52%202.853%205.813%203.047%2011.94.58%2018.38l-34.97-.09a.719.719%200%200%201-.711-.603.74.74%200%200%201%20.021-.337l8.59-27.77c.247-.807.793-1.207%201.64-1.2l12.83.1Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='M608.86%20935.85c2.467-6.44%202.273-12.567-.58-18.38-2.387-4.84-6.393-8.68-12.02-11.52l29.57-.11a.772.772%200%200%201%20.631.315.778.778%200%200%201%20.119.695l-8.63%2027.93c-.09.29-.269.543-.512.723-.243.18-.537.277-.838.277l-7.74.07Z'%20/%3e%3cpath%20fill='%231350CE'%20d='M959.01%20919.75a6.77%206.77%200%201%200%200-13.54%206.77%206.77%200%200%200%200%2013.54Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='M196%20911.39c-1.57%202.12-3.32%202.01-4.91%203.55.067-.433-.013-.927-.24-1.48.313.113.603.087.87-.08a19.508%2019.508%200%200%201%204.28-1.99Z'%20/%3e%3cpath%20fill='%23FAF9F9'%20d='m394.81%20937.77%204.54-24.04c.66-.967%201.067-.557%201.22%201.23.047.533.05%201.063.01%201.59-.473%207.06-.637%2013.96-.49%2020.7a.908.908%200%200%201-1%20.92l-4.28-.4Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='m187.66%20918.47-3.19%2049.9c-.08%201.26.513%201.857%201.78%201.79l6.54-.34-.08.49-55.25-.22a.753.753%200%200%201-.75-.76c.1-9.967%205.023-16.75%2014.77-20.35%202.713-1.007%205.623-1.507%208.73-1.5a1.715%201.715%200%200%200%201.6-1.09c2.387-5.973%206.473-10.5%2012.26-13.58%201.78-.95%207.06-1.7%207.98-4.56a26.652%2026.652%200%200%201%205.61-9.78Z'%20/%3e%3cpath%20fill='%23377DFE'%20d='m249.67%20922.18%201.75%202.43a.76.76%200%200%200%20.557.315.764.764%200%200%200%20.603-.215c2.04-1.966%204.51-3.196%207.41-3.69%204.6-.54%208.75.214%2012.45%202.26%206.78%205.54%209.94%2014.57%204.94%2022.39-.24.38-.35.703-.33.97.027.347.163.684.41%201.01.153.867.823%201.69%202.01%202.47.273.18.433.433.48.76l2.49%2018.01c.047.327.233.5.56.52l13.8.89-27.11.11c-.047-1-1.283-1.537-3.71-1.61a272.08%20272.08%200%200%200-16.16%200c-.9-15.467-.95-31.007-.15-46.62Z'%20/%3e%3cpath%20fill='%232466F8'%20d='M330.48%20941.25a6.55%206.55%200%201%200-.001-13.101%206.55%206.55%200%200%200%20.001%2013.101Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M654.7%20948.96a8.59%208.59%200%201%200%200-17.18%208.59%208.59%200%200%200%200%2017.18Z'%20/%3e%3cpath%20fill='%231350CE'%20d='M916.32%20932.57c10.96%203.987%2019.39%2011.24%2025.29%2021.76a12.525%2012.525%200%200%201-3.8-3.44c-1.773-2.433-2.777-3.773-3.01-4.02-2.56-2.73-4.86-5.37-8.01-7.48a471.761%20471.761%200%200%200-4.86-3.23c-2.207-.893-4.077-2.09-5.61-3.59Z'%20/%3e%3cpath%20fill='%232466F8'%20d='M941.61%20954.33c.74.947%201.363%202.197%201.87%203.75a1.087%201.087%200%200%200%201.113.747c.16-.011.317-.058.457-.137%201.85-1.05%203.46-2.52%205.4-3.36%207.373-3.187%2014.477-2.983%2021.31.61%205.26%202.76%209%207.85%209.47%2013.85a.622.622%200%200%201-.62.67l-99.82-.14c4.253-.747%207.707-1.127%2010.36-1.14%208.453-.053%2016.9-.11%2025.34-.17.333%200%20.59-.143.77-.43a77.057%2077.057%200%200%200%204.37-7.73c4.1-8.34%202.92-16.16.3-24.69a471.761%20471.761%200%200%201%204.86%203.23c3.15%202.11%205.45%204.75%208.01%207.48.233.247%201.237%201.587%203.01%204.02a12.525%2012.525%200%200%200%203.8%203.44Z'%20/%3e%3cpath%20fill='%2362A1FF'%20d='M625.08%20944.34c7.26%205.91%208.82%2015.17%208.24%2023.76a2.153%202.153%200%200%201-.685%201.431%202.134%202.134%200%200%201-1.475.569l-13.92-.09c2.193-8.927%204.807-17.483%207.84-25.67Z'%20/%3e%3cpath%20fill='%239DCBFE'%20d='M469.07%20947.3c.507.773-.207%201.253-2.14%201.44-2.58.253-8.64.163-18.18-.27%205.56-4.63%2014.19-5.61%2020.32-1.17ZM607.73%20970.22l-16.72-.05-1.03-.65a.903.903%200%200%201-.43-.74c-.39-7.25-3.68-15.06-10.72-18.11-1.393-.607-4.46-1.727-9.2-3.36-.007-.933.25-1.663.77-2.19.233-.24.517-.36.85-.36l42.41-.15c.98%200%201.333.473%201.06%201.42l-6.99%2024.19Z'%20/%3e%3cpath%20fill='%231350CE'%20d='M127.69%20960.23a6.54%206.54%200%201%200%200-13.08%206.54%206.54%200%200%200%200%2013.08Z'%20/%3e%3cpath%20fill='%23B4D9FD'%20d='m591.01%20970.17-28.27.05%206.89-22.91c4.74%201.633%207.807%202.753%209.2%203.36%207.04%203.05%2010.33%2010.86%2010.72%2018.11.02.32.163.567.43.74l1.03.65Z'%20/%3e%3cpath%20fill='%232466F8'%20d='M277.46%20947.65c2.48.82%204.013%201.41%204.6%201.77%204.853%203%208.737%206.863%2011.65%2011.59.507.82%201.153.957%201.94.41%207.52-5.2%2019.43-2.34%2020.75%207.93.1.793-.247%201.183-1.04%201.17l-18.56-.22-13.8-.89c-.327-.02-.513-.193-.56-.52l-2.49-18.01a1.05%201.05%200%200%200-.48-.76c-1.187-.78-1.857-1.603-2.01-2.47Z'%20/%3e%3cpath%20fill='%23FDCB7D'%20d='M387.71%20950.36c1.227.28%202.42.737%203.58%201.37.38.207.873.203%201.48-.01-.853.307-1.44%201.143-1.76%202.51-.64%202.74.23%206.33%203.37%206.92a21.69%2021.69%200%200%201%203.09.83c2.213.78%202.177%201.427-.11%201.94-2.647.587-5.253.063-7.82-1.57-.313-.2-.65-.343-1.01-.43l-2.02-.5a1.48%201.48%200%200%201-.941-.732%201.464%201.464%200%200%201-.089-1.188c.973-2.707%201.403-5.447%201.29-8.22-.02-.36.137-.607.47-.74l.47-.18ZM429.18%20952.25c-1.353%206.447.873%209.71%206.68%209.79.773.013%201.07.397.89%201.15-.033.133-.083.26-.15.38a1.32%201.32%200%200%201-.83.66c-3.167.827-6.697.363-10.59-1.39-.333-.153-.49-.413-.47-.78l.61-9.74a6.734%206.734%200%200%201%203.86-.07Z'%20/%3e%3cpath%20fill='%231350CE'%20d='m269.69%20970.41-76.98-.1.08-.49%2057.03-1.02c5.333-.16%2010.72-.16%2016.16%200%202.427.073%203.663.61%203.71%201.61Z'%20/%3e%3cg%20clip-path='url(%23a)'%3e%3cpath%20fill='url(%23b)'%20d='m515.287%20249.813%2011.74%2011.546a2.742%202.742%200%200%201%200%203.924%202.854%202.854%200%200%201-3.99%200l-7.75-7.621a2.854%202.854%200%200%200-3.99%200l-19.489%2019.168a2.743%202.743%200%200%200%200%203.925l19.489%2019.168a2.854%202.854%200%200%200%203.99%200l7.75-7.622a2.854%202.854%200%200%201%203.99%200%202.742%202.742%200%200%201%200%203.924l-11.74%2011.547a2.854%202.854%200%200%201-3.99%200l-27.47-27.017a2.741%202.741%200%200%201%200-3.925l27.469-27.017a2.855%202.855%200%200%201%203.991%200Z'%20/%3e%3cpath%20fill='url(%23c)'%20d='M531.018%20269.208a2.854%202.854%200%200%201%203.99%200l7.749%207.622a2.741%202.741%200%200%201%200%203.925l-7.749%207.621a2.852%202.852%200%200%201-3.99%200%202.742%202.742%200%200%201%200-3.924l3.758-3.697a2.74%202.74%200%200%200%200-3.924l-3.758-3.697a2.744%202.744%200%200%201%200-3.926Z'%20/%3e%3cpath%20fill='%2361DAFB'%20d='M512.686%20279.714c0%20.397.161.777.449%201.057.287.281.676.438%201.083.438a1.55%201.55%200%200%200%201.083-.438c.287-.28.448-.66.448-1.057%200-.396-.161-.777-.448-1.057a1.554%201.554%200%200%200-2.166%200c-.288.28-.449.661-.449%201.057Z'%20/%3e%3cpath%20fill='%2361DAFB'%20d='M526.059%20279.351c0-1.739-1.949-3.246-4.977-4.157.763-3.207.494-5.73-.942-6.6-1.439-.869-3.657.147-5.922%202.443-2.266-2.296-4.483-3.312-5.922-2.443-1.437.87-1.706%203.396-.943%206.6-3.028.911-4.977%202.418-4.977%204.157%200%201.739%201.949%203.246%204.977%204.157-.763%203.204-.494%205.73.943%206.599a2.25%202.25%200%200%200%201.193.322c1.048%200%202.318-.604%203.696-1.778.344-.294.689-.626%201.033-.975.343.349.689.681%201.032.975%201.378%201.174%202.645%201.778%203.696%201.778.438%200%20.84-.106%201.194-.322%201.436-.869%201.705-3.392.942-6.599%203.028-.911%204.977-2.418%204.977-4.157Zm-6.434-9.821c.932.565%201.127%202.612.464%205.395a23.031%2023.031%200%200%200-3.149-.515%2025.282%2025.282%200%200%200-2.002-2.603c1.563-1.587%203.015-2.448%204.013-2.448a1.26%201.26%200%200%201%20.674.171Zm-2.107%2011.82c-.364.665-.75%201.302-1.143%201.911-.689.056-1.408.086-2.157.086-.748%200-1.466-.03-2.155-.086a30.24%2030.24%200%200%201-2.149-3.91c.301-.654.634-1.321%201.006-2a31.1%2031.1%200%200%201%201.146-1.913%2026.585%2026.585%200%200%201%202.154-.086c.747%200%201.466.03%202.155.086.388.598.773%201.235%201.145%201.91a31.47%2031.47%200%200%201%201.006%202%2032.37%2032.37%200%200%201-1.008%202.002Zm1.552-.731c.296.737.539%201.443.74%202.119-.658.155-1.365.288-2.121.388.246-.402.486-.812.721-1.236.233-.426.452-.85.66-1.271Zm-4.852%205.509a23.659%2023.659%200%200%201-1.379-1.734c.452.022.911.036%201.379.036.467%200%20.926-.014%201.378-.036a23.923%2023.923%200%200%201-1.378%201.734Zm-3.472-3.002a21.74%2021.74%200%200%201-2.12-.388c.2-.676.443-1.382.739-2.119.209.421.425.845.66%201.271.235.421.475.831.721%201.236Zm-1.381-5.044a23.769%2023.769%200%200%201-.739-2.118%2021.51%2021.51%200%200%201%202.117-.388%2029.475%2029.475%200%200%200-1.378%202.506Zm4.853-5.508c.456.518.918%201.102%201.375%201.736a28.142%2028.142%200%200%200-1.375-.036c-.468%200-.924.014-1.376.036.457-.634.919-1.218%201.376-1.736Zm4.19%204.237a37.856%2037.856%200%200%200-.719-1.235c.756.1%201.46.233%202.118.388a24.422%2024.422%200%200%201-.739%202.118%2029.763%2029.763%200%200%200-.66-1.271Zm-9.597-7.281c.19-.116.417-.171.675-.171.998%200%202.448.861%204.011%202.448a25.497%2025.497%200%200%200-2.001%202.603%2023.097%2023.097%200%200%200-3.15.515c-.663-2.786-.465-4.832.465-5.395Zm-5.405%209.821c0-1.13%201.592-2.332%204.224-3.119.293.997.676%202.044%201.149%203.119a26.395%2026.395%200%200%200-1.149%203.118c-2.632-.786-4.224-1.991-4.224-3.118Zm9.13%208.46c-1.576%201.344-2.933%201.839-3.725%201.363-.932-.565-1.128-2.612-.465-5.395.969.233%202.025.407%203.15.515a25.736%2025.736%200%200%200%202.001%202.609c-.32.324-.639.634-.961.908Zm7.089%201.363c-.79.479-2.149-.017-3.726-1.363a17.013%2017.013%200%200%201-.963-.908%2025.449%2025.449%200%200%200%202.001-2.609%2022.484%2022.484%200%200%200%203.15-.518c.665%202.786.467%204.833-.462%205.398Zm1.183-6.705a26.045%2026.045%200%200%200-1.149-3.118c.47-1.075.855-2.122%201.149-3.119%202.632.79%204.224%201.992%204.224%203.119-.003%201.127-1.595%202.332-4.224%203.118Z'%20/%3e%3c/g%3e%3cdefs%3e%3clinearGradient%20id='b'%20x1='537.663'%20x2='479.351'%20y1='278.792'%20y2='278.792'%20gradientUnits='userSpaceOnUse'%3e%3cstop%20stop-color='%2347B4E0'%20/%3e%3cstop%20offset='.172'%20stop-color='%231588E0'%20/%3e%3cstop%20offset='1'%20stop-color='%236EB4E0'%20/%3e%3c/linearGradient%3e%3clinearGradient%20id='c'%20x1='536.887'%20x2='536.887'%20y1='289.189'%20y2='268.396'%20gradientUnits='userSpaceOnUse'%3e%3cstop%20offset='.032'%20stop-color='%23F0776F'%20/%3e%3cstop%20offset='.503'%20stop-color='%23F0656F'%20/%3e%3cstop%20offset='1'%20stop-color='%23F0606F'%20/%3e%3c/linearGradient%3e%3cclipPath%20id='a'%3e%3cpath%20fill='%23fff'%20d='M483%20249h61v60h-61z'%20/%3e%3c/clipPath%3e%3c/defs%3e%3c/svg%3e";
})), Fl, Il = w((() => {
	Fl = "data:image/svg+xml,%3csvg%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2085%2084'%3e%3cpath%20d='M44.9903%201.13755L61.3489%2017.3023C62.8848%2018.82%2062.8848%2021.2797%2061.3489%2022.7966C59.813%2024.3143%2057.3238%2024.3143%2055.7888%2022.7966L44.9903%2012.127C43.4544%2010.6093%2040.9652%2010.6093%2039.4302%2012.127L12.2732%2038.9622C10.7372%2040.4799%2010.7372%2042.9396%2012.2732%2044.4565L39.4302%2071.2917C40.9661%2072.8094%2043.4553%2072.8094%2044.9903%2071.2917L55.7888%2060.6213C57.3247%2059.1036%2059.8139%2059.1036%2061.3489%2060.6213C62.8848%2062.139%2062.8848%2064.5987%2061.3489%2066.1156L44.9903%2082.2803C43.4544%2083.798%2040.9652%2083.798%2039.4302%2082.2803L1.15193%2044.4565C-0.383976%2042.9388%20-0.383976%2040.4791%201.15193%2038.9622L39.4293%201.13838C40.9652%20-0.379323%2043.4553%20-0.379322%2044.9903%201.13755Z'%20fill='url(%23paint0_linear_1_12)'/%3e%3cpath%20d='M66.91%2028.2918C68.4459%2026.7741%2070.9351%2026.7741%2072.4702%2028.2918L83.2686%2038.9622C84.8045%2040.4799%2084.8045%2042.9396%2083.2686%2044.4565L72.4702%2055.127C70.9343%2056.6447%2068.445%2056.6447%2066.91%2055.127C65.3741%2053.6093%2065.3741%2051.1495%2066.91%2049.6327L72.1474%2044.4573C73.6833%2042.9396%2073.6833%2040.4799%2072.1474%2038.963L66.91%2033.7877C65.3741%2032.2692%2065.3741%2029.8095%2066.91%2028.2918Z'%20fill='url(%23paint1_linear_1_12)'/%3e%3cpath%20d='M41.3659%2043C41.3659%2043.5551%2041.5907%2044.0875%2041.9909%2044.48C42.3912%2044.8725%2042.934%2045.093%2043.5%2045.093C44.066%2045.093%2044.6088%2044.8725%2045.0091%2044.48C45.4093%2044.0875%2045.6342%2043.5551%2045.6342%2043C45.6342%2042.4449%2045.4093%2041.9125%2045.0091%2041.52C44.6088%2041.1275%2044.066%2040.907%2043.5%2040.907C42.934%2040.907%2042.3912%2041.1275%2041.9909%2041.52C41.5907%2041.9125%2041.3659%2042.4449%2041.3659%2043Z'%20fill='%2361DAFB'/%3e%3cpath%20d='M60%2042.4911C60%2040.0563%2057.285%2037.947%2053.0652%2036.6714C54.1284%2032.1816%2053.7532%2028.6495%2051.7518%2027.432C49.7468%2026.2146%2046.6565%2027.6375%2043.5%2030.8517C40.3435%2027.6375%2037.2532%2026.2146%2035.2482%2027.432C33.2468%2028.6495%2032.8716%2032.1855%2033.9348%2036.6714C29.7151%2037.947%2027%2040.0563%2027%2042.4911C27%2044.926%2029.7151%2047.0352%2033.9348%2048.3108C32.8716%2052.7968%2033.2468%2056.3328%2035.2482%2057.5502C35.7411%2057.8527%2036.3003%2058%2036.911%2058C38.3716%2058%2040.1411%2057.1548%2042.0615%2055.5108C42.5398%2055.0998%2043.0217%2054.6346%2043.5%2054.146C43.9783%2054.6346%2044.4602%2055.0998%2044.9385%2055.5108C46.8589%2057.1548%2048.6247%2058%2050.089%2058C50.6997%2058%2051.2589%2057.8527%2051.7518%2057.5502C53.7532%2056.3328%2054.1284%2052.8007%2053.0652%2048.3108C57.285%2047.0352%2060%2044.926%2060%2042.4911ZM51.0344%2028.7425C52.3331%2029.5335%2052.6054%2032.3988%2051.6819%2036.2954C50.3318%2035.9697%2048.8602%2035.7254%2047.293%2035.5742C46.3843%2034.221%2045.4462%2032.9997%2044.5043%2031.9296C46.6823%2029.708%2048.7057%2028.5022%2050.0963%2028.5022C50.4495%2028.4983%2050.7659%2028.5797%2051.0344%2028.7425ZM48.0987%2045.2905C47.591%2046.221%2047.0538%2047.1128%2046.5057%2047.9658C45.5455%2048.0433%2044.5448%2048.086%2043.5%2048.086C42.4589%2048.086%2041.4582%2048.0433%2040.498%2047.9658C39.9462%2047.1128%2039.4127%2046.2171%2038.905%2045.2905C38.3863%2044.3406%2037.9227%2043.4062%2037.5033%2042.4911C37.9227%2041.5761%2038.3863%2040.6417%2038.905%2039.6918C39.4237%2038.7419%2039.9609%2037.854%2040.5017%2037.0126C41.4619%2036.9351%2042.4625%2036.8924%2043.5037%2036.8924C44.5448%2036.8924%2045.5455%2036.9351%2046.5057%2037.0126C47.0465%2037.8501%2047.5836%2038.7419%2048.1023%2039.6879C48.6211%2040.6378%2049.0846%2041.5722%2049.504%2042.4873C49.0809%2043.4062%2048.6174%2044.3406%2048.0987%2045.2905ZM50.2619%2044.2669C50.6739%2045.2982%2051.0124%2046.2869%2051.292%2047.233C50.3759%2047.4501%2049.39%2047.6362%2048.3378%2047.7758C48.6799%2047.2136%2049.0147%2046.6398%2049.3421%2046.0465C49.6659%2045.4495%2049.9712%2044.8562%2050.2619%2044.2669ZM43.5%2051.9787C42.8488%2051.2343%2042.2087%2050.4239%2041.5796%2049.5515C42.2087%2049.5826%2042.8488%2049.602%2043.5%2049.602C44.1512%2049.602%2044.7913%2049.5826%2045.4204%2049.5515C44.7913%2050.4239%2044.1512%2051.2343%2043.5%2051.9787ZM38.6622%2047.7758C37.61%2047.6362%2036.6278%2047.4501%2035.708%2047.233C35.9876%2046.2869%2036.3261%2045.2982%2036.7381%2044.2669C37.0288%2044.8562%2037.3304%2045.4495%2037.6579%2046.0465C37.9853%2046.6359%2038.3201%2047.2097%2038.6622%2047.7758ZM36.7381%2040.7154C36.3261%2039.684%2035.9876%2038.6953%2035.708%2037.7493C36.6241%2037.5322%2037.6064%2037.3461%2038.6585%2037.2065C38.3201%2037.7648%2037.9816%2038.3386%2037.6579%2038.9357C37.3341%2039.5328%2037.0288%2040.126%2036.7381%2040.7154ZM43.5%2033.0036C44.1365%2033.7286%2044.7803%2034.5467%2045.4167%2035.4346C44.7876%2035.4036%2044.1512%2035.3842%2043.5%2035.3842C42.8488%2035.3842%2042.2124%2035.4036%2041.5833%2035.4346C42.2197%2034.5467%2042.8635%2033.7286%2043.5%2033.0036ZM49.3385%2038.9357C49.011%2038.3425%2048.6763%2037.7687%2048.3378%2037.2065C49.39%2037.3461%2050.3722%2037.5322%2051.2883%2037.7493C51.0087%2038.6953%2050.6702%2039.684%2050.2582%2040.7154C49.9712%2040.126%2049.6659%2039.5328%2049.3385%2038.9357ZM35.9656%2028.7425C36.2304%2028.5797%2036.5468%2028.5022%2036.9074%2028.5022C38.298%2028.5022%2040.3177%2029.708%2042.4957%2031.9296C41.5538%2032.9997%2040.6157%2034.2249%2039.707%2035.5742C38.1435%2035.7254%2036.6682%2035.9697%2035.3181%2036.2954C34.3946%2032.3949%2034.6706%2029.5296%2035.9656%2028.7425ZM28.4348%2042.4911C28.4348%2040.9092%2030.6532%2039.2265%2034.3211%2038.1254C34.7294%2039.5212%2035.2629%2040.9868%2035.9214%2042.4911C35.2666%2043.9955%2034.7294%2045.4611%2034.3211%2046.8569C30.6532%2045.7558%2028.4348%2044.0692%2028.4348%2042.4911ZM41.1565%2054.336C38.9602%2056.2165%2037.0692%2056.9105%2035.9656%2056.2436C34.6669%2055.4527%2034.3946%2052.5874%2035.3181%2048.6908C36.6682%2049.0165%2038.1398%2049.2608%2039.707%2049.412C40.6047%2050.7496%2041.5428%2051.9748%2042.4957%2053.0643C42.0505%2053.5179%2041.6054%2053.9522%2041.1565%2054.336ZM51.0344%2056.2436C49.9344%2056.9144%2048.0398%2056.2204%2045.8435%2054.336C45.3983%2053.9522%2044.9495%2053.5179%2044.5007%2053.0643C45.4572%2051.9748%2046.3916%2050.7496%2047.2893%2049.412C48.8528%2049.2608%2050.3281%2049.0165%2051.6783%2048.6869C52.6054%2052.5874%2052.3294%2055.4527%2051.0344%2056.2436ZM52.6826%2046.8569C52.2742%2045.4611%2051.7408%2043.9955%2051.0823%2042.4911C51.7371%2040.9868%2052.2742%2039.5212%2052.6826%2038.1254C56.3505%2039.2304%2058.5689%2040.9131%2058.5689%2042.4911C58.5652%2044.0692%2056.3468%2045.7558%2052.6826%2046.8569Z'%20fill='%2361DAFB'/%3e%3cdefs%3e%3clinearGradient%20id='paint0_linear_1_12'%20x1='76.1703'%20y1='41.7094'%20x2='-5.08475'%20y2='41.7094'%20gradientUnits='userSpaceOnUse'%3e%3cstop%20stop-color='%2347B4E0'/%3e%3cstop%20offset='0.1718'%20stop-color='%231588E0'/%3e%3cstop%20offset='1'%20stop-color='%236EB4E0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='paint1_linear_1_12'%20x1='75.0889'%20y1='56.2647'%20x2='75.0889'%20y2='27.1539'%20gradientUnits='userSpaceOnUse'%3e%3cstop%20offset='0.0322'%20stop-color='%23F0776F'/%3e%3cstop%20offset='0.5032'%20stop-color='%23F0656F'/%3e%3cstop%20offset='1'%20stop-color='%23F0606F'/%3e%3c/linearGradient%3e%3c/defs%3e%3c/svg%3e";
})), Ll, Rl, zl = w((() => {
	Ll = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: "1em",
		height: "1em",
		viewBox: "0 0 24 24",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			fill: "currentColor",
			d: "M20 5v14H4V5zm0-2H4c-1.11 0-2 .89-2 2v14c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V5c0-1.11-.89-2-2-2m-2 12H6v2h12zm-8-8H6v6h4zm2 2h6V7h-6zm6 2h-6v2h6z"
		})]
	}), Rl = _(Ll);
})), Bl, Vl, Hl = w((() => {
	Bl = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: "1em",
		height: "1em",
		viewBox: "0 0 24 24",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			fill: "currentColor",
			d: "M4 7v12h15v2H4c-2 0-2-2-2-2V7zm17-2v10H8V5zm.3-2H7.7C6.76 3 6 3.7 6 4.55v10.9c0 .86.76 1.55 1.7 1.55h13.6c.94 0 1.7-.69 1.7-1.55V4.55C23 3.7 22.24 3 21.3 3M9 6h3v5H9zm11 8H9v-2h11zm0-6h-6V6h6zm0 3h-6V9h6z"
		})]
	}), Vl = _(Bl);
})), Ul, Wl, Gl = w((() => {
	Ul = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: "1em",
		height: "1em",
		viewBox: "0 0 1024 1024",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			d: "M284 862c-17.673 0-32-14.327-32-32V194c0-17.673 14.327-32 32-32h456c17.673 0 32 14.327 32 32v636c0 17.673-14.327 32-32 32zm40-72h376V234H324zm-152 72h-56a8 8 0 01-8-8V170a8 8 0 018-8h56a8 8 0 018 8v684a8 8 0 01-8 8m736 0h-56a8 8 0 01-8-8V170a8 8 0 018-8h56a8 8 0 018 8v684a8 8 0 01-8 8",
			fill: "currentColor"
		})]
	}), Wl = _(Ul);
})), Kl, ql, Jl = w((() => {
	Kl = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: "1em",
		height: "1em",
		viewBox: "0 0 1024 1024",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			d: "M426.667 128a42.667 42.667 0 00-85.334 0zm-85.334 768a42.667 42.667 0 1085.334 0zm-143.445-13.952-19.37 38.016zm-55.936-55.936 38.016-19.37zm740.096 0-38.016-19.37zm-55.936 55.936-19.37-38.016zm0-740.096-19.37 38.016zm55.936 55.936 38.016-19.37zm-684.16-55.936 19.37 38.016zm-55.936 55.936 38.016 19.37zM341.333 128v768h85.334V128zm-8.533 42.667h358.4V85.333H332.8zM853.333 332.8v358.4h85.334V332.8zM691.2 853.333H332.8v85.334h358.4zM170.667 691.2V332.8H85.333v358.4zM332.8 853.333c-36.565 0-61.397 0-80.597-1.621-18.688-1.493-28.288-4.267-34.944-7.68l-38.742 76.032c20.694 10.539 42.752 14.763 66.731 16.725 23.467 1.878 52.395 1.878 87.552 1.878zM85.333 691.2c0 35.157 0 64.043 1.878 87.552 1.962 23.979 6.186 46.037 16.725 66.73l76.032-38.74c-3.413-6.657-6.187-16.214-7.68-34.945-1.621-19.2-1.621-44.032-1.621-80.597zM217.26 844.032a85.33 85.33 0 01-37.291-37.29l-76.032 38.74a170.67 170.67 0 0074.581 74.582zM853.333 691.2c0 36.565 0 61.397-1.621 80.597-1.493 18.688-4.267 28.288-7.68 34.944l76.032 38.742c10.539-20.694 14.763-42.752 16.725-66.731 1.92-23.467 1.878-52.395 1.878-87.552zM691.2 938.667c35.157 0 64.043 0 87.552-1.878 23.979-1.962 46.037-6.186 66.73-16.725l-38.74-76.032c-6.657 3.413-16.214 6.187-34.945 7.68-19.2 1.579-44.032 1.621-80.597 1.621zM844.032 806.74a85.33 85.33 0 01-37.29 37.291l38.74 76.032a170.67 170.67 0 0074.582-74.581zM691.2 170.667c36.565 0 61.397 0 80.597 1.621 18.688 1.493 28.288 4.267 34.944 7.68l38.742-76.032c-20.694-10.539-42.752-14.763-66.731-16.725-23.467-1.878-52.395-1.878-87.552-1.878zM938.667 332.8c0-35.157 0-64.043-1.878-87.552-1.962-23.979-6.186-46.037-16.725-66.73l-76.032 38.74c3.413 6.657 6.187 16.214 7.68 34.945 1.621 19.2 1.621 44.032 1.621 80.597zM806.74 179.968a85.33 85.33 0 0137.291 37.29l76.032-38.74a170.67 170.67 0 00-74.581-74.582zM332.8 85.333c-35.157 0-64.043 0-87.552 1.878-23.979 1.962-46.037 6.186-66.73 16.725l38.74 76.032c6.657-3.413 16.214-6.187 34.945-7.68 19.2-1.621 44.032-1.621 80.597-1.621zM170.667 332.8c0-36.565 0-61.397 1.621-80.597 1.493-18.688 4.267-28.288 7.68-34.944l-76.032-38.742c-10.539 20.694-14.763 42.752-16.725 66.731-1.878 23.467-1.878 52.395-1.878 87.552zm7.85-228.864a170.67 170.67 0 00-74.581 74.581l76.032 38.742a85.33 85.33 0 0137.29-37.291z",
			fill: "currentColor"
		})]
	}), ql = _(Kl);
})), Yl, Xl, Zl = w((() => {
	Yl = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: "1em",
		height: "1em",
		viewBox: "0 0 1024 1024",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			d: "M682.667 128a42.667 42.667 0 10-85.334 0zm-85.334 768a42.667 42.667 0 1085.334 0zm-399.445-13.952-19.37 38.016zm-55.936-55.936 38.016-19.37zm740.096 0-38.016-19.37zm-55.936 55.936-19.37-38.016zm0-740.096-19.37 38.016zm55.936 55.936 38.016-19.37zm-684.16-55.936 19.37 38.016zm-55.936 55.936 38.016 19.37zM597.333 128v768h85.334V128zM332.8 170.667h358.4V85.333H332.8zM853.333 332.8v358.4h85.334V332.8zM691.2 853.333H332.8v85.334h358.4zM170.667 691.2V332.8H85.333v358.4zM332.8 853.333c-36.565 0-61.397 0-80.597-1.621-18.688-1.493-28.288-4.267-34.944-7.68l-38.742 76.032c20.694 10.539 42.752 14.763 66.731 16.725 23.467 1.878 52.395 1.878 87.552 1.878zM85.333 691.2c0 35.157 0 64.043 1.878 87.552 1.962 23.979 6.186 46.037 16.725 66.73l76.032-38.74c-3.413-6.657-6.187-16.214-7.68-34.945-1.621-19.2-1.621-44.032-1.621-80.597zM217.26 844.032a85.33 85.33 0 01-37.291-37.29l-76.032 38.74a170.67 170.67 0 0074.581 74.582zM853.333 691.2c0 36.565 0 61.397-1.621 80.597-1.493 18.688-4.267 28.288-7.68 34.944l76.032 38.742c10.539-20.694 14.763-42.752 16.725-66.731 1.92-23.467 1.878-52.395 1.878-87.552zM691.2 938.667c35.157 0 64.043 0 87.552-1.878 23.979-1.962 46.037-6.186 66.73-16.725l-38.74-76.032c-6.657 3.413-16.214 6.187-34.945 7.68-19.2 1.579-44.032 1.621-80.597 1.621zM844.032 806.74a85.33 85.33 0 01-37.29 37.291l38.74 76.032a170.67 170.67 0 0074.582-74.581zM691.2 170.667c36.565 0 61.397 0 80.597 1.621 18.688 1.493 28.288 4.267 34.944 7.68l38.742-76.032c-20.694-10.539-42.752-14.763-66.731-16.725-23.467-1.878-52.395-1.878-87.552-1.878zM938.667 332.8c0-35.157 0-64.043-1.878-87.552-1.962-23.979-6.186-46.037-16.725-66.73l-76.032 38.74c3.413 6.657 6.187 16.214 7.68 34.945 1.621 19.2 1.621 44.032 1.621 80.597zM806.74 179.968a85.33 85.33 0 0137.291 37.29l76.032-38.74a170.67 170.67 0 00-74.581-74.582zM332.8 85.333c-35.157 0-64.043 0-87.552 1.878-23.979 1.962-46.037 6.186-66.73 16.725l38.74 76.032c6.657-3.413 16.214-6.187 34.945-7.68 19.2-1.621 44.032-1.621 80.597-1.621zM170.667 332.8c0-36.565 0-61.397 1.621-80.597 1.493-18.688 4.267-28.288 7.68-34.944l-76.032-38.742c-10.539 20.694-14.763 42.752-16.725 66.731-1.878 23.467-1.878 52.395-1.878 87.552zm7.85-228.864a170.67 170.67 0 00-74.581 74.581l76.032 38.742a85.33 85.33 0 0137.29-37.291z",
			fill: "currentColor"
		})]
	}), Xl = _(Yl);
})), Ql, $l, eu = w((() => {
	Ql = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: "1em",
		height: "1em",
		viewBox: "0 0 104 66",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ C("g", {
			fill: "none",
			children: [
				/* @__PURE__ */ S("rect", {
					width: 104,
					height: 66,
					x: .135,
					y: .135,
					fill: "currentColor",
					fillOpacity: .02,
					rx: 4
				}),
				/* @__PURE__ */ S("path", {
					fill: "#1677ff",
					d: "M-.074-.058h104.079v9.07H-.074z"
				}),
				/* @__PURE__ */ S("rect", {
					width: 7.525,
					height: 2.789,
					x: 15.582,
					y: 3.208,
					fill: "#e5e5e5",
					rx: 1.395
				}),
				/* @__PURE__ */ S("path", {
					fill: "#fff",
					d: "M98.198 2.872c0-.543.457-1 1-1h1.925c.544 0 1 .457 1 1v2.4c0 .543-.456 1-1 1h-1.925c-.543 0-1-.457-1-1z"
				}),
				/* @__PURE__ */ S("rect", {
					width: 44.131,
					height: 21.519,
					x: 53.379,
					y: 13.457,
					fill: "currentColor",
					fillOpacity: .08,
					rx: 2
				}),
				/* @__PURE__ */ S("path", {
					fill: "currentColor",
					fillOpacity: .08,
					d: "M19.44 15.742c0-1.086.79-2 1.73-2h23.185c.94 0 1.73.914 1.73 2v17.25c0 1.086-.79 2-1.73 2H21.17c-.94 0-1.73-.914-1.73-2z"
				}),
				/* @__PURE__ */ S("rect", {
					width: 78.394,
					height: 21.654,
					x: 19.936,
					y: 39.347,
					fill: "currentColor",
					fillOpacity: .08,
					rx: 2
				}),
				/* @__PURE__ */ S("rect", {
					width: 7.525,
					height: 2.789,
					x: 28.149,
					y: 3.073,
					fill: "#e5e5e5",
					rx: 1.395
				}),
				/* @__PURE__ */ S("rect", {
					width: 7.525,
					height: 2.789,
					x: 41.257,
					y: 3.208,
					fill: "#e5e5e5",
					rx: 1.395
				}),
				/* @__PURE__ */ S("rect", {
					width: 7.525,
					height: 2.789,
					x: 54.23,
					y: 3.073,
					fill: "#e5e5e5",
					rx: 1.395
				}),
				/* @__PURE__ */ S("rect", {
					width: 7.784,
					height: 7.138,
					x: 1.533,
					y: .881,
					fill: "#fff",
					rx: 2
				}),
				/* @__PURE__ */ S("path", {
					fill: "#69b1ff",
					d: "M-.064 9.031h15.446v56.812H-.064z"
				}),
				/* @__PURE__ */ S("path", {
					fill: "#e5e5e5",
					d: "M2.387 15.38c0-.203.272-.374.595-.374h7.982c.323 0 .595.17.595.375v3.235c0 .204-.272.375-.595.375H2.982c-.323 0-.595-.171-.595-.375zm0 13.053c0-.203.272-.375.595-.375h7.982c.323 0 .595.172.595.375v3.236c0 .203-.272.375-.595.375H2.982c-.323 0-.595-.172-.595-.375zm-.211 12.842c0-.203.272-.375.596-.375h7.981c.324 0 .596.172.596.375v3.236c0 .204-.272.375-.596.375H2.772c-.324 0-.596-.171-.596-.375zm0 13.053c0-.204.272-.375.596-.375h7.981c.324 0 .596.171.596.375v3.235c0 .204-.272.375-.596.375H2.772c-.324 0-.596-.17-.596-.375z"
				})
			]
		})]
	}), $l = _(Ql);
})), tu, nu, ru = w((() => {
	tu = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: "1em",
		height: "1em",
		viewBox: "0 0 24 24",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			fill: "currentColor",
			d: "M5 2c0-.55-.45-1-1-1s-1 .45-1 1v4H2c-.55 0-1 .45-1 1v5h6V7c0-.55-.45-1-1-1H5zm4 14c0 1.3.84 2.4 2 2.82V22c0 .55.45 1 1 1s1-.45 1-1v-3.18c1.16-.41 2-1.51 2-2.82v-2H9zm-8 0c0 1.3.84 2.4 2 2.82V22c0 .55.45 1 1 1s1-.45 1-1v-3.18C6.16 18.4 7 17.3 7 16v-2H1zM21 6V2c0-.55-.45-1-1-1s-1 .45-1 1v4h-1c-.55 0-1 .45-1 1v5h6V7c0-.55-.45-1-1-1zm-8-4c0-.55-.45-1-1-1s-1 .45-1 1v4h-1c-.55 0-1 .45-1 1v5h6V7c0-.55-.45-1-1-1h-1zm4 14c0 1.3.84 2.4 2 2.82V22c0 .55.45 1 1 1s1-.45 1-1v-3.18c1.16-.41 2-1.51 2-2.82v-2h-6z"
		})]
	}), nu = _(tu);
})), iu, au, ou = w((() => {
	iu = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: "1em",
		height: "1em",
		viewBox: "0 0 24 24",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			fill: "none",
			stroke: "currentColor",
			strokeLinecap: "round",
			strokeLinejoin: "round",
			strokeWidth: 2,
			d: "M15 9h3m-3 3h3m-3 3h3m-6 1c-.306-.613-.933-1-1.618-1H7.618c-.685 0-1.312.387-1.618 1M4 5h16a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V6a1 1 0 011-1m7 5a2 2 0 11-4 0 2 2 0 014 0"
		})]
	}), au = _(iu);
})), su, cu, lu = w((() => {
	su = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: "1em",
		height: "1em",
		viewBox: "0 0 1189 1024",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ C("g", {
			fill: "currentColor",
			children: [
				/* @__PURE__ */ S("path", { d: "M694.148 784.901c-19.59-1.19-34.65-17.956-33.885-37.743s17.087-35.313 36.719-34.94c19.632.362 35.375 16.498 35.406 36.305a37.06 37.06 0 01-11.482 26.345 36.44 36.44 0 01-26.748 10.033zm-122.756 0c-19.6-1.19-34.66-17.956-33.895-37.743.775-19.787 17.097-35.313 36.719-34.94 19.642.362 35.374 16.498 35.405 36.305a37.06 37.06 0 01-11.48 26.345 36.44 36.44 0 01-26.749 10.033m-437.734-72.218h215.37v72.218h-215.37zm-58.15-86.874H10.891v202.524a44.15 44.15 0 0013.912 31.744 43.4 43.4 0 0032.395 11.688h767.255a44.48 44.48 0 0032.075-12.03 45.23 45.23 0 0014.233-31.402V625.81zm620.264-463.127c-20.966 1.603-39.47-13.706-41.995-34.754.797-20.14 16.653-36.358 36.616-37.464 20.15-.435 37.36 14.584 39.833 34.754-.207 19.57-15.112 35.788-34.454 37.464m-122.766 0a41.87 41.87 0 01-35.53-17.377 34.44 34.44 0 010-36.378 39.17 39.17 0 0141.529-17.553 39.51 39.51 0 0130.616 33.295 36 36 0 01-9.981 27.162 35.38 35.38 0 01-26.634 10.85M133.658 89.926h215.37v72.756h-215.37zM806.147 3.04H76.583c-34.382-.9-63.137 26.169-64.605 60.83v185.685H873.45V63.86c-2.586-35.219-32.313-62.07-67.304-60.819m-672.49 405.607H349.03v72.208H133.658zm436.121 0a38.73 38.73 0 0135.54 21.722 33.86 33.86 0 01-7.55 39.087 43.34 43.34 0 01-41.446 8.689 37.96 37.96 0 01-24.773-33.12c1.407-20.325 18.039-36.15 38.23-36.378m122.767 0c20.149-.434 37.36 14.574 39.843 34.744-.807 20.139-16.653 36.357-36.616 37.464-20.15.434-37.36-14.584-39.843-34.754.28-20.356 16.425-36.874 36.616-37.454M10.892 567.72h858.246V321.753H7.664z" }),
				/* @__PURE__ */ S("path", { d: "M871.496 424.08c40.133 0 78.631 7.293 115.485 21.888 36.854 14.584 68.525 34.857 94.746 61.057a303.4 303.4 0 0163.333 92.387c15.825 35.396 23.748 72.953 23.748 112.661 0 39.719-7.913 77.266-23.748 112.66-15.836 35.396-36.864 66.199-63.344 92.399-26.479 26.2-57.881 47.01-94.735 62.68a292.2 292.2 0 01-115.485 23.501c-40.132 0-78.082-7.83-113.85-23.5-35.757-15.67-66.88-36.481-93.37-62.681-26.48-26.21-47.497-56.734-63.333-92.398-15.836-35.395-23.759-72.942-23.759-112.66s7.923-77.266 23.76-112.662c15.825-35.385 36.853-66.187 63.332-92.387 26.48-26.21 57.334-46.473 93.37-61.057 36.047-14.585 73.987-21.887 113.85-21.887" }),
				/* @__PURE__ */ S("path", {
					fill: "#fff",
					d: "M898.565 713.263 1006.24 605.67a13.074 13.074 0 00.062-18.442 12.93 12.93 0 00-18.37-.052L880.226 694.768l-106.765-107.55a12.96 12.96 0 00-18.37-.032 13.095 13.095 0 00-.03 18.463l106.754 107.53L754.18 820.7a13.074 13.074 0 009.154 22.29c3.31 0 6.62-1.261 9.164-3.795l107.645-107.54L987.9 840.186a12.93 12.93 0 0018.37.03 13.084 13.084 0 00.021-18.452L898.576 713.263z"
				})
			]
		})]
	}), cu = _(su);
})), uu, du, fu = w((() => {
	uu = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: "1em",
		height: "1em",
		viewBox: "0 0 104 66",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ C("g", {
			fill: "none",
			children: [
				/* @__PURE__ */ S("rect", {
					width: 104,
					height: 66,
					fill: "currentColor",
					fillOpacity: .02,
					rx: 4
				}),
				/* @__PURE__ */ S("path", {
					fill: "#1677ff",
					d: "M-3.378 3.62A4.492 4.025 0 011.114-.406h26.358V66H1.114a4.492 4.025 0 01-4.492-4.025z"
				}),
				/* @__PURE__ */ S("rect", {
					width: 17.66,
					height: 2.789,
					x: 4.906,
					y: 23.884,
					fill: "#e5e5e5",
					rx: 1.395
				}),
				/* @__PURE__ */ S("rect", {
					width: 9.811,
					height: 9.706,
					x: 8.83,
					y: 5.881,
					fill: "#fff",
					rx: 2
				}),
				/* @__PURE__ */ S("path", {
					fill: "#fff",
					d: "M4.906 35.833c0-.758.637-1.395 1.395-1.395h14.87c.758 0 1.395.637 1.395 1.395v-.001c0 .758-.637 1.395-1.395 1.395H6.301a1.41 1.41 0 01-1.395-1.395z"
				}),
				/* @__PURE__ */ S("rect", {
					width: 17.66,
					height: 2.789,
					x: 4.906,
					y: 44.992,
					fill: "#fff",
					rx: 1.395
				}),
				/* @__PURE__ */ S("rect", {
					width: 17.66,
					height: 2.789,
					x: 4.906,
					y: 55.546,
					fill: "#fff",
					rx: 1.395
				}),
				/* @__PURE__ */ S("rect", {
					width: 73.539,
					height: 9.07,
					x: 28.98,
					y: 1.429,
					fill: "currentColor",
					fillOpacity: .08,
					rx: 2
				}),
				/* @__PURE__ */ S("rect", {
					width: 3.925,
					height: 4.4,
					x: 32.039,
					y: 3.899,
					fill: "#b2b2b2",
					rx: 1
				}),
				/* @__PURE__ */ S("rect", {
					width: 3.925,
					height: 4.4,
					x: 80.751,
					y: 3.629,
					fill: "#b2b2b2",
					rx: 1
				}),
				/* @__PURE__ */ S("rect", {
					width: 3.925,
					height: 4.4,
					x: 87.582,
					y: 3.494,
					fill: "#b2b2b2",
					rx: 1
				}),
				/* @__PURE__ */ S("rect", {
					width: 3.925,
					height: 4.4,
					x: 94.685,
					y: 3.629,
					fill: "#b2b2b2",
					rx: 1
				}),
				/* @__PURE__ */ S("rect", {
					width: 45.631,
					height: 21.519,
					x: 56.052,
					y: 14.613,
					fill: "currentColor",
					fillOpacity: .08,
					rx: 2
				}),
				/* @__PURE__ */ S("rect", {
					width: 22.83,
					height: 20.978,
					x: 29.385,
					y: 14.613,
					fill: "currentColor",
					fillOpacity: .08,
					rx: 2
				}),
				/* @__PURE__ */ S("rect", {
					width: 72.458,
					height: 21.654,
					x: 28.98,
					y: 39.482,
					fill: "currentColor",
					fillOpacity: .08,
					rx: 2
				})
			]
		})]
	}), du = _(uu);
})), pu, mu, hu = w((() => {
	pu = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: "1em",
		height: "1em",
		viewBox: "0 0 104 66",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ C("g", {
			fill: "none",
			children: [
				/* @__PURE__ */ S("rect", {
					width: 104,
					height: 66,
					x: .135,
					y: .135,
					fill: "currentColor",
					fillOpacity: .02,
					rx: 4
				}),
				/* @__PURE__ */ S("path", {
					fill: "#1677ff",
					d: "M-.074-.058h104.079v9.07H-.074z"
				}),
				/* @__PURE__ */ S("rect", {
					width: 7.525,
					height: 2.789,
					x: 15.582,
					y: 3.208,
					fill: "#e5e5e5",
					rx: 1.395
				}),
				/* @__PURE__ */ S("path", {
					fill: "#fff",
					d: "M98.198 2.872c0-.543.457-1 1-1h1.925c.544 0 1 .457 1 1v2.4c0 .543-.456 1-1 1h-1.925c-.543 0-1-.457-1-1z"
				}),
				/* @__PURE__ */ S("rect", {
					width: 53.604,
					height: 21.519,
					x: 43.484,
					y: 13.667,
					fill: "currentColor",
					fillOpacity: .08,
					rx: 2
				}),
				/* @__PURE__ */ S("path", {
					fill: "currentColor",
					fillOpacity: .08,
					d: "M3.44 15.532c0-1.087 1.033-2 2.263-2h30.33c1.23 0 2.263.913 2.263 2V32.78c0 1.086-1.033 2-2.263 2H5.703c-1.23 0-2.264-.914-2.264-2V15.53z"
				}),
				/* @__PURE__ */ S("rect", {
					width: 95.025,
					height: 21.654,
					x: 3.304,
					y: 39.347,
					fill: "currentColor",
					fillOpacity: .08,
					rx: 2
				}),
				/* @__PURE__ */ S("rect", {
					width: 7.525,
					height: 2.789,
					x: 28.149,
					y: 3.073,
					fill: "#e5e5e5",
					rx: 1.395
				}),
				/* @__PURE__ */ S("rect", {
					width: 7.525,
					height: 2.789,
					x: 41.257,
					y: 3.208,
					fill: "#e5e5e5",
					rx: 1.395
				}),
				/* @__PURE__ */ S("rect", {
					width: 7.525,
					height: 2.789,
					x: 54.23,
					y: 3.073,
					fill: "#e5e5e5",
					rx: 1.395
				}),
				/* @__PURE__ */ S("rect", {
					width: 7.784,
					height: 7.138,
					x: 1.533,
					y: .881,
					fill: "#fff",
					rx: 2
				})
			]
		})]
	}), mu = _(pu);
})), gu, _u, vu = w((() => {
	gu = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		width: "1em",
		height: "1em",
		viewBox: "0 0 104 66",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ C("g", {
			fill: "none",
			children: [
				/* @__PURE__ */ S("rect", {
					width: 104,
					height: 66,
					x: .135,
					y: .135,
					fill: "currentColor",
					fillOpacity: .02,
					rx: 4
				}),
				/* @__PURE__ */ S("path", {
					fill: "#1677ff",
					d: "M-3.378 3.754A1.934 4.025 0 01-1.444-.27H9.904v66.405H-1.444a1.934 4.025 0 01-1.934-4.024z"
				}),
				/* @__PURE__ */ S("rect", {
					width: 5.474,
					height: 2.789,
					x: 1.641,
					y: 15.461,
					fill: "#e5e5e5",
					rx: 1.395
				}),
				/* @__PURE__ */ S("rect", {
					width: 8.189,
					height: 7.679,
					x: .587,
					y: 1.422,
					fill: "#fff",
					rx: 2
				}),
				/* @__PURE__ */ S("rect", {
					width: 75.92,
					height: 9.07,
					x: 25.383,
					y: 1.429,
					fill: "currentColor",
					fillOpacity: .08,
					rx: 2
				}),
				/* @__PURE__ */ S("rect", {
					width: 3.925,
					height: 4.4,
					x: 27.915,
					y: 3.693,
					fill: "#b2b2b2",
					rx: 1
				}),
				/* @__PURE__ */ S("rect", {
					width: 3.925,
					height: 4.4,
					x: 80.751,
					y: 3.629,
					fill: "#b2b2b2",
					rx: 1
				}),
				/* @__PURE__ */ S("rect", {
					width: 3.925,
					height: 4.4,
					x: 87.789,
					y: 3.7,
					fill: "#b2b2b2",
					rx: 1
				}),
				/* @__PURE__ */ S("rect", {
					width: 3.925,
					height: 4.4,
					x: 94.685,
					y: 3.629,
					fill: "#b2b2b2",
					rx: 1
				}),
				/* @__PURE__ */ S("rect", {
					width: 42.929,
					height: 21.519,
					x: 58.754,
					y: 14.613,
					fill: "currentColor",
					fillOpacity: .08,
					rx: 2
				}),
				/* @__PURE__ */ S("rect", {
					width: 28.369,
					height: 20.978,
					x: 26.143,
					y: 14.613,
					fill: "currentColor",
					fillOpacity: .08,
					rx: 2
				}),
				/* @__PURE__ */ S("rect", {
					width: 75.095,
					height: 21.654,
					x: 26.343,
					y: 39.688,
					fill: "currentColor",
					fillOpacity: .08,
					rx: 2
				}),
				/* @__PURE__ */ S("rect", {
					width: 5.474,
					height: 2.789,
					x: 1.798,
					y: 28.395,
					fill: "#e5e5e5",
					rx: 1.395
				}),
				/* @__PURE__ */ S("rect", {
					width: 5.474,
					height: 2.789,
					x: 1.641,
					y: 41.802,
					fill: "#e5e5e5",
					rx: 1.395
				}),
				/* @__PURE__ */ S("rect", {
					width: 5.474,
					height: 2.789,
					x: 1.641,
					y: 55.366,
					fill: "#e5e5e5",
					rx: 1.395
				}),
				/* @__PURE__ */ S("path", {
					fill: "#69b1ff",
					d: "M9.855-.026h12.493v65.721H9.855z"
				})
			]
		})]
	}), _u = _(gu);
})), yu, bu, xu, Su, Cu, wu, Tu, Eu, Du, Ou, ku, Au, ju = w((() => {
	zl(), Hl(), Gl(), Jl(), Zl(), eu(), ru(), ou(), lu(), fu(), hu(), vu(), yu = Rl, bu = Vl, xu = Wl, Su = ql, Cu = Xl, wu = $l, Tu = nu, Eu = au, Du = cu, Ou = du, ku = mu, Au = _u;
})), Mu, Nu, Pu = w((() => {
	Mu = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		viewBox: "0 0 24 24",
		width: "1em",
		height: "1em",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			fill: "currentColor",
			d: "M12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12S6.477 2 12 2m.16 14a6.98 6.98 0 0 0-5.147 2.256A7.97 7.97 0 0 0 12 20a7.97 7.97 0 0 0 5.167-1.892A6.98 6.98 0 0 0 12.16 16M12 4a8 8 0 0 0-6.384 12.821A8.98 8.98 0 0 1 12.16 14a8.97 8.97 0 0 1 6.362 2.634A8 8 0 0 0 12 4m0 1a4 4 0 1 1 0 8a4 4 0 0 1 0-8m0 2a2 2 0 1 0 0 4a2 2 0 0 0 0-4"
		})]
	}), Nu = _(Mu);
})), Fu, Iu, Lu = w((() => {
	Fu = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		viewBox: "0 0 24 24",
		width: "1em",
		height: "1em",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			fill: "currentColor",
			d: "M12 21.997c-5.523 0-10-4.477-10-10s4.477-10 10-10s10 4.477 10 10s-4.477 10-10 10m0-2v-16a8 8 0 0 0 0 16"
		})]
	}), Iu = _(Fu);
})), Ru, zu, Bu = w((() => {
	Ru = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		viewBox: "0 0 24 24",
		width: "1em",
		height: "1em",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			fill: "currentColor",
			d: "M18 7h4v2h-6V3h2zM8 9H2V7h4V3h2zm10 8v4h-2v-6h6v2zM8 15v6H6v-4H2v-2z"
		})]
	}), zu = _(Ru);
})), Vu, Hu, Uu = w((() => {
	Vu = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		viewBox: "0 0 24 24",
		width: "1em",
		height: "1em",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			fill: "currentColor",
			d: "M8 3v2H4v4H2V3zM2 21v-6h2v4h4v2zm20 0h-6v-2h4v-4h2zm0-12h-2V5h-4V3h6z"
		})]
	}), Hu = _(Vu);
})), Wu, Gu, Ku = w((() => {
	Wu = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		viewBox: "0 0 24 24",
		width: "1em",
		height: "1em",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			fill: "currentColor",
			d: "M22 14h-2V7.238l-7.928 7.1L4 7.216V19h10v2H3a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h18a1 1 0 0 1 1 1zM4.511 5l7.55 6.662L19.502 5zM19 22l-3.536-3.535l1.415-1.415L19 19.172l3.535-3.536l1.415 1.414z"
		})]
	}), Gu = _(Wu);
})), qu, Ju, Yu = w((() => {
	qu = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		viewBox: "0 0 24 24",
		width: "1em",
		height: "1em",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			fill: "currentColor",
			d: "M10 7a7 7 0 0 0 12 4.9v.1c0 5.523-4.477 10-10 10S2 17.523 2 12S6.477 2 12 2h.1A6.98 6.98 0 0 0 10 7m-6 5a8 8 0 0 0 15.062 3.762A9 9 0 0 1 8.238 4.938A8 8 0 0 0 4 12"
		})]
	}), Ju = _(qu);
})), Xu, Zu, Qu = w((() => {
	Xu = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		viewBox: "0 0 24 24",
		width: "1em",
		height: "1em",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			fill: "currentColor",
			d: "M12.001 13.5a1.5 1.5 0 1 1 0-3a1.5 1.5 0 0 1 0 3m-.528 2.994q.262.316.528.609q.266-.292.528-.609a25 25 0 0 1-1.056 0m-1.995-.125a21 21 0 0 1-2.285-.367q-.113.525-.17 1.015c-.19 1.583.075 2.545.478 2.777s1.368-.019 2.645-.974q.395-.296.794-.655a21 21 0 0 1-1.462-1.796m7.331-.367a21 21 0 0 1-2.285.367a21 21 0 0 1-1.462 1.796q.4.36.794.655c1.277.955 2.242 1.207 2.645.974c.403-.232.667-1.194.479-2.777a11 11 0 0 0-.17-1.015m1.45-.388c.577 2.639.274 4.74-1.008 5.48s-3.253-.048-5.25-1.867c-1.997 1.819-3.968 2.606-5.25 1.866s-1.585-2.84-1.009-5.48C3.168 14.794 1.501 13.48 1.501 12s1.667-2.793 4.241-3.613c-.576-2.64-.273-4.74 1.009-5.48s3.253.047 5.25 1.866c1.997-1.819 3.968-2.606 5.25-1.866s1.585 2.84 1.009 5.48c2.573.82 4.24 2.133 4.24 3.613s-1.668 2.794-4.241 3.614m-7.32-9.779q-.398-.359-.793-.655C8.869 4.225 7.904 3.973 7.5 4.206c-.403.232-.667 1.194-.479 2.778q.06.49.17 1.015a21 21 0 0 1 2.286-.368q.714-.981 1.462-1.796m3.585 1.796a21 21 0 0 1 2.285.368q.113-.526.17-1.015c.19-1.584-.075-2.546-.478-2.778s-1.368.019-2.645.974q-.395.296-.794.655q.748.815 1.462 1.796m-1.995-.125q-.262-.316-.528-.609q-.265.293-.528.609a25 25 0 0 1 1.056 0m-4.156 7.198a25 25 0 0 1-.528-.914q-.143.385-.263.762q.386.083.79.152m1.932.234a23 23 0 0 0 3.392 0A23 23 0 0 0 15.393 12a23 23 0 0 0-1.696-2.938a23 23 0 0 0-3.392 0A23 23 0 0 0 8.609 12a23 23 0 0 0 1.696 2.938m5.852-4.728q.143-.385.263-.761a18 18 0 0 0-.79-.153a25 25 0 0 1 .527.914M6.131 9.837q-.51.165-.964.36c-1.465.628-2.166 1.338-2.166 1.803s.7 1.175 2.166 1.803q.454.195.964.36c.222-.7.497-1.426.825-2.163a21 21 0 0 1-.825-2.163m1.45-.388q.121.375.264.76a25 25 0 0 1 .528-.913q-.405.069-.791.153m10.29 4.714q.51-.165.964-.36C20.3 13.175 21 12.465 21 12s-.7-1.175-2.166-1.803q-.454-.195-.965-.36c-.22.7-.496 1.426-.824 2.163c.328.737.603 1.463.825 2.163m-1.45.389q-.122-.377-.264-.762a25 25 0 0 1-.528.914q.405-.07.791-.152"
		})]
	}), Zu = _(Xu);
})), $u, ed, td = w((() => {
	$u = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		viewBox: "0 0 24 24",
		width: "1em",
		height: "1em",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			fill: "currentColor",
			d: "M12 18a6 6 0 1 1 0-12a6 6 0 0 1 0 12m0-2a4 4 0 1 0 0-8a4 4 0 0 0 0 8M11 1h2v3h-2zm0 19h2v3h-2zM3.515 4.929l1.414-1.414L7.05 5.636L5.636 7.05zM16.95 18.364l1.414-1.414l2.121 2.121l-1.414 1.414zm2.121-14.85l1.414 1.415l-2.121 2.121l-1.414-1.414zM5.636 16.95l1.414 1.414l-2.121 2.121l-1.414-1.414zM23 11v2h-3v-2zM4 11v2H1v-2z"
		})]
	}), ed = _($u);
})), nd, rd, id = w((() => {
	nd = ({ title: e, titleId: t, ...n }, r) => /* @__PURE__ */ C("svg", {
		viewBox: "0 0 24 24",
		width: "1em",
		height: "1em",
		ref: r,
		"aria-labelledby": t,
		...n,
		children: [e ? /* @__PURE__ */ S("title", {
			id: t,
			children: e
		}) : null, /* @__PURE__ */ S("path", {
			fill: "currentColor",
			d: "M12 14v2a6 6 0 0 0-6 6H4a8 8 0 0 1 8-8m0-1c-3.315 0-6-2.685-6-6s2.685-6 6-6s6 2.685 6 6s-2.685 6-6 6m0-2c2.21 0 4-1.79 4-4s-1.79-4-4-4s-4 1.79-4 4s1.79 4 4 4m2.595 7.811a3.5 3.5 0 0 1 0-1.622l-.992-.573l1-1.732l.992.573A3.5 3.5 0 0 1 17 14.645V13.5h2v1.145c.532.158 1.012.44 1.405.812l.992-.573l1 1.732l-.991.573a3.5 3.5 0 0 1 0 1.622l.991.573l-1 1.732l-.992-.573a3.5 3.5 0 0 1-1.405.812V22.5h-2v-1.145a3.5 3.5 0 0 1-1.405-.812l-.992.573l-1-1.732zM18 19.5a1.5 1.5 0 1 0 0-3a1.5 1.5 0 0 0 0 3"
		})]
	}), rd = _(nd);
})), ad, od, sd, cd, ld, ud, dd, fd, pd, md = w((() => {
	Pu(), Lu(), Bu(), Uu(), Ku(), Yu(), Qu(), td(), id(), ad = Nu, od = Iu, sd = zu, cd = Hu, ld = Gu, ud = Ju, dd = Zu, fd = ed, pd = rd;
})), hd, gd = w((() => {
	ju(), md(), hd = {
		EmbeddedIcon: yu,
		HomeOutlined: _e,
		SafetyOutlined: ke,
		CloudOutlined: oe,
		FileTextOutlined: me,
		LockOutlined: ye,
		EyeOutlined: pe,
		NodeExpandOutlined: we,
		SisternodeOutlined: Me,
		SubnodeOutlined: Ne,
		OutsidePageIcon: Tu,
		AntDesignOutlined: h,
		ContainerOutlined: se,
		ExternalIcon: bu,
		RiReactjsLine: dd,
		SettingOutlined: je,
		UserOutlined: Re,
		TeamOutlined: Fe,
		MenuOutlined: Se,
		ApartmentOutlined: g,
		RiAccountCircleLine: ad,
		ProfileCardIcon: Eu,
		RiUserSettingsLine: pd,
		CopyrightOutlined: le
	};
})), _d = w((() => {
	ju(), gd(), md();
}));
//#endregion
//#region src/hooks/use-layout-menu/index.tsx
function vd(e) {
	return [
		{
			icon: /* @__PURE__ */ S(Su, {}),
			label: e("authority.layout.alignLeft"),
			key: "layout-left"
		},
		{
			icon: /* @__PURE__ */ S(xu, {}),
			label: e("authority.layout.alignCenter"),
			key: "layout-center"
		},
		{
			icon: /* @__PURE__ */ S(Cu, {}),
			label: e("authority.layout.alignRight"),
			key: "layout-right"
		}
	];
}
function yd() {
	let { t: e } = b(), t = E((e) => e.pageLayout), n = E((e) => e.setPreferences);
	function r(e) {
		n({ pageLayout: e });
	}
	let i = ({ key: e }) => {
		r(e);
	}, a = vd(e);
	return {
		pageLayout: t,
		setPageLayout: r,
		layoutButtonTrigger: /* @__PURE__ */ S($e, {
			menu: {
				items: a,
				selectable: !0,
				onClick: i,
				selectedKeys: [t]
			},
			trigger: ["click"],
			arrow: !1,
			placement: "bottom",
			children: /* @__PURE__ */ S(Ke, {
				size: "large",
				type: "text",
				icon: a.find((e) => e.key === t)?.icon
			})
		})
	};
}
var bd = w((() => {
	_d(), D();
}));
//#endregion
//#region src/utils/cn/index.ts
function O(...e) {
	return Ht(Vt(e));
}
var k = w((() => {}));
//#endregion
//#region src/layout/layout-footer/index.tsx
function xd({ className: e }) {
	let { enableFooter: t, companyName: n, companyWebsite: r, copyrightDate: i, ICPNumber: a, ICPLink: o } = E();
	return t ? /* @__PURE__ */ C("footer", {
		className: O("h-10 flex flex-wrap shrink-0 items-center justify-center text-xs md:text-sm text-colorTextSecondary", e),
		children: [
			a ? /* @__PURE__ */ C("span", { children: [/* @__PURE__ */ S("a", {
				href: o,
				rel: "noreferrer noopener",
				target: "_blank",
				children: a
			}), "\xA0"] }) : null,
			"Copyright ©\xA0",
			i,
			i ? /* @__PURE__ */ S(x, { children: "\xA0" }) : "",
			n ? /* @__PURE__ */ S("span", { children: /* @__PURE__ */ C("a", {
				href: r,
				rel: "noreferrer noopener",
				target: "_blank",
				children: [n, "\xA0"]
			}) }) : null,
			"All right reserved"
		]
	}) : null;
}
var Sd = w((() => {
	D(), k();
}));
//#endregion
//#region src/components/basic-button/index.tsx
function Cd(e) {
	let { children: t, ...n } = e, r = { ...n };
	return /* @__PURE__ */ S(Ke, {
		type: "primary",
		...r,
		children: t
	});
}
var wd = w((() => {}));
//#endregion
//#region src/hooks/use-language/index.ts
function Td() {
	let { i18n: e } = b(), { changeLanguage: t } = E(), n = Pt(async (n) => {
		t(n), await e.changeLanguage(n);
	}, [t, e]);
	return y(() => ({
		language: e.language,
		setLanguage: n
	}), [n, e.language]);
}
var Ed = w((() => {
	D();
})), Dd, Od = w((() => {
	Dd = () => [{
		label: "简体中文",
		key: "zh-CN",
		value: "zh-CN"
	}, {
		label: "English",
		key: "en-US",
		value: "en-US"
	}];
}));
//#endregion
//#region src/layout/layout-header/components/language-button.tsx
function kd({ ...e }) {
	let { language: t, setLanguage: n } = Td(), r = Dd();
	return /* @__PURE__ */ S($e, {
		menu: {
			items: r,
			onClick: ({ key: e }) => {
				n(e);
			},
			selectable: !0,
			selectedKeys: [t]
		},
		trigger: ["click"],
		arrow: !1,
		placement: "bottom",
		children: /* @__PURE__ */ S(Cd, {
			type: "text",
			...e,
			children: /* @__PURE__ */ S(Ie, {})
		})
	});
}
var Ad = w((() => {
	wd(), Ed(), Od();
}));
//#endregion
//#region src/layout/layout-header/components/theme-button.tsx
function jd() {
	if (Nd) {
		let e = "theme-switch-view-transition-styles";
		if (!document.getElementById(e)) {
			let t = document.createElement("style");
			t.id = e, t.textContent = "\n        html.stop-transition * {\n          transition: none !important;\n        }\n        ::view-transition-old(root),\n        ::view-transition-new(root) {\n          animation: none;\n          mix-blend-mode: normal;\n        }\n        ::view-transition-old(root),\n        .dark::view-transition-new(root) {\n          z-index: 999999999;\n        }\n        ::view-transition-new(root),\n        .dark::view-transition-old(root) {\n          z-index: 1;\n        }\n      ", document.head.appendChild(t);
		}
	}
}
function Md({ ...e }) {
	let { isDark: t, changeSiteTheme: n } = Dr();
	v(() => {
		jd();
	}, []);
	function r(e) {
		if (!(document.startViewTransition && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) || !e) {
			n(t ? "light" : "dark");
			return;
		}
		let r = e.clientX, i = e.clientY, a = Math.hypot(Math.max(r, innerWidth - r), Math.max(i, innerHeight - i));
		document.startViewTransition(() => {
			Ut(() => {
				n(t ? "light" : "dark");
			});
		}).ready.then(() => {
			let e = [`circle(0px at ${r}px ${i}px)`, `circle(${a}px at ${r}px ${i}px)`];
			document.documentElement.animate({ clipPath: t ? [...e].reverse() : e }, {
				duration: 500,
				easing: "ease-in",
				fill: "forwards",
				pseudoElement: t ? "::view-transition-old(root)" : "::view-transition-new(root)"
			});
		});
	}
	return /* @__PURE__ */ S(Cd, {
		type: "text",
		...e,
		icon: S(t ? fd : ud, {}),
		onPointerDown: (t) => {
			e?.onPointerDown?.(t), r(t);
		}
	});
}
var Nd, Pd = w((() => {
	wd(), Or(), _d(), Nd = typeof window < "u";
}));
//#endregion
//#region src/layout/fullscreen-layout/index.tsx
function Fd() {
	let { isDark: e } = Dr(), { token: t } = Et.useToken(), { t: n } = b(), r = rt.useBreakpoint(), { pageLayout: i, layoutButtonTrigger: o } = yd(), s = y(() => i === "layout-left", [i]), c = y(() => i === "layout-center", [i]);
	return /* @__PURE__ */ C("div", {
		style: { backgroundColor: t.colorBgContainer },
		children: [/* @__PURE__ */ C("header", {
			className: "z-10 absolute flex items-center right-3 top-3 left-3",
			children: [/* @__PURE__ */ C("div", {
				className: "text-colorText flex flex-1 items-center",
				children: [/* @__PURE__ */ S("img", {
					alt: "App Logo",
					src: Fl,
					className: "mr-2 w-11"
				}), /* @__PURE__ */ S("h1", {
					className: "m-0 text-xl font-medium",
					children: "React Antd Admin"
				})]
			}), /* @__PURE__ */ C("div", {
				className: "flex items-center",
				children: [
					o,
					/* @__PURE__ */ S(Md, { size: "large" }),
					/* @__PURE__ */ S(kd, {
						size: "large",
						className: "px-2.75"
					})
				]
			})]
		}), /* @__PURE__ */ S("div", {
			className: "flex items-center overflow-hidden h-full",
			children: /* @__PURE__ */ C(dt, {
				className: Vt("h-screen w-full", { "flex-row-reverse": s }),
				children: [/* @__PURE__ */ S(Je, {
					xs: 0,
					sm: 0,
					lg: 15,
					style: { backgroundImage: `radial-gradient(${t.colorBgContainer}, ${e ? t.colorBgBlur : t.colorPrimaryBg})` },
					className: Vt({ hidden: c }),
					children: /* @__PURE__ */ C("div", {
						className: "flex flex-col items-center justify-center h-full gap-3",
						children: [
							/* @__PURE__ */ S("img", {
								alt: "",
								src: Nl,
								className: "h-64 motion-safe:animate-bounce-in-down-out-up"
							}),
							/* @__PURE__ */ S("div", {
								className: "text-xl text-colorTextSecondary mt-6 font-sans lg:text-2xl",
								children: n("authority.pageTitle")
							}),
							/* @__PURE__ */ S("div", {
								className: "text-colorTextTertiary mt-2",
								children: n("authority.pageDescription")
							})
						]
					})
				}), /* @__PURE__ */ C(Je, {
					xs: 24,
					sm: 24,
					lg: c ? 24 : 9,
					className: "relative flex flex-col justify-center px-6 py-10 xl:px-8",
					style: c || !r.xl && !r.xxl && !r.lg ? { backgroundImage: `radial-gradient(${t.colorBgContainer}, ${t.colorPrimaryBg})` } : {},
					children: [/* @__PURE__ */ S(xd, { className: "w-full absolute bottom-3 left-1/2 -translate-x-1/2" }), /* @__PURE__ */ S("div", {
						className: "w-full sm:mx-auto md:max-w-md",
						children: /* @__PURE__ */ S(a, {})
					})]
				})]
			})
		})]
	});
}
var Id = w((() => {
	Pl(), Il(), bd(), Or(), Sd(), Ad(), Pd();
}));
//#endregion
//#region src/utils/get-redirect-path.ts
function Ld(e) {
	let t = new URLSearchParams(e).get("redirect");
	return t?.startsWith("/") && !t.startsWith("//") ? t : "/home";
}
var Rd = w((() => {})), zd = /* @__PURE__ */ T({ default: () => Bd });
function Bd() {
	let [e, t] = It(!1), { t: n } = b(), [r] = f(), i = u(), a = mv((e) => e.login);
	return /* @__PURE__ */ C("div", {
		className: "w-full max-w-90 mx-auto",
		children: [/* @__PURE__ */ S("h2", {
			className: "text-colorText mb-6 text-3xl font-bold tracking-tight",
			children: n("authority.welcomeBack")
		}), /* @__PURE__ */ C(nt, {
			name: "builtinLoginForm",
			layout: "vertical",
			initialValues: Vd,
			onFinish: async (e) => {
				t(!0), a(e).then(() => {
					i(Ld(r));
				}).catch(() => {}).finally(() => {
					t(!1);
				});
			},
			children: [
				/* @__PURE__ */ S(nt.Item, {
					label: n("authority.username"),
					name: "username",
					rules: [{
						required: !0,
						message: n("form.username.required")
					}],
					children: /* @__PURE__ */ S(it, {
						autoFocus: !0,
						placeholder: n("form.username.required")
					})
				}),
				/* @__PURE__ */ S(nt.Item, {
					label: n("authority.password"),
					name: "password",
					rules: [{
						required: !0,
						message: n("form.password.required")
					}],
					children: /* @__PURE__ */ S(it.Password, { placeholder: n("form.password.required") })
				}),
				/* @__PURE__ */ S(nt.Item, { children: /* @__PURE__ */ S(Ke, {
					block: !0,
					type: "primary",
					htmlType: "submit",
					loading: e,
					children: n("authority.login")
				}) })
			]
		})]
	});
}
var Vd, Hd = w((() => {
	hv(), Rd(), Vd = {
		username: "admin",
		password: "123456789admin"
	};
})), Ud, Wd, Gd = w((() => {
	Id(), sl(), Jn(), Ud = Mt(() => Promise.resolve().then(() => (Hd(), zd))), Wd = [{
		path: Hn,
		Component: Fd,
		handle: {
			layout: "fullscreen",
			login: !0,
			internal: !0,
			hideInMenu: !0,
			title: el("authority.login")
		},
		children: [{
			index: !0,
			Component: Ud,
			handle: { title: el("authority.login") }
		}]
	}];
})), Kd = /* @__PURE__ */ T({
	NotFound: () => qd,
	default: () => qd
});
function qd() {
	let { t: e } = b(), t = u();
	return /* @__PURE__ */ S(ut, {
		status: "404",
		title: e("exception.notFoundTitle"),
		subTitle: e("exception.notFoundSubTitle"),
		extra: /* @__PURE__ */ S(Ke, {
			icon: /* @__PURE__ */ S(ne, {}),
			type: "primary",
			onClick: () => {
				t(Jd);
			},
			children: e("common.backHome")
		})
	});
}
var Jd, Yd = w((() => {
	({VITE_BASE_HOME_PATH: Jd} = { VITE_BASE_HOME_PATH: "/home" });
})), Xd, Zd = w((() => {
	Xd = [{
		path: "*",
		id: "404",
		Component: Mt(() => Promise.resolve().then(() => (Yd(), Kd))),
		handle: {
			title: "404",
			hideInMenu: !0
		}
	}];
})), Qd, $d = w((() => {
	Tl(), Gd(), Zd(), Qd = [...wl([...Wd]), ...Xd];
})), ef, tf, nf, rf, af, of, sf, cf = w((() => {
	ml(), xl(), Jn(), Cl(), Dl(), Ml(), $d(), ef = /* #__PURE__ */ Object.assign({
		"./external/privacy-policy.ts": dl,
		"./external/terms-of-service.ts": vl
	}), tf = /* #__PURE__ */ Object.assign({}), nf = El(ef), rf = El(tf), af = Sl([...Qd, ...nf]), of = [...rf], sf = [Hn, ...kl(nf, (e) => e.path)];
}));
//#endregion
//#region src/store/auth-provider.ts
function lf(e, t) {
	if (ff) {
		console.warn(`[auth] 重复的认证 provider 忽略：已由模块 "${ff.moduleName}" 提供，忽略 "${e}"（先到先得，与 login 路由去重同一规则）。`);
		return;
	}
	ff = {
		moduleName: e,
		provider: t
	};
}
function uf() {
	return ff?.provider;
}
function df(e) {
	ff?.moduleName === e && (ff = void 0);
}
var ff, pf = w((() => {}));
//#endregion
//#region src/utils/is/index.ts
function mf(e) {
	return typeof e == "number" && Number.isFinite(e);
}
function hf(e) {
	return typeof e == "string";
}
function gf(e) {
	return typeof e == "object" && !!e;
}
function _f(e) {
	return e === void 0;
}
var vf = w((() => {}));
//#endregion
//#region src/utils/static-antd/index.ts
function yf() {
	let e = He.useApp();
	return bf = e.message, xf = e.notification, Cf = e.modal, window.$message = bf, window.$modal = Cf, window.$notification = xf, null;
}
var bf, xf, Sf, Cf, wf = w((() => {
	bf = wt, xf = Tt, {...Sf} = ct, Cf = Sf;
}));
//#endregion
//#region src/utils/request/must-change.tsx
function Tf(e) {
	if (gf(e)) {
		let t = e;
		return t.code === "must_change" || (t.msg ?? "").includes("password change required");
	}
	return !1;
}
function Ef() {
	Df || location.pathname.endsWith("/change-password") || (Df = !0, Cf.confirm({
		title: "需要修改密码",
		icon: /* @__PURE__ */ S(fe, {}),
		content: "出于安全策略，当前账号要求首次登录后修改密码。请先完成密码修改，再继续使用系统功能。",
		okText: "去修改密码",
		closable: !1,
		maskClosable: !1,
		cancelButtonProps: { style: { display: "none" } },
		onOk: () => {
			window.location.href = `${Ln()}change-password`;
		},
		afterClose: () => {
			Df = !1;
		}
	}));
}
var Df, Of = w((() => {
	vf(), Bn(), wf(), Df = !1;
})), kf, Af, jf = w((() => {
	sr(), pf(), Of(), kf = {
		id: "",
		avatar: "",
		username: "",
		displayName: "",
		email: "",
		phoneNumber: "",
		description: "",
		roles: []
	}, Af = t()((e) => ({
		...kf,
		getUserInfo: async () => {
			let t = uf(), n = t ? await t.getUserInfo() : await ar();
			return e({ ...n }), (n.must_change === !0 || n.mustChange === !0) && Ef(), n;
		},
		reset: () => e({ ...kf })
	}));
})), Mf = w((() => {
	Wt.configure({
		easing: "ease",
		speed: 500,
		showSpinner: !1,
		trickleSpeed: 200,
		minimum: .3
	});
}));
//#endregion
//#region src/utils/toggle-html-class/index.ts
function Nf(e) {
	function t() {
		document.documentElement.classList.add(e);
	}
	function n() {
		document.documentElement.classList.remove(e);
	}
	return {
		add: t,
		remove: n
	};
}
var Pf = w((() => {}));
//#endregion
//#region src/layout/layout-effects/index.tsx
function Ff() {
	let e = l(), { t, i18n: n } = b(), r = c(), { language: i, isDark: a, enableDynamicTitle: o } = Dr(), s = mv((e) => !!e.token), u = Af((e) => !!e.id);
	return v(() => {
		n.language !== i && n.changeLanguage(i);
	}, [i, n]), v(() => {
		if (o && !(!sf.includes(r.pathname) && s && !u)) {
			let n = e[e.length - 1].handle?.title, r = hf(n) ? n : n?.props?.children;
			document.title = t(r) || document.title;
		}
	}, [
		o,
		i,
		r,
		e,
		s,
		u,
		t
	]), v(() => {
		a ? Nf("dark").add() : Nf("dark").remove();
	}, [a]), v(() => {
		Wt.done();
	}, [r.pathname]), null;
}
var If = w((() => {
	Or(), cf(), hv(), jf(), vf(), Mf(), Pf();
}));
//#endregion
//#region src/hooks/use-current-route/index.ts
function Lf() {
	let e = l();
	return y(() => e[e.length - 1], [e]);
}
var Rf = w((() => {}));
//#endregion
//#region src/layout/layout-registry.ts
function zf(e, t, n) {
	let r = Hf.get(t);
	if (r) {
		console.warn(`[layout] 重复的布局名 "${t}" 忽略：已由模块 "${r.moduleName}" 提供，忽略 "${e}"（先到先得）。`);
		return;
	}
	Hf.set(t, {
		moduleName: e,
		component: n
	});
}
function Bf(e) {
	return Hf.get(e)?.component;
}
function Vf(e) {
	for (let [t, n] of Hf) n.moduleName === e && Hf.delete(t);
}
var Hf, Uf = w((() => {
	Hf = /* @__PURE__ */ new Map();
}));
//#endregion
//#region src/components/jss-theme-provider/index.tsx
function Wf({ children: e }) {
	let t = Nt(Xe.ConfigContext).getPrefixCls(), { token: n } = Gf(), { theme: r, isDark: i, isLight: a } = Dr();
	return /* @__PURE__ */ S(Gt, {
		theme: {
			token: n,
			theme: r,
			isDark: i,
			isLight: a,
			prefixCls: t
		},
		children: e
	});
}
var Gf, Kf = w((() => {
	Or(), {useToken: Gf} = Et;
}));
//#endregion
//#region src/hooks/use-device-type/index.ts
function qf() {
	let e = Zt();
	return {
		isMobile: e.xs && !e.sm || e.sm && !e.md,
		isIpad: e.md && !e.xl,
		isPC: e.xl
	};
}
var Jf = w((() => {}));
//#endregion
//#region src/hooks/use-css-var/index.ts
function Yf(e, t = Xf, n = {}) {
	let r = y(() => ({
		set: (n) => t.style.setProperty(e, n),
		get: () => t.style.getPropertyValue(e),
		remove: () => t.style.removeProperty(e)
	}), [e, t]);
	return v(() => {
		n?.initialValue && r.set(n.initialValue);
	}, [n?.initialValue, r]), v(() => () => r.remove(), [r]), r;
}
var Xf, Zf = w((() => {
	Xf = typeof document < "u" ? document.body : void 0;
})), Qf, $f, ep, tp, np, rp, ip = w((() => {
	Qf = "react-antd-admin", $f = `__${Qf}_main_content`, ep = `--${Qf}-content-height`, tp = `--${Qf}-content-width`, np = `--${Qf}-header-height`, rp = `--${Qf}-footer-height`;
}));
//#endregion
//#region src/utils/dom/index.ts
function ap(e) {
	if (!e) return {
		bottom: 0,
		height: 0,
		left: 0,
		right: 0,
		top: 0,
		width: 0
	};
	let t = e.getBoundingClientRect(), n = Math.max(document.documentElement.clientHeight, window.innerHeight), r = Math.max(t.top, 0), i = Math.min(t.bottom, n), a = Math.max(document.documentElement.clientWidth, window.innerWidth), o = Math.max(t.left, 0), s = Math.min(t.right, a);
	return {
		bottom: i,
		height: Math.max(0, i - r),
		left: o,
		right: s,
		top: r,
		width: Math.max(0, s - o)
	};
}
var op = w((() => {}));
//#endregion
//#region src/hooks/use-layout-style/index.ts
function sp() {
	let e = Ft(null), [t, n] = It(null), r = Ft(null), i = Yf(ep), a = Yf(tp), o = y(() => {
		let { height: e, left: n, top: r, width: i } = t || {};
		return {
			height: `${e}px`,
			left: `${n}px`,
			position: "fixed",
			top: `${r}px`,
			width: `${i}px`,
			zIndex: 150
		};
	}, [t]), s = qt((t) => {
		let r = ap(e.current);
		n(r), r && (i.set(`${r.height}px`), a.set(`${r.width}px`));
	}, { wait: 16 });
	return v(() => {
		if (e.current && !r.current) {
			let t = new ResizeObserver(s.run);
			r.current = t, t.observe(e.current);
		}
		return () => {
			r.current?.disconnect(), r.current = null;
		};
	}, [s]), {
		contentElementRef: e,
		overlayStyle: o,
		visibleDomRect: t
	};
}
function cp() {
	let e = Yf(np);
	return {
		getLayoutHeaderHeight: () => Number.parseInt(`${e.get()}`, 10),
		setLayoutHeaderHeight: (t) => {
			e.set(`${t}px`);
		}
	};
}
function lp() {
	let e = Yf(rp);
	return {
		getLayoutFooterHeight: () => Number.parseInt(`${e.get()}`, 10),
		setLayoutFooterHeight: (t) => {
			e.set(`${t}px`);
		}
	};
}
var up = w((() => {
	Zf(), ip(), op();
})), dp, fp, pp, mp = w((() => {
	D(), vr(), dp = {
		openTabs: /* @__PURE__ */ new Map([]),
		activeKey: "",
		isRefresh: !1,
		isMaximize: !1
	}, fp = /* @__PURE__ */ new Set(), pp = t()(n((e, t) => {
		let n = async (e) => {
			for (let n of e) {
				let e = t().openTabs.get(n)?.beforeClose;
				if (e == null) continue;
				let r = Array.isArray(e) ? e : [e];
				for (let e of r) try {
					if (!await e()) return !1;
				} catch (e) {
					return console.error("[tabs] beforeClose 守卫抛错，按中止关闭处理", e), !1;
				}
			}
			return !0;
		}, r = async (t, r) => {
			if (t.length !== 0) {
				for (let e of t) fp.add(e);
				try {
					if (!await n(t)) return;
					e((e) => {
						let n = new Set(t), i = new Map([...e.openTabs].filter(([e]) => !n.has(e)));
						if (i.size === e.openTabs.size) return e;
						let a = [...i.keys()];
						return {
							openTabs: i,
							activeKey: n.has(e.activeKey) || !i.has(e.activeKey) ? r(a) : e.activeKey
						};
					});
				} finally {
					for (let e of t) fp.delete(e);
				}
			}
		};
		return {
			...dp,
			setIsRefresh: (t) => {
				e({ isRefresh: t });
			},
			setActiveKey: (t) => {
				e({ activeKey: t });
			},
			insertBeforeTab: (t, n) => {
				e((e) => {
					if (t?.length) {
						let r = /* @__PURE__ */ new Map([[t, n]]);
						for (let [t, n] of e.openTabs) r.set(t, n);
						return { openTabs: r };
					}
					return e;
				});
			},
			addTab: (t, n) => {
				e((e) => {
					if (t?.length) {
						let r = new Map(e.openTabs), i = r.get(t), a = {
							...i,
							...n
						};
						return n.beforeClose === null ? a.beforeClose = void 0 : i?.beforeClose != null && n.beforeClose !== void 0 && (a.beforeClose = [...Array.isArray(i.beforeClose) ? i.beforeClose : [i.beforeClose], ...Array.isArray(n.beforeClose) ? n.beforeClose : [n.beforeClose]].filter((e, t, n) => n.indexOf(e) === t)), r.set(t, a), { openTabs: r };
					}
					return e;
				});
			},
			removeTab: async (e) => {
				let t = "/home";
				!e?.length || e === t || fp.has(e) || await r([e], (e) => e.at(-1) ?? t);
			},
			closeRightTabs: async (e) => {
				if (fp.has(e)) return;
				let n = [...t().openTabs.keys()], i = n.indexOf(e);
				i < 0 || await r(n.slice(i + 1), () => e);
			},
			closeLeftTabs: async (e) => {
				if (fp.has(e)) return;
				let n = [...t().openTabs.keys()], i = n.indexOf(e);
				i < 0 || await r(n.slice(0, i).filter((e) => e !== "/home"), () => e);
			},
			closeOtherTabs: async (e) => {
				fp.has(e) || await r([...t().openTabs.keys()].filter((t) => t !== "/home" && t !== e), () => e);
			},
			closeAllTabs: async () => {
				let e = "/home";
				await r([...t().openTabs.keys()].filter((t) => t !== e), () => e);
			},
			changeTabOrder: (t, n) => {
				e((e) => {
					let r = Array.from(e.openTabs.entries()), [i] = r.splice(t, 1);
					return r.splice(n, 0, i), { openTabs: new Map(r) };
				});
			},
			toggleMaximize: (t) => {
				e({ isMaximize: t });
			},
			setTableTitle: (t, n) => {
				e((e) => {
					let r = new Map(e.openTabs), i = r.get(t);
					return i ? (i.newTabTitle = n, r.set(t, i), { openTabs: r }) : e;
				});
			},
			resetTableTitle: (t) => {
				e((e) => {
					let n = new Map(e.openTabs), r = n.get(t);
					return r ? (delete r.newTabTitle, n.set(t, r), { openTabs: n }) : e;
				});
			},
			resetTabs: () => {
				e(() => ({ ...dp }));
			}
		};
	}, {
		name: _r("tabbar"),
		partialize: (e) => Object.fromEntries(Object.entries(e).filter(([e]) => !["activeKey"].includes(e))),
		storage: {
			getItem: (e) => {
				let t = sessionStorage.getItem(e), n = E.getState().tabbarPersist;
				if (!t || !n) return null;
				let r = JSON.parse(t);
				return {
					...r,
					state: {
						...r.state,
						openTabs: new Map(r.state.openTabs)
					}
				};
			},
			setItem: (e, t) => {
				let n = JSON.stringify({
					...t,
					state: {
						...t.state,
						openTabs: Array.from(t.state.openTabs.entries())
					}
				});
				sessionStorage.setItem(e, n);
			},
			removeItem: (e) => sessionStorage.removeItem(e)
		}
	}));
}));
//#endregion
//#region src/layout/hooks/use-layout.ts
function hp() {
	let { isMobile: e } = qf(), t = E((e) => e.navigationStyle), n = E((e) => e.sidebarWidth), r = E((e) => e.sideCollapsedWidth), i = E((e) => e.firstColumnWidthInTwoColumnNavigation), a = y(() => e ? ur : t, [e, t]), o = y(() => a === ur, [a]), s = y(() => a === dr, [a]), c = y(() => a === fr, [a]);
	return {
		currentLayout: a,
		isSideNav: o,
		isTopNav: s,
		isMixedNav: y(() => a === pr, [a]),
		isTwoColumnNav: c,
		sidebarWidth: n,
		sideCollapsedWidth: r,
		firstColumnWidthInTwoColumnNavigation: i
	};
}
var gp = w((() => {
	Jf(), mr(), D();
})), _p = w((() => {
	gp();
})), vp, yp, bp = w((() => {
	vp = { globalSpin: !1 }, yp = t((e) => ({
		...vp,
		openGlobalSpin: () => e({ globalSpin: !0 }),
		closeGlobalSpin: () => e({ globalSpin: !1 })
	}));
}));
//#endregion
//#region src/components/global-spin/index.tsx
function xp({ children: e, className: t }) {
	let n = Sp(), r = yp((e) => e.globalSpin), i = en(r, {
		delay: 500,
		minDuration: 200
	});
	return E((e) => e.transitionLoading) ? /* @__PURE__ */ S(ht, {
		delay: 300,
		spinning: i,
		classNames: { root: O(n.rootSpin, t) },
		children: e
	}) : e;
}
var Sp, Cp = w((() => {
	bp(), D(), k(), Sp = Kt({ rootSpin: {
		height: "100%",
		"& .ant-spin-container": { height: "100%" },
		"& .ant-spin-spinning": { maxHeight: "100% !important" }
	} });
}));
//#endregion
//#region src/components/scrollbar/index.tsx
function wp({ ref: e, children: t, ...n }) {
	return /* @__PURE__ */ S(tn, {
		autoHide: !0,
		scrollableNodeProps: { ref: e },
		clickOnTrack: !1,
		...n,
		className: O("h-full", n.className),
		children: t
	});
}
var Tp = w((() => {
	k();
}));
//#endregion
//#region src/layout/keep-alive-layer/index.tsx
function Ep() {
	let { pathname: e, search: t } = c(), n = d(), r = an(), i = pp((e) => e.isRefresh), a = pp((e) => e.openTabs), o = E((e) => e.tabbarEnable), s = E((e) => e.transitionName), l = E((e) => e.transitionEnable), u = y(() => e + t, [e, t]);
	v(() => {
		(r.current?.getCacheNodes?.())?.forEach((e) => {
			a.has(e.cacheKey) || r.current?.destroy(e.cacheKey);
		});
	}, [a, r]), v(() => {
		o || (r.current?.getCacheNodes?.())?.forEach((e) => {
			e.cacheKey !== u && r.current?.destroy(e.cacheKey);
		});
	}, [
		o,
		r,
		u
	]), v(() => {
		o && i && r.current?.refresh();
	}, [
		i,
		r,
		o
	]);
	let f = y(() => o ? Hg() : Ug(), [o]);
	return /* @__PURE__ */ S(nn, {
		max: 20,
		transition: !0,
		duration: 300,
		cacheNodeClassName: l ? `keepalive-${s}` : void 0,
		exclude: f,
		activeCacheKey: u,
		aliveRef: r,
		children: n
	});
}
var Dp = w((() => {
	qg(), D(), mp();
}));
//#endregion
//#region src/layout/layout-content/index.tsx
function Op() {
	let { token: { colorBgLayout: e } } = Et.useToken(), { contentElementRef: t } = sp(), n = E((e) => e.enableFooter), r = E((e) => e.fixedFooter);
	return /* @__PURE__ */ S("main", {
		id: $f,
		ref: t,
		className: "relative overflow-y-auto overflow-x-hidden grow",
		style: { backgroundColor: e },
		children: /* @__PURE__ */ S(wp, { children: /* @__PURE__ */ S(xp, { children: /* @__PURE__ */ C("div", {
			className: "flex flex-col h-full",
			children: [/* @__PURE__ */ S("div", {
				style: { height: `var(${ep})` },
				children: /* @__PURE__ */ S(Ep, {})
			}), n && !r ? /* @__PURE__ */ S(xd, {}) : null]
		}) }) })
	});
}
var kp = w((() => {
	Cp(), Tp(), up(), ip(), Dp(), Sd(), D();
}));
//#endregion
//#region src/layout/widgets/global-search/components/search-footer.tsx
function Ap({ searchItems: e }) {
	let { t } = b();
	return /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S(Ze, { className: "mt-2 my-0" }), /* @__PURE__ */ C("div", {
		className: "px-4 py-2 flex items-center justify-between text-xs",
		children: [/* @__PURE__ */ C("div", {
			className: "flex items-center",
			children: [
				/* @__PURE__ */ S("span", {
					className: "flex items-center justify-center p-1 h-5 rounded-md bg-[#F3F4F5] dark:bg-[#26313C]",
					children: /* @__PURE__ */ S(re, {})
				}),
				/* @__PURE__ */ S("span", {
					className: "flex items-center justify-center p-1 h-5 rounded-md bg-[#F3F4F5] dark:bg-[#26313C] ml-2",
					children: /* @__PURE__ */ S(te, {})
				}),
				/* @__PURE__ */ S("span", {
					className: "ml-2",
					children: t("widgets.search.navigate")
				}),
				/* @__PURE__ */ S("span", {
					className: "flex items-center justify-center p-1 h-5 rounded-md bg-[#F3F4F5] dark:bg-[#26313C] ml-2",
					children: "ESC"
				}),
				/* @__PURE__ */ S("span", {
					className: "ml-2",
					children: t("widgets.search.close")
				}),
				/* @__PURE__ */ S("span", {
					className: "flex items-center justify-center p-1 h-5 rounded-md bg-[#F3F4F5] dark:bg-[#26313C] ml-2",
					children: /* @__PURE__ */ S(de, {})
				}),
				/* @__PURE__ */ S("span", {
					className: "ml-2",
					children: t("widgets.search.select")
				})
			]
		}), /* @__PURE__ */ S("span", { children: t("widgets.search.total", { total: e }) })]
	})] });
}
var jp = w((() => {}));
//#endregion
//#region src/layout/widgets/global-search/components/search-panel.tsx
function Mp({ menuItem: e, active: t, enter: n, setActiveKey: r, showCloseButton: i, removeHistoryItem: a }) {
	let { t: o } = b(), s = jt(e?.label);
	function c(e) {
		r(e);
	}
	return /* @__PURE__ */ S(x, { children: /* @__PURE__ */ S("li", {
		"data-search-item": e.key,
		onMouseEnter: () => {
			c(e.key);
		},
		onClick: () => n(s),
		className: Vt("flex flex-col bg-colorBgLayout cursor-pointer px-4 py-4 rounded-md mb-2", t ? "text-colorBgContainer" : "text-colorText", { "bg-primaryActive": t }),
		children: /* @__PURE__ */ C("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ C("div", {
				className: "flex items-center",
				children: [e.icon && /* @__PURE__ */ S("div", {
					className: "mr-3",
					children: e.icon
				}), /* @__PURE__ */ S("span", { children: jt(e?.label) ? kt(e.label, {}, o(e.label?.props?.children)) : o(`${e?.label}`) })]
			}), /* @__PURE__ */ C("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ S("div", {
					className: "opacity-50",
					children: e.key
				}), /* @__PURE__ */ S(Ke, {
					className: Vt({ hidden: !i }, t ? "text-colorBgContainer!" : "text-colorText!"),
					size: "small",
					ghost: !1,
					type: "text",
					shape: "circle",
					icon: /* @__PURE__ */ S(ae, {}),
					onClick: (t) => {
						t.stopPropagation(), a(e.key);
					}
				})]
			})]
		})
	}) });
}
var Np = w((() => {}));
//#endregion
//#region src/layout/widgets/global-search/index.tsx
function Pp(e, t = []) {
	return e && e.length === 0 ? [] : e.reduce((e, n) => (n.children || e.push(n), n.children && n.children.length > 0 && Pp(n.children, t), e), t);
}
async function Fp() {
	return Rp ||= (await import("pinyin-pro")).match, Rp;
}
function Ip() {
	let e = j((e) => e.wholeMenus), t = j((e) => e.bottomMenus), { isMobile: n } = qf(), [r, i] = It(!1), a = u(), [o, s] = It(""), [c, l] = It(""), [d, f] = It([]), { t: p } = b(), m = Ft(null), h = Ft(null), [g = [], ee] = Xt(Lp, { defaultValue: [] }), te = y(() => Pp([...e, ...t]), [e, t]);
	function ne() {
		i(!1);
	}
	function re() {
		ne(), f([]), s(""), l("");
	}
	function ie(e) {
		h.current && h.current.children[e]?.scrollIntoView({
			behavior: "smooth",
			block: "nearest"
		});
	}
	function ae(e) {
		ee((t) => t.filter((t) => t !== e));
	}
	function oe() {
		return d.findIndex((e) => e.key === c);
	}
	function se(e) {
		let { length: t } = d;
		if (t === 0) return;
		let n = oe();
		if (n === -1) return;
		let r = (n + e + t) % t, i = d[r].key;
		l(i), ie(r);
	}
	let { run: ce } = qt(async (e) => {
		let t = e.target.value?.trim()?.toLocaleLowerCase();
		if (!t) {
			f([]), l("");
			return;
		}
		let n = te.map((e) => {
			let t = "";
			return jt(e.label) && (t = e.label.props.children), hf(e.label) && (t = e.label), {
				menuItem: e,
				label: p(t)?.toLocaleLowerCase()
			};
		}), r = n.filter((e) => e.label?.includes(t)), i = n.filter((e) => !e.label?.includes(t));
		if (i.length > 0) {
			let e = await Fp();
			r.push(...i.filter((n) => e(n.label, t)));
		}
		let a = new Set(r.map((e) => e.menuItem.key)), o = te.filter((e) => a.has(e.key)), s = o[0]?.key ?? "";
		l(s), f(o);
	}, { wait: 100 }), le = (e) => {
		let t = e.target.value?.trim();
		s(t);
	};
	function ue() {
		se(-1);
	}
	function de() {
		se(1);
	}
	Yt(["meta.K"], () => {
		r || i(!0);
	});
	function fe(e) {
		d.length !== 0 && c !== "" && (g?.includes(c) || ee([...g ?? [], c]), re(), e ? window.open(c) : a(c));
	}
	return Yt("Escape", re), Yt("Enter", () => fe()), Yt("uparrow", ue), Yt("downarrow", de), v(() => {
		!o.length && Array.isArray(g) && f(te.filter((e) => g?.includes(e.key)));
	}, [
		o,
		g,
		te
	]), /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ C("div", {
		onClick: () => i((e) => !e),
		className: "group flex justify-center items-center gap-2 md:bg-colorBgLayout px-3 py-1.5 rounded-full cursor-pointer text-colorTextSecondary hover:text-colorText md:mr-2.5",
		children: [
			/* @__PURE__ */ S(Ae, {}),
			/* @__PURE__ */ S("span", {
				className: "hidden text-xs duration-300 md:block",
				children: p("common.search")
			}),
			/* @__PURE__ */ C("span", {
				className: "bg-colorBgContainer relative hidden rounded-sm rounded-r-xl px-1.5 py-1 text-xs leading-none group-hover:opacity-100 md:block",
				children: ["⌘", /* @__PURE__ */ S("kbd", { children: "K" })]
			})
		]
	}), /* @__PURE__ */ S(ct, {
		open: r,
		onCancel: () => re(),
		afterOpenChange: (e) => {
			e && m.current?.focus();
		},
		keyboard: !0,
		title: /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S("div", {
			className: "mr-17",
			children: /* @__PURE__ */ S(it, {
				ref: m,
				value: o,
				onChange: le,
				onInput: ce,
				variant: "outlined",
				placeholder: p("widgets.search.placeholder"),
				allowClear: !0,
				autoFocus: !0,
				prefix: /* @__PURE__ */ S(Ae, {}),
				name: "global-search-input",
				className: "mx-4 mt-4"
			})
		}), /* @__PURE__ */ S(Ze, { className: "my-4" })] }),
		footer: n ? null : /* @__PURE__ */ S(Ap, { searchItems: d.length }),
		style: n ? {
			margin: 0,
			maxWidth: "100%",
			top: 0,
			paddingBottom: 0
		} : void 0,
		styles: {
			body: {
				flexGrow: "1",
				overflow: "hidden"
			},
			container: {
				padding: 0,
				height: n ? "100vh" : void 0,
				display: n ? "flex" : "block",
				flexDirection: n ? "column" : "row"
			}
		},
		width: n ? "100%" : 580,
		children: /* @__PURE__ */ S(wp, {
			style: { maxHeight: n ? "100%" : "450px" },
			children: /* @__PURE__ */ S("ul", {
				className: "px-4 pb-4 md:pb-0",
				ref: h,
				children: d.length === 0 ? /* @__PURE__ */ S(et, {
					className: "my-8",
					styles: { image: { height: 40 } },
					image: o.length ? /* @__PURE__ */ S(Ae, {
						className: "text-colorTextTertiary",
						style: { fontSize: 40 }
					}) : et.PRESENTED_IMAGE_SIMPLE,
					description: o.length ? `${p("widgets.search.noResults")} ${JSON.stringify(o)}` : p("widgets.search.noRecent")
				}) : d.map((e) => /* @__PURE__ */ S(Mp, {
					active: e.key === c,
					enter: fe,
					removeHistoryItem: ae,
					setActiveKey: l,
					menuItem: e,
					showCloseButton: o.length === 0
				}, e.key))
			})
		})
	})] });
}
var Lp, Rp, zp = w((() => {
	Tp(), Jf(), fv(), vf(), jp(), Np(), Lp = `__search-history-${location.hostname}__`;
}));
//#endregion
//#region src/utils/request/envelope.ts
async function Bp(e) {
	return (await e).data;
}
var Vp = w((() => {}));
//#endregion
//#region src/api/notifications/index.ts
function Hp() {
	let e = Sn();
	return e ? e.fetchNotifications() : Bp(M.get("notifications").json());
}
var Up = w((() => {
	Mn(), Xv(), Vp();
})), Wp, Gp, Kp, qp = w((() => {
	wd(), _d(), k(), Wp = "/notification-center", Gp = Kt(({ token: e }) => ({ notification: {
		"& .ant-popover-inner": { padding: 0 },
		"& .ant-list-footer": { borderTop: `1px solid ${e.colorBorder}` },
		"& .ant-list-items": {
			height: 380,
			overflowY: "auto"
		}
	} })), Kp = ({ dot: e, notifications: t, onEventChange: n, onOpenChange: r, ...i }) => {
		let [a, o] = $t(), s = Gp(), { t: c } = b(), l = !n, d = u(), f = () => {
			o.set(!1);
		}, p = () => {
			d(Wp), f();
		}, m = () => {
			l || n && n("makeAll");
		}, h = () => {
			l || n && n("clear");
		}, g = (e) => {
			l || (n && n("read", e), e.link && window.open(e.link, "_blank", "noopener"));
		}, ee = (e) => {
			if (!e.category) return null;
			let t = e.category === "pm" ? "magenta" : e.category === "mention" ? "orange" : "blue";
			return /* @__PURE__ */ S(vt, {
				color: t,
				className: "ml-1 text-xs",
				children: c(`widgets.notiCategory.${e.category}`)
			});
		};
		return e = y(() => !!t?.filter((e) => !e?.isRead).length, [t]), /* @__PURE__ */ S(lt, {
			placement: "bottomLeft",
			classNames: { root: Vt(s.notification, "w-72 md:w-96 right-4") },
			open: a,
			arrow: !1,
			trigger: "click",
			onOpenChange: (e) => {
				o.set(e), r?.(e);
			},
			content: /* @__PURE__ */ S(ot, {
				size: "small",
				bordered: !0,
				header: /* @__PURE__ */ C("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ S("div", { children: c("widgets.notifications") }), /* @__PURE__ */ S(yt, {
						title: t?.length ? c("widgets.markAllAsRead") : null,
						children: /* @__PURE__ */ S(Cd, {
							disabled: l || !t?.length,
							onClick: m,
							type: "text",
							icon: /* @__PURE__ */ S(ld, {})
						})
					})]
				}),
				footer: /* @__PURE__ */ C("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ S(Cd, {
						disabled: l || !t?.length,
						type: "text",
						onClick: h,
						children: c("widgets.clearNotifications")
					}), /* @__PURE__ */ S(Cd, {
						onClick: p,
						children: c("widgets.viewAll")
					})]
				}),
				dataSource: (t ?? []).filter((e) => !!e),
				renderItem: (e) => /* @__PURE__ */ C(ot.Item, {
					className: "relative justify-start gap-5 hover:bg-gray-100 cursor-pointer",
					onClick: () => g(e),
					children: [
						!e.isRead && /* @__PURE__ */ S("span", { className: "absolute w-2 h-2 rounded bg-primary right-2 top-2" }),
						/* @__PURE__ */ S("span", {
							className: "relative flex w-10 h-10 overflow-hidden rounded-full shrink-0",
							children: e.avatar ? /* @__PURE__ */ S("img", {
								src: e.avatar,
								className: "object-cover w-full h-full aspect-square",
								role: "img"
							}) : /* @__PURE__ */ S("span", {
								className: "flex w-full h-full items-center justify-center bg-gray-200 dark:bg-gray-700 text-gray-500",
								children: /* @__PURE__ */ S(ie, {})
							})
						}),
						/* @__PURE__ */ C("div", {
							className: "flex flex-col gap-1 leading-none",
							children: [
								/* @__PURE__ */ C("p", {
									className: "font-semibold flex items-center",
									children: [e.title, ee(e)]
								}),
								/* @__PURE__ */ S("p", {
									className: "my-1 text-xs text-muted-foreground line-clamp-2",
									children: e.message
								}),
								/* @__PURE__ */ S("p", {
									className: "text-xs text-muted-foreground line-clamp-2",
									children: e.date
								})
							]
						})
					]
				})
			}),
			children: /* @__PURE__ */ S(Cd, {
				size: "large",
				type: "text",
				...i,
				className: O("relative group", i.className),
				icon: /* @__PURE__ */ S(ie, { className: "group-hover:animate-wiggle" }),
				children: e && /* @__PURE__ */ S("span", { className: "bg-blue-600 absolute right-2 top-1.5 h-2 w-2 rounded" })
			})
		});
	};
}));
//#endregion
//#region src/layout/widgets/notification/notification-container.tsx
function Jp({ ...e }) {
	let [t, n] = It([]), r = Sn(), i = r, a = !!(i?.fetchNotifications && i.markRead && i.markAllRead && i.clearAll);
	r && !a && !Yp.has("notifications") && (Yp.add("notifications"), console.warn("[notification] 已注册的通知 provider 缺少写方法（markRead/markAllRead/clearAll），疑似老版本模块 bundle；通知降级为只读展示。"));
	let o = Pt(() => {
		Hp().then((e) => {
			n(Array.isArray(e) ? e : []);
		}).catch(() => {});
	}, []);
	return v(() => {
		o();
	}, [o]), /* @__PURE__ */ S(Kp, {
		notifications: t,
		onEventChange: a ? (e, t) => {
			let n = r;
			n && (e === "read" ? () => n.markRead(t.id) : e === "makeAll" ? () => n.markAllRead() : e === "clear" ? () => n.clearAll() : void 0)?.().then(o).catch(() => {});
		} : void 0,
		onOpenChange: (e) => e && o(),
		...e
	});
}
var Yp, Xp = w((() => {
	Up(), Mn(), qp(), Yp = /* @__PURE__ */ new Set();
}));
//#endregion
//#region src/layout/widgets/preferences/switch-item.tsx
function A({ tooltip: e, children: t, disabled: n, checked: r, name: i, onChange: a, ...o }) {
	return /* @__PURE__ */ C("div", {
		className: "hover:bg-gray-100 dark:hover:bg-gray-700 my-1 flex w-full items-center justify-between rounded-md px-2 py-2.5",
		children: [/* @__PURE__ */ C("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ S("span", {
				className: "flex items-center text-sm",
				children: t
			}), e ? /* @__PURE__ */ S(yt, {
				title: e,
				children: /* @__PURE__ */ S(Te, {})
			}) : null]
		}), /* @__PURE__ */ S(gt, {
			disabled: n,
			checked: r,
			size: "default",
			onChange: () => a?.(i, !r),
			...o
		})]
	});
}
var Zp = w((() => {}));
//#endregion
//#region src/layout/widgets/preferences/blocks/animation/index.tsx
function Qp() {
	let e = E((e) => e.transitionEnable), t = E((e) => e.transitionLoading), n = E((e) => e.transitionProgress), r = E((e) => e.transitionName), i = E((e) => e.setPreferences), { t: a } = b();
	function o(e) {
		i("transitionName", e);
	}
	return /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S(A, {
			name: "transitionProgress",
			checked: n,
			onChange: (e, t) => i(e, t),
			children: a("preferences.animation.progress")
		}),
		/* @__PURE__ */ S(A, {
			name: "transitionLoading",
			checked: t,
			onChange: (e, t) => i(e, t),
			children: a("preferences.animation.loading")
		}),
		/* @__PURE__ */ S(A, {
			name: "transitionEnable",
			checked: e,
			onChange: (e, t) => i(e, t),
			children: a("preferences.animation.transition")
		}),
		/* @__PURE__ */ S("ul", {
			className: "w-full flex flex-wrap justify-between gap-x-3 gap-y-5 list-none px-0",
			children: $p.map((e) => /* @__PURE__ */ S("li", {
				onClick: () => o(e),
				className: O("relative p-2 outline outline-1 outline-gray-300 dark:outline-gray-700 cursor-pointer rounded-md", "before:content-[''] before:absolute before:left-1/2 before:top-1/2 before:h-0 before:w-0 before:rounded-sm before:opacity-0 before:outline before:outline-2 before:outline-transparent", e === r ? "" : "before:transition-all before:duration-300", e === r ? "" : "before:hover:outline-blue-600 dark:before:hover:outline-blue-700 before:hover:left-0 before:hover:top-0 before:hover:h-full before:hover:w-full before:hover:p-1 before:hover:opacity-100", { "outline-2 outline-blue-600 dark:outline-blue-700": e === r }),
				children: /* @__PURE__ */ S("div", {
					className: O("dark:bg-gray-700", "bg-gray-100 h-10 w-12 rounded-md text-xs flex items-center justify-center text-center", {
						"fade-slide": e === "fade-slide",
						fade: e === "fade",
						"fade-up": e === "fade-up",
						"fade-down": e === "fade-down",
						"fade-zoom": e === "fade-zoom"
					}),
					children: /* @__PURE__ */ S("span", {
						className: "scale-75 text-opacity-75",
						children: e
					})
				})
			}, e))
		})
	] });
}
var $p, em = w((() => {
	D(), k(), Zp(), $p = [
		"fade",
		"fade-slide",
		"fade-up",
		"fade-down",
		"fade-zoom"
	];
}));
//#endregion
//#region src/layout/widgets/preferences/text-input.tsx
function tm({ children: e, disabled: t, value: n, name: r, onChange: i }) {
	return /* @__PURE__ */ C("div", {
		className: "hover:bg-gray-100 dark:hover:bg-gray-700 my-1 flex w-full items-center justify-between rounded-md px-2 py-2.5",
		children: [/* @__PURE__ */ S("span", {
			className: "flex items-center text-sm",
			children: e
		}), /* @__PURE__ */ S(it, {
			className: "w-40",
			disabled: t,
			allowClear: !0,
			value: n,
			onChange: (e) => {
				e && i?.(r, e.target.value);
			}
		})]
	});
}
var nm = w((() => {}));
//#endregion
//#region src/layout/widgets/preferences/blocks/footer/index.tsx
function rm() {
	let { t: e } = b(), { enableFooter: t, fixedFooter: n, companyName: r, companyWebsite: i, copyrightDate: a, ICPNumber: o, ICPLink: s, setPreferences: c } = E();
	return /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S(A, {
			name: "enableFooter",
			checked: t,
			onChange: (e, t) => c(e, t),
			children: e("preferences.footer.showFooter")
		}),
		/* @__PURE__ */ S(A, {
			name: "fixedFooter",
			checked: n,
			onChange: (e, t) => c(e, t),
			children: e("preferences.footer.fixedFooter")
		}),
		/* @__PURE__ */ S(tm, {
			name: "companyName",
			value: r,
			onChange: (e, t) => c(e, t),
			children: e("preferences.footer.companyName")
		}),
		/* @__PURE__ */ S(tm, {
			name: "companyWebsite",
			value: i,
			onChange: (e, t) => c(e, t),
			children: e("preferences.footer.companyWebsite")
		}),
		/* @__PURE__ */ S(tm, {
			name: "copyrightDate",
			value: a,
			onChange: (e, t) => c(e, t),
			children: e("preferences.footer.copyrightDate")
		}),
		/* @__PURE__ */ S(tm, {
			name: "ICPNumber",
			value: o,
			onChange: (e, t) => c(e, t),
			children: e("preferences.footer.ICPNumber")
		}),
		/* @__PURE__ */ S(tm, {
			name: "ICPLink",
			value: s,
			onChange: (e, t) => c(e, t),
			children: e("preferences.footer.ICPLink")
		})
	] });
}
var im = w((() => {
	D(), Zp(), nm();
}));
//#endregion
//#region src/layout/widgets/preferences/select-item.tsx
function am({ children: e, items: t, disabled: n, value: r, name: i }) {
	let { setPreferences: a } = E();
	return /* @__PURE__ */ C("div", {
		className: "hover:bg-gray-100 dark:hover:bg-gray-700 my-1 flex w-full items-center justify-between rounded-md px-2 py-2.5",
		children: [/* @__PURE__ */ S("span", {
			className: "flex items-center text-sm",
			children: e
		}), /* @__PURE__ */ S(ft, {
			className: "w-2/5",
			options: t,
			disabled: n,
			value: r,
			onChange: (e) => a(i, e)
		})]
	});
}
var om = w((() => {
	D();
}));
//#endregion
//#region src/layout/widgets/preferences/blocks/general/index.tsx
function sm() {
	let { t: e } = b(), { language: t, enableDynamicTitle: n, watermark: r, watermarkContent: i, enableCheckUpdates: a, enableBackTopButton: o, setPreferences: s } = E();
	return /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S(am, {
			name: "language",
			value: t,
			items: Dd(),
			children: e("preferences.general.language")
		}),
		/* @__PURE__ */ S(A, {
			name: "enableDynamicTitle",
			checked: n,
			onChange: (e, t) => s(e, t),
			children: e("preferences.general.dynamicTitle")
		}),
		/* @__PURE__ */ S(A, {
			name: "enableCheckUpdates",
			checked: a,
			onChange: (e, t) => s(e, t),
			children: e("preferences.general.enableCheckUpdate")
		}),
		/* @__PURE__ */ S(A, {
			name: "enableBackTopButton",
			checked: o,
			onChange: (e, t) => s(e, t),
			children: e("preferences.general.enableBackTopButton")
		}),
		/* @__PURE__ */ S(A, {
			name: "watermark",
			checked: r,
			onChange: (e, t) => s(e, t),
			tooltip: e("preferences.general.watermarkTip"),
			children: e("preferences.general.watermark")
		}),
		/* @__PURE__ */ S(tm, {
			name: "watermarkContent",
			value: i,
			onChange: (e, t) => s(e, t),
			children: e("preferences.general.watermarkContent")
		})
	] });
}
var cm = w((() => {
	D(), om(), Zp(), nm(), Od();
}));
//#endregion
//#region src/layout/widgets/preferences/blocks/layout/index.tsx
function lm() {
	let e = E((e) => e.navigationStyle), t = E((e) => e.setPreferences), { t: n } = b(), r = [
		{
			name: n("preferences.layout.sideNavigation"),
			tip: n("preferences.layout.sideNavigationTip"),
			icon: /* @__PURE__ */ S(Ou, { className: "h-[0.63em] text-[4rem] en-US:text-[9rem]" }),
			type: ur
		},
		{
			name: n("preferences.layout.topNavigation"),
			tip: n("preferences.layout.topNavigationTip"),
			icon: /* @__PURE__ */ S(ku, { className: "h-[0.63em] text-[4rem] en-US:text-[9rem]" }),
			type: dr
		},
		{
			name: n("preferences.layout.twoColumnNavigation"),
			tip: n("preferences.layout.twoColumnNavigationTip"),
			icon: /* @__PURE__ */ S(Au, { className: "h-[0.63em] text-[4rem] en-US:text-[9rem]" }),
			type: fr
		},
		{
			name: n("preferences.layout.mixedNavigation"),
			tip: n("preferences.layout.mixedNavigationTip"),
			icon: /* @__PURE__ */ S(wu, { className: "h-[0.63em] text-[4rem] en-US:text-[9rem]" }),
			type: pr
		}
	];
	function i(e) {
		t("navigationStyle", e);
	}
	return /* @__PURE__ */ S(x, { children: /* @__PURE__ */ S("ul", {
		className: "w-full flex flex-wrap justify-between gap-1 en-US:gap-y-3 px-0 list-none",
		children: r.map((t) => /* @__PURE__ */ S("li", {
			onClick: () => i(t.type),
			children: /* @__PURE__ */ C("dl", {
				className: "mb-0",
				children: [/* @__PURE__ */ S("dd", {
					className: O("relative p-1 outline outline-1 outline-gray-300 dark:outline-gray-700 rounded-md cursor-pointer", "before:content-[''] before:absolute before:left-1/2 before:top-1/2 before:h-0 before:w-0 before:rounded-sm before:opacity-0 before:outline before:outline-2 before:outline-transparent", t.type === e ? "" : "before:transition-all before:duration-300", t.type === e ? "" : "before:hover:outline-blue-600 dark:before:hover:outline-blue-700 before:hover:left-0 before:hover:top-0 before:hover:h-full before:hover:w-full before:hover:p-1 before:hover:opacity-100", { "outline-2 outline-blue-600 dark:outline-blue-700": t.type === e }),
					children: t.icon
				}), /* @__PURE__ */ C("dt", {
					className: "mt-2.5 flex gap-1 justify-center text-xs opacity-90",
					children: [/* @__PURE__ */ S("span", {
						className: "",
						children: t.name
					}), /* @__PURE__ */ S(yt, {
						title: t.tip,
						placement: "bottom",
						children: /* @__PURE__ */ S(Te, { className: "cursor-help" })
					})]
				})]
			})
		}, t.type))
	}) });
}
var um = w((() => {
	_d(), mr(), D(), k();
}));
//#endregion
//#region src/layout/widgets/preferences/number-input-spinner.tsx
function dm({ children: e, disabled: t, value: n, name: r, onChange: i, min: a, max: o }) {
	return /* @__PURE__ */ C("div", {
		className: "hover:bg-gray-100 dark:hover:bg-gray-700 my-1 flex w-full items-center justify-between rounded-md px-2 py-2.5",
		children: [/* @__PURE__ */ S("span", {
			className: "flex items-center text-sm",
			children: e
		}), /* @__PURE__ */ S(at, {
			className: "w-40",
			min: a,
			max: o,
			precision: 0,
			changeOnWheel: !0,
			mode: "spinner",
			disabled: t,
			value: n,
			onChange: (e) => {
				e && mf(e) && i?.(r, e);
			}
		})]
	});
}
var fm = w((() => {
	vf();
}));
//#endregion
//#region src/layout/widgets/preferences/blocks/sidebar/index.tsx
function pm() {
	let { accordion: e, sidebarEnable: t, sidebarCollapsed: n, sidebarWidth: r, setPreferences: i, sideCollapsedWidth: a, sidebarTheme: o, firstColumnWidthInTwoColumnNavigation: s } = E(), { t: c } = b(), l = [
		{
			label: c("preferences.sidebar.enable"),
			name: "sidebarEnable",
			value: t,
			disabled: !1
		},
		{
			label: c("preferences.sidebar.collapsed"),
			name: "sidebarCollapsed",
			value: n,
			disabled: !t
		},
		{
			label: c("preferences.sidebar.accordion"),
			name: "accordion",
			value: e,
			disabled: !t
		}
	], u = (e, t) => {
		i(e, t);
	};
	return /* @__PURE__ */ C(x, { children: [
		l.map((e) => /* @__PURE__ */ S(A, {
			name: e.name,
			checked: e.value,
			onChange: u,
			disabled: e.disabled,
			children: e.label
		}, e.name)),
		/* @__PURE__ */ S(A, {
			name: "sidebarTheme",
			checked: o === "light",
			onChange: (e, t) => i(e, t ? "light" : "dark"),
			disabled: !t,
			unCheckedChildren: /* @__PURE__ */ S(od, {}),
			checkedChildren: /* @__PURE__ */ S(ud, {}),
			children: c("preferences.sidebar.sidebarTheme")
		}),
		/* @__PURE__ */ S(dm, {
			min: 40,
			max: 80,
			name: "sideCollapsedWidth",
			value: a,
			onChange: (e, t) => i(e, t),
			children: c("preferences.sidebar.collapsedWidth")
		}),
		/* @__PURE__ */ S(dm, {
			min: 180,
			max: 320,
			name: "sidebarWidth",
			value: r,
			onChange: (e, t) => i(e, t),
			children: c("preferences.sidebar.width")
		}),
		/* @__PURE__ */ S(dm, {
			min: 50,
			max: 250,
			name: "firstColumnWidthInTwoColumnNavigation",
			value: s,
			onChange: (e, t) => i(e, t),
			children: c("preferences.sidebar.firstColumnWidthInTwoColumnNavigation")
		})
	] });
}
var mm = w((() => {
	_d(), fm(), D(), Zp();
}));
//#endregion
//#region src/layout/widgets/preferences/blocks/tabbar/index.tsx
function hm() {
	let { t: e } = b(), { tabbarEnable: t, tabbarShowIcon: n, tabbarPersist: r, tabbarDraggable: i, tabbarStyleType: a, tabbarShowMore: o, tabbarShowMaximize: s, setPreferences: c } = E(), l = [
		{
			label: e("preferences.tabbar.styleType.chrome"),
			value: "chrome"
		},
		{
			label: e("preferences.tabbar.styleType.plain"),
			value: "plain"
		},
		{
			label: e("preferences.tabbar.styleType.card"),
			value: "card"
		},
		{
			label: e("preferences.tabbar.styleType.brisk"),
			value: "brisk"
		}
	];
	return /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S(A, {
			name: "tabbarEnable",
			checked: t,
			onChange: (e, t) => c(e, t),
			children: e("preferences.tabbar.enable")
		}),
		/* @__PURE__ */ S(A, {
			name: "tabbarPersist",
			checked: r,
			disabled: !t,
			onChange: (e, t) => c(e, t),
			children: e("preferences.tabbar.persist")
		}),
		/* @__PURE__ */ S(A, {
			name: "tabbarDraggable",
			checked: i,
			disabled: !0,
			onChange: (e, t) => c(e, t),
			children: e("preferences.tabbar.draggable")
		}),
		/* @__PURE__ */ S(A, {
			name: "tabbarShowIcon",
			checked: n,
			disabled: !0,
			onChange: (e, t) => c(e, t),
			children: e("preferences.tabbar.icon")
		}),
		/* @__PURE__ */ S(A, {
			name: "tabbarShowMore",
			checked: o,
			disabled: !t,
			onChange: (e, t) => c(e, t),
			children: e("preferences.tabbar.showMore")
		}),
		/* @__PURE__ */ S(A, {
			name: "tabbarShowMaximize",
			checked: s,
			disabled: !t,
			onChange: (e, t) => c(e, t),
			children: e("preferences.tabbar.showMaximize")
		}),
		/* @__PURE__ */ S(am, {
			name: "tabbarStyleType",
			value: a,
			disabled: !t,
			items: l,
			children: e("preferences.tabbar.styleType.title")
		})
	] });
}
var gm = w((() => {
	D(), om(), Zp();
}));
//#endregion
//#region src/layout/widgets/preferences/blocks/theme/builtin.tsx
function _m() {
	let { builtinTheme: e, themeColorPrimary: t, setPreferences: n } = E(), [r, i] = It(e === "custom" ? t : "#1677ff"), { t: a } = b(), o = [
		{
			label: a("preferences.theme.builtin.red"),
			value: "red",
			color: "#f5222d"
		},
		{
			label: a("preferences.theme.builtin.volcano"),
			value: "volcano",
			color: "#fa541c"
		},
		{
			label: a("preferences.theme.builtin.orange"),
			value: "orange",
			color: "#fa8c16"
		},
		{
			label: a("preferences.theme.builtin.gold"),
			value: "gold",
			color: "#faad14"
		},
		{
			label: a("preferences.theme.builtin.yellow"),
			value: "yellow",
			color: "#fadb14"
		},
		{
			label: a("preferences.theme.builtin.lime"),
			value: "lime",
			color: "#a0d911"
		},
		{
			label: a("preferences.theme.builtin.green"),
			value: "green",
			color: "#52c41a"
		},
		{
			label: a("preferences.theme.builtin.cyan"),
			value: "cyan",
			color: "#13c2c2"
		},
		{
			label: /* @__PURE__ */ C(x, { children: [
				/* @__PURE__ */ S("span", { children: a("preferences.theme.builtin.blue") }),
				/* @__PURE__ */ S("br", { className: "zh-CN:hidden" }),
				/* @__PURE__ */ C("span", { children: [
					"(",
					a("preferences.theme.builtin.title"),
					")"
				] })
			] }),
			value: "blue",
			color: "#1677ff"
		},
		{
			label: a("preferences.theme.builtin.geekblue"),
			value: "geekblue",
			color: "#2f54eb"
		},
		{
			label: a("preferences.theme.builtin.purple"),
			value: "purple",
			color: "#722ed1"
		},
		{
			label: a("preferences.theme.builtin.magenta"),
			value: "magenta",
			color: "#eb2f96"
		},
		{
			label: a("preferences.theme.builtin.gray"),
			value: "gray",
			color: "#bfbfbf"
		},
		{
			label: a("preferences.theme.builtin.custom"),
			value: "custom",
			color: "#1677ff"
		}
	], s = (e) => {
		let t = `#${e.toHex()}`;
		i(t), n({
			builtinTheme: "custom",
			themeColorPrimary: t
		});
	};
	function c(e) {
		n({
			builtinTheme: e,
			themeColorPrimary: o.find((t) => t.value === e)?.color
		});
	}
	return /* @__PURE__ */ S(x, { children: /* @__PURE__ */ S("ul", {
		className: "flex justify-between flex-wrap w-full gap-3 p-0 m-0 list-none",
		children: o.map((t) => {
			let n = /* @__PURE__ */ S("li", {
				onClick: () => c(t.value),
				children: /* @__PURE__ */ C("dl", {
					className: "mb-0",
					children: [/* @__PURE__ */ S("dd", {
						className: O("relative py-4 px-9 outline outline-1 outline-gray-300 dark:outline-gray-700 rounded-md cursor-pointer", "before:content-[''] before:absolute before:left-1/2 before:top-1/2 before:h-0 before:w-0 before:rounded-sm before:opacity-0 before:outline before:outline-2 before:outline-transparent", t.value === e ? "" : "before:transition-all before:duration-300", t.value === e ? "" : "before:hover:outline-blue-600 dark:before:hover:outline-blue-700 before:hover:left-0 before:hover:top-0 before:hover:h-full before:hover:w-full before:hover:p-1 before:hover:opacity-100", { "outline-2 outline-blue-600 dark:outline-blue-700": t.value === e }),
						children: /* @__PURE__ */ C("div", {
							className: "rounded-md size-5",
							style: { backgroundColor: t.value === "custom" ? r : t.color },
							children: [/* @__PURE__ */ S("span", {
								className: "hidden",
								children: t.label
							}), /* @__PURE__ */ S("span", {
								className: "hidden",
								children: t.color
							})]
						})
					}), /* @__PURE__ */ S("dt", {
						className: "mt-2.5 flex gap-1 justify-center text-xs opacity-90",
						children: /* @__PURE__ */ S("span", {
							className: "",
							children: t.label
						})
					})]
				})
			}, t.value);
			return t.value === "custom" ? /* @__PURE__ */ S(Ye, {
				value: r,
				onChangeComplete: s,
				children: n
			}, t.value) : n;
		})
	}) });
}
var vm = w((() => {
	D(), k();
}));
//#endregion
//#region src/layout/widgets/preferences/blocks/theme/theme.tsx
function ym() {
	let { t: e } = b(), { theme: t, colorBlindMode: n, colorGrayMode: r, themeRadius: i, changeSiteTheme: a, setPreferences: o } = E(), s = [
		{
			name: e("preferences.theme.light"),
			icon: /* @__PURE__ */ S(fd, { className: "text-xl" }),
			type: "light"
		},
		{
			name: e("preferences.theme.dark"),
			icon: /* @__PURE__ */ S(ud, { className: "text-xl" }),
			type: "dark"
		},
		{
			name: e("preferences.theme.followSystem"),
			icon: /* @__PURE__ */ S(od, { className: "text-xl" }),
			type: "auto"
		}
	];
	function c(e) {
		a(e);
	}
	let l = (e) => {
		o("themeRadius", e);
	};
	return /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S("ul", {
			className: "flex justify-between w-full gap-3 p-0 m-0 list-none",
			children: s.map((e) => /* @__PURE__ */ S("li", {
				onClick: () => c(e.type),
				children: /* @__PURE__ */ C("dl", {
					className: "mb-0",
					children: [/* @__PURE__ */ S("dd", {
						className: O("relative py-4 px-10 outline outline-1 outline-gray-300 dark:outline-gray-700 rounded-md cursor-pointer", "before:content-[''] before:absolute before:left-1/2 before:top-1/2 before:h-0 before:w-0 before:rounded-sm before:opacity-0 before:outline before:outline-2 before:outline-transparent", e.type === t ? "" : "before:transition-all before:duration-300", e.type === t ? "" : "before:hover:outline-blue-600 dark:before:hover:outline-blue-700 before:hover:left-0 before:hover:top-0 before:hover:h-full before:hover:w-full before:hover:p-1 before:hover:opacity-100", { "outline-2 outline-blue-600 dark:outline-blue-700": e.type === t }),
						children: e.icon
					}), /* @__PURE__ */ S("dt", {
						className: "mt-2.5 flex gap-1 justify-center text-xs opacity-90",
						children: /* @__PURE__ */ S("span", {
							className: "",
							children: e.name
						})
					})]
				})
			}, e.type))
		}),
		/* @__PURE__ */ S(A, {
			name: "colorBlindMode",
			checked: n,
			onChange: (e, t) => o(e, t),
			children: e("preferences.theme.colorBlindMode")
		}),
		/* @__PURE__ */ S(A, {
			name: "colorGrayMode",
			checked: r,
			onChange: (e, t) => o(e, t),
			children: e("preferences.theme.grayMode")
		}),
		/* @__PURE__ */ C("div", {
			className: "flex justify-between w-full rounded-md px-2 py-2.5 hover:bg-gray-100 dark:hover:bg-gray-700",
			children: [
				/* @__PURE__ */ S("span", {
					className: "flex items-center text-sm",
					children: e("preferences.theme.radius")
				}),
				/* @__PURE__ */ S("div", {
					className: "w-1/3",
					children: /* @__PURE__ */ S(pt, {
						rootClassName: "w-full",
						min: 0,
						max: 16,
						onChange: l,
						value: i
					})
				}),
				/* @__PURE__ */ S("div", { children: /* @__PURE__ */ S(at, {
					keyboard: !0,
					changeOnWheel: !0,
					className: "ml-4",
					min: 0,
					max: 16,
					value: i,
					onChange: l
				}) })
			]
		})
	] });
}
var bm = w((() => {
	_d(), D(), k(), Zp();
})), xm = w((() => {
	vm(), bm();
})), Sm = w((() => {
	em(), im(), cm(), um(), mm(), gm(), xm();
}));
//#endregion
//#region src/layout/widgets/preferences/index.tsx
function Cm({ ...e }) {
	let { t } = b(), n = u(), [r, i] = It(!1), { isMobile: a } = qf(), { reset: o, isDefault: s, isDark: c } = Dr(), l = E(), d = mv((e) => e.logout), f = async () => {
		await d(), E.persist.clearStorage(), n(Hn);
	}, p = async () => {
		let e = JSON.stringify(l, null, 2);
		await navigator.clipboard.writeText(e), window.$modal?.success?.({
			title: t("preferences.copyPreferencesSuccessTitle"),
			content: t("preferences.copyPreferencesSuccess")
		});
	};
	return /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S(Cd, {
		type: "text",
		...e,
		onClick: (t) => {
			e?.onClick?.(t), i(!0);
		},
		children: /* @__PURE__ */ S(je, {})
	}), /* @__PURE__ */ S(Xe, {
		theme: { algorithm: c ? Et.darkAlgorithm : Et.defaultAlgorithm },
		children: /* @__PURE__ */ C(Qe, {
			title: t("preferences.title"),
			placement: "right",
			onClose: () => {
				i(!1);
			},
			extra: /* @__PURE__ */ S(We, {
				style: {
					width: 8,
					height: 8
				},
				dot: !s,
				color: "blue",
				offset: [-5, 5],
				children: /* @__PURE__ */ S(Cd, {
					onPointerDown: () => !s && o(),
					type: "text",
					icon: /* @__PURE__ */ S(Ee, { rotate: 270 })
				})
			}),
			footer: /* @__PURE__ */ C("div", {
				className: "flex justify-between",
				children: [/* @__PURE__ */ S(Cd, {
					icon: /* @__PURE__ */ S(ce, { rotate: 180 }),
					onPointerDown: p,
					children: t("preferences.copyPreferences")
				}), /* @__PURE__ */ S(Cd, {
					type: "text",
					onPointerDown: f,
					children: t("preferences.clearAndLogout")
				})]
			}),
			...a ? { width: "100vw" } : {},
			open: r,
			id: wm,
			children: [/* @__PURE__ */ C("div", {
				style: {
					display: "flex",
					flexDirection: "column",
					alignItems: "center"
				},
				children: [
					/* @__PURE__ */ S(Ze, { children: t("preferences.general.title") }),
					/* @__PURE__ */ S(sm, {}),
					/* @__PURE__ */ S(Ze, { children: t("preferences.theme.title") }),
					/* @__PURE__ */ S(ym, {}),
					/* @__PURE__ */ S(Ze, { children: t("preferences.theme.builtin.title") }),
					/* @__PURE__ */ S(_m, {}),
					/* @__PURE__ */ S(Ze, { children: t("preferences.layout.title") }),
					/* @__PURE__ */ S(lm, {}),
					/* @__PURE__ */ S(Ze, { children: t("preferences.sidebar.title") }),
					/* @__PURE__ */ S(pm, {}),
					/* @__PURE__ */ S(Ze, { children: t("preferences.tabbar.title") }),
					/* @__PURE__ */ S(hm, {}),
					/* @__PURE__ */ S(Ze, { children: t("preferences.animation.title") }),
					/* @__PURE__ */ S(Qp, {}),
					/* @__PURE__ */ S(Ze, { children: t("preferences.footer.title") }),
					/* @__PURE__ */ S(rm, {})
				]
			}), /* @__PURE__ */ S(tt.BackTop, {
				icon: /* @__PURE__ */ S(Oe, {}),
				target: () => document.querySelector(`#${wm} .ant-drawer-body`)
			})]
		})
	})] });
}
var wm, Tm = w((() => {
	wd(), Jf(), Or(), Jn(), hv(), D(), Sm(), wm = "__react-antd-admin__preferences_drawer__";
}));
//#endregion
//#region src/module-loader/slots.ts
function Em(e, t, n) {
	km.setState((r) => {
		let i = r.slots[t] ?? {};
		return { slots: {
			...r.slots,
			[t]: {
				...i,
				[e]: n
			}
		} };
	});
}
function Dm(e) {
	km.setState((t) => {
		let n = {}, r = !1;
		for (let [i, a] of Object.entries(t.slots)) {
			if (!(e in a)) {
				n[i] = a;
				continue;
			}
			r = !0;
			let t = { ...a };
			delete t[e], Object.keys(t).length > 0 && (n[i] = t);
		}
		return r ? { slots: n } : t;
	});
}
function Om(e) {
	let t = km((t) => t.slots[e]);
	return Object.values(t ?? {});
}
var km, Am = w((() => {
	km = t(() => ({ slots: {} }));
})), jm, Mm = w((() => {
	wd(), jm = ({ target: e, fullscreenIcon: t, fullscreenExitIcon: n, ...r }) => {
		let [i, { toggleFullscreen: a }] = Jt(e);
		return /* @__PURE__ */ S(Cd, {
			type: "text",
			...r,
			icon: i ? n ?? /* @__PURE__ */ S(he, {}) : t ?? /* @__PURE__ */ S(ge, {}),
			onClick: a
		});
	};
}));
//#endregion
//#region src/layout/layout-header/components/fullscreen-button.tsx
function Nm({ target: e, ...t }) {
	return /* @__PURE__ */ S(jm, {
		...t,
		target: e,
		fullscreenExitIcon: /* @__PURE__ */ S(sd, {}),
		fullscreenIcon: /* @__PURE__ */ S(cd, {})
	});
}
var Pm = w((() => {
	Mm(), _d();
}));
//#endregion
//#region src/utils/is-windows-os/index.ts
function Fm() {
	return /windows|win32/i.test(navigator.userAgent);
}
var Im = w((() => {}));
//#endregion
//#region src/layout/layout-header/components/user-menu.tsx
function Lm({ ...e }) {
	let t = u(), { t: n } = b(), r = Af((e) => e.avatar), i = mv((e) => e.logout), a = async ({ key: e }) => {
		e === "logout" && (await i(), t(Hn)), e === "personal-center" && t("/personal-center/my-profile");
	}, o = y(() => Fm() ? "Alt" : "⌥", []), s = [{
		label: n("personal-center:menu.personalCenter"),
		key: "personal-center",
		icon: /* @__PURE__ */ S(ad, {}),
		extra: `${o}P`
	}, {
		label: n("authority.logout"),
		key: "logout",
		icon: /* @__PURE__ */ S(be, {}),
		extra: `${o}Q`
	}];
	return Yt(["alt.P"], () => {
		t("/personal-center/my-profile");
	}), Yt(["alt.Q"], () => {
		a({ key: "logout" });
	}), /* @__PURE__ */ S($e, {
		menu: {
			items: s,
			onClick: a
		},
		arrow: !1,
		placement: "bottomRight",
		trigger: ["click"],
		children: /* @__PURE__ */ S(Cd, {
			type: "text",
			...e,
			className: O(e.className, "rounded-full px-1"),
			children: /* @__PURE__ */ S(Ue, {
				src: r || void 0,
				icon: /* @__PURE__ */ S(Re, {})
			})
		})
	});
}
var Rm = w((() => {
	wd(), _d(), Jn(), hv(), jf(), k(), Im();
}));
//#endregion
//#region src/layout/layout-header/index.tsx
function zm({ className: e, children: t }) {
	let { token: { Menu: n } } = Et.useToken(), { sidebarCollapsed: r, setPreferences: i, isDark: a, sidebarTheme: o } = Dr(), { isMobile: s } = qf(), c = pp((e) => e.isMaximize), { isTopNav: l, isMixedNav: u } = hp(), d = Om("header-actions"), f = a || o === "dark" && (u || l), p = s ? {
		size: "middle",
		className: "px-2"
	} : {
		size: "large",
		className: "px-[11px]"
	};
	return /* @__PURE__ */ S(Xe, {
		theme: { algorithm: f ? Et.darkAlgorithm : Et.defaultAlgorithm },
		children: /* @__PURE__ */ C("header", {
			className: O("flex-shrink-0 flex justify-between items-center transition-all px-2 md:px-4", s ? "gap-2" : "gap-5", { "overflow-hidden": c }, e),
			style: {
				background: f ? n?.darkItemBg : n?.itemBg,
				height: c ? 0 : 48
			},
			children: [
				s ? /* @__PURE__ */ S(Ke, {
					type: "text",
					icon: S(r ? Ce : xe, {}),
					onClick: () => i("sidebarCollapsed", !r),
					className: "h-full"
				}) : null,
				/* @__PURE__ */ S("div", {
					className: "flex items-center grow h-full overflow-hidden",
					children: t
				}),
				/* @__PURE__ */ C("div", {
					className: O("flex items-center min-w-0", s && "overflow-x-auto"),
					children: [
						Dt.toArray(d),
						/* @__PURE__ */ S(Ip, {}),
						/* @__PURE__ */ S(Cm, { ...p }),
						/* @__PURE__ */ S(Md, { ...p }),
						/* @__PURE__ */ S(kd, { ...p }),
						/* @__PURE__ */ S(Nm, {
							...p,
							target: document.documentElement
						}),
						/* @__PURE__ */ S(Jp, { ...p }),
						/* @__PURE__ */ S(Lm, { ...p })
					]
				})
			]
		})
	});
}
var Bm = w((() => {
	Jf(), Or(), gp(), zp(), Xp(), Tm(), Am(), mp(), k(), ip(), Pm(), Ad(), Pd(), Rm();
})), Vm, Hm = w((() => {
	Vm = Kt({ menuBackgroundColor: { "& .ant-menu-submenu-selected .ant-menu-submenu-title": { backgroundColor: "var(--ant-menu-item-selected-bg)" } } });
}));
//#endregion
//#region src/router/utils/remove-trailing-slash.ts
function Um(e) {
	return e.length > 1 && e.endsWith("/") ? e.slice(0, -1) : e;
}
var Wm = w((() => {}));
//#endregion
//#region src/layout/layout-menu/utils.ts
function Gm(e, t) {
	return e.map((e) => {
		let n = e.label;
		if (jt(e.label)) {
			let r = t(e.label.props.children);
			n = kt(e.label, {}, r ?? "");
		}
		hf(e.label) && (n = t(e.label));
		let r = {
			...e,
			label: n
		};
		return e.children && e.children.length > 0 && (r.children = Gm(e.children, t)), r;
	});
}
function Km(e, t) {
	let n = e.findLast((e) => e.handle?.currentActiveMenu);
	if (n?.handle?.currentActiveMenu) {
		let e = Um(n.handle.currentActiveMenu);
		return [...t[e] || [], e];
	}
	let r = e.findLast((e) => e.handle?.hideInMenu !== !0);
	return r?.id ? [...t[r.id] || [], r.id] : [];
}
function qm(e, t) {
	let n = null, r = null, i = null;
	if (!t) return {
		findMenu: null,
		rootMenu: null,
		rootMenuPath: null
	};
	let a = (e, t, o = []) => {
		for (let s of e) {
			if (s.key === t) return n = s, o.length === 0 ? (r = s, i = s.key) : (r = o[0], i = o[0].key), !0;
			if (s.children && s.children.length > 0 && a(s.children, t, [...o, s])) return !0;
		}
		return !1;
	};
	return a(e, t), {
		findMenu: n,
		rootMenu: r,
		rootMenuPath: i
	};
}
function Jm(e) {
	if (!e || e.length === 0) return null;
	let t = e[0];
	return t.children && t.children.length > 0 ? Jm(t.children) : t;
}
function Ym(e) {
	let t = {};
	function n(e, r = []) {
		for (let i of e) t[i.key] = [...r], Array.isArray(i.children) && i.children.length && n(i.children, [...r, i.key]);
	}
	return n(e), t;
}
var Xm = w((() => {
	Wm(), vf();
}));
//#endregion
//#region src/layout/layout-menu/index.tsx
function Zm({ mode: e = "inline", autoExpandCurrentMenu: t, handleMenuSelect: n, menus: r = Qm }) {
	let i = Vm(), a = l(), o = j((e) => e.wholeMenus), s = j((e) => e.bottomMenus), { sidebarCollapsed: c, sidebarTheme: u, isDark: d, accordion: f } = Dr(), [p, m] = It([]), { isMobile: h } = qf(), g = y(() => Ym([...o, ...s]), [o, s]), ee = y(() => Km(a, g), [a, g]), te = y(() => e === "inline" ? { inlineCollapsed: !h && c } : {}, [
		e,
		h,
		c
	]), ne = Pt((e) => {
		if (f || c) {
			let t = e.find((e) => !p.includes(e));
			if (t !== void 0) {
				let e = g[t] || [];
				m([...e, t]);
			} else {
				let t = p.find((t) => !e.includes(t));
				t && m(g[t]);
			}
		} else m(e);
	}, [
		f,
		c,
		p,
		g
	]), re = y(() => t ? {
		openKeys: p,
		onOpenChange: ne
	} : {}, [
		t,
		p,
		ne
	]);
	return v(() => {
		m(c ? [] : f ? ee : (e) => e.length === 0 ? ee : e);
	}, [
		a,
		c,
		ee,
		f
	]), /* @__PURE__ */ S(st, {
		className: O("!border-none min-w-0 flex-auto", { [i.menuBackgroundColor]: c }),
		inlineIndent: 16,
		...te,
		style: { height: h ? "100%" : "initial" },
		mode: e,
		theme: d ? "dark" : u,
		items: r,
		...re,
		selectedKeys: ee,
		onClick: ({ key: t }) => n?.(t, e)
	});
}
var Qm, $m = w((() => {
	Jf(), Or(), fv(), k(), Hm(), Xm(), Qm = [];
}));
//#endregion
//#region src/layout/layout-menu/use-menu.ts
function eh() {
	let e = j((e) => e.wholeMenus), t = j((e) => e.bottomMenus), { isMixedNav: n, isTwoColumnNav: r } = hp(), i = u(), { t: a } = b(), o = Gm(e, a), s = Gm(t, a), c = y(() => [...o, ...s], [o, s]), { pathname: d } = Lf(), f = l(), p = y(() => n || r, [n, r]), m = y(() => {
		if (!p) return "";
		let e = f.findLast((e) => e.handle?.currentActiveMenu)?.handle?.currentActiveMenu, t = Um(e || d), { rootMenuPath: n } = qm(c, t);
		return n ?? "";
	}, [
		p,
		d,
		f,
		c
	]), h = y(() => {
		let e = c.find((e) => e?.key === m);
		return e ? e?.children ?? [e] : [];
	}, [m, c]);
	return {
		handleMenuSelect: (e, t) => {
			if (e.startsWith("solgroup:")) return;
			let n = Um(e);
			if (n !== Um(d)) {
				if (!p || t !== "horizontal") /http(s)?:/.test(e) ? window.open(e) : i(n);
				else {
					let t = Jm(c.find((t) => t?.key === e)?.children ?? []);
					i(t ? Um(t.key) : n);
				}
			}
		},
		sideNavMenuKeyInSplitMode: m,
		topNavItems: y(() => p ? c.map((e) => ({
			...e,
			children: void 0
		})) : c, [p, c]),
		sideNavItems: y(() => p ? h : o, [
			p,
			h,
			o
		]),
		bottomNavItems: s
	};
}
var th = w((() => {
	Rf(), Wm(), fv(), _p(), Xm();
}));
//#endregion
//#region src/layout/widgets/sider-trigger/index.tsx
function nh({ className: e }) {
	let { sidebarCollapsed: t, setPreferences: n, sidebarTheme: r } = Dr();
	return /* @__PURE__ */ S(Cd, {
		type: "text",
		style: {
			boxShadow: "0px -3px 5px 0 rgb(29, 35, 41, 0.05)",
			height: 40
		},
		icon: S(t ? Ce : xe, {}),
		onClick: () => n("sidebarCollapsed", !t),
		className: O("w-full rounded-none border-t", e, r === "dark" ? "border-t-[#303030]" : "border-t-colorBorderSecondary")
	});
}
var rh = w((() => {
	wd(), Or(), k(), ip();
})), ih, ah = w((() => {
	ih = "data:image/svg+xml,%3csvg%20fill='none'%20xmlns='http://www.w3.org/2000/svg'%20viewBox='0%200%2085%2084'%3e%3cpath%20d='M44.9903%201.13755L61.3489%2017.3023C62.8848%2018.82%2062.8848%2021.2797%2061.3489%2022.7966C59.813%2024.3143%2057.3238%2024.3143%2055.7888%2022.7966L44.9903%2012.127C43.4544%2010.6093%2040.9652%2010.6093%2039.4302%2012.127L12.2732%2038.9622C10.7372%2040.4799%2010.7372%2042.9396%2012.2732%2044.4565L39.4302%2071.2917C40.9661%2072.8094%2043.4553%2072.8094%2044.9903%2071.2917L55.7888%2060.6213C57.3247%2059.1036%2059.8139%2059.1036%2061.3489%2060.6213C62.8848%2062.139%2062.8848%2064.5987%2061.3489%2066.1156L44.9903%2082.2803C43.4544%2083.798%2040.9652%2083.798%2039.4302%2082.2803L1.15193%2044.4565C-0.383976%2042.9388%20-0.383976%2040.4791%201.15193%2038.9622L39.4293%201.13838C40.9652%20-0.379323%2043.4553%20-0.379322%2044.9903%201.13755Z'%20fill='url(%23paint0_linear_1_12)'/%3e%3cpath%20d='M66.91%2028.2918C68.4459%2026.7741%2070.9351%2026.7741%2072.4702%2028.2918L83.2686%2038.9622C84.8045%2040.4799%2084.8045%2042.9396%2083.2686%2044.4565L72.4702%2055.127C70.9343%2056.6447%2068.445%2056.6447%2066.91%2055.127C65.3741%2053.6093%2065.3741%2051.1495%2066.91%2049.6327L72.1474%2044.4573C73.6833%2042.9396%2073.6833%2040.4799%2072.1474%2038.963L66.91%2033.7877C65.3741%2032.2692%2065.3741%2029.8095%2066.91%2028.2918Z'%20fill='url(%23paint1_linear_1_12)'/%3e%3cpath%20d='M41.3659%2043C41.3659%2043.5551%2041.5907%2044.0875%2041.9909%2044.48C42.3912%2044.8725%2042.934%2045.093%2043.5%2045.093C44.066%2045.093%2044.6088%2044.8725%2045.0091%2044.48C45.4093%2044.0875%2045.6342%2043.5551%2045.6342%2043C45.6342%2042.4449%2045.4093%2041.9125%2045.0091%2041.52C44.6088%2041.1275%2044.066%2040.907%2043.5%2040.907C42.934%2040.907%2042.3912%2041.1275%2041.9909%2041.52C41.5907%2041.9125%2041.3659%2042.4449%2041.3659%2043Z'%20fill='%2361DAFB'/%3e%3cpath%20d='M60%2042.4911C60%2040.0563%2057.285%2037.947%2053.0652%2036.6714C54.1284%2032.1816%2053.7532%2028.6495%2051.7518%2027.432C49.7468%2026.2146%2046.6565%2027.6375%2043.5%2030.8517C40.3435%2027.6375%2037.2532%2026.2146%2035.2482%2027.432C33.2468%2028.6495%2032.8716%2032.1855%2033.9348%2036.6714C29.7151%2037.947%2027%2040.0563%2027%2042.4911C27%2044.926%2029.7151%2047.0352%2033.9348%2048.3108C32.8716%2052.7968%2033.2468%2056.3328%2035.2482%2057.5502C35.7411%2057.8527%2036.3003%2058%2036.911%2058C38.3716%2058%2040.1411%2057.1548%2042.0615%2055.5108C42.5398%2055.0998%2043.0217%2054.6346%2043.5%2054.146C43.9783%2054.6346%2044.4602%2055.0998%2044.9385%2055.5108C46.8589%2057.1548%2048.6247%2058%2050.089%2058C50.6997%2058%2051.2589%2057.8527%2051.7518%2057.5502C53.7532%2056.3328%2054.1284%2052.8007%2053.0652%2048.3108C57.285%2047.0352%2060%2044.926%2060%2042.4911ZM51.0344%2028.7425C52.3331%2029.5335%2052.6054%2032.3988%2051.6819%2036.2954C50.3318%2035.9697%2048.8602%2035.7254%2047.293%2035.5742C46.3843%2034.221%2045.4462%2032.9997%2044.5043%2031.9296C46.6823%2029.708%2048.7057%2028.5022%2050.0963%2028.5022C50.4495%2028.4983%2050.7659%2028.5797%2051.0344%2028.7425ZM48.0987%2045.2905C47.591%2046.221%2047.0538%2047.1128%2046.5057%2047.9658C45.5455%2048.0433%2044.5448%2048.086%2043.5%2048.086C42.4589%2048.086%2041.4582%2048.0433%2040.498%2047.9658C39.9462%2047.1128%2039.4127%2046.2171%2038.905%2045.2905C38.3863%2044.3406%2037.9227%2043.4062%2037.5033%2042.4911C37.9227%2041.5761%2038.3863%2040.6417%2038.905%2039.6918C39.4237%2038.7419%2039.9609%2037.854%2040.5017%2037.0126C41.4619%2036.9351%2042.4625%2036.8924%2043.5037%2036.8924C44.5448%2036.8924%2045.5455%2036.9351%2046.5057%2037.0126C47.0465%2037.8501%2047.5836%2038.7419%2048.1023%2039.6879C48.6211%2040.6378%2049.0846%2041.5722%2049.504%2042.4873C49.0809%2043.4062%2048.6174%2044.3406%2048.0987%2045.2905ZM50.2619%2044.2669C50.6739%2045.2982%2051.0124%2046.2869%2051.292%2047.233C50.3759%2047.4501%2049.39%2047.6362%2048.3378%2047.7758C48.6799%2047.2136%2049.0147%2046.6398%2049.3421%2046.0465C49.6659%2045.4495%2049.9712%2044.8562%2050.2619%2044.2669ZM43.5%2051.9787C42.8488%2051.2343%2042.2087%2050.4239%2041.5796%2049.5515C42.2087%2049.5826%2042.8488%2049.602%2043.5%2049.602C44.1512%2049.602%2044.7913%2049.5826%2045.4204%2049.5515C44.7913%2050.4239%2044.1512%2051.2343%2043.5%2051.9787ZM38.6622%2047.7758C37.61%2047.6362%2036.6278%2047.4501%2035.708%2047.233C35.9876%2046.2869%2036.3261%2045.2982%2036.7381%2044.2669C37.0288%2044.8562%2037.3304%2045.4495%2037.6579%2046.0465C37.9853%2046.6359%2038.3201%2047.2097%2038.6622%2047.7758ZM36.7381%2040.7154C36.3261%2039.684%2035.9876%2038.6953%2035.708%2037.7493C36.6241%2037.5322%2037.6064%2037.3461%2038.6585%2037.2065C38.3201%2037.7648%2037.9816%2038.3386%2037.6579%2038.9357C37.3341%2039.5328%2037.0288%2040.126%2036.7381%2040.7154ZM43.5%2033.0036C44.1365%2033.7286%2044.7803%2034.5467%2045.4167%2035.4346C44.7876%2035.4036%2044.1512%2035.3842%2043.5%2035.3842C42.8488%2035.3842%2042.2124%2035.4036%2041.5833%2035.4346C42.2197%2034.5467%2042.8635%2033.7286%2043.5%2033.0036ZM49.3385%2038.9357C49.011%2038.3425%2048.6763%2037.7687%2048.3378%2037.2065C49.39%2037.3461%2050.3722%2037.5322%2051.2883%2037.7493C51.0087%2038.6953%2050.6702%2039.684%2050.2582%2040.7154C49.9712%2040.126%2049.6659%2039.5328%2049.3385%2038.9357ZM35.9656%2028.7425C36.2304%2028.5797%2036.5468%2028.5022%2036.9074%2028.5022C38.298%2028.5022%2040.3177%2029.708%2042.4957%2031.9296C41.5538%2032.9997%2040.6157%2034.2249%2039.707%2035.5742C38.1435%2035.7254%2036.6682%2035.9697%2035.3181%2036.2954C34.3946%2032.3949%2034.6706%2029.5296%2035.9656%2028.7425ZM28.4348%2042.4911C28.4348%2040.9092%2030.6532%2039.2265%2034.3211%2038.1254C34.7294%2039.5212%2035.2629%2040.9868%2035.9214%2042.4911C35.2666%2043.9955%2034.7294%2045.4611%2034.3211%2046.8569C30.6532%2045.7558%2028.4348%2044.0692%2028.4348%2042.4911ZM41.1565%2054.336C38.9602%2056.2165%2037.0692%2056.9105%2035.9656%2056.2436C34.6669%2055.4527%2034.3946%2052.5874%2035.3181%2048.6908C36.6682%2049.0165%2038.1398%2049.2608%2039.707%2049.412C40.6047%2050.7496%2041.5428%2051.9748%2042.4957%2053.0643C42.0505%2053.5179%2041.6054%2053.9522%2041.1565%2054.336ZM51.0344%2056.2436C49.9344%2056.9144%2048.0398%2056.2204%2045.8435%2054.336C45.3983%2053.9522%2044.9495%2053.5179%2044.5007%2053.0643C45.4572%2051.9748%2046.3916%2050.7496%2047.2893%2049.412C48.8528%2049.2608%2050.3281%2049.0165%2051.6783%2048.6869C52.6054%2052.5874%2052.3294%2055.4527%2051.0344%2056.2436ZM52.6826%2046.8569C52.2742%2045.4611%2051.7408%2043.9955%2051.0823%2042.4911C51.7371%2040.9868%2052.2742%2039.5212%2052.6826%2038.1254C56.3505%2039.2304%2058.5689%2040.9131%2058.5689%2042.4911C58.5652%2044.0692%2056.3468%2045.7558%2052.6826%2046.8569Z'%20fill='%2361DAFB'/%3e%3cdefs%3e%3clinearGradient%20id='paint0_linear_1_12'%20x1='76.1703'%20y1='41.7094'%20x2='-5.08475'%20y2='41.7094'%20gradientUnits='userSpaceOnUse'%3e%3cstop%20stop-color='%2347B4E0'/%3e%3cstop%20offset='0.1718'%20stop-color='%231588E0'/%3e%3cstop%20offset='1'%20stop-color='%236EB4E0'/%3e%3c/linearGradient%3e%3clinearGradient%20id='paint1_linear_1_12'%20x1='75.0889'%20y1='56.2647'%20x2='75.0889'%20y2='27.1539'%20gradientUnits='userSpaceOnUse'%3e%3cstop%20offset='0.0322'%20stop-color='%23F0776F'/%3e%3cstop%20offset='0.5032'%20stop-color='%23F0656F'/%3e%3cstop%20offset='1'%20stop-color='%23F0606F'/%3e%3c/linearGradient%3e%3c/defs%3e%3c/svg%3e";
}));
//#endregion
//#region src/layout/widgets/logo/index.tsx
function oh({ sidebarCollapsed: e, className: t }) {
	let n = u();
	return /* @__PURE__ */ C("div", {
		style: { height: 48 },
		className: Vt("flex items-center justify-center gap-2 cursor-pointer", t),
		onClick: () => n("/home"),
		children: [/* @__PURE__ */ S("img", {
			src: ih,
			alt: "logo",
			width: 32,
			height: 32
		}), /* @__PURE__ */ S(sh, {
			level: 1,
			className: Vt("text-sm m-0", { hidden: e }),
			ellipsis: !0,
			children: "React Antd Admin"
		})]
	});
}
var sh, ch = w((() => {
	ah(), ip(), {Title: sh} = xt;
}));
//#endregion
//#region src/layout/layout-mixed-sidebar/first-column-menu.tsx
function lh({ handleMenuSelect: e, menus: t = dh, sideNavMenuKeyInSplitMode: n }) {
	let r = uh(), { firstColumnWidthInTwoColumnNavigation: i, isDark: a, sidebarTheme: o } = Dr();
	return /* @__PURE__ */ C("div", {
		style: { width: i },
		className: Vt("border-r h-full", o === "dark" ? "border-r-[#303030]" : "border-r-colorBorderSecondary"),
		children: [/* @__PURE__ */ S(oh, { sidebarCollapsed: !0 }), /* @__PURE__ */ S(wp, {
			style: { height: "calc(100% - 48px)" },
			children: /* @__PURE__ */ S(Xe, {
				theme: { components: { Menu: { collapsedWidth: i - 1 } } },
				children: /* @__PURE__ */ S(st, {
					mode: "vertical",
					selectedKeys: [n ?? ""],
					className: Vt(r.menu),
					items: t,
					theme: a ? "dark" : o,
					onClick: ({ key: t }) => e?.(t, "horizontal")
				})
			})
		})]
	});
}
var uh, dh, fh = w((() => {
	Tp(), Or(), ip(), ch(), uh = Kt(({ token: e }) => ({ menu: { "& .ant-menu-item": {
		gap: e.sizeXS,
		height: "60px",
		display: "flex",
		flexDirection: "column",
		alignItems: "center",
		justifyContent: "center",
		"& .ant-menu-title-content": {
			lineHeight: "initial",
			margin: "0px !important",
			fontSize: e.fontSizeIcon
		}
	} } })), dh = [];
}));
//#endregion
//#region src/layout/layout-mixed-sidebar/index.tsx
function ph({ computedSidebarWidth: e = hh, sideNavItems: t = mh, topNavItems: n = mh, handleMenuSelect: r, sideNavMenuKeyInSplitMode: i }) {
	let { isDark: a, sidebarTheme: o, sidebarCollapsed: s, firstColumnWidthInTwoColumnNavigation: c } = Dr(), { token: { Menu: l } } = Et.useToken(), u = a || o === "dark";
	return /* @__PURE__ */ S(Xe, {
		theme: { algorithm: u ? Et.darkAlgorithm : Et.defaultAlgorithm },
		children: /* @__PURE__ */ C("aside", {
			className: "fixed left-0 top-0 bottom-0 flex",
			style: {
				backgroundColor: u ? l?.darkItemBg : l?.itemBg,
				boxShadow: "3px 0 5px 0 rgb(29, 35, 41, 0.05)"
			},
			children: [/* @__PURE__ */ S(lh, {
				sideNavMenuKeyInSplitMode: i,
				menus: n,
				handleMenuSelect: r
			}), /* @__PURE__ */ C("div", {
				style: { width: e - c },
				className: "relative transition-all",
				children: [
					s ? null : /* @__PURE__ */ S(xt.Title, {
						level: 1,
						ellipsis: !0,
						className: "flex items-center my-0 pl-2 text-lg mx-3",
						style: { height: 52 },
						children: "React Antd Admin"
					}),
					/* @__PURE__ */ S("div", {
						className: "overflow-hidden",
						style: { height: s ? "calc(100%  - 40px)" : "calc(100% - 52px - 40px)" },
						children: /* @__PURE__ */ S(wp, { children: /* @__PURE__ */ S(Zm, {
							autoExpandCurrentMenu: !0,
							menus: t,
							handleMenuSelect: r
						}) })
					}),
					/* @__PURE__ */ S(nh, {})
				]
			})]
		})
	});
}
var mh, hh, gh = w((() => {
	Tp(), Or(), ip(), $m(), rh(), fh(), mh = [], hh = 0;
}));
//#endregion
//#region src/layout/layout-mobile-menu/index.tsx
function _h() {
	let e = vh(), { token: { Menu: t } } = Et.useToken(), { sidebarCollapsed: n, setPreferences: r, isDark: i, sidebarTheme: a } = Dr(), { isMobile: o } = qf(), { sideNavItems: s, bottomNavItems: c, handleMenuSelect: l } = eh(), u = y(() => [...s, ...c], [s, c]);
	return o ? /* @__PURE__ */ S(Qe, {
		styles: { body: { backgroundColor: i || a === "dark" ? t?.darkItemBg : t?.itemBg } },
		open: n,
		placement: "left",
		width: "clamp(200px, 50vw, 210px)",
		className: O(e.drawerStyles),
		onClose: () => r("sidebarCollapsed", !1),
		children: /* @__PURE__ */ S(wp, { children: /* @__PURE__ */ S(Zm, {
			autoExpandCurrentMenu: !0,
			menus: u,
			handleMenuSelect: l
		}) })
	}) : null;
}
var vh, yh = w((() => {
	Tp(), Jf(), Or(), k(), $m(), th(), vh = Kt({ drawerStyles: {
		"& .ant-drawer-body": {
			padding: 0,
			"&>ul": { paddingTop: "1em" }
		},
		"& .ant-drawer-header": { display: "none" }
	} });
}));
//#endregion
//#region src/layout/layout-sidebar/index.tsx
function bh({ children: e, computedSidebarWidth: t }) {
	let { sidebarCollapsed: n, sidebarTheme: r, isDark: i } = Dr(), { bottomNavItems: a, handleMenuSelect: o } = eh(), { token: { Menu: s } } = Et.useToken(), c = i || r === "dark";
	return /* @__PURE__ */ S(Xe, {
		theme: { algorithm: c ? Et.darkAlgorithm : Et.defaultAlgorithm },
		children: /* @__PURE__ */ C("aside", {
			style: {
				width: t + 1,
				backgroundColor: c ? s?.darkItemBg : s?.itemBg,
				boxShadow: "3px 0 5px 0 rgb(29, 35, 41, 0.05)"
			},
			className: "fixed top-0 bottom-0 left-0 flex flex-col overflow-x-hidden overflow-y-auto transition-all border-r border-r-colorBorderSecondary",
			children: [
				/* @__PURE__ */ S(oh, { sidebarCollapsed: n }),
				/* @__PURE__ */ S("div", {
					className: "flex-1 min-h-10 overflow-hidden",
					children: /* @__PURE__ */ S(wp, { children: e })
				}),
				a.length > 0 ? /* @__PURE__ */ S("div", {
					className: n ? "shrink-0" : "min-h-0 overflow-y-auto",
					children: /* @__PURE__ */ S(Zm, {
						autoExpandCurrentMenu: !0,
						menus: a,
						handleMenuSelect: o
					})
				}) : null,
				/* @__PURE__ */ S(nh, {})
			]
		})
	});
}
var xh = w((() => {
	Tp(), Or(), $m(), th(), ch(), rh();
}));
//#endregion
//#region src/layout/layout-tabbar/components/draggable-tab-bar.tsx
function Sh({ className: e, children: t, ...n }) {
	let { attributes: r, listeners: i, setNodeRef: a, transform: o, transition: s, isDragging: c } = fn({ id: n["data-node-key"] }), l = {
		...n.style,
		transform: pn.Translate.toString({
			x: o?.x || 0,
			y: 0,
			scaleX: 1,
			scaleY: 1
		}),
		transition: s,
		cursor: c ? "move" : "pointer"
	}, u = {
		ref: a,
		...n,
		style: l,
		className: e,
		...r,
		...i
	};
	return kt(t, u);
}
function Ch({ tabBarProps: e, DefaultTabBar: t, tabItems: n, items: r, onClickMenu: i }) {
	let a = ln(sn, { activationConstraint: { distance: 5 } }), o = pp((e) => e.changeTabOrder);
	return /* @__PURE__ */ S(on, {
		sensors: [a],
		collisionDetection: cn,
		onDragEnd: ({ active: e, over: t }) => {
			e.id !== t?.id && o(e?.data?.current?.sortable?.index, t?.data?.current?.sortable?.index);
		},
		children: /* @__PURE__ */ S(un, {
			items: n.map((e) => e.key),
			strategy: dn,
			children: /* @__PURE__ */ S(t, {
				...e,
				children: (e) => /* @__PURE__ */ S($e, {
					menu: {
						items: r(e.key),
						onClick: ({ key: t }) => i(t, e.key)
					},
					trigger: ["contextMenu"],
					children: n.some((t) => t.key === e.key && t.draggable === !1) ? e : /* @__PURE__ */ S(Sh, {
						...e.props,
						children: e
					})
				}, e.key)
			})
		})
	});
}
var wh = w((() => {
	mp();
}));
//#endregion
//#region src/layout/layout-tabbar/components/tab-maximize.tsx
function Th({ className: e }) {
	let { isMaximize: t } = pp(mn((e) => ({ isMaximize: e.isMaximize }))), { toggleMaximize: n } = pp(mn((e) => ({ toggleMaximize: e.toggleMaximize })));
	return /* @__PURE__ */ S(Cd, {
		className: O(e),
		type: "text",
		size: "middle",
		icon: S(t ? he : ge, {}),
		onClick: () => {
			n(!t);
		}
	});
}
var Eh = w((() => {
	wd(), mp(), k();
}));
//#endregion
//#region src/layout/layout-tabbar/hooks/use-dropdown-menu.tsx
function Dh() {
	let { t: e } = b(), { openTabs: t, activeKey: n, removeTab: r, closeLeftTabs: i, closeRightTabs: a, closeOtherTabs: o, closeAllTabs: s, setIsRefresh: c } = pp(), { refresh: l } = rn(), u = Pt((r) => {
		let i = t.size === 2 && t.has(Oh), a = Array.from(t.keys()).pop() === r;
		return [
			{
				key: kh.REFRESH,
				icon: /* @__PURE__ */ S(Ee, { rotate: 270 }),
				label: e("preferences.tabbar.contextMenu.refresh"),
				disabled: n !== r
			},
			{
				key: kh.CLOSE,
				icon: /* @__PURE__ */ S(ae, {}),
				label: e("preferences.tabbar.contextMenu.close"),
				disabled: r === Oh
			},
			{ type: "divider" },
			{
				key: kh.CLOSE_LEFT,
				icon: /* @__PURE__ */ S(ze, { rotate: 90 }),
				label: e("preferences.tabbar.contextMenu.closeLeft"),
				disabled: r === Oh || i
			},
			{
				key: kh.CLOSE_RIGHT,
				icon: /* @__PURE__ */ S(Ve, { rotate: 90 }),
				label: e("preferences.tabbar.contextMenu.closeRight"),
				disabled: r === Oh || i || a
			},
			{ type: "divider" },
			{
				key: kh.CLOSE_OTHERS,
				icon: /* @__PURE__ */ S(Be, { rotate: 90 }),
				label: e("preferences.tabbar.contextMenu.closeOthers"),
				disabled: r === Oh || i
			},
			{
				key: kh.CLOSE_ALL,
				icon: /* @__PURE__ */ S(Pe, {}),
				label: e("preferences.tabbar.contextMenu.closeAll"),
				disabled: r === Oh
			}
		];
	}, [
		e,
		n,
		t
	]), d = y(() => ({
		[kh.REFRESH]: (e) => {
			l(e), c(!0);
		},
		[kh.CLOSE]: r,
		[kh.CLOSE_RIGHT]: a,
		[kh.CLOSE_LEFT]: i,
		[kh.CLOSE_OTHERS]: o,
		[kh.CLOSE_ALL]: s
	}), [
		l,
		c,
		r,
		a,
		i,
		o,
		s
	]);
	return [u, Pt((e, t) => {
		let n = d[e];
		n && n(t);
	}, [d])];
}
var Oh, kh, Ah = w((() => {
	mp(), Oh = "/home", kh = {
		REFRESH: "refresh",
		CLOSE: "close",
		CLOSE_RIGHT: "closeRight",
		CLOSE_LEFT: "closeLeft",
		CLOSE_OTHERS: "closeOthers",
		CLOSE_ALL: "closeAll"
	};
}));
//#endregion
//#region src/layout/layout-tabbar/components/tab-options.tsx
function jh({ activeKey: e, className: t }) {
	let [n, r] = It(!1), [i, a] = Dh();
	return /* @__PURE__ */ S($e, {
		trigger: ["click"],
		menu: {
			items: i(e),
			onClick: ({ key: t }) => {
				a(t, e), r(!1);
			}
		},
		open: n,
		onOpenChange: (e) => {
			r(e);
		},
		children: /* @__PURE__ */ S(Cd, {
			className: O(t),
			size: "middle",
			type: "text",
			icon: /* @__PURE__ */ S(ue, {})
		})
	});
}
var Mh = w((() => {
	wd(), k(), Ah();
})), Nh, Ph = w((() => {
	Nh = Kt(({ token: e }) => ({
		tabsContainer: {
			backgroundColor: e.colorBgContainer,
			borderTop: `1px solid ${e.colorBorderSecondary}`,
			borderBottom: `1px solid ${e.colorBorderSecondary}`
		},
		resetTabs: {
			"& .ant-tabs-nav::before": { display: "none" },
			"& .ant-tabs-nav": {
				margin: 0,
				"& .ant-tabs-tab": {
					transition: "inherit",
					marginLeft: "0px !important",
					border: "none !important",
					borderRadius: "0px !important",
					paddingTop: "0.3em !important",
					paddingBottom: "0.3em !important"
				}
			}
		},
		brisk: {
			"& .ant-tabs-nav": { "& .ant-tabs-tab": { borderRight: `1px solid ${e.colorBorder} !important` } },
			"& .ant-tabs-ink-bar": {
				backgroundColor: e.colorPrimary,
				visibility: "visible !important"
			}
		},
		plain: { "& .ant-tabs-nav": { "& .ant-tabs-tab": { borderRight: `1px solid ${e.colorBorder} !important` } } },
		chrome: { "& .ant-tabs-nav": {
			"& .ant-tabs-nav-list": { gap: "5px" },
			"& .ant-tabs-tab:not(.ant-tabs-tab-active)": {
				backgroundColor: e.colorBgContainer,
				position: "relative",
				borderRadius: "7px !important",
				padding: "0px 12px !important",
				marginTop: "3px",
				marginBottom: "3px",
				"&:hover": {
					backgroundColor: e.colorBorder,
					color: "inherit"
				},
				"&:hover::before": {
					content: "' '",
					height: "100%",
					width: "1px",
					backgroundColor: e.colorBgContainer,
					left: "-3px",
					position: "absolute"
				},
				"&:hover::after": { display: "none" },
				"&::after": {
					content: "' '",
					position: "absolute",
					right: "-3px",
					width: "1px",
					height: "16px",
					backgroundColor: e.colorBorder
				}
			},
			"& .ant-tabs-tab-active": {
				marginTop: "3px",
				padding: "0px 12px 3px !important",
				backgroundColor: e.colorPrimaryBg,
				borderTopLeftRadius: "7px !important",
				borderTopRightRadius: "7px !important",
				position: "relative",
				"&::before": {
					content: "' '",
					position: "absolute",
					left: "-7px",
					bottom: "0",
					width: "7px",
					height: "7px",
					backgroundColor: e.colorPrimaryBg,
					transform: "rotate(-90deg)",
					zIndex: 1,
					clipPath: "path('M 0 0 A 7 7 0 0 0 7 7 L 0 7 Z')"
				},
				"&>div::before": {
					content: "' '",
					height: "100%",
					width: "1px",
					backgroundColor: e.colorBgContainer,
					left: "-3px",
					position: "absolute"
				},
				"&::after": {
					content: "' '",
					position: "absolute",
					right: "-7px",
					bottom: "0",
					width: "7px",
					height: "7px",
					zIndex: 1,
					backgroundColor: e.colorPrimaryBg,
					clipPath: "path('M 0 0 A 7 7 0 0 0 7 7 L 0 7 Z')"
				}
			}
		} },
		card: {
			"& .ant-tabs-nav-list": { gap: "5px" },
			"& .ant-tabs-nav": {
				"& .ant-tabs-tab": {
					backgroundColor: e.colorBgContainer,
					border: `1px solid ${e.colorBorder} !important`,
					position: "relative",
					borderRadius: "7px !important",
					padding: "0px 12px !important",
					marginTop: "3px",
					marginBottom: "3px",
					"&:hover": {
						backgroundColor: e.colorBorder,
						color: "inherit"
					}
				},
				"& .ant-tabs-tab-active": { backgroundColor: e.colorBgTextActive }
			}
		}
	}));
}));
//#endregion
//#region src/layout/layout-tabbar/index.tsx
function Fh() {
	let e = Nh(), t = u(), n = c(), { t: r } = b(), i = Lf(), { tabbarStyleType: a, tabbarShowMaximize: o, tabbarShowMore: s } = E(), { flatRouteList: l } = j(), { activeKey: d, isRefresh: f, setActiveKey: p, setIsRefresh: m, openTabs: h, addTab: g, insertBeforeTab: ee } = pp(), [te, ne] = Dh(), re = Array.from(h.values()).map((e) => {
		let t = e.newTabTitle ?? e.label;
		return {
			...e,
			label: /* @__PURE__ */ S("div", {
				className: "relative flex items-center gap-1",
				children: hf(t) ? r(t) : t
			})
		};
	});
	v(() => {
		if (f) {
			let e = setTimeout(() => {
				m(!1);
			}, 500);
			return () => clearTimeout(e);
		}
	}, [f, m]);
	let ie = Pt((e) => {
		let n = h.get(e)?.historyState || {
			search: "",
			hash: ""
		};
		t(e + n.search + n.hash);
	}, [h, t]), ae = Pt((e, t) => {
		t === "remove" && ne(kh.CLOSE, e);
	}, [ne]), oe = Pt((e, t) => /* @__PURE__ */ S(Ch, {
		DefaultTabBar: t,
		tabBarProps: e,
		items: te,
		tabItems: re,
		onClickMenu: ne
	}), [
		re,
		te,
		ne
	]), se = y(() => ({ right: /* @__PURE__ */ C("div", {
		className: "flex items-center",
		style: { height: 35 },
		children: [
			/* @__PURE__ */ S(Ke, {
				icon: /* @__PURE__ */ S(Ee, {
					rotate: 270,
					className: Vt({ "animate-spin": f })
				}),
				size: "middle",
				type: "text",
				className: Vt("rounded-none h-full border-l border-l-colorBorderSecondary"),
				onClick: () => ne(kh.REFRESH, d)
			}),
			o ? /* @__PURE__ */ S(Th, { className: "h-full border-l rounded-none border-l-colorBorderSecondary" }) : null,
			s ? /* @__PURE__ */ S(jh, {
				activeKey: d,
				className: "h-full border-l rounded-none border-l-colorBorderSecondary"
			}) : null
		]
	}) }), [
		f,
		d,
		ne,
		s,
		o
	]);
	return v(() => {
		let e = h.get(d)?.historyState || {
			search: "",
			hash: ""
		}, r = d + e.search + e.hash, i = n.pathname + n.search + n.hash;
		d.length > 0 && r !== i && t(r);
	}, [d]), v(() => {
		if (!Array.from(h.keys()).includes("/home")) {
			let e = l["/home"]?.handle?.title;
			ee("/home", {
				key: "/home",
				label: jt(e) ? e.props?.children : e,
				closable: !1,
				draggable: !1
			});
		}
	}, [
		h,
		ee,
		l
	]), v(() => {
		let e = n.pathname, t = Um(e);
		if (t !== d) {
			p(t);
			let e = i.handle?.title;
			g(t, {
				key: t,
				label: jt(e) ? e?.props?.children : e,
				historyState: {
					search: n.search,
					hash: n.hash
				},
				closable: t !== "/home",
				draggable: t !== "/home"
			});
		}
	}, [
		n,
		i,
		p,
		g
	]), /* @__PURE__ */ S("div", {
		className: e.tabsContainer,
		children: /* @__PURE__ */ S(_t, {
			className: Vt(e.resetTabs, a === "brisk" ? e.brisk : "", a === "plain" ? e.plain : "", a === "chrome" ? e.chrome : "", a === "card" ? e.card : ""),
			size: "small",
			hideAdd: !0,
			animated: !0,
			onChange: ie,
			activeKey: Um(d),
			type: "editable-card",
			onEdit: ae,
			items: re,
			renderTabBar: oe,
			tabBarExtraContent: se
		})
	});
}
var Ih = w((() => {
	Rf(), Wm(), fv(), D(), mp(), vf(), ip(), wh(), Eh(), Mh(), Ah(), Ph();
}));
//#endregion
//#region src/layout/widgets/breadcrumb-views/index.tsx
function Lh() {
	let { t: e } = b(), t = l();
	return /* @__PURE__ */ S(Ge, {
		className: "hidden md:block",
		separator: "->",
		itemRender: Rh,
		items: t.filter((e) => e.handle && !e.pathname.endsWith("/")).map((t) => ({
			title: hf(t.handle?.title) ? e(t.handle?.title) : t.handle?.title,
			path: t.pathname
		}))
	});
}
var Rh, zh = w((() => {
	vf(), Rh = (e, t, n) => (n.indexOf(e) === n.length - 1 || e.path, /* @__PURE__ */ S("span", { children: e.title }));
}));
//#endregion
//#region src/layout/container-layout/index.tsx
function Bh() {
	let e = Vh(), { isTopNav: t, isTwoColumnNav: n, isMixedNav: r, sidebarWidth: i, sideCollapsedWidth: a, firstColumnWidthInTwoColumnNavigation: o } = hp(), s = pp((e) => e.isMaximize), { watermark: c, watermarkContent: l, enableFooter: u, fixedFooter: d, enableBackTopButton: f, tabbarEnable: p, sidebarEnable: m, sidebarCollapsed: h, setPreferences: g } = E(), { isMobile: ee } = qf(), { sideNavItems: te, topNavItems: ne, handleMenuSelect: re, sideNavMenuKeyInSplitMode: ie } = eh(), { setLayoutHeaderHeight: ae } = cp(), { setLayoutFooterHeight: oe } = lp();
	v(() => {
		e.lg && !e.xl ? g("sidebarCollapsed", !0) : (e.xl || e.xs || e.sm && !e.md) && g("sidebarCollapsed", !1);
	}, [e, g]);
	let se = y(() => !t && m, [t, m]), ce = y(() => {
		if (s || ee) return 0;
		let e = h ? a : i;
		return n ? e + (o ?? 0) : se ? e : 0;
	}, [
		ee,
		s,
		n,
		se,
		i,
		h,
		a,
		o
	]), le = y(() => {
		let e = 48;
		return p && (e += 35), e;
	}, [p]);
	return v(() => {
		ae(s ? 35 : le);
	}, [le, s]), v(() => {
		oe(40);
	}, []), /* @__PURE__ */ S(Wf, { children: /* @__PURE__ */ S(Ct, {
		content: c ? l : "",
		children: /* @__PURE__ */ C("section", {
			style: { paddingLeft: ce },
			className: O("transition-all flex flex-col h-screen"),
			children: [
				/* @__PURE__ */ S(zm, { children: t || r ? /* @__PURE__ */ C(x, { children: [t ? /* @__PURE__ */ S(oh, {
					sidebarCollapsed: !1,
					className: "mr-8"
				}) : null, /* @__PURE__ */ S(Zm, {
					mode: "horizontal",
					menus: ne,
					handleMenuSelect: re
				})] }) : /* @__PURE__ */ S(Lh, {}) }),
				p ? /* @__PURE__ */ S(Fh, {}) : null,
				/* @__PURE__ */ S(_h, {}),
				se && !n ? /* @__PURE__ */ S(bh, {
					computedSidebarWidth: ce,
					children: /* @__PURE__ */ S(Zm, {
						autoExpandCurrentMenu: !0,
						menus: te,
						handleMenuSelect: re
					})
				}) : null,
				n ? /* @__PURE__ */ S(ph, {
					sideNavMenuKeyInSplitMode: ie,
					computedSidebarWidth: ce,
					sideNavItems: te,
					topNavItems: ne,
					handleMenuSelect: re
				}) : null,
				/* @__PURE__ */ S(Op, {}),
				u && d ? /* @__PURE__ */ S(xd, { className: "bg-colorBgContainer" }) : null,
				f ? /* @__PURE__ */ S(tt.BackTop, {
					icon: /* @__PURE__ */ S(Oe, {}),
					target: () => document.querySelector(`#${$f} .simplebar-content-wrapper`) || document
				}) : null
			]
		})
	}) });
}
var Vh, Hh = w((() => {
	Kf(), Jf(), up(), D(), mp(), k(), ip(), _p(), kp(), Sd(), Bm(), $m(), th(), gh(), yh(), xh(), Ih(), zh(), ch(), {useBreakpoint: Vh} = rt;
}));
//#endregion
//#region src/layout/parent-layout/index.tsx
function Uh() {
	let e = d();
	return /* @__PURE__ */ S(Ot, { children: e });
}
var Wh = w((() => {}));
//#endregion
//#region src/router/utils/resolve-layout.ts
function Gh(e) {
	let t = e?.layout ?? (e?.category === "admin" ? "container" : void 0);
	return !t || t === "none" ? a : Bf(t) || (qh[t] ? qh[t] : (Jh.has(t) || (Jh.add(t), console.warn(`[layout] 未知名布局 "${t}"：既非内建（container/parent/fullscreen），也无模块登记，回落 Outlet。`)), a));
}
function Kh(e) {
	return e.map((e) => {
		let t = !e.Component && e.children?.length ? {
			...e,
			Component: Gh(e.handle)
		} : e;
		return t.children?.length ? {
			...t,
			children: Kh(t.children)
		} : t;
	});
}
var qh, Jh, Yh = w((() => {
	Hh(), Id(), Uf(), Wh(), qh = {
		parent: Uh,
		container: Bh,
		fullscreen: Fd
	}, Jh = /* @__PURE__ */ new Set();
}));
//#endregion
//#region src/router/utils/rewrite-admin-paths.ts
function Xh(e, ...t) {
	if (t.length === 0) {
		if (e.handle?.category !== "admin") return e.path;
		let t = e.id ?? e.path;
		return !t || t === eg || t.startsWith(`${eg}/`) ? t : Qh([{
			...e,
			path: t
		}])[0]?.path;
	}
	let n = t.reduce((e, t) => Zh(t.path, e), "/"), r = e.index ? `${n}/` : e.id ?? Zh(e.path, n), i;
	{
		let e = "/";
		for (let n of t) e = Zh(n.path, e), n.handle?.category === "admin" && (i = e);
	}
	return !r || !i || !r.startsWith(i) ? r : `${eg}${r}`;
}
function Zh(e, t) {
	return e ? e.startsWith("/") ? e : `${t.replace(/\/+$/, "")}/${e}` : t;
}
function Qh(e, t = eg) {
	let n = [];
	return [...e.map((e) => $h(e, "/", t, n, void 0)).filter((e) => e !== null), ...n];
}
function $h(e, t, n, r, i) {
	let a = Zh(e.path, t), o = i ?? a;
	if (e.handle?.category === "admin") {
		let t = `${n}${o}${a.slice(o.length) || ""}`;
		return r.push(...wl([{
			...e,
			path: t
		}], t)), null;
	}
	if (!e.children || e.children.length === 0) return { ...e };
	let s = [];
	for (let t of e.children) {
		let e = $h(t, a, n, r, o);
		e !== null && s.push(e);
	}
	let c = { ...e };
	return c.children = s, c;
}
var eg, tg = w((() => {
	Tl(), eg = "/system";
}));
//#endregion
//#region src/store/header-provider.ts
function ng(e, t) {
	if (ag) {
		console.warn(`[header] 重复的请求头 provider 忽略：已由模块 "${ag.moduleName}" 提供，忽略 "${e}"（先到先得，与 authProvider 同一规则）。`);
		return;
	}
	ag = {
		moduleName: e,
		provider: t
	};
}
function rg() {
	return ag?.provider;
}
function ig(e) {
	ag?.moduleName === e && (ag = void 0);
}
var ag, og = w((() => {}));
//#endregion
//#region src/utils/request/scoped.ts
function sg(e, t, n = M) {
	function r(n) {
		let r = t(), i = (Array.isArray(r) ? r : [r]).filter((e) => typeof e == "string" && e.length > 0);
		if (i.length === 0) throw Error(`[module] 模块 "${e}" 尚未登记 API 前缀：请先在生命周期中调用 ctx.register.apiPrefix("/your-prefix") 再发起请求。`);
		let a;
		try {
			a = new URL(n, "http://scoped.local").pathname;
		} catch {
			a = n;
		}
		if (!i.some((e) => {
			let t = e.endsWith("/") ? e.slice(0, -1) : e;
			return a === t || a.startsWith(`${t}/`);
		})) throw Error(`[module] 模块 "${e}" 请求越界：${n} 不在其登记前缀 ${i.join("、")} 内。请调整接口路径，或登记正确前缀（D11 安全收敛）。`);
	}
	function i(e) {
		if (!e) return e;
		let { prefix: t, prefixUrl: n, ...r } = e;
		return r;
	}
	let a = ((e, t) => (r(String(e)), n(e, i(t))));
	for (let e of [
		"get",
		"post",
		"put",
		"patch",
		"delete",
		"head"
	]) a[e] = ((t, a) => (r(String(t)), n[e](t, i(a))));
	return a;
}
var cg = w((() => {
	Xv();
}));
//#endregion
//#region src/module-loader/keep-alive.ts
function lg(e) {
	let t = [];
	for (let n of e) t.push(...n.routes);
	return t;
}
function ug(e, t) {
	return e ? e.startsWith("/") ? e : `${t.replace(/\/+$/, "")}/${e}` : t;
}
function dg(e) {
	let t = [], n = (e, r) => {
		for (let i of e) {
			let e = ug(i.path, r), a = i.index ? r : e;
			i.handle?.keepAlive === !1 && t.push(a), i.children?.length && n(i.children, e);
		}
	};
	return n(e, ""), t;
}
function fg(e) {
	let t = /* @__PURE__ */ new Set(), n = (e, r) => {
		for (let i of e) {
			let e = ug(i.path, r);
			t.add(i.index ? r : e), i.children?.length && n(i.children, e);
		}
	};
	return n(e, ""), [...t];
}
function pg(e) {
	return dg(lg(e));
}
function mg(e) {
	return fg(lg(e));
}
var hg = w((() => {}));
//#endregion
//#region src/module-loader/semver.ts
function gg(e) {
	let t = /^(\d+)\.(\d+)\.(\d+)/.exec(e.trim());
	return t ? {
		major: Number(t[1]),
		minor: Number(t[2]),
		patch: Number(t[3])
	} : null;
}
function _g(e, t) {
	return e.major - t.major || e.minor - t.minor || e.patch - t.patch;
}
function vg(e, t) {
	let n = /^(>=|<=|[><^~])?(\d+\.\d+\.\d+)$/.exec(t.trim());
	if (!n) return !1;
	let [, r = "", i] = n, a = gg(i);
	switch (r) {
		case "": return _g(e, a) === 0;
		case ">=": return _g(e, a) >= 0;
		case "<=": return _g(e, a) <= 0;
		case ">": return _g(e, a) > 0;
		case "<": return _g(e, a) < 0;
		case "^": return _g(e, a) >= 0 && e.major === a.major;
		case "~": return _g(e, a) >= 0 && e.major === a.major && e.minor === a.minor;
		default: return !1;
	}
}
function yg(e, t) {
	let n = gg(e);
	if (!n) return !1;
	let r = t.trim();
	return r === "*" || r === "" || r.split(/\s+/).every((e) => vg(n, e));
}
var bg = w((() => {}));
//#endregion
//#region src/module-loader/index.ts
function xg(e, t) {
	return {
		module: {
			name: e.name,
			version: e.version,
			routePrefix: t
		},
		utils: { request: sg(e.name, () => Kg.get(e.name)) },
		register: {
			store: (e, t) => {
				Gg.set(e, t);
			},
			apiPrefix: (t) => {
				let n = Kg.get(e.name) ?? [];
				n.includes(t) || n.push(t), Kg.set(e.name, n);
			},
			authProvider: (t) => {
				lf(e.name, t);
			},
			headerProvider: (t) => {
				ng(e.name, t);
			},
			systemApi: (t) => {
				yn(e.name, t);
			},
			notificationsApi: (t) => {
				xn(e.name, t);
			},
			uploadApi: (t) => {
				Cn(e.name, t);
			},
			routesApi: (t) => {
				Tn(e.name, t);
			},
			layout: (t, n) => {
				zf(e.name, t, n);
			}
		},
		registerSlot: (t, n) => {
			Em(e.name, t, n);
		}
	};
}
async function Sg(e) {
	try {
		let t = (await import(
			/* @vite-ignore */
			e.entry
)).default;
		return t.name === e.name ? t : (console.error(`[module-loader] Name mismatch: manifest=${e.name}, actual=${t.name}`), null);
	} catch (t) {
		return console.error(`[module-loader] Failed to load module "${e.name}":`, t), null;
	}
}
function Cg(e, t) {
	let n = [], r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Set();
	function a(o) {
		let s = o.name;
		if (r.has(s)) return;
		if (i.has(s)) {
			console.warn(`[module-loader] Circular dependency detected for "${s}"`);
			return;
		}
		i.add(s);
		let c = t.get(s)?.config?.dependencies ?? [];
		for (let t of c) {
			let n = e.find((e) => e.name === t);
			n ? a(n) : console.warn(`[module-loader] Dependency "${t}" not found for "${s}"`);
		}
		i.delete(s), r.add(s), n.push(o);
	}
	for (let t of e) a(t);
	return n;
}
async function wg(e) {
	if (e.i18n) for (let [t, n] of Object.entries(e.i18n)) {
		let r = await n();
		Bt.addResourceBundle(t, e.name, r.default || r);
	}
	for (let [t, n] of Object.entries(e.i18nNamespaces ?? {})) for (let [e, r] of Object.entries(n)) {
		let n = await r();
		Bt.addResourceBundle(e, t, n.default || n);
	}
}
async function Tg(e) {
	let t = e.modules.filter((e) => e.enabled !== !1), n = await Promise.all(t.map(async (e) => ({
		entry: e,
		definition: await Sg(e)
	}))), r = /* @__PURE__ */ new Map(), i = [];
	for (let { entry: t, definition: a } of n) if (a) {
		let n = a.peerRuntime ?? t.peerRuntime;
		if (e.runtimeVersion && n && !yg(e.runtimeVersion, n)) {
			console.error(`[module-loader] 模块 "${t.name}" 与宿主 runtime 版本不兼容：期望 ${n}，实际 ${e.runtimeVersion}。已跳过加载。修复建议：升级宿主 runtime 或按兼容范围重新构建该模块（US-5）。`), Wg.set(t.name, Pg(t, a, "error", /* @__PURE__ */ Error(`模块 "${t.name}" peerRuntime 不兼容：期望 ${n}，实际 ${e.runtimeVersion}`)));
			continue;
		}
		r.set(t.name, a), i.push(t), Wg.set(t.name, Pg(t, a, "loaded"));
	} else Wg.set(t.name, Pg(t, {
		name: t.name,
		description: "",
		version: "0.0.0",
		routes: []
	}, "error", /* @__PURE__ */ Error("Failed to load module entry")));
	for (let e = i.length - 1; e >= 0; e--) {
		let t = i[e], n = r.get(t.name), a = (n.config?.dependencies ?? t.dependencies ?? []).filter((e) => !r.has(e));
		a.length > 0 && (console.error(`[module-loader] 模块 "${t.name}" 依赖缺失：${a.join(", ")} 未加载。已跳过该模块（不执行生命周期、不注册路由）。修复建议：先部署依赖模块，或在清单中移除该依赖（US-9）。`), Wg.set(t.name, Pg(t, n, "missing-deps", /* @__PURE__ */ Error(`模块 "${t.name}" 依赖缺失：${a.join(", ")}`))), i.splice(e, 1), r.delete(t.name));
	}
	let a = Cg(i, r);
	for (let e of a) {
		let t = r.get(e.name), n = xg(t, Wg.get(e.name).routePrefix);
		try {
			t.lifecycle?.beforeInit && await t.lifecycle.beforeInit(n), t.lifecycle?.onInit && await t.lifecycle.onInit(n), await wg(t);
		} catch (n) {
			console.error(`[module-loader] Lifecycle error for "${e.name}":`, n), Wg.set(e.name, Pg(e, t, "error", n instanceof Error ? n : Error(String(n))));
		}
	}
	let o = Ig();
	return o.length > 0 && j.getState().setAccessStore(o), Array.from(Wg.values());
}
function Eg() {
	return Array.from(Wg.values());
}
function Dg(e) {
	return Wg.get(e);
}
function Og(e) {
	return Wg.get(e)?.routePrefix ?? e;
}
function kg(e, t) {
	return e.map((e) => {
		let n = {
			...e,
			handle: {
				...e.handle,
				module: t
			}
		};
		return Array.isArray(e.children) && e.children.length > 0 && (n.children = kg(e.children, t)), n;
	});
}
function Ag(e, t) {
	return e.map((e) => {
		let n = typeof e.path == "string" ? e.path : "", r = n.startsWith("/"), i = n.replace(/^\/?/, "").split("/")[0] ?? "", a = r ? n.slice(1 + i.length) : n.slice(i.length), o = r ? `/${t}${a}` : `${t}${a}`;
		return {
			...e,
			path: o
		};
	});
}
function jg(e) {
	let t = e[0]?.path;
	if (typeof t == "string" && t.length !== 0) return t.replace(/^\/?/, "").split("/")[0] || void 0;
}
function Mg(e, t) {
	let n = t.replace(/^\/+|\/+$/g, "");
	return n ? e.map((e) => {
		let t = typeof e.path == "string" ? e.path : "";
		return !t || t.startsWith("/") ? e : {
			...e,
			path: `${n}/${t}`
		};
	}) : e;
}
function Ng(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e) {
		let e = (typeof n.path == "string" ? n.path : "").replace(/^\/?/, "").split("/")[0];
		e && t.add(e);
	}
	return t.size > 1;
}
function Pg(e, t, n, r) {
	let i = t.routes ?? [], a = Ng(i);
	return {
		definition: t,
		routePrefix: e.routePrefix ?? (a ? e.name : jg(i) ?? e.name),
		multiRoot: a,
		status: n,
		error: r
	};
}
function Fg(e, t) {
	let n = [];
	for (let r of e) {
		let e = r.handle?.roles;
		if (e?.length && !e.some((e) => t.includes(e))) continue;
		let i = "children" in r && Array.isArray(r.children) ? Fg(r.children, t) : void 0;
		n.push(i ? {
			...r,
			children: i
		} : r);
	}
	return n;
}
function Ig() {
	let { roles: e, permissions: t = [] } = Af.getState(), n = [];
	for (let r of Wg.values()) {
		if (r.status !== "loaded" && r.status !== "active") continue;
		let i = r.definition.config?.requiredRoles;
		if (i?.length && !i.some((t) => e.includes(t))) continue;
		let a = r.definition.config?.requiredPermissions;
		a?.length && !a.every((e) => t.includes(e)) || r.definition.routes.length > 0 && n.push(...Fg(Kh(kg(r.definition.routes, r.definition.name)), e));
	}
	return wl(n);
}
function Lg() {
	return Qh(Ig().map((e) => {
		let t = e.handle?.module;
		if (!t) return e;
		let n = Wg.get(t);
		if (n?.multiRoot) return Mg([e], n.routePrefix)[0] ?? e;
		let r = n?.routePrefix ?? t;
		return Ag([e], r)[0] ?? e;
	}));
}
function Rg(e) {
	return Gg.get(e);
}
function zg(e) {
	return Kg.get(e)?.[0];
}
async function Bg(e) {
	let t = Wg.get(e);
	if (t) {
		let e = xg(t.definition, t.routePrefix);
		t.definition.lifecycle?.onDestroy && await t.definition.lifecycle.onDestroy(e);
	}
	Dm(e), df(e), ig(e), Dn(e), Vf(e), Wg.delete(e);
}
function Vg() {
	return Array.from(Wg.values()).filter((e) => e.status === "loaded" || e.status === "active").map((e) => e.definition);
}
function Hg() {
	return pg(Vg());
}
function Ug() {
	return mg(Vg());
}
var Wg, Gg, Kg, qg = w((() => {
	Uf(), Tl(), Yh(), tg(), fv(), Mn(), pf(), og(), jf(), cg(), hg(), bg(), Am(), Wg = /* @__PURE__ */ new Map(), Gg = /* @__PURE__ */ new Map(), Kg = /* @__PURE__ */ new Map();
}));
//#endregion
//#region src/plugins/loading.ts
function Jg() {
	let e = `
<style>
#${Xg} {
	position: fixed;
	inset: 0;
	z-index: 9999999;
	display: flex;
	align-items: center;
	justify-content: center;
	height: 100vh;
	width: 100vw;
	background-color: ${Cr(E.getState().theme) ? "#181818" : "transparent"};
	overflow: hidden;
}
#${Yg},
#${Yg}::before,
#${Yg}::after {
	width: 2.5em;
	height: 2.5em;
	border-radius: 50%;
	animation: animation-loader 1.8s infinite ease-in-out;
	animation-fill-mode: both;
}

#${Yg} {
	position: relative;
	top: 0;
	margin: 80px auto;
	font-size: 10px;
	color: ${E.getState().themeColorPrimary};
	text-indent: -9999em;
	transform: translateZ(0);
	transform: translate(-50%, 0);
	animation-delay: -0.16s;
}

#${Yg}::before,
#${Yg}::after {
	position: absolute;
	top: 0;
	content: "";
}

#${Yg}::before {
	left: -3.5em;
	animation-delay: -0.32s;
}

#${Yg}::after {
	left: 3.5em;
}

@keyframes animation-loader {
	0%,
	80%,
	100% {
		box-shadow: 0 2.5em 0 -1.3em;
	}

	40% {
		box-shadow: 0 2.5em 0 0;
	}
}
</style>
<div id="${Yg}"></div>
`;
	if (!document.getElementById("loading-container-e8a3a985")) {
		let t = document.createElement("div");
		t.id = Xg, t.innerHTML = `<!-- A loading animation displayed before code loads, driven by setupLoading function -->${e}`;
		let n = document.getElementById("root");
		n && n.before(t);
	}
}
var Yg, Xg, Zg = w((() => {
	D(), wr(), Yg = "loading-e8a3a985", Xg = "loading-container-e8a3a985";
}));
//#endregion
//#region src/plugins/hide-loading.ts
function Qg() {
	let e = document.querySelector(`#${Xg}`);
	e?.setAttribute("style", "visibility: hidden; opacity: 0; transition: all 0.6s ease-out;"), e?.addEventListener("transitionend", () => {
		e.remove();
	}, { once: !0 });
}
var $g = w((() => {
	Zg();
})), e_ = w((() => {})), t_ = /* @__PURE__ */ T({ default: () => n_ });
function n_({ status: e }) {
	let t = u(), n = r_[e];
	return /* @__PURE__ */ S(ut, {
		status: e,
		title: n.title,
		subTitle: n.subTitle,
		extra: /* @__PURE__ */ S(Ke, {
			type: "primary",
			onClick: () => t("/"),
			children: "返回首页"
		})
	});
}
var r_, i_ = w((() => {
	r_ = {
		403: {
			title: "403",
			subTitle: "抱歉，您没有权限访问该页面。"
		},
		404: {
			title: "404",
			subTitle: "抱歉，您访问的页面不存在。"
		},
		500: {
			title: "500",
			subTitle: "抱歉，服务器出现异常，请稍后重试。"
		}
	};
}));
//#endregion
//#region src/router/routes/core/exception.ts
function a_(e, t) {
	for (let n of e) n.path && t.add(n.path), n.children && a_(n.children, t);
}
function o_(e) {
	let t = /* @__PURE__ */ new Set();
	a_(e, t);
	let n = c_.filter((e) => !t.has(e.path));
	return n.length > 0 ? [...e, ...n] : e;
}
var s_, c_, l_ = w((() => {
	qn(), s_ = Mt(() => Promise.resolve().then(() => (i_(), t_))), c_ = [
		{
			path: Wn,
			Component: () => At(s_, { status: "403" }),
			handle: {
				title: "403",
				hideInMenu: !0
			}
		},
		{
			path: Gn,
			Component: () => At(s_, { status: "404" }),
			handle: {
				title: "404",
				hideInMenu: !0
			}
		},
		{
			path: Kn,
			Component: () => At(s_, { status: "500" }),
			handle: {
				title: "500",
				hideInMenu: !0
			}
		}
	];
}));
//#endregion
//#region src/utils/iframe-guard.ts
function u_(e) {
	if (!e) return null;
	let t;
	try {
		t = new URL(e);
	} catch {
		return null;
	}
	return t.protocol === "https:" && d_.some((e) => t.host === e || t.host.endsWith(`.${e}`)) ? e : null;
}
var d_, f_ = w((() => {
	d_ = [
		"ant.design",
		"react.dev",
		"condorheroblog.github.io"
	];
}));
//#endregion
//#region src/components/iframe/index.tsx
function p_() {
	let e = l(), { t } = b(), n = e[e.length - 1], r = n.handle?.iframeLink, i = n.handle?.title, a;
	if (jt(i)) {
		let e = i?.props?.children;
		a = typeof e == "string" ? t(e) : "";
	} else a = typeof i == "string" ? i : "";
	let o = u_(r ?? "");
	return r && !o && console.error(`[iframe] 链接未通过安全校验（须 https 且域名在白名单内），已拒绝渲染：${r}`), o ? /* @__PURE__ */ S("iframe", {
		src: o,
		title: a,
		width: "100%",
		height: "100%",
		loading: "lazy",
		sandbox: "allow-scripts allow-popups",
		className: "p-4 rounded-sm"
	}) : null;
}
var m_ = w((() => {
	f_();
})), h_ = /* @__PURE__ */ T({
	UnknownComponent: () => g_,
	default: () => g_
});
function g_() {
	let { t: e } = b(), t = u();
	return /* @__PURE__ */ S(ut, {
		status: "warning",
		icon: /* @__PURE__ */ S(ee, {}),
		title: e("exception.unknownComponentTitle"),
		subTitle: e("exception.unknownComponentSubTitle"),
		extra: /* @__PURE__ */ C("div", { children: [/* @__PURE__ */ S(__, {
			code: !0,
			copyable: { text: location.href },
			children: location.href
		}), /* @__PURE__ */ S(Ke, {
			icon: /* @__PURE__ */ S(ne, {}),
			type: "primary",
			onClick: () => {
				t(v_);
			},
			children: e("common.backHome")
		})] })
	});
}
var __, v_, y_ = w((() => {
	({Paragraph: __} = xt), {VITE_BASE_HOME_PATH: v_} = { VITE_BASE_HOME_PATH: "/home" };
}));
//#endregion
//#region src/router/utils/generate-routes-from-backend.ts
function b_(e) {
	let t = e.path ?? "/";
	return e.component ? `/packages/runtime/src/pages${e.component}` : `/packages/runtime/src/pages${t}/index.tsx`;
}
async function x_(e) {
	let t = Object.keys(C_);
	if (!e?.length) return [];
	let n = async (e, n) => {
		let r = n, i = t.findIndex((e) => e === r);
		if (i !== -1) {
			let n = C_[t[i]];
			e.Component = Mt(n);
		} else console.warn(`[Frontend component not found]: ${n}`), e.Component = S_;
	}, r = async (e, t) => {
		let i = {
			...e,
			handle: {
				...e.handle,
				backstage: !0
			}
		}, o = i.handle?.icon;
		return hf(o) && (hd[o] ? i.handle.icon = At(hd[o]) : (console.warn(`[backstage-route]: icon "${o}" not found in icons/menu-icons.ts`), i.handle.icon = void 0)), i.index === !0 && t ? await n(i, t) : i.handle?.iframeLink ? i.Component = p_ : i.handle?.externalLink || (i.children?.length ? i.Component = t ? a : Gh(i.handle) : await n(i, b_(i))), i.children?.length && (i.children = await Promise.all(i.children.map((e) => r(e, b_(i))))), i;
	}, i = e.map((e) => e.children?.length ? e : {
		...e,
		children: [{
			index: !0,
			handle: { ...e.handle }
		}]
	});
	return wl(await Promise.all(i.map((e) => r(e))));
}
var S_, C_, w_ = w((() => {
	m_(), gd(), vf(), Tl(), Yh(), S_ = Mt(() => Promise.resolve().then(() => (y_(), h_))), C_ = /* #__PURE__ */ Object.assign({});
}));
//#endregion
//#region src/router/utils/generate-routes-from-frontend.ts
function T_(e, t) {
	return Al(e, (e) => E_(e, t));
}
function E_(e, t) {
	let n = e.handle?.roles;
	return !n || t.some((e) => n.includes(e));
}
var D_ = w((() => {
	Ml();
}));
//#endregion
//#region src/router/guard/utils.ts
function O_(e) {
	let t = /* @__PURE__ */ new Set();
	return e.filter((e) => !t.has(e.path) && (t.add(e.path), !0));
}
var k_ = w((() => {}));
//#endregion
//#region src/router/guard/auth-guard.tsx
function A_({ children: e }) {
	let t = u(), n = Lf(), { pathname: r, search: a } = c(), o = mv((e) => !!e.token), l = Af((e) => !!e.id), d = Af((e) => e.getUserInfo), f = Af((e) => e.roles), { setAccessStore: p, isAccessChecked: m, routeList: h } = j(), { enableBackendAccess: g, enableFrontendAceess: ee } = E((e) => e), te = y(() => new Set(Ig().map((e) => e.path).filter((e) => !!e)), []), ne = y(() => [...te].some((e) => r === e || r.startsWith(`${e}/`)), [te, r]), re = j_.includes(r);
	if (v(() => {
		async function e() {
			Jg();
			let e = [];
			e.push(d()), g && e.push(ir());
			let n = await Promise.allSettled(e), [i, o] = n, s = [], c = [];
			i.status === "fulfilled" && "roles" in i.value && c.push(...i.value?.roles ?? []);
			let l = Ig();
			l.length > 0 && s.push(...l);
			let u = new Set(s.map((e) => e.path).filter(Boolean));
			g && o.status === "fulfilled" && Array.isArray(o.value) && s.push(...await x_(((e) => e.filter((e) => !u.has(e.path)))(o.value))), ee && s.push(...T_(of, c));
			let f = O_(o_(s));
			if (p(f), n.some((e) => e.status === "rejected") && !n.some((e) => e.reason.response.status === 401)) return t(Kn);
			t(`${r}${a}`, {
				replace: !0,
				flushSync: !0
			});
		}
		let n = Ig();
		if (n.length > 0) {
			let e = j.getState().routeList;
			n.every((t) => e.some((e) => e.path === t.path)) || p(n);
		}
		!sf.includes(r) && o && !l && e();
	}, [
		r,
		o,
		l
	]), re) return Qg(), e;
	if (!o) {
		if (Qg(), ne) return e;
		if (r !== "/login") {
			let e = r.length > 1 ? `${Hn}?redirect=${r}${a}` : Hn;
			return /* @__PURE__ */ S(i, {
				to: e,
				replace: !0
			});
		}
		return e;
	}
	if (r === "/login") {
		let e = Ld(a);
		return e === r ? /* @__PURE__ */ S(i, {
			to: "/home",
			replace: !0
		}) : /* @__PURE__ */ S(i, {
			to: e,
			replace: !0
		});
	}
	if (!l && !ne || !m && !ne) return null;
	if (Qg(), r === "/") return /* @__PURE__ */ S(i, {
		to: "/home",
		replace: !0
	});
	let ie = n?.handle?.roles;
	if (n?.handle?.ignoreAccess === !0) return e;
	let ae = s(h, r) ?? [], oe = ae[ae.length - 1]?.route?.children?.filter((e) => !e.index)?.length;
	if (oe && oe > 0) return /* @__PURE__ */ S(i, {
		to: Gn,
		replace: !0
	});
	let se = f.some((e) => ie?.includes(e));
	return ie && ie.length && !se ? /* @__PURE__ */ S(i, {
		to: Wn,
		replace: !0
	}) : e;
}
var j_, M_ = w((() => {
	sr(), Rf(), qg(), $g(), Zg(), Jn(), cf(), e_(), l_(), w_(), D_(), fv(), hv(), D(), jf(), Rd(), k_(), j_ = Array.from(sf).filter((e) => e !== Hn);
})), N_ = w((() => {
	M_();
}));
//#endregion
//#region src/layout/layout-root/index.tsx
function P_() {
	return /* @__PURE__ */ C(m, {
		FallbackComponent: br,
		children: [/* @__PURE__ */ S(Ff, {}), /* @__PURE__ */ S(A_, { children: /* @__PURE__ */ S(a, {}) })]
	});
}
var F_ = w((() => {
	Sr(), If(), N_();
})), I_, L_ = w((() => {
	I_ = "root-route";
}));
//#endregion
//#region src/router/index.ts
function R_() {
	return o(B_, { basename: Ln() });
}
var z_, B_, V_, H_ = w((() => {
	F_(), D(), Mf(), Bn(), L_(), cf(), z_ = /* @__PURE__ */ new Set(), B_ = [{
		path: "/",
		id: I_,
		Component: P_,
		children: af,
		loader: ({ request: e }) => {
			let { transitionProgress: t } = E.getState();
			if (t) {
				Wt.start();
				let t = new URL(e.url).pathname;
				z_.add(t);
			}
			return null;
		},
		shouldRevalidate: ({ nextUrl: e, currentUrl: t }) => {
			if (e.pathname === t.pathname) return !1;
			let { transitionProgress: n } = E.getState(), r = z_.has(e.pathname);
			return n && !r && (Wt.start(), z_.add(e.pathname)), !1;
		}
	}], V_ = R_();
}));
//#endregion
//#region src/router/utils/flatten-routes.ts
function U_(e) {
	let t = {};
	function n(e, r) {
		e.forEach((e) => {
			e.index && r?.path && (t[`${r.path}/`] = e), e.path && (t[e.path] = e), e.children && e.children.length > 0 && n(e.children, e);
		});
	}
	return n(e), t;
}
var W_ = w((() => {}));
//#endregion
//#region src/router/utils/generate-menu-items-from-routes.ts
function G_(e, t) {
	return e ? e.startsWith("/") ? e : `${t.replace(/\/+$/, "")}/${e}` : t;
}
function K_(e, t = "/") {
	return e.reduce((e, n) => {
		let i = n.handle, a = i?.title, o = i?.externalLink, s = i?.icon, c = G_(n.path, t), l = {
			key: n.index ? `${c.replace(/\/+$/, "")}/` : c,
			label: o ? At(r, {
				onClick: (e) => {
					e.stopPropagation();
				},
				to: o,
				target: "_blank",
				rel: "noopener noreferrer"
			}, a) : a
		};
		if (s && (l.icon = s), i?.module && (l.module = i.module), i?.category && (l.category = i.category), i?.order !== void 0 && (l.order = i.order), Array.isArray(n.children) && n.children.length > 0) {
			let e = n.children.filter((e) => !e?.handle?.hideInMenu && e?.handle?.category !== "hidden"), t = e.filter((e) => !e.index), r = t.length > 0 ? e : t;
			r.length > 0 && (l.children = K_(r, c));
		}
		return i?.hideInMenu || i?.category === "hidden" ? e : [...e, l];
	}, []);
}
var q_ = w((() => {}));
//#endregion
//#region src/router/utils/group-solution-menus.ts
function J_(e) {
	ev.has(e) || (ev.add(e), console.warn(e));
}
function Y_(e, t) {
	return {
		module: e.module ?? t?.module,
		category: e.category ?? t?.category
	};
}
function X_(e, t, n) {
	let r = !1, i = [];
	for (let a of e) {
		let { module: e, category: o } = Y_(a, t.get(a.key));
		if (o === "admin" && e) {
			let t = a.children && a.children.length > 0 ? a.children : [a], i = n.get(e) ?? {
				items: [],
				module: e,
				minOrder: Infinity
			};
			for (let e of t) i.items.push(e);
			i.minOrder = Math.min(i.minOrder, a.order ?? 0), n.set(e, i), r = !0;
			continue;
		}
		if (a.children && a.children.length > 0) {
			let e = X_(a.children, t, n);
			e === a.children ? i.push(a) : (r = !0, i.push({
				...a,
				children: e
			}));
		} else i.push(a);
	}
	return r ? i : e;
}
function Z_(e, t) {
	let n = t.map((e) => ({
		item: e,
		order: e.order ?? 0
	})).sort((e, t) => e.order - t.order);
	return {
		key: `${$_}${e}`,
		label: `${e}:menu.main`,
		children: n.map((e) => e.item)
	};
}
function Q_(e, t, n, r = {}) {
	let i = r.systemKey ?? "/system", a = r.onWarn ?? J_, o = /* @__PURE__ */ new Map();
	for (let e of n ?? []) e.category === "admin" && e.enabled !== !1 && o.set(e.path, e);
	let s = /* @__PURE__ */ new Map(), c = X_(e, o, s), l = X_(t, o, s), u = [...s.entries()].map(([e, t]) => ({
		minOrder: t.minOrder,
		group: Z_(e, t.items)
	})).sort((e, t) => e.minOrder - t.minOrder), d = l, f = l.findIndex((e) => e.key === i);
	if (u.length > 0) {
		if (f !== -1) {
			let e = l[f];
			d = l.slice(), d[f] = {
				...e,
				children: [...e.children ?? [], ...u.map((e) => e.group)]
			};
		} else a(`[solution-menu-grouping] system menu "${i}" not found; admin items dropped from menu.`);
	}
	return {
		top: c,
		bottom: d
	};
}
var $_, ev, tv = w((() => {
	$_ = "solgroup:admin:", ev = /* @__PURE__ */ new Set();
}));
//#endregion
//#region src/router/utils/merge-solution-categories.ts
function nv(e, t) {
	if (t.length === 0) return e;
	let n = new Map(t.map((e) => [e.path, e]));
	return e.map((e) => {
		let t = e.path ? n.get(e.path) : void 0;
		return !t || t.enabled !== !1 ? e : {
			...e,
			handle: {
				...e.handle,
				hideInMenu: !0
			}
		};
	});
}
var rv = w((() => {}));
//#endregion
//#region src/router/utils/resolve-login-route.ts
function iv(e, t, n, r) {
	let i;
	for (let e of t) if (!(!av(e) || e.handle?.internal === !0)) {
		if (e.path !== "/login") {
			console.warn(`[login] handle.login 拒绝：契约路径必须是 ${Hn}，收到 "${e.path}"`);
			continue;
		}
		if (i) {
			console.warn(`[login] 重复的 login 路由忽略：${Hn} 已由先注册的模块提供`);
			continue;
		}
		i = e;
	}
	if (!i) return e;
	let [a] = r;
	return n._internalSetRoutes([{
		...a,
		children: (a.children ?? []).filter((e) => !ov(e))
	}]), n.patchRoutes(I_, [i]), e.filter((e) => !ov(e));
}
var av, ov, sv = w((() => {
	L_(), Jn(), av = (e) => e.handle?.login === !0, ov = (e) => e?.handle?.login === !0 && e?.handle?.internal === !0;
}));
//#endregion
//#region src/store/access.ts
function cv(e) {
	let t = e.findIndex((e) => (e.handle.order ?? 0) < 0);
	return t === -1 ? {
		top: e,
		bottom: []
	} : {
		top: e.slice(0, t),
		bottom: e.slice(t)
	};
}
var lv, uv, dv, j, fv = w((() => {
	H_(), L_(), cf(), Cl(), W_(), q_(), tv(), rv(), sv(), tg(), lv = cv(af), uv = {
		wholeMenus: K_(lv.top),
		bottomMenus: K_(lv.bottom),
		routeList: af,
		flatRouteList: U_(af),
		isAccessChecked: !1,
		solutionRoutes: []
	}, dv = [], j = t((e, t) => ({
		...uv,
		setAccessStore: (n) => {
			let r = Qh(n), i = Sl([...iv(af, r, V_, B_), ...nv(r, t().solutionRoutes)]);
			V_.patchRoutes(I_, r);
			let a = U_(i), { top: o, bottom: s } = cv(i), c = Q_(K_(o), K_(s), t().solutionRoutes), l = {
				wholeMenus: c.top,
				bottomMenus: c.bottom,
				routeList: i,
				flatRouteList: a,
				isAccessChecked: !0
			};
			return dv = n, e(() => l), l;
		},
		setSolutionRoutes: (n) => {
			e({ solutionRoutes: n }), dv.length > 0 && t().setAccessStore(dv);
		},
		reset: () => {
			V_._internalSetRoutes(B_), e(uv), dv.length > 0 && j.getState().setAccessStore(dv);
		}
	}));
})), pv, mv, hv = w((() => {
	sr(), fv(), pf(), mp(), jf(), vr(), pv = {
		token: "",
		refreshToken: ""
	}, mv = t()(n((e, t) => ({
		...pv,
		login: async (t) => {
			let n = uf();
			if (n) {
				e(await n.login(t));
				return;
			}
			e(await nr(t));
		},
		logout: async () => {
			try {
				let e = uf();
				e ? await e.logout() : await rr({ refreshToken: t().refreshToken });
			} finally {
				t().reset();
			}
		},
		reset: () => {
			e({ ...pv }), Af.getState().reset(), j.getState().reset(), pp.getState().resetTabs();
		}
	}), { name: _r("access-token") }));
}));
//#endregion
//#region src/store/tenant.ts
function gv() {
	let e = new URLSearchParams(window.location.search).get(yv)?.trim();
	return e && xv.getState().setTenant(e), xv.getState().tenant;
}
function _v() {
	return xv.getState().tenant || "default";
}
var vv, yv, bv, xv, Sv = w((() => {
	vv = "default", yv = "tenant", bv = "X-TENANT-ID", xv = t()(n((e) => ({
		tenant: vv,
		setTenant: (t) => e({ tenant: t.trim() || "default" }),
		clear: () => e({ tenant: vv })
	}), { name: "oj-tenant" })), typeof window < "u" && gv();
}));
//#endregion
//#region src/utils/api-base.ts
function Cv(e) {
	let t = e?.trim();
	return t && t.replace(/\/+$/, "") || Tv;
}
function wv() {
	let e = globalThis.__OJ_API_BASE__;
	return Cv(typeof e == "string" ? e : "/api");
}
var Tv, Ev = w((() => {
	Tv = "/api";
}));
//#endregion
//#region src/utils/request/error-response.ts
async function Dv(e) {
	let t = await e.clone().text().catch(() => ""), n;
	try {
		n = JSON.parse(t);
	} catch {}
	if (gf(n)) {
		if (Tf(n)) return Ef(), e;
		if (e.status === 403) return e;
		let t = n;
		bf.error(t.msg || e.statusText);
	} else e.status !== 403 && bf.error(e.statusText);
	return e;
}
var Ov = w((() => {
	vf(), wf(), Of();
})), kv, Av, jv = w((() => {
	bp(), kv = 0, Av = {
		start() {
			kv === 0 && yp.getState().openGlobalSpin(), kv++;
		},
		done() {
			kv = Math.max(kv - 1, 0), kv === 0 && yp.getState().closeGlobalSpin();
		},
		forceFinish() {
			kv = 0, yp.getState().closeGlobalSpin();
		}
	};
}));
//#endregion
//#region src/utils/remember-route/index.ts
function Mv() {
	let { pathname: e, search: t } = window.location, n = Ln(), r = n === "/" ? e : `/${e.slice(n.length)}`;
	return r.length > 1 && r !== "/login" ? `?redirect=${r}${t}` : "";
}
var Nv = w((() => {
	Jn(), Bn();
}));
//#endregion
//#region src/utils/request/go-login.ts
function Pv() {
	mv.getState().reset(), window.location.href = `${Ln()}login${Mv()}`;
}
var Fv = w((() => {
	hv(), Nv(), Bn();
}));
//#endregion
//#region src/utils/request/header-safe.ts
function Iv(e) {
	for (let t of e) if (t.charCodeAt(0) > 255) return !1;
	return !0;
}
function Lv(e, t, n) {
	let r = Iv(t) ? t : encodeURIComponent(t), i = Iv(n) ? n : encodeURIComponent(n);
	e.set(r, i);
}
var Rv = w((() => {}));
//#endregion
//#region src/utils/request/refresh.ts
async function zv(t, n, r) {
	if (Uv) return new Promise((r, i) => {
		Hv({
			resolve: async (i) => {
				Lv(t.headers, Yn, `Bearer ${i}`), r(e(t, n));
			},
			reject: i
		});
	});
	Uv = !0;
	try {
		let i = await or({ refreshToken: r });
		return mv.setState({
			token: i.token,
			refreshToken: i.refreshToken
		}), Bv(i.token), Lv(t.headers, Yn, `Bearer ${i.token}`), e(t, n);
	} catch (e) {
		throw Vv(e), Pv(), e;
	} finally {
		Uv = !1;
	}
}
function Bv(e) {
	Wv.forEach((t) => t.resolve(e)), Wv = [];
}
function Vv(e) {
	Wv.forEach((t) => t.reject(e)), Wv = [];
}
function Hv(e) {
	Wv.push(e);
}
var Uv, Wv, Gv = w((() => {
	sr(), hv(), $n(), Fv(), Rv(), Uv = !1, Wv = [];
}));
//#endregion
//#region src/utils/request/whitelist.ts
function Kv(e) {
	return qv.some((t) => e.endsWith(t));
}
var qv, Jv = w((() => {
	$n(), qv = [Qn];
})), Yv, M, Xv = w((() => {
	Jn(), hv(), og(), D(), Sv(), Ev(), $n(), Ov(), jv(), Fv(), Rv(), Gv(), Jv(), Yv = {
		prefix: wv(),
		timeout: 1e4,
		retry: { limit: 3 },
		hooks: {
			beforeRequest: [({ request: e, options: t }) => {
				if (t.ignoreLoading || Av.start(), !Kv(e.url)) {
					let { token: t } = mv.getState();
					Lv(e.headers, Yn, `Bearer ${t}`);
				}
				Lv(e.headers, Xn, E.getState().language), Lv(e.headers, bv, _v());
				let n = rg();
				if (n) for (let [t, r] of Object.entries(n())) Lv(e.headers, t, r);
			}],
			afterResponse: [async ({ request: e, options: t, response: n }) => {
				if (t.ignoreLoading || Av.done(), !n.ok) {
					if (n.status === 401) {
						if (["/auth/refresh"].some((t) => e.url.endsWith(t))) return Pv(), n;
						let { refreshToken: r } = mv.getState();
						return r ? zv(e, t, r) : (Vn(location.pathname) || Pv(), n);
					}
					return t.silentError ? n : Dv(n);
				}
				return n;
			}]
		}
	}, M = e.create(Yv);
}));
//#endregion
//#region src/api/rbac/index.ts
Xv();
function Zv(e) {
	return M.get(e).json().then((e) => e.data);
}
function Qv(e, t) {
	return M.post(e, { json: t }).json().then((e) => e.data);
}
function $v(e, t) {
	return M.put(e, { json: t }).json().then((e) => e.data);
}
function ey(e) {
	return M.delete(e).json().then((e) => e.data);
}
var ty = () => Zv("system/roles"), ny = () => Zv("system/permissions"), ry = (e) => Qv("system/roles", e), iy = (e, t) => $v(`system/roles/bindings?name=${encodeURIComponent(e)}`, { permissions: t }), ay = (e) => ey(`system/roles?name=${encodeURIComponent(e)}`), oy = () => Zv("system/users"), sy = (e) => Qv("system/users", e), cy = (e, t) => $v(`system/users/roles?uid=${e}`, { roles: t }), ly = (e, t) => $v(`system/users/password?uid=${e}`, { password: t }), uy = (e, t) => $v(`system/users/forbidden?uid=${e}`, { forbidden: t });
function dy(e) {
	let t = new URLSearchParams();
	for (let [n, r] of Object.entries(e)) r != null && r !== "" && t.set(n, String(r));
	return Zv(`system/oplog?${t.toString()}`);
}
var fy = (e) => Qv("system/oplog", e), py = () => Zv("system/settings"), my = (e, t) => $v("system/settings", {
	key: e,
	value: t
}), hy = () => Zv("_platform/solutions/routes");
function gy(e, t) {
	return Zv(`_platform/contacts?keyword=${encodeURIComponent(e)}${t ? `&limit=${t}` : ""}`);
}
var _y = (e) => Zv(`_platform/contacts/detail?id=${e}`), vy = () => Zv("system/login-methods"), yy = (e) => $v("auth/password", e), by = (e) => Qv("auth/ldap-login", e);
//#endregion
//#region src/api/rbac/helpers.ts
function xy(e) {
	return e.title || e.name;
}
function Sy(e) {
	return !e.builtin;
}
function Cy(e) {
	return !e.builtin && e.holders === 0;
}
function wy(e, t) {
	return e.includes("superadmin") ? !0 : e.includes("admin") ? t !== "superadmin" && t !== "admin" : !1;
}
function Ty(e, t) {
	let n = new Set(e), r = new Set(t);
	return {
		added: t.filter((e) => !n.has(e)),
		removed: e.filter((e) => !r.has(e))
	};
}
function Ey(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) (t.get(n.module) ?? t.set(n.module, []).get(n.module)).push(n);
	return [...t.entries()].map(([e, t]) => ({
		module: e,
		items: t
	}));
}
var Dy = /* @__PURE__ */ new Set([
	"framework",
	"market",
	"ldap",
	"sso"
]);
function Oy(e) {
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
	for (let r of e) if (Dy.has(r.module)) (t.get(r.group) ?? t.set(r.group, []).get(r.group)).push(r);
	else {
		let e = n.get(r.module) ?? n.set(r.module, /* @__PURE__ */ new Map()).get(r.module);
		(e.get(r.group) ?? e.set(r.group, []).get(r.group)).push(r);
	}
	let r = [];
	for (let [e, n] of t) r.push({
		module: null,
		group: e,
		label_key: null,
		items: n
	});
	for (let e of [...n.keys()].sort()) for (let [t, i] of n.get(e)) r.push({
		module: e,
		group: t,
		label_key: `${e}:settings.group.${t}`,
		items: i
	});
	return r;
}
Mn(), Xv(), Vp();
function ky(e) {
	let t = bn();
	return t ? t.fetchMenuList(e) : Bp(M.get("menu-list", {
		searchParams: e,
		ignoreLoading: !0
	}).json());
}
function Ay(e) {
	let t = bn();
	return t ? t.fetchAddMenuItem(e) : Bp(M.post("menu-item", {
		json: e,
		ignoreLoading: !0
	}).json());
}
function jy(e) {
	let t = bn();
	return t ? t.fetchUpdateMenuItem(e) : Bp(M.put("menu-item", {
		json: e,
		ignoreLoading: !0
	}).json());
}
function My(e) {
	let t = bn();
	return t ? t.fetchDeleteMenuItem(e) : Bp(M.delete("menu-item", {
		json: e,
		ignoreLoading: !0
	}).json());
}
//#endregion
//#region src/api/system/role/client/api.ts
Xv();
function Ny() {
	return M;
}
async function Py(e) {
	if (e instanceof hn) return e;
	let t = e, n = t?.response, r = t?.data;
	return n instanceof Response && r && typeof r.code == "number" ? new hn(r.code, r.msg ?? n.statusText) : e;
}
async function Fy(e) {
	let t = Ny();
	try {
		let n = await t.post("role-item", {
			json: e,
			ignoreLoading: !0
		}).json();
		if (typeof n.code == "number" && n.code !== 0) throw new hn(n.code, n.msg ?? "业务错误（信封 code 非 0）");
		return n.data;
	} catch (e) {
		throw await Py(e);
	}
}
async function Iy(e) {
	let t = Ny();
	try {
		let n = await t.delete("role-item", {
			json: e,
			ignoreLoading: !0
		}).json();
		if (typeof n.code == "number" && n.code !== 0) throw new hn(n.code, n.msg ?? "业务错误（信封 code 非 0）");
		return n.data;
	} catch (e) {
		throw await Py(e);
	}
}
async function Ly(e) {
	let t = Ny();
	try {
		let n = await t.get("menu-by-role-id", { searchParams: e }).json();
		if (typeof n.code == "number" && n.code !== 0) throw new hn(n.code, n.msg ?? "业务错误（信封 code 非 0）");
		return n.data;
	} catch (e) {
		throw await Py(e);
	}
}
async function Ry(e) {
	let t = Ny();
	try {
		let n = await t.get("role-list", {
			searchParams: e,
			ignoreLoading: !0
		}).json();
		if (typeof n.code == "number" && n.code !== 0) throw new hn(n.code, n.msg ?? "业务错误（信封 code 非 0）");
		return n.data;
	} catch (e) {
		throw await Py(e);
	}
}
async function zy() {
	let e = Ny();
	try {
		let t = await e.get("role-menu", { ignoreLoading: !0 }).json();
		if (typeof t.code == "number" && t.code !== 0) throw new hn(t.code, t.msg ?? "业务错误（信封 code 非 0）");
		return t.data;
	} catch (e) {
		throw await Py(e);
	}
}
async function By(e) {
	let t = Ny();
	try {
		let n = await t.put("role-item", {
			json: e,
			ignoreLoading: !0
		}).json();
		if (typeof n.code == "number" && n.code !== 0) throw new hn(n.code, n.msg ?? "业务错误（信封 code 非 0）");
		return n.data;
	} catch (e) {
		throw await Py(e);
	}
}
//#endregion
//#region src/api/system/role/index.ts
Mn();
async function Vy(e) {
	return bn()?.fetchRoleList(e) ?? Ry(e);
}
async function Hy(e) {
	return bn()?.fetchAddRoleItem(e) ?? Fy(e);
}
async function Uy(e) {
	return bn()?.fetchUpdateRoleItem(e) ?? By(e);
}
async function Wy(e) {
	return bn()?.fetchDeleteRoleItem(e) ?? Iy(e);
}
async function Gy() {
	return bn()?.fetchRoleMenu() ?? zy();
}
async function Ky(e) {
	return bn()?.fetchMenuByRoleId(e) ?? Ly(e);
}
//#endregion
//#region src/hooks/use-access/constants.ts
var qy = "permission:button", Jy = {
	get: `${qy}:get`,
	update: `${qy}:update`,
	delete: `${qy}:delete`,
	add: `${qy}:add`
}, Yy = {
	admin: "admin",
	common: "common"
};
jf(), vf();
function Xy() {
	let e = l(), { roles: t } = Af(), n = e[e.length - 1];
	return {
		hasAccessByCodes: (e) => {
			if (!e) return !1;
			let t = n?.handle?.permissions;
			return t ? (e = hf(e) ? [e] : e, e = e.map((e) => e.toLowerCase()), t.some((t) => e.includes(t.toLowerCase()))) : !1;
		},
		hasAccessByRoles: (e) => !e || !t ? !1 : (e = hf(e) ? [e] : e, e = e.map((e) => e.toLowerCase()), t.some((t) => e.includes(t.toLowerCase())))
	};
}
//#endregion
//#region src/components/access-control/index.ts
function Zy({ type: e = "code", codes: t, children: n, fallback: r }) {
	let { hasAccessByCodes: i, hasAccessByRoles: a } = Xy();
	return n ? !e || e === "code" ? i(t) ? n : r : e === "role" && a(t) ? n : r : null;
}
//#endregion
//#region src/components/antd-app/constants.ts
var Qy = [
	"blue",
	"purple",
	"cyan",
	"green",
	"magenta",
	"pink",
	"red",
	"orange",
	"yellow",
	"volcano",
	"geekblue",
	"gold",
	"lime"
], $y = [
	"colorPrimary",
	"colorPrimaryBg",
	"colorPrimaryBgHover",
	"colorPrimaryBorder",
	"colorPrimaryBorderHover",
	"colorPrimaryHover",
	"colorPrimaryActive",
	"colorPrimaryTextHover",
	"colorPrimaryText",
	"colorPrimaryTextActive"
], eb = [
	"colorSuccess",
	"colorSuccessBg",
	"colorSuccessBgHover",
	"colorSuccessBorder",
	"colorSuccessBorderHover",
	"colorSuccessHover",
	"colorSuccessActive",
	"colorSuccessTextHover",
	"colorSuccessText",
	"colorSuccessTextActive"
], tb = [
	"colorWarning",
	"colorWarningBg",
	"colorWarningBgHover",
	"colorWarningBorder",
	"colorWarningBorderHover",
	"colorWarningHover",
	"colorWarningActive",
	"colorWarningTextHover",
	"colorWarningText",
	"colorWarningTextActive"
], nb = [
	"colorError",
	"colorErrorBg",
	"colorErrorBgHover",
	"colorErrorBorder",
	"colorErrorBorderHover",
	"colorErrorHover",
	"colorErrorActive",
	"colorErrorTextHover",
	"colorErrorText",
	"colorErrorTextActive"
], rb = [
	"colorInfo",
	"colorInfoBg",
	"colorInfoBgHover",
	"colorInfoBorder",
	"colorInfoBorderHover",
	"colorInfoHover",
	"colorInfoActive",
	"colorInfoTextHover",
	"colorInfoText",
	"colorInfoTextActive"
], ib = [
	...eb,
	...tb,
	...nb,
	...rb
], ab = [
	"colorText",
	"colorTextSecondary",
	"colorTextTertiary",
	"colorTextQuaternary",
	"colorBgContainer",
	"colorBgElevated",
	"colorBgLayout",
	"colorBgSpotlight",
	"colorBgMask",
	"colorBorder",
	"colorBorderSecondary",
	"colorFill",
	"colorFillSecondary",
	"colorFillTertiary",
	"colorFillQuaternary"
], ob = [...$y, ...ib], sb = Qy.flatMap((e) => [e, ...Array.from({ length: 10 }, (t, n) => `${e}-${n + 1}`)]);
//#endregion
//#region src/components/antd-app/utils.ts
function cb(e) {
	return e = e.replace("#", ""), `${Number.parseInt(e.substring(0, 2), 16)} ${Number.parseInt(e.substring(2, 4), 16)} ${Number.parseInt(e.substring(4, 6), 16)}`;
}
function lb(e) {
	return e.trim().startsWith("rgb");
}
function ub(e) {
	return Object.entries(e).reduce((e, [t, n]) => ob.includes(t) ? `${e}--oo-${t}:${cb(n)};` : ab.includes(t) ? `${e}--oo-${t}:${lb(n) ? n : `rgb(${cb(n)})`};` : sb.includes(t) ? `${e}--oo-${t}:${cb(n)};` : e, "");
}
//#endregion
//#region src/components/antd-app/setup-antd-theme.ts
function db(e) {
	let t = ub(e), n = "antd-theme-tokens", r = document.querySelector(`#${n}`) || document.createElement("style");
	r.id = n, r.textContent = `:root { ${t} }`, document.head.appendChild(r);
}
//#endregion
//#region src/components/antd-app/index.tsx
wf();
function fb({ children: e }) {
	let { token: t } = Et.useToken();
	return v(() => {
		db(t);
	}, [t]), /* @__PURE__ */ C(He, {
		className: "h-full",
		children: [/* @__PURE__ */ S(yf, {}), e]
	});
}
//#endregion
//#region src/components/basic-content/index.tsx
function pb(e) {
	let { children: t, className: n, style: r } = e;
	return /* @__PURE__ */ S("div", {
		id: "basic-content",
		className: Vt("p-4 box-border", n),
		style: { ...r },
		children: t
	});
}
Mn(), Ev();
function mb({ value: e, onChange: t }) {
	let { t: n } = b(), r = wn(), i = r?.action ?? `${wv()}/upload`, a = r?.headers() ?? { authorization: "authorization-text" };
	return /* @__PURE__ */ S(x, { children: /* @__PURE__ */ C("div", {
		className: "flex items-center gap-5",
		children: [/* @__PURE__ */ S(Ue, {
			size: 100,
			src: e
		}), /* @__PURE__ */ S(gn, {
			rotationSlider: !0,
			aspectSlider: !0,
			showReset: !0,
			showGrid: !0,
			cropShape: "rect",
			children: /* @__PURE__ */ S(St, {
				accept: "image/*",
				showUploadList: !1,
				name: "file",
				action: i,
				headers: a,
				onChange: (e) => {
					e.file.status === "done" ? (window.$message?.success(n("common.uploadSuccess", { name: e.file.name })), t?.(e.file.response?.data)) : e.file.status === "error" && window.$message?.error(n("common.uploadFailed", { name: e.file.name }));
				},
				children: /* @__PURE__ */ S(Ke, {
					icon: /* @__PURE__ */ S(Le, {}),
					children: n("common.avatarChange")
				})
			})
		})]
	}) });
}
//#endregion
//#region src/components/basic-form/form-items/form-tree-item.tsx
var { Search: hb } = it;
function gb(e, t) {
	let n;
	for (let r = 0; r < t.length; r++) {
		let i = t[r];
		i.children && (i.children.some((t) => t.id === e) ? n = i.id : gb(e, i.children) && (n = gb(e, i.children)));
	}
	return n;
}
function _b({ treeData: e, value: t, onChange: n }) {
	let [r, i] = It([]), [a, o] = It(""), [s, c] = It([]), [l, u] = It(!0), { t: d } = b(), f = (e) => {
		n?.(e);
	}, p = (e) => {
		i(e), u(!1);
	}, m = y(() => {
		let t = [], n = (e) => {
			for (let r = 0; r < e.length; r++) {
				let i = e[r];
				t.push({
					id: i.id,
					title: i.title
				}), i.children && n(i.children);
			}
		};
		return n(e), t;
	}, [e]);
	return v(() => {
		s.includes("expandAll") ? i(m.map((e) => e.id)) : i([]), s.includes("checkAll") ? n?.(m.map((e) => e.id)) : n?.([]);
	}, [s, m]), /* @__PURE__ */ C(x, { children: [
		/* @__PURE__ */ S(hb, {
			className: "mb-3",
			placeholder: d("common.keywordSearch"),
			allowClear: !0,
			value: a,
			onChange: (t) => {
				let { value: n } = t.target, r = m.map((t) => d(t.title).includes(n) ? gb(t.id, e) : null).filter((e, t, n) => !!(e && n.indexOf(e) === t));
				i(r), o(n), u(!0);
			}
		}),
		/* @__PURE__ */ S(qe.Group, {
			options: [{
				label: s.includes("expandAll") ? d("common.collapseAll") : d("common.expandAll"),
				value: "expandAll"
			}, {
				label: s.includes("checkAll") ? d("common.cancelAll") : d("common.checkAll"),
				value: "checkAll"
			}],
			value: s,
			rootClassName: "flex justify-between items-center mb-3",
			onChange: (e) => {
				c(e);
			}
		}),
		/* @__PURE__ */ S(bt, {
			checkable: !0,
			blockNode: !0,
			defaultExpandAll: !0,
			titleRender: (e) => d(e.title),
			onExpand: p,
			expandedKeys: r,
			autoExpandParent: l,
			fieldNames: { key: "id" },
			checkedKeys: t,
			treeData: e,
			onCheck: f
		})
	] });
}
//#endregion
//#region src/components/basic-table/constants.ts
var vb = "basic-table", yb = Kt(({ prefixCls: e, isDark: t }) => ({ basicTable: { [`& .${e}-table`]: { [`& .${e}-table-container`]: { [`& .${e}-table-content, & .${e}-table-body`]: {
	"scrollbar-width": "thin",
	"scrollbar-color": t ? "#909399 transparent" : "#eaeaea transparent",
	"scrollbar-gutter": "stable"
} } } } }));
ip(), D(), k(), vf();
function bb(e) {
	let t = yb(), { t: n } = b(), { adaptive: r } = e, i = Ft(null), a = Qt(i), { enableFooter: o, fixedFooter: s } = E(), [c, l] = It(r ? "initial" : void 0), u = y(() => o && s ? 40 : 0, [o, s]), d = Pt(() => e.pagination !== !1 && {
		placement: ["bottomStart"],
		defaultPageSize: 10,
		showQuickJumper: !0,
		showSizeChanger: !0,
		showTotal: (e) => n("common.pagination", { total: e }),
		...e.pagination
	}, [e.pagination, n]), f = y(() => {
		let e = d();
		return e === !1 ? 0 : e.size ? 56 : 64;
	}, [d]);
	v(() => {
		if (_f(e.scroll?.y) && r && i.current && a?.height) {
			let e = i.current.getElementsByClassName(vb)[0];
			if (!e || i.current.getBoundingClientRect().top > window.innerHeight) return;
			let t = e.querySelector("div.ant-table-body");
			if (!t) return;
			let n = t.getBoundingClientRect(), a = (gf(r) ? r.offsetBottom ?? 16 : 16) + f + u, o = window.innerHeight - n.top - a;
			t.setAttribute("style", `overflow-y: auto;min-height: ${o}px;max-height: ${o}px;`), l(o);
		}
	}, [
		a,
		r,
		f,
		u,
		e.scroll?.y
	]);
	let p = () => e.loading === !1 ? !1 : e.loading === !0 || {
		indicator: /* @__PURE__ */ S(ve, { spin: !0 }),
		...e.loading
	};
	return /* @__PURE__ */ S("div", {
		className: "h-full",
		ref: i,
		children: /* @__PURE__ */ S(_n, {
			cardBordered: !0,
			rowKey: "id",
			dateFormatter: "string",
			...e,
			options: {
				fullScreen: !0,
				...e.options
			},
			rootClassName: O(vb, e.rootClassName),
			className: O(t.basicTable, e.className),
			scroll: {
				y: c,
				x: "max-content",
				...e.scroll
			},
			loading: p(),
			pagination: d(),
			expandable: { ...e.expandable }
		})
	});
}
//#endregion
//#region src/constants/options.ts
function xb(e) {
	return [{
		label: e("common.yes"),
		value: 1
	}, {
		label: e("common.no"),
		value: 0
	}];
}
function Sb(e) {
	return [{
		label: e("common.yes"),
		value: !0
	}, {
		label: e("common.no"),
		value: !1
	}];
}
//#endregion
//#region src/hooks/use-tab-key/index.ts
Wm();
function Cb() {
	let { pathname: e } = c(), t = Ft(void 0);
	return t.current === void 0 && (t.current = Um(e)), t.current;
}
//#endregion
//#region src/module-loader/define-module.ts
function wb(e) {
	return e;
}
fv(), hv();
var Tb = t((e) => ({
	routes: [],
	loaded: !1,
	refresh: async () => {
		try {
			let t = await hy();
			e({
				routes: t,
				loaded: !0
			}), j.getState().setSolutionRoutes(t);
		} catch {
			e({
				routes: [],
				loaded: !0
			}), j.getState().setSolutionRoutes([]);
		}
	},
	reset: () => {
		e({
			routes: [],
			loaded: !1
		}), j.getState().setSolutionRoutes([]);
	}
})), Eb = !1;
function Db() {
	if (Eb) return;
	Eb = !0;
	let e = mv.getState().token;
	e && Tb.getState().refresh(), mv.subscribe((t) => {
		t.token !== e && (e = t.token, t.token ? Tb.getState().refresh() : Tb.getState().reset());
	});
}
Db();
//#endregion
//#region src/utils/get-all-expanded-keys/index.ts
function Ob(e, t = "key") {
	return e.flatMap((e) => [e[t], ...e.children?.length ? Ob(e.children, t) : []]);
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/util.js
var kb = /* @__PURE__ */ T({
	BIGINT_FORMAT_RANGES: () => dx,
	CONSTANT_CATCH: () => qx,
	Class: () => Lx,
	NUMBER_FORMAT_RANGES: () => ux,
	aborted: () => yx,
	allowsEval: () => ex,
	assert: () => Fb,
	assertEqual: () => Ab,
	assertIs: () => Nb,
	assertNever: () => Pb,
	assertNotEqual: () => jb,
	assignProp: () => P,
	attachSchema: () => Cx,
	base64ToUint8Array: () => jx,
	base64urlToUint8Array: () => Nx,
	cached: () => Rb,
	captureStackTrace: () => Qb,
	cleanEnum: () => Ax,
	cleanRegex: () => Bb,
	clone: () => F,
	cloneDef: () => Kb,
	codePointLength: () => Dx,
	constantCatch: () => Jx,
	createTransparentProxy: () => cx,
	defineLazy: () => Ub,
	defineLazyInternal: () => z,
	esc: () => Xb,
	escapeRegex: () => sx,
	explicitlyAborted: () => bx,
	extend: () => mx,
	finalizeIssue: () => wx,
	floatSafeRemainder: () => Vb,
	getElementAtPath: () => qb,
	getEnumValues: () => Ib,
	getLengthableOrigin: () => Ox,
	getParsedType: () => ix,
	getSizableOrigin: () => Tx,
	hexToUint8Array: () => Fx,
	hide: () => Bx,
	installLazyProp: () => Kx,
	isObject: () => $b,
	isPlainObject: () => tx,
	issue: () => kx,
	joinValues: () => N,
	jsonStringifyReplacer: () => Lb,
	members: () => Rx,
	merge: () => gx,
	mergeDefs: () => Gb,
	normalizeParams: () => I,
	nullish: () => zb,
	numKeys: () => rx,
	objectClone: () => Wb,
	omit: () => px,
	optionalKeys: () => lx,
	own: () => zx,
	parsedType: () => R,
	partial: () => _x,
	pick: () => fx,
	prefixIssues: () => xx,
	primitiveTypes: () => ox,
	promiseAllObject: () => Jb,
	propertyKeyTypes: () => ax,
	randomString: () => Yb,
	required: () => vx,
	safeExtend: () => hx,
	shallowClone: () => nx,
	slugify: () => Zb,
	stringifyPrimitive: () => L,
	toZod: () => Mb,
	uint8ArrayToBase64: () => Mx,
	uint8ArrayToBase64url: () => Px,
	uint8ArrayToHex: () => Ix,
	unwrapMessage: () => Sx
});
function Ab(e) {
	return e;
}
function jb(e) {
	return e;
}
function Mb() {
	return (e) => e;
}
function Nb(e) {}
function Pb(e) {
	throw Error("Unexpected value in exhaustive check");
}
function Fb(e) {}
function Ib(e) {
	let t = Object.values(e).filter((e) => typeof e == "number");
	return Object.entries(e).filter(([e, n]) => t.indexOf(+e) === -1).map(([e, t]) => t);
}
function N(e, t = "|") {
	return e.map((e) => L(e)).join(t);
}
function Lb(e, t) {
	return typeof t == "bigint" ? t.toString() : t;
}
function Rb(e) {
	return { get value() {
		{
			let t = e();
			return Object.defineProperty(this, "value", { value: t }), t;
		}
	} };
}
function zb(e) {
	return e == null;
}
function Bb(e) {
	let t = +!!e.startsWith("^"), n = e.endsWith("$") ? e.length - 1 : e.length;
	return e.slice(t, n);
}
function Vb(e, t) {
	let n = e / t, r = Math.round(n), i = 4 * 2 ** -52 * Math.max(Math.abs(n), 1);
	return Math.abs(n - r) < i ? 0 : n - r;
}
var Hb = /* @__PURE__*/ Symbol("evaluating");
function Ub(e, t, n) {
	let r;
	Object.defineProperty(e, t, {
		get() {
			if (r !== Hb) return r === void 0 && (r = Hb, r = n()), r;
		},
		set(n) {
			Object.defineProperty(e, t, { value: n });
		},
		configurable: !0
	});
}
function Wb(e) {
	return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
}
function P(e, t, n) {
	Object.defineProperty(e, t, {
		value: n,
		writable: !0,
		enumerable: !0,
		configurable: !0
	});
}
function Gb(...e) {
	let t = {};
	for (let n of e) {
		let e = Object.getOwnPropertyDescriptors(n);
		Object.assign(t, e);
	}
	return Object.defineProperties({}, t);
}
function Kb(e) {
	return Gb(e._zod.def);
}
function qb(e, t) {
	return t ? t.reduce((e, t) => e?.[t], e) : e;
}
function Jb(e) {
	let t = Object.keys(e), n = t.map((t) => e[t]);
	return Promise.all(n).then((e) => {
		let n = {};
		for (let r = 0; r < t.length; r++) n[t[r]] = e[r];
		return n;
	});
}
function Yb(e = 10) {
	let t = "";
	for (let n = 0; n < e; n++) t += "abcdefghijklmnopqrstuvwxyz"[Math.floor(Math.random() * 26)];
	return t;
}
function Xb(e) {
	return JSON.stringify(e);
}
function Zb(e) {
	return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
var Qb = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {};
function $b(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
var ex = /* @__PURE__*/ Rb(() => {
	if (rS.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare")) return !1;
	try {
		return Function(""), !0;
	} catch {
		return !1;
	}
});
function tx(e) {
	if ($b(e) === !1) return !1;
	let t = e.constructor;
	if (t === void 0 || typeof t != "function") return !0;
	let n = t.prototype;
	return $b(n) !== !1 && Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") !== !1;
}
function nx(e) {
	return tx(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
function rx(e) {
	let t = 0;
	for (let n in e) Object.prototype.hasOwnProperty.call(e, n) && t++;
	return t;
}
var ix = (e) => {
	let t = typeof e;
	switch (t) {
		case "undefined": return "undefined";
		case "string": return "string";
		case "number": return Number.isNaN(e) ? "nan" : "number";
		case "boolean": return "boolean";
		case "function": return "function";
		case "bigint": return "bigint";
		case "symbol": return "symbol";
		case "object": return Array.isArray(e) ? "array" : e === null ? "null" : e.then && typeof e.then == "function" && e.catch && typeof e.catch == "function" ? "promise" : typeof Map < "u" && e instanceof Map ? "map" : typeof Set < "u" && e instanceof Set ? "set" : typeof Date < "u" && e instanceof Date ? "date" : typeof File < "u" && e instanceof File ? "file" : "object";
		default: throw Error(`Unknown data type: ${t}`);
	}
}, ax = /* @__PURE__*/ new Set([
	"string",
	"number",
	"symbol"
]), ox = /* @__PURE__*/ new Set([
	"string",
	"number",
	"bigint",
	"boolean",
	"symbol",
	"undefined"
]);
function sx(e) {
	return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function F(e, t, n) {
	let r = new e._zod.constr(t ?? e._zod.def);
	return (!t || n?.parent) && (r._zod.parent = e), r;
}
function I(e) {
	let t = e;
	if (!t) return {};
	if (typeof t == "string") return { error: () => t };
	if (t?.message !== void 0) {
		if (t?.error !== void 0) throw Error("Cannot specify both `message` and `error` params");
		t.error = t.message;
	}
	return delete t.message, typeof t.error == "string" ? {
		...t,
		error: () => t.error
	} : t;
}
function cx(e) {
	let t;
	return new Proxy({}, {
		get(n, r, i) {
			return t ??= e(), Reflect.get(t, r, i);
		},
		set(n, r, i, a) {
			return t ??= e(), Reflect.set(t, r, i, a);
		},
		has(n, r) {
			return t ??= e(), Reflect.has(t, r);
		},
		deleteProperty(n, r) {
			return t ??= e(), Reflect.deleteProperty(t, r);
		},
		ownKeys(n) {
			return t ??= e(), Reflect.ownKeys(t);
		},
		getOwnPropertyDescriptor(n, r) {
			return t ??= e(), Reflect.getOwnPropertyDescriptor(t, r);
		},
		defineProperty(n, r, i) {
			return t ??= e(), Reflect.defineProperty(t, r, i);
		}
	});
}
function L(e) {
	return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
function lx(e) {
	return Object.keys(e).filter((t) => e[t]._zod.optin !== void 0 && e[t]._zod.optout === "optional");
}
var ux = {
	safeint: [-(2 ** 53 - 1), 2 ** 53 - 1],
	int32: [-2147483648, 2147483647],
	uint32: [0, 4294967295],
	float32: [-34028234663852886e22, 34028234663852886e22],
	float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, dx = {
	int64: [/* @__PURE__*/ BigInt("-9223372036854775808"), /* @__PURE__*/ BigInt("9223372036854775807")],
	uint64: [/* @__PURE__*/ BigInt(0), /* @__PURE__*/ BigInt("18446744073709551615")]
};
function fx(e, t) {
	let n = e._zod.def, r = n.checks;
	if (r && r.length > 0) throw Error(".pick() cannot be used on object schemas containing refinements");
	return F(e, Gb(e._zod.def, {
		get shape() {
			let e = {};
			for (let r of Reflect.ownKeys(t)) {
				if (!Object.prototype.hasOwnProperty.call(n.shape, r)) throw Error(`Unrecognized key: "${String(r)}"`);
				t[r] && P(e, r, n.shape[r]);
			}
			return P(this, "shape", e), e;
		},
		checks: []
	}));
}
function px(e, t) {
	let n = e._zod.def, r = n.checks;
	if (r && r.length > 0) throw Error(".omit() cannot be used on object schemas containing refinements");
	return F(e, Gb(e._zod.def, {
		get shape() {
			let r = { ...e._zod.def.shape };
			for (let e of Reflect.ownKeys(t)) {
				if (!Object.prototype.hasOwnProperty.call(n.shape, e)) throw Error(`Unrecognized key: "${String(e)}"`);
				t[e] && delete r[e];
			}
			return P(this, "shape", r), r;
		},
		checks: []
	}));
}
function mx(e, t) {
	if (!tx(t)) throw Error("Invalid input to extend: expected a plain object");
	let n = e._zod.def.checks;
	if (n && n.length > 0) {
		let n = e._zod.def.shape;
		for (let e of Reflect.ownKeys(t)) if (Object.getOwnPropertyDescriptor(n, e) !== void 0) throw Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
	}
	return F(e, Gb(e._zod.def, { get shape() {
		let n = {
			...e._zod.def.shape,
			...t
		};
		return P(this, "shape", n), n;
	} }));
}
function hx(e, t) {
	if (!tx(t)) throw Error("Invalid input to safeExtend: expected a plain object");
	return F(e, Gb(e._zod.def, { get shape() {
		let n = {
			...e._zod.def.shape,
			...t
		};
		return P(this, "shape", n), n;
	} }));
}
function gx(e, t) {
	if (!t?._zod?.def) throw Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
	if (e._zod.def.checks?.length) throw Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
	return F(e, Gb(e._zod.def, {
		get shape() {
			let n = {
				...e._zod.def.shape,
				...t._zod.def.shape
			};
			return P(this, "shape", n), n;
		},
		get catchall() {
			return t._zod.def.catchall;
		},
		checks: t._zod.def.checks ?? []
	}));
}
function _x(e, t, n, r = "partial") {
	let i = t._zod.def.checks;
	if (i && i.length > 0) throw Error(`.${r}() cannot be used on object schemas containing refinements`);
	return F(t, Gb(t._zod.def, {
		get shape() {
			let r = t._zod.def.shape, i = { ...r };
			if (n) for (let t of Reflect.ownKeys(n)) {
				if (!Object.prototype.hasOwnProperty.call(r, t)) throw Error(`Unrecognized key: "${String(t)}"`);
				n[t] && (i[t] = e ? new e({
					type: "optional",
					innerType: r[t]
				}) : r[t]);
			}
			else for (let t of Reflect.ownKeys(r)) i[t] = e ? new e({
				type: "optional",
				innerType: r[t]
			}) : r[t];
			return P(this, "shape", i), i;
		},
		checks: []
	}));
}
function vx(e, t, n) {
	return F(t, Gb(t._zod.def, { get shape() {
		let r = t._zod.def.shape, i = { ...r };
		if (n) for (let t of Reflect.ownKeys(n)) {
			if (!Object.prototype.hasOwnProperty.call(i, t)) throw Error(`Unrecognized key: "${String(t)}"`);
			n[t] && (i[t] = new e({
				type: "nonoptional",
				innerType: r[t]
			}));
		}
		else for (let t of Reflect.ownKeys(r)) i[t] = new e({
			type: "nonoptional",
			innerType: r[t]
		});
		return P(this, "shape", i), i;
	} }));
}
function yx(e, t = 0) {
	if (e.aborted === !0) return !0;
	for (let n = t; n < e.issues.length; n++) if (e.issues[n]?.continue !== !0) return !0;
	return !1;
}
function bx(e, t = 0) {
	if (e.aborted === !0) return !0;
	for (let n = t; n < e.issues.length; n++) if (e.issues[n]?.continue === !1) return !0;
	return !1;
}
function xx(e, t) {
	return t.map((t) => {
		var n;
		return (n = t).path ?? (n.path = []), t.path.unshift(e), t;
	});
}
function Sx(e) {
	return typeof e == "string" ? e : e?.message;
}
function Cx(e, t, n) {
	var r;
	for (let i = t; i < e.length; i++) (r = e[i]).schema ?? (r.schema = n);
}
function wx(e, t, n) {
	var r;
	let i = e.inst?._zod?.traits;
	i?.has("$ZodType") && (i.has("$ZodCheck") ? (r = e).schema ?? (r.schema = e.inst) : e.schema = e.inst);
	let a = e.schema === e.inst ? void 0 : e.schema?._zod.def?.error, o = e.message ? e.message : Sx(e.inst?._zod.def?.error?.(e)) ?? Sx(a?.(e)) ?? Sx(t?.error?.(e)) ?? Sx(n.customError?.(e)) ?? Sx(n.localeError?.(e)) ?? "Invalid input", { inst: s, schema: c, continue: l, input: u, ...d } = e;
	return d.path ??= [], d.message = o, t?.reportInput && (d.input = u), d;
}
function Tx(e) {
	return e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof File ? "file" : "unknown";
}
var Ex = /[\uD800-\uDBFF]/;
function Dx(e) {
	let t = e.length;
	if (!Ex.test(e)) return t;
	let n = t;
	for (let r = 0; r < t - 1; r++) (e.charCodeAt(r) & 64512) == 55296 && (e.charCodeAt(r + 1) & 64512) == 56320 && (n--, r++);
	return n;
}
function Ox(e) {
	return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
function R(e) {
	let t = typeof e;
	switch (t) {
		case "number": return Number.isNaN(e) ? "nan" : "number";
		case "object": {
			if (e === null) return "null";
			if (Array.isArray(e)) return "array";
			let t = e;
			if (t && Object.getPrototypeOf(t) !== Object.prototype && "constructor" in t && t.constructor) return t.constructor.name;
		}
	}
	return t;
}
function kx(...e) {
	let [t, n, r] = e;
	return typeof t == "string" ? {
		message: t,
		code: "custom",
		input: n,
		inst: r
	} : { ...t };
}
function Ax(e) {
	return Object.entries(e).filter(([e, t]) => Number.isNaN(Number.parseInt(e, 10))).map((e) => e[1]);
}
function jx(e) {
	let t = atob(e), n = new Uint8Array(t.length);
	for (let e = 0; e < t.length; e++) n[e] = t.charCodeAt(e);
	return n;
}
function Mx(e) {
	let t = "";
	for (let n = 0; n < e.length; n++) t += String.fromCharCode(e[n]);
	return btoa(t);
}
function Nx(e) {
	let t = e.replace(/-/g, "+").replace(/_/g, "/");
	return jx(t + "=".repeat((4 - t.length % 4) % 4));
}
function Px(e) {
	return Mx(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
function Fx(e) {
	let t = e.replace(/^0x/, "");
	if (t.length % 2 != 0) throw Error("Invalid hex string length");
	let n = new Uint8Array(t.length / 2);
	for (let e = 0; e < t.length; e += 2) n[e / 2] = Number.parseInt(t.slice(e, e + 2), 16);
	return n;
}
function Ix(e) {
	return Array.from(e).map((e) => e.toString(16).padStart(2, "0")).join("");
}
var Lx = class {
	constructor(...e) {}
};
function Rx(e, t) {
	for (let n in t) {
		let r = Object.getOwnPropertyDescriptor(t, n);
		r.get ? Object.defineProperty(e, n, {
			...r,
			enumerable: !1
		}) : Vx(e, n, r.value);
	}
}
function zx(e, t, n, r = !0) {
	return Object.defineProperty(e, t, {
		configurable: !0,
		writable: !0,
		enumerable: r,
		value: n
	}), n;
}
function Bx(e, t, n) {
	return zx(e, t, n, !1);
}
function Vx(e, t, n) {
	Object.defineProperty(e, t, {
		configurable: !0,
		get() {
			return this == null ? n : zx(this, t, n.bind(this));
		},
		set(e) {
			zx(this, t, e);
		}
	});
}
function Hx(e, t) {
	let n = Object.getPrototypeOf(e);
	return t in n ? void 0 : n;
}
var Ux, Wx = !1, Gx = {
	configurable: !0,
	get() {
		Wx = !0;
	}
};
function z(e, t, n) {
	let r = Object.getPrototypeOf(e._zod);
	if (t in r && Ux !== e._zod) {
		Ux = void 0;
		return;
	}
	Ux = e._zod, Object.defineProperty(r, t, {
		configurable: !0,
		get() {
			Object.defineProperty(this, t, Gx);
			let e = Wx;
			Wx = !1;
			try {
				let r = n(this);
				return Wx ? delete this[t] : Object.defineProperty(this, t, {
					configurable: !0,
					writable: !0,
					value: r
				}), Wx ||= e, r;
			} catch (n) {
				throw delete this[t], Wx ||= e, n;
			}
		},
		set(e) {
			Object.defineProperty(this, t, {
				configurable: !0,
				writable: !0,
				value: e
			});
		}
	});
}
function Kx(e, t, n, r) {
	let i = Hx(e, t);
	i && Object.defineProperty(i, t, {
		configurable: !0,
		get() {
			let e = {
				configurable: !0,
				writable: !0,
				enumerable: r,
				value: void 0
			};
			return Object.defineProperty(this, t, e), e.value = n(this), Object.defineProperty(this, t, e), e.value;
		},
		set(e) {
			Object.defineProperty(this, t, {
				configurable: !0,
				writable: !0,
				enumerable: r,
				value: e
			});
		}
	});
}
var qx = "~constantCatch";
function Jx(e) {
	let t = () => e;
	return t[qx] = !0, t;
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/core.js
var Yx, Xx = /*@__PURE__*/ Object.freeze({ status: "aborted" }), Zx = {
	value: void 0,
	enumerable: !1
}, Qx = "captureStackTrace" in Error ? Error : null;
function $x(e) {
	let t = Qx;
	if (t) {
		let n = t.stackTraceLimit;
		if (typeof n == "number") {
			try {
				t.stackTraceLimit = 0;
			} catch {
				return Qx = null, new e();
			}
			try {
				return new e();
			} finally {
				t.stackTraceLimit = n;
			}
		}
	}
	return new e();
}
function B(e, t, n, r) {
	let i = {};
	function a(e) {
		this.def = e, this.constr = d, this.traits = /* @__PURE__ */ new Set();
	}
	a.prototype = i;
	let o = n, s = o && /* @__PURE__ */ new WeakSet();
	function c(n, r) {
		if (!n._zod) {
			Zx.value = new a(r);
			try {
				Object.defineProperty(n, "_zod", Zx);
			} finally {
				Zx.value = void 0;
			}
		}
		if (n._zod.traits.has(e)) return;
		if (n._zod.traits.add(e), t(n, r), s) {
			let e = Object.getPrototypeOf(n), t = n._zod.constr.prototype, r = e;
			for (; r && r !== t;) r = Object.getPrototypeOf(r);
			let i = r ?? e;
			s.has(i) || (s.add(i), Rx(i, o));
		}
		let i = d.prototype;
		for (let e in i) Object.prototype.hasOwnProperty.call(i, e) && (e in n || (n[e] = i[e].bind(n)));
	}
	let l = r?.Parent ?? Object;
	class u extends l {}
	Object.defineProperty(u, "name", { value: e });
	function d(e) {
		let t = r?.Parent ? $x(u) : this;
		c(t, e);
		let n = t._zod.deferred;
		if (n) {
			for (let e of n) e();
			t._zod.deferred = void 0;
		}
		let i = globalThis.__zod_globalConfig?.postProcessor;
		return i && i(t), t;
	}
	return Object.defineProperty(d, "init", { value: c }), Object.defineProperty(d, Symbol.hasInstance, { value: (t) => r?.Parent && t instanceof r.Parent ? !0 : t?._zod?.traits?.has(e) }), Object.defineProperty(d, "name", { value: e }), d;
}
var eS = /*@__PURE__*/ Symbol("zod_brand"), tS = class extends Error {
	constructor() {
		super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
	}
}, nS = class extends Error {
	constructor(e) {
		super(`Encountered unidirectional transform during encode: ${e}`), this.name = "ZodEncodeError";
	}
};
(Yx = globalThis).__zod_globalConfig ?? (Yx.__zod_globalConfig = {});
var rS = globalThis.__zod_globalConfig;
function V(e) {
	return e && Object.assign(rS, e), rS;
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/errors.js
function iS() {
	let e = this._zod;
	return e.message ??= JSON.stringify(e.def, Lb, 2), e.message;
}
function aS(e) {
	this._zod.message = e;
}
var oS = {
	get: iS,
	set: aS,
	enumerable: !0,
	configurable: !0
}, sS = {
	value: void 0,
	enumerable: !1
}, cS = {
	value: void 0,
	enumerable: !1
}, lS = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), uS = (e, t) => {
	e.name = "$ZodError", sS.value = e._zod, Object.defineProperty(e, "_zod", sS), cS.value = t, Object.defineProperty(e, "issues", cS), sS.value = void 0, cS.value = void 0, Object.defineProperty(e, "message", oS);
	let n = Object.getPrototypeOf(e);
	lS.has(n) || (lS.add(n), Object.defineProperty(n, "toString", {
		configurable: !0,
		enumerable: !1,
		get() {
			let e = () => this.message;
			return Object.defineProperty(this, "toString", {
				value: e,
				configurable: !0,
				writable: !0
			}), e;
		},
		set(e) {
			Object.defineProperty(this, "toString", {
				value: e,
				configurable: !0,
				writable: !0
			});
		}
	}));
}, dS = B("$ZodError", uS), fS = B("$ZodError", uS, void 0, { Parent: Error });
function pS(e, t, n) {
	return Object.prototype.hasOwnProperty.call(e, t) || (t === "__proto__" ? Object.defineProperty(e, t, {
		value: n(),
		writable: !0,
		enumerable: !0,
		configurable: !0
	}) : e[t] = n()), e[t];
}
function mS(e, t = (e) => e.message) {
	let n = {}, r = [];
	for (let i of e.issues) i.path.length > 0 ? pS(n, i.path[0], () => []).push(t(i)) : r.push(t(i));
	return {
		formErrors: r,
		fieldErrors: n
	};
}
function hS(e, t = (e) => e.message) {
	let n = { _errors: [] }, r = (e, i = []) => {
		for (let a of e.issues) if (a.code === "invalid_union" && a.errors.length) a.errors.map((e) => r({ issues: e }, [...i, ...a.path]));
		else if (a.code === "invalid_key") r({ issues: a.issues }, [...i, ...a.path]);
		else if (a.code === "invalid_element") r({ issues: a.issues }, [...i, ...a.path]);
		else {
			let e = [...i, ...a.path];
			if (e.length === 0) n._errors.push(t(a));
			else {
				let r = n, i = 0;
				for (; i < e.length;) {
					let n = e[i], o = i === e.length - 1;
					if (n === "_errors") {
						o && r._errors.push(t(a)), i++;
						continue;
					}
					Object.prototype.hasOwnProperty.call(r, n) || Object.defineProperty(r, n, {
						value: { _errors: [] },
						enumerable: !0,
						writable: !0,
						configurable: !0
					});
					let s = r[n];
					o && s._errors.push(t(a)), r = s, i++;
				}
			}
		}
	};
	return r(e), n;
}
function gS(e, t = (e) => e.message) {
	let n = { errors: [] }, r = (e, i = []) => {
		var a;
		for (let o of e.issues) if (o.code === "invalid_union" && o.errors.length) o.errors.map((e) => r({ issues: e }, [...i, ...o.path]));
		else if (o.code === "invalid_key") r({ issues: o.issues }, [...i, ...o.path]);
		else if (o.code === "invalid_element") r({ issues: o.issues }, [...i, ...o.path]);
		else {
			let e = [...i, ...o.path];
			if (e.length === 0) {
				n.errors.push(t(o));
				continue;
			}
			let r = n, s = 0;
			for (; s < e.length;) {
				let n = e[s], i = s === e.length - 1;
				typeof n == "string" ? (r.properties ?? (r.properties = {}), Object.prototype.hasOwnProperty.call(r.properties, n) || Object.defineProperty(r.properties, n, {
					value: { errors: [] },
					enumerable: !0,
					writable: !0,
					configurable: !0
				}), r = r.properties[n]) : (r.items ?? (r.items = []), (a = r.items)[n] ?? (a[n] = { errors: [] }), r = r.items[n]), i && r.errors.push(t(o)), s++;
			}
		}
	};
	return r(e), n;
}
function _S(e) {
	let t = [], n = e.map((e) => typeof e == "object" ? e.key : e);
	for (let e of n) typeof e == "number" ? t.push(`[${e}]`) : typeof e == "symbol" ? t.push(`[${JSON.stringify(String(e))}]`) : /[^\w$]/.test(e) ? t.push(`[${JSON.stringify(e)}]`) : (t.length && t.push("."), t.push(e));
	return t.join("");
}
function vS(e) {
	let t = [], n = [...e.issues].sort((e, t) => (e.path ?? []).length - (t.path ?? []).length);
	for (let e of n) t.push(`✖ ${e.message}`), e.path?.length && t.push(`  → at ${_S(e.path)}`);
	return t.join("\n");
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/parse.js
function yS(e, t) {
	return {
		callee: t?.callee ?? e,
		Err: t?.Err
	};
}
var bS = (e) => {
	let t = (n, r, i, a) => {
		let o = i ? {
			...i,
			async: !1
		} : { async: !1 }, s = n._zod.run({
			value: r,
			issues: []
		}, o);
		if (s instanceof Promise) throw new tS();
		if (s.issues.length) {
			let n = new ((a?.Err) ?? e)(s.issues.map((e) => wx(e, o, V())));
			throw Qb(n, a?.callee ?? t), n;
		}
		return s.value;
	};
	return t;
}, xS = /* @__PURE__*/ bS(fS), SS = (e) => {
	let t = async (n, r, i, a) => {
		let o = i ? {
			...i,
			async: !0
		} : { async: !0 }, s = n._zod.run({
			value: r,
			issues: []
		}, o);
		if (s instanceof Promise && (s = await s), s.issues.length) {
			let n = new ((a?.Err) ?? e)(s.issues.map((e) => wx(e, o, V())));
			throw Qb(n, a?.callee ?? t), n;
		}
		return s.value;
	};
	return t;
}, CS = /* @__PURE__*/ SS(fS), wS = (e) => (t, n, r) => {
	let i = r ? {
		...r,
		async: !1
	} : { async: !1 }, a = t._zod.run({
		value: n,
		issues: []
	}, i);
	if (a instanceof Promise) throw new tS();
	return a.issues.length ? {
		success: !1,
		error: new (e ?? dS)(a.issues.map((e) => wx(e, i, V())))
	} : {
		success: !0,
		data: a.value
	};
}, TS = /* @__PURE__*/ wS(fS), ES = (e) => async (t, n, r) => {
	let i = r ? {
		...r,
		async: !0
	} : { async: !0 }, a = t._zod.run({
		value: n,
		issues: []
	}, i);
	return a instanceof Promise && (a = await a), a.issues.length ? {
		success: !1,
		error: new e(a.issues.map((e) => wx(e, i, V())))
	} : {
		success: !0,
		data: a.value
	};
}, DS = /* @__PURE__*/ ES(fS), OS = /* @__PURE__ */ Symbol.for("zod.compile.invalid"), kS = /* @__PURE__ */ Symbol.for("zod.compile.fallback"), AS = ((e, t, n) => {
	let r = e._zod.bag.validator;
	return r !== void 0 && r(t) !== OS || jS(e, t, n);
});
function jS(e, t, n) {
	let r = n ? {
		...n,
		async: !1
	} : { async: !1 }, i = e._zod.bag.fallbackRun, a;
	if (i ? (r[kS] = !0, a = i({
		value: t,
		issues: []
	}, r)) : a = e._zod.run({
		value: t,
		issues: []
	}, r), a instanceof Promise) throw new tS();
	return a.issues.length === 0;
}
var MS = async (e, t, n) => {
	let r = n ? {
		...n,
		async: !0
	} : { async: !0 }, i = e._zod.run({
		value: t,
		issues: []
	}, r);
	return i instanceof Promise && (i = await i), i.issues.length === 0;
}, NS = (e) => {
	let t = bS(e), n = (e, r, i, a) => {
		let o = i ? {
			...i,
			direction: "backward"
		} : { direction: "backward" };
		return t(e, r, o, yS(n, a));
	};
	return n;
}, PS = /* @__PURE__*/ NS(fS), FS = (e) => {
	let t = bS(e), n = (e, r, i, a) => t(e, r, i, yS(n, a));
	return n;
}, IS = /* @__PURE__*/ FS(fS), LS = (e) => {
	let t = SS(e), n = async (e, r, i, a) => {
		let o = i ? {
			...i,
			direction: "backward"
		} : { direction: "backward" };
		return await t(e, r, o, yS(n, a));
	};
	return n;
}, RS = /* @__PURE__*/ LS(fS), zS = (e) => {
	let t = SS(e), n = async (e, r, i, a) => await t(e, r, i, yS(n, a));
	return n;
}, BS = /* @__PURE__*/ zS(fS), VS = (e) => (t, n, r) => {
	let i = r ? {
		...r,
		direction: "backward"
	} : { direction: "backward" };
	return wS(e)(t, n, i);
}, HS = /* @__PURE__*/ VS(fS), US = (e) => (t, n, r) => wS(e)(t, n, r), WS = /* @__PURE__*/ US(fS), GS = (e) => async (t, n, r) => {
	let i = r ? {
		...r,
		direction: "backward"
	} : { direction: "backward" };
	return ES(e)(t, n, i);
}, KS = /* @__PURE__*/ GS(fS), qS = (e) => async (t, n, r) => ES(e)(t, n, r), JS = /* @__PURE__*/ qS(fS), YS = /* @__PURE__ */ T({
	base64: () => CC,
	base64url: () => wC,
	bigint: () => LC,
	boolean: () => BC,
	browserEmail: () => hC,
	cidrv4: () => xC,
	cidrv6: () => SC,
	creditCard: () => kC,
	cuid: () => XS,
	cuid2: () => ZS,
	date: () => MC,
	datetime: () => FC,
	domain: () => EC,
	duration: () => rC,
	e164: () => OC,
	email: () => uC,
	emoji: () => _C,
	extendedDuration: () => iC,
	guid: () => aC,
	hex: () => GC,
	hostname: () => TC,
	html5Email: () => dC,
	httpProtocol: () => DC,
	idnEmail: () => mC,
	integer: () => RC,
	ipv4: () => vC,
	ipv6: () => yC,
	ksuid: () => eC,
	lowercase: () => UC,
	mac: () => bC,
	md5_base64: () => YC,
	md5_base64url: () => XC,
	md5_hex: () => JC,
	nanoid: () => tC,
	nanoidOfLength: () => nC,
	null: () => VC,
	number: () => zC,
	rfc5322Email: () => fC,
	sha1_base64: () => QC,
	sha1_base64url: () => $C,
	sha1_hex: () => ZC,
	sha256_base64: () => tw,
	sha256_base64url: () => nw,
	sha256_hex: () => ew,
	sha384_base64: () => iw,
	sha384_base64url: () => aw,
	sha384_hex: () => rw,
	sha512_base64: () => sw,
	sha512_base64url: () => cw,
	sha512_hex: () => ow,
	string: () => IC,
	time: () => PC,
	ulid: () => QS,
	undefined: () => HC,
	unicodeEmail: () => pC,
	uppercase: () => WC,
	uuid: () => oC,
	uuid4: () => sC,
	uuid6: () => cC,
	uuid7: () => lC,
	xid: () => $S
}), XS = /^[cC][0-9a-z]{6,}$/, ZS = /^[0-9a-z]+$/, QS = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, $S = /^[0-9a-vA-V]{20}$/, eC = /^[A-Za-z0-9]{27}$/, tC = /^[a-zA-Z0-9_-]{21}$/;
function nC(e) {
	return RegExp(`^[a-zA-Z0-9_-]{${e}}$`);
}
var rC = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, iC = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/, aC = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, oC = (e) => e ? RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, sC = /*@__PURE__*/ oC(4), cC = /*@__PURE__*/ oC(6), lC = /*@__PURE__*/ oC(7), uC = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, dC = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, fC = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, pC = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u, mC = pC, hC = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, gC = "^[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function _C() {
	return new RegExp(gC, "u");
}
var vC = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, yC = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, bC = (e) => {
	let t = sx(e ?? ":");
	return RegExp(`^(?:[0-9A-F]{2}${t}){5}[0-9A-F]{2}$|^(?:[0-9a-f]{2}${t}){5}[0-9a-f]{2}$`);
}, xC = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, SC = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, CC = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, wC = /^[A-Za-z0-9_-]*$/, TC = /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/, EC = /^(?=.{1,253}$)([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$/, DC = /^https?$/, OC = /^\+[1-9]\d{6,14}$/, kC = /^\d(?:[ -]?\d){11,18}$/, AC = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function jC(e) {
	return RegExp(`^${e}$`);
}
var MC = /*@__PURE__*/ jC(AC);
function NC(e) {
	let t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
	return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : e.seconds ? `${t}:[0-5]\\d(?:\\.\\d+)?` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function PC(e) {
	return RegExp(`^${NC(e)}$`);
}
function FC(e) {
	let t = ["Z"];
	e.offset && t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
	let n = `${NC({
		precision: e.precision,
		seconds: !0
	})}(?:${t.join("|")})`, r = e.local ? `${n}|${NC({ precision: e.precision })}` : n;
	return RegExp(`^${AC}T(?:${r})$`);
}
var IC = (e) => {
	let t = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
	return RegExp(`^${t}$`);
}, LC = /^-?\d+n?$/, RC = /^-?\d+$/, zC = /^-?\d+(?:\.\d+)?$/, BC = /^(?:true|false)$/i, VC = /^null$/i, HC = /^undefined$/i, UC = /^[^A-Z]*$/, WC = /^[^a-z]*$/, GC = /^[0-9a-fA-F]*$/;
function KC(e, t) {
	return RegExp(`^[A-Za-z0-9+/]{${e}}${t}$`);
}
function qC(e) {
	return RegExp(`^[A-Za-z0-9_-]{${e}}$`);
}
var JC = /^[0-9a-fA-F]{32}$/, YC = /*@__PURE__*/ KC(22, "=="), XC = /*@__PURE__*/ qC(22), ZC = /^[0-9a-fA-F]{40}$/, QC = /*@__PURE__*/ KC(27, "="), $C = /*@__PURE__*/ qC(27), ew = /^[0-9a-fA-F]{64}$/, tw = /*@__PURE__*/ KC(43, "="), nw = /*@__PURE__*/ qC(43), rw = /^[0-9a-fA-F]{96}$/, iw = /*@__PURE__*/ KC(64, ""), aw = /*@__PURE__*/ qC(64), ow = /^[0-9a-fA-F]{128}$/, sw = /*@__PURE__*/ KC(86, "=="), cw = /*@__PURE__*/ qC(86), H = /*@__PURE__*/ B("$ZodCheck", (e, t) => {
	var n;
	e._zod ??= {}, e._zod.def = t, (n = e._zod).onattach ?? (n.onattach = []);
}), lw = (e) => {
	let t = e.value;
	return !zb(t) && t.size !== void 0;
}, uw = (e) => {
	let t = e.value;
	return !zb(t) && t.length !== void 0;
}, dw = {
	number: "number",
	bigint: "bigint",
	object: "date"
}, fw = /*@__PURE__*/ B("$ZodCheckLessThan", (e, t) => {
	H.init(e, t);
	let n = dw[typeof t.value];
	e._zod.onattach.push((e) => {
		let n = e._zod.bag, r = (t.inclusive ? n.maximum : n.exclusiveMaximum) ?? Infinity;
		t.value < r && (t.inclusive ? n.maximum = t.value : n.exclusiveMaximum = t.value);
	}), e._zod.check = (r) => {
		(t.inclusive ? r.value <= t.value : r.value < t.value) || r.issues.push({
			origin: dw[typeof r.value] ?? n,
			code: "too_big",
			maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
			input: r.value,
			inclusive: t.inclusive,
			inst: e,
			continue: !t.abort
		});
	};
}), pw = /*@__PURE__*/ B("$ZodCheckGreaterThan", (e, t) => {
	H.init(e, t);
	let n = dw[typeof t.value];
	e._zod.onattach.push((e) => {
		let n = e._zod.bag, r = (t.inclusive ? n.minimum : n.exclusiveMinimum) ?? -Infinity;
		t.value > r && (t.inclusive ? n.minimum = t.value : n.exclusiveMinimum = t.value);
	}), e._zod.check = (r) => {
		(t.inclusive ? r.value >= t.value : r.value > t.value) || r.issues.push({
			origin: dw[typeof r.value] ?? n,
			code: "too_small",
			minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
			input: r.value,
			inclusive: t.inclusive,
			inst: e,
			continue: !t.abort
		});
	};
}), mw = /*@__PURE__*/ B("$ZodCheckMultipleOf", (e, t) => {
	H.init(e, t), e._zod.onattach.push((e) => {
		var n;
		(n = e._zod.bag).multipleOf ?? (n.multipleOf = t.value);
	}), e._zod.check = (n) => {
		if (typeof n.value != typeof t.value) throw Error("Cannot mix number and bigint in multiple_of check.");
		(typeof n.value == "bigint" ? t.value !== BigInt(0) && n.value % t.value === BigInt(0) : Vb(n.value, t.value) === 0) || n.issues.push({
			origin: typeof n.value,
			code: "not_multiple_of",
			divisor: t.value,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), hw = /*@__PURE__*/ B("$ZodCheckNumberFormat", (e, t) => {
	H.init(e, t), t.format = t.format || "float64";
	let n = t.format?.includes("int"), r = n ? "int" : "number", [i, a] = ux[t.format];
	e._zod.onattach.push((e) => {
		let r = e._zod.bag;
		r.format = t.format, r.minimum = i, r.maximum = a, n && (r.pattern = RC);
	}), e._zod.check = (o) => {
		let s = o.value;
		if (n) {
			if (!Number.isInteger(s)) {
				o.issues.push({
					expected: r,
					format: t.format,
					code: "invalid_type",
					continue: !1,
					input: s,
					inst: e
				});
				return;
			}
			if (!Number.isSafeInteger(s)) {
				s > 0 ? o.issues.push({
					input: s,
					code: "too_big",
					maximum: 2 ** 53 - 1,
					note: "Integers must be within the safe integer range.",
					inst: e,
					origin: r,
					inclusive: !0,
					continue: !t.abort
				}) : o.issues.push({
					input: s,
					code: "too_small",
					minimum: -(2 ** 53 - 1),
					note: "Integers must be within the safe integer range.",
					inst: e,
					origin: r,
					inclusive: !0,
					continue: !t.abort
				});
				return;
			}
		}
		s < i && o.issues.push({
			origin: "number",
			input: s,
			code: "too_small",
			minimum: i,
			inclusive: !0,
			inst: e,
			continue: !t.abort
		}), s > a && o.issues.push({
			origin: "number",
			input: s,
			code: "too_big",
			maximum: a,
			inclusive: !0,
			inst: e,
			continue: !t.abort
		});
	};
}), gw = /*@__PURE__*/ B("$ZodCheckBigIntFormat", (e, t) => {
	H.init(e, t);
	let [n, r] = dx[t.format];
	e._zod.onattach.push((e) => {
		let i = e._zod.bag;
		i.format = t.format, i.minimum = n, i.maximum = r;
	}), e._zod.check = (i) => {
		let a = i.value;
		a < n && i.issues.push({
			origin: "bigint",
			input: a,
			code: "too_small",
			minimum: n,
			inclusive: !0,
			inst: e,
			continue: !t.abort
		}), a > r && i.issues.push({
			origin: "bigint",
			input: a,
			code: "too_big",
			maximum: r,
			inclusive: !0,
			inst: e,
			continue: !t.abort
		});
	};
}), _w = /*@__PURE__*/ B("$ZodCheckMaxSize", (e, t) => {
	var n;
	H.init(e, t), (n = e._zod.def).when ?? (n.when = lw), e._zod.onattach.push((e) => {
		let n = e._zod.bag.maximum ?? Infinity;
		t.maximum < n && (e._zod.bag.maximum = t.maximum);
	}), e._zod.check = (n) => {
		let r = n.value;
		r.size <= t.maximum || n.issues.push({
			origin: Tx(r),
			code: "too_big",
			maximum: t.maximum,
			inclusive: !0,
			input: r,
			inst: e,
			continue: !t.abort
		});
	};
}), vw = /*@__PURE__*/ B("$ZodCheckMinSize", (e, t) => {
	var n;
	H.init(e, t), (n = e._zod.def).when ?? (n.when = lw), e._zod.onattach.push((e) => {
		let n = e._zod.bag.minimum ?? -Infinity;
		t.minimum > n && (e._zod.bag.minimum = t.minimum);
	}), e._zod.check = (n) => {
		let r = n.value;
		r.size >= t.minimum || n.issues.push({
			origin: Tx(r),
			code: "too_small",
			minimum: t.minimum,
			inclusive: !0,
			input: r,
			inst: e,
			continue: !t.abort
		});
	};
}), yw = /*@__PURE__*/ B("$ZodCheckSizeEquals", (e, t) => {
	var n;
	H.init(e, t), (n = e._zod.def).when ?? (n.when = lw), e._zod.onattach.push((e) => {
		let n = e._zod.bag;
		n.minimum = t.size, n.maximum = t.size, n.size = t.size;
	}), e._zod.check = (n) => {
		let r = n.value, i = r.size;
		if (i === t.size) return;
		let a = i > t.size;
		n.issues.push({
			origin: Tx(r),
			...a ? {
				code: "too_big",
				maximum: t.size
			} : {
				code: "too_small",
				minimum: t.size
			},
			inclusive: !0,
			exact: !0,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), bw = /*@__PURE__*/ B("$ZodCheckMaxLength", (e, t) => {
	var n;
	H.init(e, t), (n = e._zod.def).when ?? (n.when = uw), e._zod.onattach.push((e) => {
		let n = e._zod.bag.maximum ?? Infinity;
		t.maximum < n && (e._zod.bag.maximum = t.maximum);
	}), e._zod.check = (n) => {
		let r = n.value, i = r.length;
		if ((typeof r == "string" && i > t.maximum ? Dx(r) : i) <= t.maximum) return;
		let a = Ox(r);
		n.issues.push({
			origin: a,
			code: "too_big",
			maximum: t.maximum,
			inclusive: !0,
			input: r,
			inst: e,
			continue: !t.abort
		});
	};
}), xw = /*@__PURE__*/ B("$ZodCheckMinLength", (e, t) => {
	var n;
	H.init(e, t), (n = e._zod.def).when ?? (n.when = uw), e._zod.onattach.push((e) => {
		let n = e._zod.bag.minimum ?? -Infinity;
		t.minimum > n && (e._zod.bag.minimum = t.minimum);
	}), e._zod.check = (n) => {
		let r = n.value, i = r.length;
		if ((typeof r == "string" && i >= t.minimum && i < t.minimum * 2 ? Dx(r) : i) >= t.minimum) return;
		let a = Ox(r);
		n.issues.push({
			origin: a,
			code: "too_small",
			minimum: t.minimum,
			inclusive: !0,
			input: r,
			inst: e,
			continue: !t.abort
		});
	};
}), Sw = /*@__PURE__*/ B("$ZodCheckLengthEquals", (e, t) => {
	var n;
	H.init(e, t), (n = e._zod.def).when ?? (n.when = uw), e._zod.onattach.push((e) => {
		let n = e._zod.bag;
		n.minimum = t.length, n.maximum = t.length, n.length = t.length;
	}), e._zod.check = (n) => {
		let r = n.value, i = r.length, a = typeof r == "string" && i >= t.length && i <= t.length * 2 ? Dx(r) : i;
		if (a === t.length) return;
		let o = Ox(r), s = a > t.length;
		n.issues.push({
			origin: o,
			...s ? {
				code: "too_big",
				maximum: t.length
			} : {
				code: "too_small",
				minimum: t.length
			},
			inclusive: !0,
			exact: !0,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), Cw = /*@__PURE__*/ B("$ZodCheckStringFormat", (e, t) => {
	var n, r;
	H.init(e, t), e._zod.onattach.push((e) => {
		let n = e._zod.bag;
		n.format = t.format, t.pattern && (n.patterns ??= /* @__PURE__ */ new Set(), n.patterns.add(t.pattern));
	}), t.pattern ? (n = e._zod).check ?? (n.check = (n) => {
		t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: t.format,
			input: n.value,
			...t.pattern ? { pattern: t.pattern.toString() } : {},
			inst: e,
			continue: !t.abort
		});
	}) : (r = e._zod).check ?? (r.check = () => {});
}), ww = /*@__PURE__*/ B("$ZodCheckRegex", (e, t) => {
	Cw.init(e, t), e._zod.check = (n) => {
		t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "regex",
			input: n.value,
			pattern: t.pattern.toString(),
			inst: e,
			continue: !t.abort
		});
	};
}), Tw = /*@__PURE__*/ B("$ZodCheckLowerCase", (e, t) => {
	t.pattern ??= UC, Cw.init(e, t);
}), Ew = /*@__PURE__*/ B("$ZodCheckUpperCase", (e, t) => {
	t.pattern ??= WC, Cw.init(e, t);
}), Dw = /*@__PURE__*/ B("$ZodCheckIncludes", (e, t) => {
	H.init(e, t);
	let n = sx(t.includes), r = new RegExp(typeof t.position == "number" ? `^.{${t.position},}${n}` : n);
	t.pattern = r, e._zod.onattach.push((e) => {
		let t = e._zod.bag;
		t.patterns ??= /* @__PURE__ */ new Set(), t.patterns.add(r);
	}), e._zod.check = (n) => {
		n.value.includes(t.includes, t.position) || n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "includes",
			includes: t.includes,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), Ow = /*@__PURE__*/ B("$ZodCheckStartsWith", (e, t) => {
	H.init(e, t);
	let n = RegExp(`^${sx(t.prefix)}.*`);
	t.pattern ??= n, e._zod.onattach.push((e) => {
		let t = e._zod.bag;
		t.patterns ??= /* @__PURE__ */ new Set(), t.patterns.add(n);
	}), e._zod.check = (n) => {
		n.value.startsWith(t.prefix) || n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "starts_with",
			prefix: t.prefix,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), kw = /*@__PURE__*/ B("$ZodCheckEndsWith", (e, t) => {
	H.init(e, t);
	let n = RegExp(`.*${sx(t.suffix)}$`);
	t.pattern ??= n, e._zod.onattach.push((e) => {
		let t = e._zod.bag;
		t.patterns ??= /* @__PURE__ */ new Set(), t.patterns.add(n);
	}), e._zod.check = (n) => {
		n.value.endsWith(t.suffix) || n.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "ends_with",
			suffix: t.suffix,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
});
function Aw(e, t, n) {
	e.issues.length && t.issues.push(...xx(n, e.issues));
}
var jw = /*@__PURE__*/ B("$ZodCheckProperty", (e, t) => {
	H.init(e, t), e._zod.check = (e) => {
		let n = t.schema._zod.run({
			value: e.value[t.property],
			issues: []
		}, {});
		if (n instanceof Promise) return n.then((n) => Aw(n, e, t.property));
		Aw(n, e, t.property);
	};
}), Mw = /*@__PURE__*/ B("$ZodCheckMimeType", (e, t) => {
	H.init(e, t);
	let n = new Set(t.mime);
	e._zod.onattach.push((e) => {
		e._zod.bag.mime = t.mime;
	}), e._zod.check = (r) => {
		n.has(r.value.type) || r.issues.push({
			code: "invalid_value",
			values: t.mime,
			input: r.value.type,
			inst: e,
			continue: !t.abort
		});
	};
}), Nw = /*@__PURE__*/ B("$ZodCheckOverwrite", (e, t) => {
	H.init(e, t), e._zod.check = (e) => {
		e.value = t.tx(e.value);
	};
}), Pw = class {
	constructor(e = [], t = {}) {
		this.content = [], this.indent = 0, this.args = e, this.closed = t;
	}
	indented(e) {
		this.indent += 1, e(this), --this.indent;
	}
	write(e) {
		if (typeof e == "function") {
			e(this, { execution: "sync" }), e(this, { execution: "async" });
			return;
		}
		let t = e.split("\n").filter((e) => e), n = Math.min(...t.map((e) => e.length - e.trimStart().length)), r = t.map((e) => e.slice(n)).map((e) => " ".repeat(this.indent * 2) + e);
		for (let e of r) this.content.push(e);
	}
	compile() {
		let e = Function, t = this?.content ?? [""];
		return new e(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {\n${t.join("\n")}\n};`)(...Object.values(this.closed));
	}
}, Fw = {
	major: 4,
	minor: 5,
	patch: 4
}, U = /*@__PURE__*/ B("$ZodType", (e, t) => {
	var n;
	e ??= {}, e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = Fw;
	let r = e._zod.def.checks, i = e._zod.traits.has("$ZodCheck") ? [e, ...r ?? []] : r?.length ? [...r] : [];
	for (let t of i) for (let n of t._zod.onattach) n(e);
	if (i.length === 0) (n = e._zod).deferred ?? (n.deferred = []), e._zod.deferred?.push(() => {
		e._zod.run = e._zod.parse;
	});
	else {
		let t = (t, n, r) => {
			if (t.memo) return t;
			let i = yx(t), a;
			for (let o of n) {
				if (o._zod.def.when) {
					if (bx(t) || !o._zod.def.when(t)) continue;
				} else if (i) continue;
				let n = t.issues.length, s = o._zod.check(t);
				if (s instanceof Promise && r?.async === !1) throw new tS();
				if (a || s instanceof Promise) a = (a ?? Promise.resolve()).then(async () => {
					await s, t.issues.length !== n && (Cx(t.issues, n, e), i ||= yx(t, n));
				});
				else {
					if (t.issues.length === n) continue;
					Cx(t.issues, n, e), i ||= yx(t, n);
				}
			}
			return a ? a.then(() => t) : t;
		}, n = (n, r, a) => {
			if (yx(n)) return n.aborted = !0, n;
			let o = t(r, i, a);
			if (o instanceof Promise) {
				if (a.async === !1) throw new tS();
				return o.then((t) => e._zod.parse(t, a));
			}
			return e._zod.parse(o, a);
		};
		e._zod.run = (r, a) => {
			if (a.skipChecks) return e._zod.parse(r, a);
			if (a.direction === "backward") {
				let t = e._zod.parse({
					value: r.value,
					issues: []
				}, {
					...a,
					skipChecks: !0
				});
				return t instanceof Promise ? t.then((e) => n(e, r, a)) : n(t, r, a);
			}
			let o = e._zod.parse(r, a);
			if (o instanceof Promise) {
				if (a.async === !1) throw new tS();
				return o.then((e) => t(e, i, a));
			}
			return t(o, i, a);
		};
	}
}, {
	get "~standard"() {
		return Bx(this, "~standard", Lw(this));
	},
	set "~standard"(e) {
		zx(this, "~standard", e);
	}
}), Iw = (e) => e.success ? { value: e.data } : { issues: e.error?.issues };
function Lw(e) {
	return {
		validate: (t) => {
			try {
				return Iw(TS(e, t));
			} catch {
				return DS(e, t).then(Iw);
			}
		},
		vendor: "zod",
		version: 1
	};
}
var Rw = /*@__PURE__*/ B("$ZodString", (e, t) => {
	U.init(e, t), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? IC(e._zod.bag), e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = String(n.value);
		} catch {}
		return typeof n.value == "string" || n.issues.push({
			expected: "string",
			code: "invalid_type",
			input: n.value,
			inst: e
		}), n;
	};
}), W = /*@__PURE__*/ B("$ZodStringFormat", (e, t) => {
	Cw.init(e, t), Rw.init(e, t);
}), zw = /*@__PURE__*/ B("$ZodGUID", (e, t) => {
	t.pattern ??= aC, W.init(e, t);
}), Bw = /*@__PURE__*/ B("$ZodUUID", (e, t) => {
	if (t.version) {
		let e = {
			v1: 1,
			v2: 2,
			v3: 3,
			v4: 4,
			v5: 5,
			v6: 6,
			v7: 7,
			v8: 8
		}[t.version];
		if (e === void 0) throw Error(`Invalid UUID version: "${t.version}"`);
		t.pattern ??= oC(e);
	} else t.pattern ??= oC();
	W.init(e, t);
}), Vw = /*@__PURE__*/ B("$ZodEmail", (e, t) => {
	t.pattern ??= uC, W.init(e, t);
});
function Hw(e, t) {
	if (!t.normalize && t.protocol?.source === DC.source && !/^https?:\/\//i.test(e)) return 1;
	try {
		return new URL(e);
	} catch {
		return 2;
	}
}
var Uw = /[\t\n\r]/g;
function Ww(e) {
	return e.replace(Uw, "");
}
function Gw(e, t) {
	return t.lastIndex = 0, t.test(e.hostname);
}
function Kw(e, t) {
	return t.lastIndex = 0, t.test(e.protocol.endsWith(":") ? e.protocol.slice(0, -1) : e.protocol);
}
var qw = /*@__PURE__*/ B("$ZodURL", (e, t) => {
	W.init(e, t), e._zod.check = (n) => {
		try {
			let r = n.value.trim(), i = Hw(r, t);
			if (i === 1) {
				n.issues.push({
					code: "invalid_format",
					format: "url",
					note: "Invalid URL format",
					input: n.value,
					inst: e,
					continue: !t.abort
				});
				return;
			}
			if (i === 2) {
				n.issues.push({
					code: "invalid_format",
					format: "url",
					input: n.value,
					inst: e,
					continue: !t.abort
				});
				return;
			}
			t.hostname && !Gw(i, t.hostname) && n.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid hostname",
				pattern: t.hostname.source,
				input: n.value,
				inst: e,
				continue: !t.abort
			}), t.protocol && !Kw(i, t.protocol) && n.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid protocol",
				pattern: t.protocol.source,
				input: n.value,
				inst: e,
				continue: !t.abort
			}), n.value = t.normalize ? i.href : Ww(r);
			return;
		} catch {
			n.issues.push({
				code: "invalid_format",
				format: "url",
				input: n.value,
				inst: e,
				continue: !t.abort
			});
		}
	};
}), Jw = /*@__PURE__*/ B("$ZodEmoji", (e, t) => {
	t.pattern ??= _C(), W.init(e, t);
}), Yw = /*@__PURE__*/ B("$ZodNanoID", (e, t) => {
	if (t.length !== void 0 && (!Number.isInteger(t.length) || t.length < 1)) throw Error(`Invalid nanoid length: ${t.length}`);
	t.pattern ??= t.length === void 0 ? tC : nC(t.length), W.init(e, t);
}), Xw = /*@__PURE__*/ B("$ZodCUID", (e, t) => {
	t.pattern ??= XS, W.init(e, t);
}), Zw = /*@__PURE__*/ B("$ZodCUID2", (e, t) => {
	t.pattern ??= ZS, W.init(e, t);
}), Qw = /*@__PURE__*/ B("$ZodULID", (e, t) => {
	t.pattern ??= QS, W.init(e, t);
}), $w = /*@__PURE__*/ B("$ZodXID", (e, t) => {
	t.pattern ??= $S, W.init(e, t);
}), eT = /*@__PURE__*/ B("$ZodKSUID", (e, t) => {
	t.pattern ??= eC, W.init(e, t);
}), tT = /*@__PURE__*/ B("$ZodISODateTime", (e, t) => {
	t.pattern ??= FC(t), W.init(e, t), (t.local || t.precision === -1) && (e._zod.bag.laxFormat = !0, e._zod.onattach.push((e) => {
		e._zod.bag.laxFormat = !0;
	}));
}), nT = /*@__PURE__*/ B("$ZodISODate", (e, t) => {
	t.pattern ??= MC, W.init(e, t);
}), rT = /*@__PURE__*/ B("$ZodISOTime", (e, t) => {
	t.pattern ??= PC(t), W.init(e, t);
}), iT = /*@__PURE__*/ B("$ZodISODuration", (e, t) => {
	t.pattern ??= rC, W.init(e, t);
}), aT = /*@__PURE__*/ B("$ZodIPv4", (e, t) => {
	t.pattern ??= vC, W.init(e, t), e._zod.bag.format = "ipv4";
}), oT = /^[0-9a-fA-F:.]+$/;
function sT(e) {
	if (!oT.test(e)) return !1;
	try {
		return new URL(`http://[${e}]`), !0;
	} catch {
		return !1;
	}
}
var cT = /*@__PURE__*/ B("$ZodIPv6", (e, t) => {
	t.pattern ??= yC, W.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = (n) => {
		sT(n.value) || n.issues.push({
			code: "invalid_format",
			format: "ipv6",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), lT = /*@__PURE__*/ B("$ZodMAC", (e, t) => {
	t.pattern ??= bC(t.delimiter), W.init(e, t), e._zod.bag.format = "mac";
}), uT = /*@__PURE__*/ B("$ZodCIDRv4", (e, t) => {
	t.pattern ??= xC, W.init(e, t);
});
function dT(e) {
	let t = e.split("/");
	if (t.length !== 2) return !1;
	let [n, r] = t;
	if (!r) return !1;
	let i = Number(r);
	return `${i}` !== r || i < 0 || i > 128 ? !1 : sT(n);
}
var fT = /*@__PURE__*/ B("$ZodCIDRv6", (e, t) => {
	t.pattern ??= SC, W.init(e, t), e._zod.check = (n) => {
		dT(n.value) || n.issues.push({
			code: "invalid_format",
			format: "cidrv6",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
});
function pT(e) {
	if (e === "") return !0;
	if (/\s/.test(e) || e.length % 4 != 0) return !1;
	try {
		return atob(e), !0;
	} catch {
		return !1;
	}
}
var mT = /*@__PURE__*/ B("$ZodBase64", (e, t) => {
	t.pattern ??= CC, W.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = (n) => {
		pT(n.value) || n.issues.push({
			code: "invalid_format",
			format: "base64",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
});
function hT(e) {
	if (!wC.test(e)) return !1;
	let t = e.replace(/[-_]/g, (e) => e === "-" ? "+" : "/");
	return pT(t.padEnd(Math.ceil(t.length / 4) * 4, "="));
}
var gT = /*@__PURE__*/ B("$ZodBase64URL", (e, t) => {
	t.pattern ??= wC, W.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = (n) => {
		hT(n.value) || n.issues.push({
			code: "invalid_format",
			format: "base64url",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), _T = /*@__PURE__*/ B("$ZodE164", (e, t) => {
	t.pattern ??= OC, W.init(e, t);
}), vT = /[- ]/g;
function yT(e) {
	let t = e.length, n = 1, r = 0;
	for (; t;) {
		let i = +e[--t];
		n ^= 1, r += n ? [
			0,
			2,
			4,
			6,
			8,
			1,
			3,
			5,
			7,
			9
		][i] : i;
	}
	return r % 10 == 0;
}
function bT(e) {
	return kC.test(e) ? yT(e.replace(vT, "")) : !1;
}
var xT = /*@__PURE__*/ B("$ZodCreditCard", (e, t) => {
	t.pattern ??= kC, W.init(e, t), e._zod.check = (n) => {
		bT(n.value) || n.issues.push({
			code: "invalid_format",
			format: "credit_card",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
});
function ST(e, t = null) {
	try {
		let n = e.split(".");
		if (n.length !== 3) return !1;
		let [r] = n;
		if (!r) return !1;
		let i = JSON.parse(atob(r));
		return !("typ" in i && i?.typ !== "JWT" || !i.alg || t && (!("alg" in i) || i.alg !== t));
	} catch {
		return !1;
	}
}
var CT = /*@__PURE__*/ B("$ZodJWT", (e, t) => {
	W.init(e, t), e._zod.check = (n) => {
		ST(n.value, t.alg) || n.issues.push({
			code: "invalid_format",
			format: "jwt",
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), wT = /*@__PURE__*/ B("$ZodCustomStringFormat", (e, t) => {
	W.init(e, t), e._zod.check = (n) => {
		t.fn(n.value) || n.issues.push({
			code: "invalid_format",
			format: t.format,
			input: n.value,
			inst: e,
			continue: !t.abort
		});
	};
}), TT = /*@__PURE__*/ B("$ZodNumber", (e, t) => {
	U.init(e, t), e._zod.pattern = e._zod.bag.pattern ?? zC, e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = Number(n.value);
		} catch {}
		let i = n.value;
		if (typeof i == "number" && !Number.isNaN(i) && Number.isFinite(i)) return n;
		let a = typeof i == "number" ? Number.isNaN(i) ? "NaN" : Number.isFinite(i) ? void 0 : String(i) : void 0;
		return n.issues.push({
			expected: "number",
			code: "invalid_type",
			input: i,
			inst: e,
			...a ? { received: a } : {}
		}), n;
	};
}), ET = /*@__PURE__*/ B("$ZodNumberFormat", (e, t) => {
	hw.init(e, t), TT.init(e, t);
}), DT = /*@__PURE__*/ B("$ZodBoolean", (e, t) => {
	U.init(e, t), e._zod.pattern = BC, e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = !!n.value;
		} catch {}
		let i = n.value;
		return typeof i == "boolean" || n.issues.push({
			expected: "boolean",
			code: "invalid_type",
			input: i,
			inst: e
		}), n;
	};
}), OT = /*@__PURE__*/ B("$ZodBigInt", (e, t) => {
	U.init(e, t), e._zod.pattern = LC, e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = BigInt(n.value);
		} catch {}
		return typeof n.value == "bigint" || n.issues.push({
			expected: "bigint",
			code: "invalid_type",
			input: n.value,
			inst: e
		}), n;
	};
}), kT = /*@__PURE__*/ B("$ZodBigIntFormat", (e, t) => {
	gw.init(e, t), OT.init(e, t);
}), AT = /*@__PURE__*/ B("$ZodSymbol", (e, t) => {
	U.init(e, t), e._zod.parse = (t, n) => {
		let r = t.value;
		return typeof r == "symbol" || t.issues.push({
			expected: "symbol",
			code: "invalid_type",
			input: r,
			inst: e
		}), t;
	};
}), jT = /*@__PURE__*/ B("$ZodUndefined", (e, t) => {
	U.init(e, t), e._zod.pattern = HC, e._zod.values = /* @__PURE__ */ new Set([void 0]), e._zod.parse = (t, n) => {
		let r = t.value;
		return r === void 0 || t.issues.push({
			expected: "undefined",
			code: "invalid_type",
			input: r,
			inst: e
		}), t;
	};
}), MT = /*@__PURE__*/ B("$ZodNull", (e, t) => {
	U.init(e, t), e._zod.pattern = VC, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (t, n) => {
		let r = t.value;
		return r === null || t.issues.push({
			expected: "null",
			code: "invalid_type",
			input: r,
			inst: e
		}), t;
	};
}), NT = /*@__PURE__*/ B("$ZodAny", (e, t) => {
	U.init(e, t), e._zod.parse = (e) => e;
}), PT = /*@__PURE__*/ B("$ZodUnknown", (e, t) => {
	U.init(e, t), e._zod.parse = (e) => e;
}), FT = /*@__PURE__*/ B("$ZodNever", (e, t) => {
	U.init(e, t), e._zod.parse = (t, n) => (t.issues.push({
		expected: "never",
		code: "invalid_type",
		input: t.value,
		inst: e
	}), t);
}), IT = /*@__PURE__*/ B("$ZodVoid", (e, t) => {
	U.init(e, t), e._zod.parse = (t, n) => {
		let r = t.value;
		return r === void 0 || t.issues.push({
			expected: "void",
			code: "invalid_type",
			input: r,
			inst: e
		}), t;
	};
}), LT = /*@__PURE__*/ B("$ZodDate", (e, t) => {
	U.init(e, t), e._zod.parse = (n, r) => {
		if (t.coerce) try {
			n.value = new Date(n.value);
		} catch {}
		let i = n.value, a = i instanceof Date;
		return a && !Number.isNaN(i.getTime()) || n.issues.push({
			expected: "date",
			code: "invalid_type",
			input: i,
			...a ? { received: "Invalid Date" } : {},
			inst: e
		}), n;
	};
});
function RT(e, t, n) {
	e.issues.length && t.issues.push(...xx(n, e.issues)), t.value[n] = e.value;
}
var zT = /*@__PURE__*/ B("$ZodArray", (e, t) => {
	U.init(e, t);
	let n = rS.memoizer;
	n?.attach(e), e._zod.parse = (r, i) => {
		let a = r.value;
		if (!Array.isArray(a)) return r.issues.push({
			expected: "array",
			code: "invalid_type",
			input: a,
			inst: e
		}), r;
		r.value = n ? n.alloc(e, r, Array(a.length), i) : Array(a.length);
		let o = [];
		for (let e = 0; e < a.length; e++) {
			let n = a[e], s = t.element._zod.run({
				value: n,
				issues: []
			}, i);
			s instanceof Promise ? o.push(s.then((t) => RT(t, r, e))) : RT(s, r, e);
		}
		return o.length ? Promise.all(o).then(() => r) : r;
	};
});
function BT(e, t, n, r, i, a) {
	let o = n in r, s = a === "optional";
	if (!(!o && s && i === "optional")) {
		if (e.issues.length) {
			if (i !== void 0 && s && !o) return;
			t.issues.push(...xx(n, e.issues));
		}
		if (!o && i === void 0) {
			e.issues.length || t.issues.push({
				code: "invalid_type",
				expected: "nonoptional",
				input: void 0,
				path: [n]
			});
			return;
		}
		e.value === void 0 ? o && (t.value[n] = void 0) : t.value[n] = e.value;
	}
}
var VT = [];
function HT(e) {
	let t = Object.keys(e.shape), n = Object.getOwnPropertySymbols(e.shape), r = n.length ? n : VT, i = r.length ? [...t, ...r] : t;
	for (let t of i) if (!e.shape?.[t]?._zod?.traits?.has("$ZodType")) throw Error(`Invalid element at key "${String(t)}": expected a Zod schema`);
	let a = lx(e.shape);
	return {
		...e,
		allKeys: i,
		symbolKeys: r,
		keySet: new Set(t),
		numKeys: t.length,
		optionalKeys: new Set(a)
	};
}
function UT(e, t, n, r, i, a) {
	let o = [], s = i.keySet, c = i.catchall._zod, l = c.def.type, u = c.optin, d = c.optout;
	for (let i in t) {
		if (s.has(i)) continue;
		if (i === "__proto__") {
			l === "never" && o.push(i);
			continue;
		}
		if (l === "never") {
			o.push(i);
			continue;
		}
		let a = c.run({
			value: t[i],
			issues: []
		}, r);
		a instanceof Promise ? e.push(a.then((e) => BT(e, n, i, t, u, d))) : BT(a, n, i, t, u, d);
	}
	return o.length && n.issues.push({
		code: "unrecognized_keys",
		keys: o,
		input: t,
		inst: a,
		continue: !0
	}), e.length ? Promise.all(e).then(() => n) : n;
}
var WT = /* @__PURE__ */ new WeakMap(), GT = /*@__PURE__*/ B("$ZodObject", (e, t) => {
	if (U.init(e, t), !Object.getOwnPropertyDescriptor(t, "shape")?.get) {
		let e = t.shape;
		WT.set(t, e), Object.defineProperty(t, "shape", { get: () => {
			let n = { ...e };
			return Object.defineProperty(t, "shape", { value: n }), WT.set(t, n), n;
		} });
	}
	let n = Rb(() => HT(t));
	z(e, "propValues", (e) => {
		let t = e.def.shape, n = {};
		for (let e in t) {
			let r = t[e]._zod;
			if (r.values) {
				Object.prototype.hasOwnProperty.call(n, e) || P(n, e, /* @__PURE__ */ new Set());
				for (let t of r.values) n[e].add(t);
				r.optin !== void 0 && n[e].add(void 0);
			}
		}
		return n;
	});
	let r = $b, i = t.catchall, a, o = rS.memoizer;
	o?.attach(e), e._zod.parse = (t, s) => {
		a ??= n.value;
		let c = t.value;
		if (!r(c)) return t.issues.push({
			expected: "object",
			code: "invalid_type",
			input: c,
			inst: e
		}), t;
		t.value = o ? o.alloc(e, t, {}, s) : {};
		let l = [], u = a.shape;
		for (let e of a.allKeys) {
			if (e === "__proto__") continue;
			let n = u[e], r = n._zod.optin, i = n._zod.optout, a = n._zod.run({
				value: c[e],
				issues: []
			}, s);
			a instanceof Promise ? l.push(a.then((n) => BT(n, t, e, c, r, i))) : BT(a, t, e, c, r, i);
		}
		return i ? UT(l, c, t, s, n.value, e) : l.length ? Promise.all(l).then(() => t) : t;
	};
}), KT = /*@__PURE__*/ B("$ZodObjectJIT", (e, t) => {
	GT.init(e, t);
	let n = e._zod.parse, r = Rb(() => HT(t)), i = rS.memoizer, a = (t) => {
		let n = r.value, a = n.symbolKeys, o = new Pw(["payload", "ctx"], {
			shape: t,
			inst: e,
			memo: i,
			syms: a
		}), s = (e) => `shape[${e}]._zod.run({ value: input[${e}], issues: [] }, ctx)`, c = (e, t) => `
          for (let i = 0; i < ${e}.issues.length; i++) {
            const iss = ${e}.issues[i];
            iss.path = iss.path ? [${t}, ...iss.path] : [${t}];
            payload.issues.push(iss);
          }`;
		o.write("const input = payload.value;");
		let l = Object.create(null), u = 0;
		for (let e of n.allKeys) l[e] = `key_${u++}`;
		o.write(i ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
		for (let e of n.allKeys) {
			if (e === "__proto__") continue;
			let n = l[e], r = typeof e == "symbol" ? `syms[${a.indexOf(e)}]` : Xb(e), i = `${r} in input`, u = t[e], d = u?._zod?.optin, f = d !== void 0, p = u?._zod?.optout === "optional";
			if (o.write(`const ${n} = ${s(r)};`), f && p) {
				let e = d === "optional" ? `${n}_present` : `${n}.value !== undefined || ${n}_present`;
				o.write(`
        const ${n}_present = ${i};
        if (!${n}.issues.length || ${n}_present) {
          if (${n}.issues.length) {${c(n, r)}
          }

          if (${e}) {
            newResult[${r}] = ${n}.value;
          }
        }

      `);
			} else f ? o.write(`
        if (${n}.issues.length) {${c(n, r)}
        }
        
        if (${n}.value === undefined) {
          if (${i}) {
            newResult[${r}] = undefined;
          }
        } else {
          newResult[${r}] = ${n}.value;
        }

      `) : o.write(`
        const ${n}_present = ${i};
        if (${n}.issues.length) {${c(n, r)}
        }
        if (!${n}_present && !${n}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${r}]
          });
        }

        if (${n}_present) {
          newResult[${r}] = ${n}.value;
        }

      `);
		}
		return o.write("payload.value = newResult;"), o.write("return payload;"), o.compile();
	}, o, s = $b, c = !rS.jitless, l = c && ex.value, u = t.catchall, d;
	e._zod.parse = (i, f) => {
		d ??= r.value;
		let p = i.value;
		return s(p) ? c && l && f?.async === !1 && f.jitless !== !0 ? (o ||= a(t.shape), i = o(i, f), u ? UT([], p, i, f, d, e) : i) : n(i, f) : (i.issues.push({
			expected: "object",
			code: "invalid_type",
			input: p,
			inst: e
		}), i);
	};
});
function qT(e, t, n, r) {
	for (let n of e) if (n.issues.length === 0) return t.value = n.value, t;
	let i = e.filter((e) => !yx(e));
	return i.length === 1 ? (t.value = i[0].value, i[0]) : (t.issues.push({
		code: "invalid_union",
		input: t.value,
		inst: n,
		errors: e.map((e) => e.issues.map((e) => wx(e, r, V())))
	}), t);
}
var JT = /*@__PURE__*/ B("$ZodUnion", (e, t) => {
	U.init(e, t), z(e, "optin", (e) => e.def.options.some((e) => e._zod.optin === "defaulted") ? "defaulted" : e.def.options.some((e) => e._zod.optin !== void 0) ? "optional" : void 0), z(e, "optout", (e) => e.def.options.some((e) => e._zod.optout === "optional") ? "optional" : void 0), z(e, "values", (e) => {
		if (e.def.options.every((e) => e._zod.values)) return new Set(e.def.options.flatMap((e) => Array.from(e._zod.values)));
	}), z(e, "pattern", (e) => {
		if (e.def.options.every((e) => e._zod.pattern)) {
			let t = e.def.options.map((e) => e._zod.pattern);
			return RegExp(`^(${t.map((e) => Bb(e.source)).join("|")})$`);
		}
	});
	let n = t.options.length === 1 ? t.options[0]._zod.run : null;
	e._zod.parse = (r, i) => {
		if (n) return n(r, i);
		let a = !1, o = [];
		for (let e of t.options) {
			let t = e._zod.run({
				value: r.value,
				issues: []
			}, i);
			if (t instanceof Promise) o.push(t), a = !0;
			else {
				if (t.issues.length === 0) return t;
				o.push(t);
			}
		}
		return a ? Promise.all(o).then((t) => qT(t, r, e, i)) : qT(o, r, e, i);
	};
});
function YT(e, t, n, r) {
	let i = [];
	for (let t = 0; t < e.length; t++) e[t].issues.length === 0 && i.push(t);
	return i.length === 1 ? (t.value = e[i[0]].value, t) : (i.length === 0 ? t.issues.push({
		code: "invalid_union",
		input: t.value,
		inst: n,
		errors: e.map((e) => e.issues.map((e) => wx(e, r, V())))
	}) : t.issues.push({
		code: "invalid_union",
		input: t.value,
		inst: n,
		errors: [],
		inclusive: !1,
		matches: i
	}), t);
}
var XT = /*@__PURE__*/ B("$ZodXor", (e, t) => {
	JT.init(e, t), t.inclusive = !1;
	let n = t.options.length === 1 ? t.options[0]._zod.run : null;
	e._zod.parse = (r, i) => {
		if (n) return n(r, i);
		let a = !1, o = [];
		for (let e of t.options) {
			let t = e._zod.run({
				value: r.value,
				issues: []
			}, i);
			t instanceof Promise ? (o.push(t), a = !0) : o.push(t);
		}
		return a ? Promise.all(o).then((t) => YT(t, r, e, i)) : YT(o, r, e, i);
	};
});
function ZT(e, t) {
	let n = e._zod, r = n.bag.optionsMap;
	if (!r) {
		r = /* @__PURE__ */ new Map();
		let { options: e, discriminator: t } = n.def;
		for (let n of e) for (let e of n._zod.propValues?.[t] ?? []) r.has(e) || r.set(e, n);
		n.bag.optionsMap = r;
	}
	return r.get(t);
}
var QT = /*@__PURE__*/ B("$ZodDiscriminatedUnion", (e, t) => {
	t.inclusive = !1, JT.init(e, t);
	let n = e._zod.parse;
	z(e, "propValues", (e) => {
		let t = {};
		for (let n of e.def.options) {
			let r = n._zod.propValues;
			if (!r || Object.keys(r).length === 0) throw Error(`Invalid discriminated union option at index "${e.def.options.indexOf(n)}"`);
			for (let [e, n] of Object.entries(r)) {
				Object.prototype.hasOwnProperty.call(t, e) || P(t, e, /* @__PURE__ */ new Set());
				for (let r of n) t[e].add(r);
			}
		}
		return t;
	}), t.options.forEach((e, n) => {
		let r = WT.get(e._zod.def);
		if (r && !Object.prototype.hasOwnProperty.call(r, t.discriminator)) throw Error(`Invalid discriminated union option at index "${n}"`);
	});
	let r = Rb(() => {
		let e = t.options, n = /* @__PURE__ */ new Map();
		for (let r of e) {
			let e = r._zod.propValues?.[t.discriminator];
			if (!e || e.size === 0) throw Error(`Invalid discriminated union option at index "${t.options.indexOf(r)}"`);
			for (let t of e) {
				if (n.has(t)) throw Error(`Duplicate discriminator value "${String(t)}"`);
				n.set(t, r);
			}
		}
		return n;
	});
	e._zod.parse = (i, a) => {
		let o = i.value;
		if (!$b(o)) return i.issues.push({
			code: "invalid_type",
			expected: "object",
			input: o,
			inst: e
		}), i;
		let s = r.value.get(o?.[t.discriminator]);
		return s ? s._zod.run(i, a) : t.unionFallback || a.direction === "backward" ? n(i, a) : (i.issues.push({
			code: "invalid_union",
			errors: [],
			note: "No matching discriminator",
			discriminator: t.discriminator,
			options: Array.from(r.value.keys()),
			input: o,
			path: [t.discriminator],
			inst: e
		}), i);
	};
}), $T = /*@__PURE__*/ B("$ZodIntersection", (e, t) => {
	U.init(e, t), e._zod.parse = (e, n) => {
		let r = e.value, i = t.left._zod.run({
			value: r,
			issues: []
		}, n), a = t.right._zod.run({
			value: r,
			issues: []
		}, n);
		return i instanceof Promise || a instanceof Promise ? Promise.all([i, a]).then(([t, n]) => tE(e, t, n)) : tE(e, i, a);
	};
});
function eE(e, t) {
	if (e === t || e instanceof Date && t instanceof Date && +e == +t) return {
		valid: !0,
		data: e
	};
	if (tx(e) && tx(t)) {
		let n = Object.keys(t), r = Object.keys(e).filter((e) => n.indexOf(e) !== -1), i = {
			...e,
			...t
		};
		Object.prototype.hasOwnProperty.call(i, "__proto__") && delete i.__proto__;
		for (let n of r) {
			if (n === "__proto__") continue;
			let r = eE(e[n], t[n]);
			if (!r.valid) return {
				valid: !1,
				mergeErrorPath: [n, ...r.mergeErrorPath]
			};
			i[n] = r.data;
		}
		return {
			valid: !0,
			data: i
		};
	}
	if (Array.isArray(e) && Array.isArray(t)) {
		if (e.length !== t.length) return {
			valid: !1,
			mergeErrorPath: []
		};
		let n = [];
		for (let r = 0; r < e.length; r++) {
			let i = e[r], a = t[r], o = eE(i, a);
			if (!o.valid) return {
				valid: !1,
				mergeErrorPath: [r, ...o.mergeErrorPath]
			};
			n.push(o.data);
		}
		return {
			valid: !0,
			data: n
		};
	}
	return {
		valid: !1,
		mergeErrorPath: []
	};
}
function tE(e, t, n) {
	let r = /* @__PURE__ */ new Map(), i, a = /* @__PURE__ */ new Map(), o = (e, t) => {
		let n;
		if (e.code === "unrecognized_keys" && !e.path?.length) i ??= e, n = e.keys;
		else if (e.code === "invalid_key" && e.origin === "record" && e.path?.length === 1) {
			let t = String(e.path[0]);
			a.has(t) || a.set(t, e), n = [t];
		} else return !1;
		for (let e of n) r.has(e) || r.set(e, {}), r.get(e)[t] = !0;
		return !0;
	};
	for (let n of t.issues) o(n, "l") || e.issues.push(n);
	for (let t of n.issues) o(t, "r") || e.issues.push(t);
	let s = [...r].filter(([, e]) => e.l && e.r).map(([e]) => e);
	if (s.length) {
		let t = i ? s.filter((e) => i.keys.includes(e)) : [];
		t.length && e.issues.push({
			...i,
			keys: t
		});
		for (let n of s) !t.includes(n) && a.has(n) && e.issues.push(a.get(n));
	}
	let c = eE(t.value, n.value);
	if (!c.valid) {
		if (yx(e)) return e;
		throw Error(`Unmergable intersection. Error path: ${JSON.stringify(c.mergeErrorPath)}`);
	}
	return e.value = c.data, e;
}
var nE = /*@__PURE__*/ B("$ZodTuple", (e, t) => {
	U.init(e, t);
	let n = t.items, r = rS.memoizer;
	r?.attach(e), e._zod.parse = (i, a) => {
		let o = i.value;
		if (!Array.isArray(o)) return i.issues.push({
			input: o,
			inst: e,
			expected: "tuple",
			code: "invalid_type"
		}), i;
		i.value = r ? r.alloc(e, i, [], a) : [];
		let s = [], c = rE(n, "optin"), l = rE(n, "optout");
		if (!t.rest) {
			if (o.length < c) return i.issues.push({
				code: "too_small",
				minimum: c,
				inclusive: !0,
				input: o,
				inst: e,
				origin: "array"
			}), i;
			o.length > n.length && i.issues.push({
				code: "too_big",
				maximum: n.length,
				inclusive: !0,
				input: o,
				inst: e,
				origin: "array"
			});
		}
		let u = Array(n.length);
		for (let e = 0; e < n.length; e++) {
			let t = n[e]._zod.run({
				value: o[e],
				issues: []
			}, a);
			t instanceof Promise ? s.push(t.then((t) => {
				u[e] = t;
			})) : u[e] = t;
		}
		if (t.rest) {
			let e = n.length - 1, r = o.slice(n.length);
			for (let n of r) {
				e++;
				let r = t.rest._zod.run({
					value: n,
					issues: []
				}, a);
				r instanceof Promise ? s.push(r.then((t) => iE(t, i, e))) : iE(r, i, e);
			}
		}
		return s.length ? Promise.all(s).then(() => aE(u, i, n, o, l)) : aE(u, i, n, o, l);
	};
});
function rE(e, t) {
	for (let n = e.length - 1; n >= 0; n--) if (!(t === "optin" ? e[n]._zod.optin !== void 0 : e[n]._zod.optout === "optional")) return n + 1;
	return 0;
}
function iE(e, t, n) {
	e.issues.length && t.issues.push(...xx(n, e.issues)), t.value[n] = e.value;
}
function aE(e, t, n, r, i) {
	for (let a = 0; a < n.length; a++) {
		let o = e[a], s = a < r.length;
		if (!s && a >= i && n[a]._zod.optin === "optional") {
			t.value.length = a;
			break;
		}
		if (o.issues.length) {
			if (!s && a >= i) {
				t.value.length = a;
				break;
			}
			t.issues.push(...xx(a, o.issues));
		}
		t.value[a] = o.value;
	}
	for (let e = t.value.length - 1; e >= r.length && n[e]._zod.optout === "optional" && t.value[e] === void 0; e--) t.value.length = e;
	return t;
}
var oE = /*@__PURE__*/ B("$ZodRecord", (e, t) => {
	U.init(e, t);
	let n = rS.memoizer;
	n?.attach(e), e._zod.parse = (r, i) => {
		let a = r.value;
		if (!tx(a)) return r.issues.push({
			expected: "record",
			code: "invalid_type",
			input: a,
			inst: e
		}), r;
		let o = [], s = t.keyType._zod.values;
		if (s && !t.partial) {
			r.value = n ? n.alloc(e, r, {}, i) : {};
			let c = /* @__PURE__ */ new Set();
			for (let n of s) if (typeof n == "string" || typeof n == "number" || typeof n == "symbol") {
				if (c.add(typeof n == "number" ? n.toString() : n), n === "__proto__") continue;
				let s = t.keyType._zod.run({
					value: n,
					issues: []
				}, i);
				if (s instanceof Promise) throw Error("Async schemas not supported in object keys currently");
				if (s.issues.length) {
					r.issues.push({
						code: "invalid_key",
						origin: "record",
						issues: s.issues.map((e) => wx(e, i, V())),
						input: n,
						path: [n],
						inst: e
					});
					continue;
				}
				let l = s.value;
				if (l === "__proto__") continue;
				let u = t.valueType._zod.run({
					value: a[n],
					issues: []
				}, i);
				u instanceof Promise ? o.push(u.then((e) => {
					e.issues.length && r.issues.push(...xx(n, e.issues)), r.value[l] = e.value;
				})) : (u.issues.length && r.issues.push(...xx(n, u.issues)), r.value[l] = u.value);
			}
			let l;
			for (let e in a) if (!c.has(e)) {
				if (t.mode === "loose") {
					if (e === "__proto__") continue;
					r.value[e] = a[e];
				} else l ??= [], l.push(e);
			}
			l && l.length > 0 && r.issues.push({
				code: "unrecognized_keys",
				input: a,
				inst: e,
				keys: l,
				continue: !0
			});
		} else {
			r.value = n ? n.alloc(e, r, {}, i) : {};
			let c;
			for (let n of Reflect.ownKeys(a)) {
				if (n === "__proto__" || !Object.prototype.propertyIsEnumerable.call(a, n)) continue;
				let l = t.keyType._zod.run({
					value: n,
					issues: []
				}, i);
				if (l instanceof Promise) throw Error("Async schemas not supported in object keys currently");
				if (typeof n == "string" && zC.test(n) && l.issues.length) {
					let e = t.keyType._zod.run({
						value: Number(n),
						issues: []
					}, i);
					if (e instanceof Promise) throw Error("Async schemas not supported in object keys currently");
					e.issues.length === 0 && (l = e);
				}
				if (l.issues.length) {
					t.mode === "loose" ? r.value[n] = a[n] : s ? (c ??= [], c.push(n)) : r.issues.push({
						code: "invalid_key",
						origin: "record",
						issues: l.issues.map((e) => wx(e, i, V())),
						input: n,
						path: [n],
						inst: e
					});
					continue;
				}
				let u = l.value;
				if (u === "__proto__") continue;
				let d = t.valueType._zod.run({
					value: a[n],
					issues: []
				}, i);
				d instanceof Promise ? o.push(d.then((e) => {
					e.issues.length && r.issues.push(...xx(n, e.issues)), r.value[u] = e.value;
				})) : (d.issues.length && r.issues.push(...xx(n, d.issues)), r.value[u] = d.value);
			}
			c && c.length > 0 && r.issues.push({
				code: "unrecognized_keys",
				input: a,
				inst: e,
				keys: c,
				continue: !0
			});
		}
		return o.length ? Promise.all(o).then(() => r) : r;
	};
}), sE = /*@__PURE__*/ B("$ZodMap", (e, t) => {
	U.init(e, t);
	let n = rS.memoizer;
	n?.attach(e), e._zod.parse = (r, i) => {
		let a = r.value;
		if (!(a instanceof Map)) return r.issues.push({
			expected: "map",
			code: "invalid_type",
			input: a,
			inst: e
		}), r;
		let o = [];
		r.value = n ? n.alloc(e, r, /* @__PURE__ */ new Map(), i) : /* @__PURE__ */ new Map();
		for (let [n, s] of a) {
			let c = t.keyType._zod.run({
				value: n,
				issues: []
			}, i), l = t.valueType._zod.run({
				value: s,
				issues: []
			}, i);
			c instanceof Promise || l instanceof Promise ? o.push(Promise.all([c, l]).then(([t, o]) => {
				cE(t, o, r, n, a, e, i);
			})) : cE(c, l, r, n, a, e, i);
		}
		return o.length ? Promise.all(o).then(() => r) : r;
	};
});
function cE(e, t, n, r, i, a, o) {
	e.issues.length && (ax.has(typeof r) ? n.issues.push(...xx(r, e.issues)) : n.issues.push({
		code: "invalid_key",
		origin: "map",
		input: i,
		inst: a,
		issues: e.issues.map((e) => wx(e, o, V()))
	})), t.issues.length && (ax.has(typeof r) ? n.issues.push(...xx(r, t.issues)) : n.issues.push({
		origin: "map",
		code: "invalid_element",
		input: i,
		inst: a,
		key: r,
		issues: t.issues.map((e) => wx(e, o, V()))
	})), n.value.set(e.value, t.value);
}
var lE = /*@__PURE__*/ B("$ZodSet", (e, t) => {
	U.init(e, t);
	let n = rS.memoizer;
	n?.attach(e), e._zod.parse = (r, i) => {
		let a = r.value;
		if (!(a instanceof Set)) return r.issues.push({
			input: a,
			inst: e,
			expected: "set",
			code: "invalid_type"
		}), r;
		let o = [];
		r.value = n ? n.alloc(e, r, /* @__PURE__ */ new Set(), i) : /* @__PURE__ */ new Set();
		for (let e of a) {
			let n = t.valueType._zod.run({
				value: e,
				issues: []
			}, i);
			n instanceof Promise ? o.push(n.then((e) => uE(e, r))) : uE(n, r);
		}
		return o.length ? Promise.all(o).then(() => r) : r;
	};
});
function uE(e, t) {
	e.issues.length && t.issues.push(...e.issues), t.value.add(e.value);
}
var dE = /*@__PURE__*/ B("$ZodEnum", (e, t) => {
	U.init(e, t);
	let n = Ib(t.entries), r = new Set(n);
	e._zod.values = r;
	let i = n.filter((e) => ax.has(typeof e));
	e._zod.pattern = RegExp(i.length ? `^(${i.map((e) => sx(e.toString())).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (t, i) => {
		let a = t.value;
		return r.has(a) || t.issues.push({
			code: "invalid_value",
			values: n,
			input: a,
			inst: e
		}), t;
	};
}), fE = /*@__PURE__*/ B("$ZodLiteral", (e, t) => {
	U.init(e, t);
	let n = new Set(t.values);
	e._zod.values = n, e._zod.pattern = RegExp(t.values.length ? `^(${t.values.map((e) => typeof e == "string" ? sx(e) : e ? sx(e.toString()) : String(e)).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (r, i) => {
		let a = r.value;
		return n.has(a) || r.issues.push({
			code: "invalid_value",
			values: t.values,
			input: a,
			inst: e
		}), r;
	};
}), pE = /*@__PURE__*/ B("$ZodFile", (e, t) => {
	U.init(e, t), e._zod.parse = (t, n) => {
		let r = t.value;
		return r instanceof File || t.issues.push({
			expected: "file",
			code: "invalid_type",
			input: r,
			inst: e
		}), t;
	};
}), mE = /*@__PURE__*/ B("$ZodTransform", (e, t) => {
	U.init(e, t), e._zod.optin = "optional", rS.memoizer?.guard(e), e._zod.parse = (n, r) => {
		if (r.direction === "backward") throw new nS(e.constructor.name);
		let i = t.transform(n.value, n);
		if (r.async) return (i instanceof Promise ? i : Promise.resolve(i)).then((e) => (n.value = e, n));
		if (i instanceof Promise) throw new tS();
		return n.value = i, n;
	};
});
function hE(e, t) {
	return e.value = t.issues.length ? void 0 : t.value, e;
}
var gE = /*@__PURE__*/ B("$ZodOptional", (e, t) => {
	U.init(e, t), z(e, "optin", (e) => e.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), e._zod.optout = "optional", z(e, "values", (e) => {
		let t = e.def.innerType._zod.values;
		return t ? /* @__PURE__ */ new Set([...t, void 0]) : void 0;
	}), z(e, "pattern", (e) => {
		let t = e.def.innerType._zod.pattern;
		return t ? RegExp(`^(${Bb(t.source)})?$`) : void 0;
	}), e._zod.parse = (e, n) => {
		if (e.value === void 0) {
			if (t.innerType._zod.optin !== "defaulted") return e;
			let r = t.innerType._zod.run({
				value: e.value,
				issues: []
			}, n);
			return r instanceof Promise ? r.then((t) => hE(e, t)) : hE(e, r);
		}
		return t.innerType._zod.run(e, n);
	};
}), _E = /*@__PURE__*/ B("$ZodExactOptional", (e, t) => {
	gE.init(e, t), z(e, "values", (e) => e.def.innerType._zod.values), z(e, "pattern", (e) => e.def.innerType._zod.pattern), e._zod.parse = (e, n) => t.innerType._zod.run(e, n);
}), vE = /*@__PURE__*/ B("$ZodNullable", (e, t) => {
	U.init(e, t), z(e, "optin", (e) => e.def.innerType._zod.optin), z(e, "optout", (e) => e.def.innerType._zod.optout), z(e, "pattern", (e) => {
		let t = e.def.innerType._zod.pattern;
		return t ? RegExp(`^(${Bb(t.source)}|null)$`) : void 0;
	}), z(e, "values", (e) => e.def.innerType._zod.values ? /* @__PURE__ */ new Set([...e.def.innerType._zod.values, null]) : void 0), e._zod.parse = (e, n) => e.value === null ? e : t.innerType._zod.run(e, n);
}), yE = /*@__PURE__*/ B("$ZodDefault", (e, t) => {
	U.init(e, t), e._zod.optin = "defaulted", z(e, "values", (e) => e.def.innerType._zod.values), e._zod.parse = (e, n) => {
		if (n.direction === "backward") return t.innerType._zod.run(e, n);
		if (e.value === void 0) return e.value = t.defaultValue, e;
		let r = t.innerType._zod.run(e, n);
		return r instanceof Promise ? r.then((e) => bE(e, t)) : bE(r, t);
	};
});
function bE(e, t) {
	return e.value === void 0 && (e.value = t.defaultValue), e;
}
var xE = /*@__PURE__*/ B("$ZodPrefault", (e, t) => {
	U.init(e, t), e._zod.optin = "defaulted", z(e, "values", (e) => e.def.innerType._zod.values), e._zod.parse = (e, n) => (n.direction === "backward" || e.value === void 0 && (e.value = t.defaultValue), t.innerType._zod.run(e, n));
}), SE = /*@__PURE__*/ B("$ZodNonOptional", (e, t) => {
	U.init(e, t), z(e, "values", (e) => {
		let t = e.def.innerType._zod.values;
		return t ? new Set([...t].filter((e) => e !== void 0)) : void 0;
	}), e._zod.parse = (n, r) => {
		let i = t.innerType._zod.run(n, r);
		return i instanceof Promise ? i.then((t) => CE(t, e)) : CE(i, e);
	};
});
function CE(e, t) {
	return !e.issues.length && e.value === void 0 && e.issues.push({
		code: "invalid_type",
		expected: "nonoptional",
		input: e.value,
		inst: t
	}), e;
}
var wE = /*@__PURE__*/ B("$ZodSuccess", (e, t) => {
	U.init(e, t), e._zod.parse = (e, n) => {
		if (n.direction === "backward") throw new nS("ZodSuccess");
		let r = t.innerType._zod.run(e, n);
		return r instanceof Promise ? r.then((t) => (e.value = t.issues.length === 0, e)) : (e.value = r.issues.length === 0, e);
	};
});
function TE(e, t, n, r) {
	return t.issues.length ? (e.value = n.catchValue({
		...t,
		value: e.value,
		error: { issues: t.issues.map((e) => wx(e, r, V())) },
		input: e.value
	}), e) : (e.value = t.value, t.memo && (e.memo = !0), e);
}
var EE = /*@__PURE__*/ B("$ZodCatch", (e, t) => {
	U.init(e, t), z(e, "optin", (e) => e.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), z(e, "optout", (e) => e.def.innerType._zod.optout), z(e, "values", (e) => e.def.innerType._zod.values), e._zod.parse = (e, n) => {
		if (n.direction === "backward") return t.innerType._zod.run(e, n);
		let r = t.innerType._zod.run({
			value: e.value,
			issues: []
		}, n);
		return r instanceof Promise ? r.then((r) => TE(e, r, t, n)) : TE(e, r, t, n);
	};
}), DE = /*@__PURE__*/ B("$ZodNaN", (e, t) => {
	U.init(e, t), e._zod.parse = (t, n) => ((typeof t.value != "number" || !Number.isNaN(t.value)) && t.issues.push({
		input: t.value,
		inst: e,
		expected: "nan",
		code: "invalid_type"
	}), t);
}), OE = /*@__PURE__*/ B("$ZodPipe", (e, t) => {
	U.init(e, t), z(e, "values", (e) => e.def.in._zod.values), z(e, "optin", (e) => e.def.in._zod.optin), z(e, "optout", (e) => e.def.out._zod.optout), z(e, "propValues", (e) => e.def.in._zod.propValues), e._zod.parse = (e, n) => {
		if (n.direction === "backward") {
			let r = t.out._zod.run(e, n);
			return r instanceof Promise ? r.then((e) => kE(e, t.in, n)) : kE(r, t.in, n);
		}
		let r = t.in._zod.run(e, n);
		return r instanceof Promise ? r.then((e) => kE(e, t.out, n)) : kE(r, t.out, n);
	};
});
function kE(e, t, n) {
	return e.issues.some((e) => e.code !== "unrecognized_keys") ? (e.aborted = !0, e) : t._zod.run({
		value: e.value,
		issues: e.issues
	}, n);
}
var AE = /*@__PURE__*/ B("$ZodCodec", (e, t) => {
	U.init(e, t), z(e, "values", (e) => e.def.in._zod.values), z(e, "optin", (e) => e.def.in._zod.optin), z(e, "optout", (e) => e.def.out._zod.optout), z(e, "propValues", (e) => e.def.in._zod.propValues), e._zod.parse = (e, n) => {
		if ((n.direction || "forward") === "forward") {
			let r = t.in._zod.run(e, n);
			return r instanceof Promise ? r.then((e) => jE(e, t, n)) : jE(r, t, n);
		}
		{
			let r = t.out._zod.run(e, n);
			return r instanceof Promise ? r.then((e) => jE(e, t, n)) : jE(r, t, n);
		}
	};
});
function jE(e, t, n) {
	if (e.issues.length) return e.aborted = !0, e;
	if ((n.direction || "forward") === "forward") {
		let r = t.transform(e.value, e);
		return r instanceof Promise ? r.then((r) => ME(e, r, t.out, n)) : ME(e, r, t.out, n);
	}
	{
		let r = t.reverseTransform(e.value, e);
		return r instanceof Promise ? r.then((r) => ME(e, r, t.in, n)) : ME(e, r, t.in, n);
	}
}
function ME(e, t, n, r) {
	return e.issues.length ? (e.aborted = !0, e) : n._zod.run({
		value: t,
		issues: e.issues
	}, r);
}
var NE = /*@__PURE__*/ B("$ZodPreprocess", (e, t) => {
	OE.init(e, t);
}), PE = /*@__PURE__*/ B("$ZodReadonly", (e, t) => {
	U.init(e, t), z(e, "propValues", (e) => e.def.innerType._zod.propValues), z(e, "values", (e) => e.def.innerType._zod.values), z(e, "optin", (e) => e.def.innerType?._zod?.optin), z(e, "optout", (e) => e.def.innerType?._zod?.optout), e._zod.parse = (e, n) => {
		if (n.direction === "backward") return t.innerType._zod.run(e, n);
		let r = t.innerType._zod.run(e, n);
		return r instanceof Promise ? r.then(FE) : FE(r);
	};
});
function FE(e) {
	return e.memo || (e.value = Object.freeze(e.value)), e;
}
var IE = /*@__PURE__*/ B("$ZodTemplateLiteral", (e, t) => {
	U.init(e, t);
	let n = [];
	for (let e of t.parts) if (typeof e == "object" && e) {
		if (!e._zod.pattern) throw Error(`Invalid template literal part, no pattern found: ${[...e._zod.traits].shift()}`);
		let t = e._zod.pattern instanceof RegExp ? e._zod.pattern.source : e._zod.pattern;
		if (!t) throw Error(`Invalid template literal part: ${e._zod.traits}`);
		let r = +!!t.startsWith("^"), i = t.endsWith("$") ? t.length - 1 : t.length;
		n.push(t.slice(r, i));
	} else if (e === null || ox.has(typeof e)) n.push(sx(`${e}`));
	else throw Error(`Invalid template literal part: ${e}`);
	e._zod.pattern = RegExp(`^${n.join("")}$`), e._zod.parse = (n, r) => typeof n.value == "string" ? (e._zod.pattern.lastIndex = 0, e._zod.pattern.test(n.value) || n.issues.push({
		input: n.value,
		inst: e,
		code: "invalid_format",
		format: t.format ?? "template_literal",
		pattern: e._zod.pattern.source
	}), n) : (n.issues.push({
		input: n.value,
		inst: e,
		expected: "string",
		code: "invalid_type"
	}), n);
}), LE = /*@__PURE__*/ B("$ZodFunction", (e, t) => (U.init(e, t), Object.defineProperty(e, "_def", { value: t }), e._zod.def = t, e.implement = (t) => {
	if (typeof t != "function") throw Error("implement() must be called with a function");
	return Object.defineProperty(function(...n) {
		let r = e._def.input ? xS(e._def.input, n) : n, i = Reflect.apply(t, this, r);
		return e._def.output ? xS(e._def.output, i) : i;
	}, "_zod", {
		value: e._zod,
		enumerable: !1
	});
}, e.implementAsync = (t) => {
	if (typeof t != "function") throw Error("implementAsync() must be called with a function");
	return Object.defineProperty(async function(...n) {
		let r = e._def.input ? await CS(e._def.input, n) : n, i = await Reflect.apply(t, this, r);
		return e._def.output ? await CS(e._def.output, i) : i;
	}, "_zod", {
		value: e._zod,
		enumerable: !1
	});
}, e._zod.parse = (t, n) => typeof t.value == "function" ? (t.value = e._def.output && e._def.output._zod.def.type === "promise" ? e.implementAsync(t.value) : e.implement(t.value), t) : (t.issues.push({
	code: "invalid_type",
	expected: "function",
	input: t.value,
	inst: e
}), t), e.input = (...t) => {
	let n = e.constructor;
	return Array.isArray(t[0]) ? new n({
		type: "function",
		input: new nE({
			type: "tuple",
			items: t[0],
			rest: t[1]
		}),
		output: e._def.output
	}) : new n({
		type: "function",
		input: t[0],
		output: e._def.output
	});
}, e.output = (t) => {
	let n = e.constructor;
	return new n({
		type: "function",
		input: e._def.input,
		output: t
	});
}, e)), RE = /*@__PURE__*/ B("$ZodPromise", (e, t) => {
	U.init(e, t), e._zod.parse = (e, n) => Promise.resolve(e.value).then((e) => t.innerType._zod.run({
		value: e,
		issues: []
	}, n));
}), zE = /*@__PURE__*/ B("$ZodLazy", (e, t) => {
	U.init(e, t), Ub(e._zod, "innerType", () => {
		let e = t;
		return e._cachedInner ||= t.getter(), e._cachedInner;
	}), z(e, "pattern", (e) => e.innerType?._zod?.pattern), z(e, "propValues", (e) => e.innerType?._zod?.propValues), z(e, "optin", (e) => e.innerType?._zod?.optin ?? void 0), z(e, "optout", (e) => e.innerType?._zod?.optout ?? void 0), e._zod.parse = (t, n) => e._zod.innerType._zod.run(t, n);
}), BE = /*@__PURE__*/ B("$ZodCustom", (e, t) => {
	H.init(e, t), U.init(e, t), e._zod.parse = (e, t) => e, e._zod.check = (n) => {
		let r = n.value, i = t.fn(r);
		if (i instanceof Promise) return i.then((t) => VE(t, n, r, e));
		VE(i, n, r, e);
	};
});
function VE(e, t, n, r) {
	if (!e) {
		let e = {
			code: "custom",
			input: n,
			inst: r,
			path: [...r._zod.def.path ?? []],
			continue: !r._zod.def.abort
		};
		r._zod.def.params && (e.params = r._zod.def.params), t.issues.push(kx(e));
	}
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/memoizer.js
var HE = class extends Error {
	constructor() {
		super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
	}
}, UE = "~memo", WE = [];
function GE(e) {
	return e.map((e) => e.path ? {
		...e,
		path: e.path.slice()
	} : { ...e });
}
var KE = /*@__PURE__*/ new WeakMap();
function qE(e, t) {
	let n = KE.get(e);
	if (n !== void 0) return n;
	if (t.has(e)) return !0;
	t.add(e);
	let r = !1, i = (e) => {
		!r && e?._zod && qE(e, t) && (r = !0);
	}, a = e._zod.def;
	switch (a.type) {
		case "object":
			for (let e of Reflect.ownKeys(a.shape)) i(a.shape[e]);
			i(a.catchall);
			break;
		case "array":
			i(a.element);
			break;
		case "tuple":
			for (let e of a.items) i(e);
			i(a.rest);
			break;
		case "record":
		case "map":
			i(a.keyType), i(a.valueType);
			break;
		case "set":
			i(a.valueType);
			break;
		case "union":
			for (let e of a.options) i(e);
			break;
		case "intersection":
			i(a.left), i(a.right);
			break;
		case "optional":
		case "nullable":
		case "default":
		case "prefault":
		case "catch":
		case "readonly":
		case "nonoptional":
		case "promise":
		case "success":
			i(a.innerType);
			break;
		case "pipe":
			i(a.in), i(a.out);
			break;
		case "function":
			i(a.input), i(a.output);
			break;
		case "lazy":
			i(e._zod.innerType);
			break;
		case "template_literal":
		case "string":
		case "number":
		case "int":
		case "boolean":
		case "bigint":
		case "symbol":
		case "undefined":
		case "null":
		case "void":
		case "never":
		case "any":
		case "unknown":
		case "date":
		case "nan":
		case "enum":
		case "literal":
		case "file":
		case "transform":
		case "custom": break;
		default: for (let e in a) {
			let t = Object.getOwnPropertyDescriptor(a, e);
			if (!t || t.get) continue;
			let n = t.value;
			if (!(!n || typeof n != "object")) {
				if (n._zod) i(n);
				else if (Array.isArray(n)) for (let e of n) i(e);
			}
		}
	}
	return t.delete(e), KE.set(e, r), r;
}
function JE(e) {
	return qE(e, /* @__PURE__ */ new Set());
}
function YE(e, t) {
	let n = e.buckets.get(t);
	return n || (n = /* @__PURE__ */ new Map(), e.buckets.set(t, n)), n;
}
var XE, ZE = [], QE = {
	alloc(e, t, n) {
		let r = XE;
		if (!r) return n;
		XE = void 0;
		let i = {
			value: n,
			issues: null
		};
		return r.set(t.value, i), ZE.push(i), n;
	},
	guard(e) {
		var t;
		(t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
			let t = e._zod.parse, n = (e, n) => {
				if (n.direction !== "backward" && eD(n, e.value)) throw new HE();
				return t(e, n);
			};
			e._zod.parse = n, e._zod.run === t && (e._zod.run = n);
		});
	},
	attach(e) {
		var t;
		let n, r, i;
		(t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
			let t = e._zod.parse, a = (o, s) => {
				if (n === void 0 && (n = qE(e, /* @__PURE__ */ new Set()), !n)) return e._zod.parse = t, e._zod.run === a && (e._zod.run = t), t(o, s);
				let c = o.value;
				if (typeof c != "object" || !c) return t(o, s);
				let l = s[UE];
				l || (l = {
					buckets: /* @__PURE__ */ new Map(),
					backEdges: void 0
				}, s[UE] = l);
				let u;
				r === s ? u = i : (u = YE(l, e), r = s, i = u);
				let d = u.get(c);
				if (d) return o.value = d.value, d.issues ? d.issues.length && o.issues.push(...GE(d.issues)) : (o.memo = !0, l.backEdges ?? (l.backEdges = /* @__PURE__ */ new Set()), l.backEdges.add(d.value)), o;
				XE = u;
				let f = ZE.length, p = t(o, s);
				XE = void 0;
				let m = ZE.length > f ? ZE.pop() : void 0;
				return p instanceof Promise ? p.then((e) => (m && (m.issues = e.issues.length ? GE(e.issues) : WE), e)) : (m && (m.issues = p.issues.length ? GE(p.issues) : WE), p);
			};
			e._zod.parse = a, e._zod.run === t && (e._zod.run = a);
		});
	}
};
function $E() {
	return QE;
}
function eD(e, t) {
	let n = e[UE]?.backEdges;
	return n !== void 0 && typeof t == "object" && !!t && n.has(t);
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/ar.js
var tD = () => {
	let e = {
		string: {
			unit: "حرف",
			verb: "أن يحوي"
		},
		file: {
			unit: "بايت",
			verb: "أن يحوي"
		},
		array: {
			unit: "عنصر",
			verb: "أن يحوي"
		},
		set: {
			unit: "عنصر",
			verb: "أن يحوي"
		},
		map: {
			unit: "عنصر",
			verb: "أن يحوي"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "مدخل",
		email: "بريد إلكتروني",
		url: "رابط",
		emoji: "إيموجي",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "تاريخ ووقت بمعيار ISO",
		date: "تاريخ بمعيار ISO",
		time: "وقت بمعيار ISO",
		duration: "مدة بمعيار ISO",
		ipv4: "عنوان IPv4",
		ipv6: "عنوان IPv6",
		mac: "عنوان MAC",
		cidrv4: "مدى عناوين بصيغة IPv4",
		cidrv6: "مدى عناوين بصيغة IPv6",
		base64: "نَص بترميز base64-encoded",
		base64url: "نَص بترميز base64url-encoded",
		json_string: "نَص على هيئة JSON",
		e164: "رقم هاتف بمعيار E.164",
		credit_card: "رقم بطاقة الائتمان",
		jwt: "JWT",
		template_literal: "مدخل"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `مدخلات غير مقبولة: يفترض إدخال instanceof ${e.expected}، ولكن تم إدخال ${i}` : `مدخلات غير مقبولة: يفترض إدخال ${t}، ولكن تم إدخال ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `مدخلات غير مقبولة: يفترض إدخال ${L(e.values[0])}` : `اختيار غير مقبول: يتوقع انتقاء أحد هذه الخيارات: ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? ` أكبر من اللازم: يفترض أن تكون ${e.origin ?? "القيمة"} ${n} ${e.maximum.toString()} ${r.unit ?? "عنصر"}` : `أكبر من اللازم: يفترض أن تكون ${e.origin ?? "القيمة"} ${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `أصغر من اللازم: يفترض لـ ${e.origin} أن يكون ${n} ${e.minimum.toString()} ${r.unit}` : `أصغر من اللازم: يفترض لـ ${e.origin} أن يكون ${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `نَص غير مقبول: يجب أن يبدأ بـ "${e.prefix}"` : t.format === "ends_with" ? `نَص غير مقبول: يجب أن ينتهي بـ "${t.suffix}"` : t.format === "includes" ? `نَص غير مقبول: يجب أن يتضمَّن "${t.includes}"` : t.format === "regex" ? `نَص غير مقبول: يجب أن يطابق النمط ${t.pattern}` : `${n[t.format] ?? e.format} غير مقبول`;
			}
			case "not_multiple_of": return `رقم غير مقبول: يجب أن يكون من مضاعفات ${e.divisor}`;
			case "unrecognized_keys": return `معرف${e.keys.length > 1 ? "ات" : ""} غريب${e.keys.length > 1 ? "ة" : ""}: ${N(e.keys, "، ")}`;
			case "invalid_key": return `معرف غير مقبول في ${e.origin}`;
			case "invalid_union": return "مدخل غير مقبول";
			case "invalid_element": return `مدخل غير مقبول في ${e.origin}`;
			default: return "مدخل غير مقبول";
		}
	};
};
function nD() {
	return { localeError: tD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/az.js
var rD = () => {
	let e = {
		string: {
			unit: "simvol",
			verb: "olmalıdır"
		},
		file: {
			unit: "bayt",
			verb: "olmalıdır"
		},
		array: {
			unit: "element",
			verb: "olmalıdır"
		},
		set: {
			unit: "element",
			verb: "olmalıdır"
		},
		map: {
			unit: "element",
			verb: "olmalıdır"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "email address",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datetime",
		date: "ISO date",
		time: "ISO time",
		duration: "ISO duration",
		ipv4: "IPv4 address",
		ipv6: "IPv6 address",
		mac: "MAC address",
		cidrv4: "IPv4 range",
		cidrv6: "IPv6 range",
		base64: "base64-encoded string",
		base64url: "base64url-encoded string",
		json_string: "JSON string",
		e164: "E.164 number",
		credit_card: "kredit kartı nömrəsi",
		jwt: "JWT",
		template_literal: "input"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Yanlış dəyər: gözlənilən instanceof ${e.expected}, daxil olan ${i}` : `Yanlış dəyər: gözlənilən ${t}, daxil olan ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Yanlış dəyər: gözlənilən ${L(e.values[0])}` : `Yanlış seçim: aşağıdakılardan biri olmalıdır: ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Çox böyük: gözlənilən ${e.origin ?? "dəyər"} ${n}${e.maximum.toString()} ${r.unit ?? "element"}` : `Çox böyük: gözlənilən ${e.origin ?? "dəyər"} ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Çox kiçik: gözlənilən ${e.origin} ${n}${e.minimum.toString()} ${r.unit}` : `Çox kiçik: gözlənilən ${e.origin} ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Yanlış mətn: "${t.prefix}" ilə başlamalıdır` : t.format === "ends_with" ? `Yanlış mətn: "${t.suffix}" ilə bitməlidir` : t.format === "includes" ? `Yanlış mətn: "${t.includes}" daxil olmalıdır` : t.format === "regex" ? `Yanlış mətn: ${t.pattern} şablonuna uyğun olmalıdır` : `Yanlış ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Yanlış ədəd: ${e.divisor} ilə bölünə bilən olmalıdır`;
			case "unrecognized_keys": return `Tanınmayan açar${e.keys.length > 1 ? "lar" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} daxilində yanlış açar`;
			case "invalid_union": return "Yanlış dəyər";
			case "invalid_element": return `${e.origin} daxilində yanlış dəyər`;
			default: return "Yanlış dəyər";
		}
	};
};
function iD() {
	return { localeError: rD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/be.js
function aD(e, t, n, r) {
	let i = Math.abs(e), a = i % 10, o = i % 100;
	return o >= 11 && o <= 19 ? r : a === 1 ? t : a >= 2 && a <= 4 ? n : r;
}
var oD = () => {
	let e = {
		string: {
			unit: {
				one: "сімвал",
				few: "сімвалы",
				many: "сімвалаў"
			},
			verb: "мець"
		},
		array: {
			unit: {
				one: "элемент",
				few: "элементы",
				many: "элементаў"
			},
			verb: "мець"
		},
		set: {
			unit: {
				one: "элемент",
				few: "элементы",
				many: "элементаў"
			},
			verb: "мець"
		},
		map: {
			unit: {
				one: "элемент",
				few: "элементы",
				many: "элементаў"
			},
			verb: "мець"
		},
		file: {
			unit: {
				one: "байт",
				few: "байты",
				many: "байтаў"
			},
			verb: "мець"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "увод",
		email: "email адрас",
		url: "URL",
		emoji: "эмодзі",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO дата і час",
		date: "ISO дата",
		time: "ISO час",
		duration: "ISO працягласць",
		ipv4: "IPv4 адрас",
		ipv6: "IPv6 адрас",
		mac: "MAC адрас",
		cidrv4: "IPv4 дыяпазон",
		cidrv6: "IPv6 дыяпазон",
		base64: "радок у фармаце base64",
		base64url: "радок у фармаце base64url",
		json_string: "JSON радок",
		e164: "нумар E.164",
		credit_card: "нумар крэдытнай карты",
		jwt: "JWT",
		template_literal: "увод"
	}, r = {
		nan: "NaN",
		number: "лік",
		array: "масіў"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Няправільны ўвод: чакаўся instanceof ${e.expected}, атрымана ${i}` : `Няправільны ўвод: чакаўся ${t}, атрымана ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Няправільны ўвод: чакалася ${L(e.values[0])}` : `Няправільны варыянт: чакаўся адзін з ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				if (r) {
					let t = aD(Number(e.maximum), r.unit.one, r.unit.few, r.unit.many);
					return `Занадта вялікі: чакалася, што ${e.origin ?? "значэнне"} павінна ${r.verb} ${n}${e.maximum.toString()} ${t}`;
				}
				return `Занадта вялікі: чакалася, што ${e.origin ?? "значэнне"} павінна быць ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				if (r) {
					let t = aD(Number(e.minimum), r.unit.one, r.unit.few, r.unit.many);
					return `Занадта малы: чакалася, што ${e.origin} павінна ${r.verb} ${n}${e.minimum.toString()} ${t}`;
				}
				return `Занадта малы: чакалася, што ${e.origin} павінна быць ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Няправільны радок: павінен пачынацца з "${t.prefix}"` : t.format === "ends_with" ? `Няправільны радок: павінен заканчвацца на "${t.suffix}"` : t.format === "includes" ? `Няправільны радок: павінен змяшчаць "${t.includes}"` : t.format === "regex" ? `Няправільны радок: павінен адпавядаць шаблону ${t.pattern}` : `Няправільны ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Няправільны лік: павінен быць кратным ${e.divisor}`;
			case "unrecognized_keys": return `Нераспазнаны ${e.keys.length > 1 ? "ключы" : "ключ"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Няправільны ключ у ${e.origin}`;
			case "invalid_union": return "Няправільны ўвод";
			case "invalid_element": return `Няправільнае значэнне ў ${e.origin}`;
			default: return "Няправільны ўвод";
		}
	};
};
function sD() {
	return { localeError: oD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/bg.js
var cD = () => {
	let e = {
		string: {
			unit: "символа",
			verb: "да съдържа"
		},
		file: {
			unit: "байта",
			verb: "да съдържа"
		},
		array: {
			unit: "елемента",
			verb: "да съдържа"
		},
		set: {
			unit: "елемента",
			verb: "да съдържа"
		},
		map: {
			unit: "елемента",
			verb: "да съдържа"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "вход",
		email: "имейл адрес",
		url: "URL",
		emoji: "емоджи",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO време",
		date: "ISO дата",
		time: "ISO време",
		duration: "ISO продължителност",
		ipv4: "IPv4 адрес",
		ipv6: "IPv6 адрес",
		mac: "MAC адрес",
		cidrv4: "IPv4 диапазон",
		cidrv6: "IPv6 диапазон",
		base64: "base64-кодиран низ",
		base64url: "base64url-кодиран низ",
		json_string: "JSON низ",
		e164: "E.164 номер",
		credit_card: "номер на кредитна карта",
		jwt: "JWT",
		template_literal: "вход"
	}, r = {
		nan: "NaN",
		number: "число",
		array: "масив"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Невалиден вход: очакван instanceof ${e.expected}, получен ${i}` : `Невалиден вход: очакван ${t}, получен ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Невалиден вход: очакван ${L(e.values[0])}` : `Невалидна опция: очаквано едно от ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Твърде голямо: очаква се ${e.origin ?? "стойност"} да съдържа ${n}${e.maximum.toString()} ${r.unit ?? "елемента"}` : `Твърде голямо: очаква се ${e.origin ?? "стойност"} да бъде ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Твърде малко: очаква се ${e.origin} да съдържа ${n}${e.minimum.toString()} ${r.unit}` : `Твърде малко: очаква се ${e.origin} да бъде ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				if (t.format === "starts_with") return `Невалиден низ: трябва да започва с "${t.prefix}"`;
				if (t.format === "ends_with") return `Невалиден низ: трябва да завършва с "${t.suffix}"`;
				if (t.format === "includes") return `Невалиден низ: трябва да включва "${t.includes}"`;
				if (t.format === "regex") return `Невалиден низ: трябва да съвпада с ${t.pattern}`;
				let r = "Невалиден";
				return t.format === "emoji" && (r = "Невалидно"), t.format === "datetime" && (r = "Невалидно"), t.format === "date" && (r = "Невалидна"), t.format === "time" && (r = "Невалидно"), t.format === "duration" && (r = "Невалидна"), `${r} ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Невалидно число: трябва да бъде кратно на ${e.divisor}`;
			case "unrecognized_keys": return `Неразпознат${e.keys.length > 1 ? "и" : ""} ключ${e.keys.length > 1 ? "ове" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Невалиден ключ в ${e.origin}`;
			case "invalid_union": return "Невалиден вход";
			case "invalid_element": return `Невалидна стойност в ${e.origin}`;
			default: return "Невалиден вход";
		}
	};
};
function lD() {
	return { localeError: cD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/bn.js
var uD = () => {
	let e = {
		string: {
			unit: "অক্ষর",
			verb: "থাকতে হবে"
		},
		file: {
			unit: "বাইট",
			verb: "থাকতে হবে"
		},
		array: {
			unit: "আইটেম",
			verb: "থাকতে হবে"
		},
		set: {
			unit: "আইটেম",
			verb: "থাকতে হবে"
		},
		map: {
			unit: "এন্ট্রি",
			verb: "থাকতে হবে"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ইনপুট",
		email: "ইমেইল ঠিকানা",
		url: "URL",
		emoji: "ইমোজি",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO তারিখ ও সময়",
		date: "ISO তারিখ",
		time: "ISO সময়",
		duration: "ISO সময়কাল",
		ipv4: "IPv4 ঠিকানা",
		ipv6: "IPv6 ঠিকানা",
		mac: "MAC ঠিকানা",
		cidrv4: "IPv4 রেঞ্জ",
		cidrv6: "IPv6 রেঞ্জ",
		base64: "base64-এনকোডেড স্ট্রিং",
		base64url: "base64url-এনকোডেড স্ট্রিং",
		json_string: "JSON স্ট্রিং",
		e164: "E.164 নম্বর",
		credit_card: "ক্রেডিট কার্ড নম্বর",
		jwt: "JWT",
		template_literal: "ইনপুট"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input);
				return `অবৈধ ইনপুট: প্রত্যাশিত ${t}, প্রাপ্ত ${r[n] ?? n}`;
			}
			case "invalid_value": return e.values.length === 1 ? `অবৈধ ইনপুট: প্রত্যাশিত ${L(e.values[0])}` : `অবৈধ অপশন: ${N(e.values, " | ")} এর মধ্যে একটি প্রত্যাশিত`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `অনেক বড়: ${e.origin ?? "মান"} ${n}${e.maximum.toString()} ${r.unit ?? "এলিমেন্ট"} হতে হবে` : `অনেক বড়: ${e.origin ?? "মান"} ${n}${e.maximum.toString()} হতে হবে`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `অনেক ছোট: ${e.origin} ${n}${e.minimum.toString()} ${r.unit} হতে হবে` : `অনেক ছোট: ${e.origin} ${n}${e.minimum.toString()} হতে হবে`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `অবৈধ স্ট্রিং: "${t.prefix}" দিয়ে শুরু হতে হবে` : t.format === "ends_with" ? `অবৈধ স্ট্রিং: "${t.suffix}" দিয়ে শেষ হতে হবে` : t.format === "includes" ? `অবৈধ স্ট্রিং: "${t.includes}" অন্তর্ভুক্ত থাকতে হবে` : t.format === "regex" ? `অবৈধ স্ট্রিং: ${t.pattern} প্যাটার্ন মিলতে হবে` : `অবৈধ ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `অবৈধ নম্বর: ${e.divisor} এর গুণিতক হতে হবে`;
			case "unrecognized_keys": return `অচেনা কী${e.keys.length > 1 ? "গুলো" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} এ অবৈধ কী`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `অবৈধ ডিসক্রিমিনেটর মান। প্রত্যাশিত ${e.options.map((e) => `'${e}'`).join(" | ")}` : "অবৈধ ইনপুট";
			case "invalid_element": return `${e.origin} এ অবৈধ মান`;
			default: return "অবৈধ ইনপুট";
		}
	};
};
function dD() {
	return { localeError: uD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/ca.js
var fD = () => {
	let e = {
		string: {
			unit: "caràcters",
			verb: "contenir"
		},
		file: {
			unit: "bytes",
			verb: "contenir"
		},
		array: {
			unit: "elements",
			verb: "contenir"
		},
		set: {
			unit: "elements",
			verb: "contenir"
		},
		map: {
			unit: "elements",
			verb: "contenir"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "entrada",
		email: "adreça electrònica",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "data i hora ISO",
		date: "data ISO",
		time: "hora ISO",
		duration: "durada ISO",
		ipv4: "adreça IPv4",
		ipv6: "adreça IPv6",
		mac: "adreça MAC",
		cidrv4: "rang IPv4",
		cidrv6: "rang IPv6",
		base64: "cadena codificada en base64",
		base64url: "cadena codificada en base64url",
		json_string: "cadena JSON",
		e164: "número E.164",
		credit_card: "número de targeta de crèdit",
		jwt: "JWT",
		template_literal: "entrada"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Tipus invàlid: s'esperava instanceof ${e.expected}, s'ha rebut ${i}` : `Tipus invàlid: s'esperava ${t}, s'ha rebut ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Valor invàlid: s'esperava ${L(e.values[0])}` : `Opció invàlida: s'esperava una de ${N(e.values, " o ")}`;
			case "too_big": {
				let n = e.inclusive ? "com a màxim" : "menys de", r = t(e.origin);
				return r ? `Massa gran: s'esperava que ${e.origin ?? "el valor"} contingués ${n} ${e.maximum.toString()} ${r.unit ?? "elements"}` : `Massa gran: s'esperava que ${e.origin ?? "el valor"} fos ${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? "com a mínim" : "més de", r = t(e.origin);
				return r ? `Massa petit: s'esperava que ${e.origin} contingués ${n} ${e.minimum.toString()} ${r.unit}` : `Massa petit: s'esperava que ${e.origin} fos ${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Format invàlid: ha de començar amb "${t.prefix}"` : t.format === "ends_with" ? `Format invàlid: ha d'acabar amb "${t.suffix}"` : t.format === "includes" ? `Format invàlid: ha d'incloure "${t.includes}"` : t.format === "regex" ? `Format invàlid: ha de coincidir amb el patró ${t.pattern}` : `Format invàlid per a ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Número invàlid: ha de ser múltiple de ${e.divisor}`;
			case "unrecognized_keys": return `Clau${e.keys.length > 1 ? "s" : ""} no reconeguda${e.keys.length > 1 ? "s" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Clau invàlida a ${e.origin}`;
			case "invalid_union": return "Entrada invàlida";
			case "invalid_element": return `Element invàlid a ${e.origin}`;
			default: return "Entrada invàlida";
		}
	};
};
function pD() {
	return { localeError: fD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/ckb.js
var mD = () => {
	let e = {
		string: {
			unit: "پیت",
			verb: "بێت"
		},
		file: {
			unit: "بایت",
			verb: "بێت"
		},
		array: {
			unit: "دانە",
			verb: "بێت"
		},
		set: {
			unit: "دانە",
			verb: "بێت"
		},
		map: {
			unit: "دانە",
			verb: "بێت"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "regex",
		email: "ئیمەیڵ",
		url: "بەستەر (URL)",
		emoji: "ئیمۆجی",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ڕێکەوت و کات",
		date: "ڕێکەوت",
		time: "کات",
		duration: "ماوە",
		ipv4: "ناونیشانی IPv4",
		ipv6: "ناونیشانی IPv6",
		mac: "ناونیشانی MAC",
		cidrv4: "مەودای IPv4",
		cidrv6: "مەودای IPv6",
		base64: "دەقی base64",
		base64url: "دەقی base64url",
		json_string: "دەقی JSON",
		e164: "ژمارەی E.164",
		credit_card: "ژمارەی کارتی کرێدیت",
		jwt: "JWT",
		template_literal: "تێکردە"
	}, r = {
		nan: "NaN",
		string: "نووسین",
		number: "ژمارە",
		boolean: "boolean",
		array: "array",
		object: "object",
		date: "ڕێکەوت",
		integer: "ژمارە",
		float: "ژمارە",
		null: "null",
		undefined: "undefined",
		function: "function",
		symbol: "symbol",
		unknown: "unknown",
		promise: "promise",
		void: "void",
		never: "never",
		map: "map",
		set: "set"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n, a = [
					"ا",
					"و",
					"ۆ",
					"وو",
					"ە",
					"ی",
					"ێ"
				].some((e) => i.endsWith(e)) ? "یە" : "ە", o = /^[a-zA-Z]+$/.test(i);
				return n === "null" || n === "undefined" ? "داواکراوە" : `چاوەڕوانکراوە ${t} بێت، بەڵام ${i}${o ? "" : a}`;
			}
			case "invalid_value": return e.values.length === 1 ? `بەهاکە نادرووستە: چاوەڕوانکراوە ${L(e.values[0])} بێت` : `هەڵبژاردەی نادروست: چاوەڕوانکراوە یەکێک بێت لە ${N(e.values, "|")}`;
			case "too_big": {
				let n = t(e.origin);
				return n ? `پێویستە بە لایەنی زۆرەوە ${e.maximum.toString()} ${n.unit} ${n.verb}` : `پێویستە بە لایەنی زۆرەوە ${e.maximum.toString()} بێت`;
			}
			case "too_small": {
				let n = t(e.origin);
				return n ? `پێویستە بە لایەنی کەمەوە ${e.minimum.toString()} ${n.unit} ${n.verb}` : `پێویستە بە لایەنی کەمەوە ${e.minimum.toString()} بێت`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `دەقی نادروست: پێویستە دەستپێبکات بە "${t.prefix}"` : t.format === "ends_with" ? `دەقی نادروست: پێویستە کۆتاییبێت بە "${t.suffix}"` : t.format === "includes" ? `دەقی نادروست: پێویستە "${t.includes}" لەخۆبگرێت` : t.format === "regex" ? `دەقی نادروست: پێویستە لەگەڵ پاتێرنی ${t.pattern} بگونجێت` : `بەهای ${n[t.format] ?? e.format} نادروستە`;
			}
			case "not_multiple_of": return `ژمارەی نادروست: دەبێت چەند هێندە بێت بۆ ${e.divisor}`;
			case "unrecognized_keys": return `کلیلی نەناسراو: ${N(e.keys, ", ")}`;
			case "invalid_key": return `کلیلی نادروست لە ${e.origin}`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `بەهای نەناسراو هەیە. بەهای چاوەڕوانکراو: ${e.options.map((e) => `'${e}'`).join(" | ")}` : "یەکگرتنی نادروست";
			case "invalid_element": return `${e.origin} بەهاکە نادروستە`;
			default: return "تێکردەی نادروست";
		}
	};
};
function hD() {
	return { localeError: mD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/cs.js
var gD = () => {
	let e = {
		string: {
			unit: "znaků",
			verb: "mít"
		},
		file: {
			unit: "bajtů",
			verb: "mít"
		},
		array: {
			unit: "prvků",
			verb: "mít"
		},
		set: {
			unit: "prvků",
			verb: "mít"
		},
		map: {
			unit: "prvků",
			verb: "mít"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "regulární výraz",
		email: "e-mailová adresa",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "datum a čas ve formátu ISO",
		date: "datum ve formátu ISO",
		time: "čas ve formátu ISO",
		duration: "doba trvání ISO",
		ipv4: "IPv4 adresa",
		ipv6: "IPv6 adresa",
		mac: "MAC adresa",
		cidrv4: "rozsah IPv4",
		cidrv6: "rozsah IPv6",
		base64: "řetězec zakódovaný ve formátu base64",
		base64url: "řetězec zakódovaný ve formátu base64url",
		json_string: "řetězec ve formátu JSON",
		e164: "číslo E.164",
		credit_card: "číslo kreditní karty",
		jwt: "JWT",
		template_literal: "vstup"
	}, r = {
		nan: "NaN",
		number: "číslo",
		string: "řetězec",
		function: "funkce",
		array: "pole"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Neplatný vstup: očekáváno instanceof ${e.expected}, obdrženo ${i}` : `Neplatný vstup: očekáváno ${t}, obdrženo ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Neplatný vstup: očekáváno ${L(e.values[0])}` : `Neplatná možnost: očekávána jedna z hodnot ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Hodnota je příliš velká: ${e.origin ?? "hodnota"} musí mít ${n}${e.maximum.toString()} ${r.unit ?? "prvků"}` : `Hodnota je příliš velká: ${e.origin ?? "hodnota"} musí být ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Hodnota je příliš malá: ${e.origin ?? "hodnota"} musí mít ${n}${e.minimum.toString()} ${r.unit ?? "prvků"}` : `Hodnota je příliš malá: ${e.origin ?? "hodnota"} musí být ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Neplatný řetězec: musí začínat na "${t.prefix}"` : t.format === "ends_with" ? `Neplatný řetězec: musí končit na "${t.suffix}"` : t.format === "includes" ? `Neplatný řetězec: musí obsahovat "${t.includes}"` : t.format === "regex" ? `Neplatný řetězec: musí odpovídat vzoru ${t.pattern}` : `Neplatný formát ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Neplatné číslo: musí být násobkem ${e.divisor}`;
			case "unrecognized_keys": return `Neznámé klíče: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Neplatný klíč v ${e.origin}`;
			case "invalid_union": return "Neplatný vstup";
			case "invalid_element": return `Neplatná hodnota v ${e.origin}`;
			default: return "Neplatný vstup";
		}
	};
};
function _D() {
	return { localeError: gD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/da.js
var vD = () => {
	let e = {
		string: {
			unit: "tegn",
			verb: "havde"
		},
		file: {
			unit: "bytes",
			verb: "havde"
		},
		array: {
			unit: "elementer",
			verb: "indeholdt"
		},
		set: {
			unit: "elementer",
			verb: "indeholdt"
		},
		map: {
			unit: "elementer",
			verb: "indeholdt"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "e-mailadresse",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO dato- og klokkeslæt",
		date: "ISO-dato",
		time: "ISO-klokkeslæt",
		duration: "ISO-varighed",
		ipv4: "IPv4-adresse",
		ipv6: "IPv6-adresse",
		mac: "MAC-adresse",
		cidrv4: "IPv4-spektrum",
		cidrv6: "IPv6-spektrum",
		base64: "base64-kodet streng",
		base64url: "base64url-kodet streng",
		json_string: "JSON-streng",
		e164: "E.164-nummer",
		credit_card: "kreditkortnummer",
		jwt: "JWT",
		template_literal: "input"
	}, r = {
		nan: "NaN",
		string: "streng",
		number: "tal",
		boolean: "boolean",
		array: "liste",
		object: "objekt",
		set: "sæt",
		file: "fil"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Ugyldigt input: forventede instanceof ${e.expected}, fik ${i}` : `Ugyldigt input: forventede ${t}, fik ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Ugyldig værdi: forventede ${L(e.values[0])}` : `Ugyldigt valg: forventede en af følgende ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", i = t(e.origin), a = r[e.origin] ?? e.origin;
				return i ? `For stor: forventede ${a ?? "value"} ${i.verb} ${n} ${e.maximum.toString()} ${i.unit ?? "elementer"}` : `For stor: forventede ${a ?? "value"} havde ${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", i = t(e.origin), a = r[e.origin] ?? e.origin;
				return i ? `For lille: forventede ${a} ${i.verb} ${n} ${e.minimum.toString()} ${i.unit}` : `For lille: forventede ${a} havde ${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ugyldig streng: skal starte med "${t.prefix}"` : t.format === "ends_with" ? `Ugyldig streng: skal ende med "${t.suffix}"` : t.format === "includes" ? `Ugyldig streng: skal indeholde "${t.includes}"` : t.format === "regex" ? `Ugyldig streng: skal matche mønsteret ${t.pattern}` : `Ugyldig ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Ugyldigt tal: skal være deleligt med ${e.divisor}`;
			case "unrecognized_keys": return `${e.keys.length > 1 ? "Ukendte nøgler" : "Ukendt nøgle"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Ugyldig nøgle i ${e.origin}`;
			case "invalid_union": return "Ugyldigt input: matcher ingen af de tilladte typer";
			case "invalid_element": return `Ugyldig værdi i ${e.origin}`;
			default: return "Ugyldigt input";
		}
	};
};
function yD() {
	return { localeError: vD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/de.js
var bD = () => {
	let e = {
		string: {
			unit: "Zeichen",
			verb: "zu haben"
		},
		file: {
			unit: "Bytes",
			verb: "zu haben"
		},
		array: {
			unit: "Elemente",
			verb: "zu haben"
		},
		set: {
			unit: "Elemente",
			verb: "zu haben"
		},
		map: {
			unit: "Elemente",
			verb: "zu haben"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "Eingabe",
		email: "E-Mail-Adresse",
		url: "URL",
		emoji: "Emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO-Datum und -Uhrzeit",
		date: "ISO-Datum",
		time: "ISO-Uhrzeit",
		duration: "ISO-Dauer",
		ipv4: "IPv4-Adresse",
		ipv6: "IPv6-Adresse",
		mac: "MAC-Adresse",
		cidrv4: "IPv4-Bereich",
		cidrv6: "IPv6-Bereich",
		base64: "Base64-codierter String",
		base64url: "Base64-URL-codierter String",
		json_string: "JSON-String",
		e164: "E.164-Nummer",
		credit_card: "Kreditkartennummer",
		jwt: "JWT",
		template_literal: "Eingabe"
	}, r = {
		nan: "NaN",
		number: "Zahl",
		array: "Array"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Ungültige Eingabe: erwartet instanceof ${e.expected}, erhalten ${i}` : `Ungültige Eingabe: erwartet ${t}, erhalten ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Ungültige Eingabe: erwartet ${L(e.values[0])}` : `Ungültige Option: erwartet eine von ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Zu groß: erwartet, dass ${e.origin ?? "Wert"} ${n}${e.maximum.toString()} ${r.unit ?? "Elemente"} hat` : `Zu groß: erwartet, dass ${e.origin ?? "Wert"} ${n}${e.maximum.toString()} ist`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Zu klein: erwartet, dass ${e.origin} ${n}${e.minimum.toString()} ${r.unit} hat` : `Zu klein: erwartet, dass ${e.origin} ${n}${e.minimum.toString()} ist`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ungültiger String: muss mit "${t.prefix}" beginnen` : t.format === "ends_with" ? `Ungültiger String: muss mit "${t.suffix}" enden` : t.format === "includes" ? `Ungültiger String: muss "${t.includes}" enthalten` : t.format === "regex" ? `Ungültiger String: muss dem Muster ${t.pattern} entsprechen` : `Ungültig: ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Ungültige Zahl: muss ein Vielfaches von ${e.divisor} sein`;
			case "unrecognized_keys": return `${e.keys.length > 1 ? "Unbekannte Schlüssel" : "Unbekannter Schlüssel"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Ungültiger Schlüssel in ${e.origin}`;
			case "invalid_union": return "Ungültige Eingabe";
			case "invalid_element": return `Ungültiger Wert in ${e.origin}`;
			default: return "Ungültige Eingabe";
		}
	};
};
function xD() {
	return { localeError: bD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/el.js
var SD = () => {
	let e = {
		string: {
			unit: "χαρακτήρες",
			verb: "να έχει"
		},
		file: {
			unit: "bytes",
			verb: "να έχει"
		},
		array: {
			unit: "στοιχεία",
			verb: "να έχει"
		},
		set: {
			unit: "στοιχεία",
			verb: "να έχει"
		},
		map: {
			unit: "καταχωρήσεις",
			verb: "να έχει"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "είσοδος",
		email: "διεύθυνση email",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO ημερομηνία και ώρα",
		date: "ISO ημερομηνία",
		time: "ISO ώρα",
		duration: "ISO διάρκεια",
		ipv4: "διεύθυνση IPv4",
		ipv6: "διεύθυνση IPv6",
		mac: "διεύθυνση MAC",
		cidrv4: "εύρος IPv4",
		cidrv6: "εύρος IPv6",
		base64: "συμβολοσειρά κωδικοποιημένη σε base64",
		base64url: "συμβολοσειρά κωδικοποιημένη σε base64url",
		json_string: "συμβολοσειρά JSON",
		e164: "αριθμός E.164",
		credit_card: "αριθμός πιστωτικής κάρτας",
		jwt: "JWT",
		template_literal: "είσοδος"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return typeof e.expected == "string" && /^[A-Z]/.test(e.expected) ? `Μη έγκυρη είσοδος: αναμενόταν instanceof ${e.expected}, λήφθηκε ${i}` : `Μη έγκυρη είσοδος: αναμενόταν ${t}, λήφθηκε ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Μη έγκυρη είσοδος: αναμενόταν ${L(e.values[0])}` : `Μη έγκυρη επιλογή: αναμενόταν ένα από ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Πολύ μεγάλο: αναμενόταν ${e.origin ?? "τιμή"} να έχει ${n}${e.maximum.toString()} ${r.unit ?? "στοιχεία"}` : `Πολύ μεγάλο: αναμενόταν ${e.origin ?? "τιμή"} να είναι ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Πολύ μικρό: αναμενόταν ${e.origin} να έχει ${n}${e.minimum.toString()} ${r.unit}` : `Πολύ μικρό: αναμενόταν ${e.origin} να είναι ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Μη έγκυρη συμβολοσειρά: πρέπει να ξεκινά με "${t.prefix}"` : t.format === "ends_with" ? `Μη έγκυρη συμβολοσειρά: πρέπει να τελειώνει με "${t.suffix}"` : t.format === "includes" ? `Μη έγκυρη συμβολοσειρά: πρέπει να περιέχει "${t.includes}"` : t.format === "regex" ? `Μη έγκυρη συμβολοσειρά: πρέπει να ταιριάζει με το μοτίβο ${t.pattern}` : `Μη έγκυρο: ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Μη έγκυρος αριθμός: πρέπει να είναι πολλαπλάσιο του ${e.divisor}`;
			case "unrecognized_keys": return `Άγνωστ${e.keys.length > 1 ? "α" : "ο"} κλειδ${e.keys.length > 1 ? "ιά" : "ί"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Μη έγκυρο κλειδί στο ${e.origin}`;
			case "invalid_union": return "Μη έγκυρη είσοδος";
			case "invalid_element": return `Μη έγκυρη τιμή στο ${e.origin}`;
			default: return "Μη έγκυρη είσοδος";
		}
	};
};
function CD() {
	return { localeError: SD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/en.js
var wD = () => {
	let e = {
		string: {
			unit: "characters",
			verb: "to have"
		},
		file: {
			unit: "bytes",
			verb: "to have"
		},
		array: {
			unit: "items",
			verb: "to have"
		},
		set: {
			unit: "items",
			verb: "to have"
		},
		map: {
			unit: "entries",
			verb: "to have"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "email address",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datetime",
		date: "ISO date",
		time: "ISO time",
		duration: "ISO duration",
		ipv4: "IPv4 address",
		ipv6: "IPv6 address",
		mac: "MAC address",
		cidrv4: "IPv4 range",
		cidrv6: "IPv6 range",
		base64: "base64-encoded string",
		base64url: "base64url-encoded string",
		json_string: "JSON string",
		e164: "E.164 number",
		credit_card: "credit card number",
		jwt: "JWT",
		template_literal: "input"
	}, r = { nan: "NaN" };
	function i(e, t) {
		return e === "number" && typeof t == "number" && !Number.isFinite(t) ? String(t) : r[e] ?? e;
	}
	return (e) => {
		switch (e.code) {
			case "invalid_type": return `Invalid input: expected ${i(e.expected)}, received ${i(R(e.input), e.input)}`;
			case "invalid_value": return e.values.length === 1 ? `Invalid input: expected ${L(e.values[0])}` : `Invalid option: expected one of ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.exact ? "exactly " : e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Too big: expected ${e.origin ?? "value"} to have ${n}${e.maximum.toString()} ${r.unit ?? "elements"}` : `Too big: expected ${e.origin ?? "value"} to be ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.exact ? "exactly " : e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Too small: expected ${e.origin} to have ${n}${e.minimum.toString()} ${r.unit}` : `Too small: expected ${e.origin} to be ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Invalid string: must start with "${t.prefix}"` : t.format === "ends_with" ? `Invalid string: must end with "${t.suffix}"` : t.format === "includes" ? `Invalid string: must include "${t.includes}"` : t.format === "regex" ? `Invalid string: must match pattern ${t.pattern}` : `Invalid ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Invalid number: must be a multiple of ${e.divisor}`;
			case "unrecognized_keys": return `Unrecognized key${e.keys.length > 1 ? "s" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Invalid key in ${e.origin}`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `Invalid discriminator value. Expected ${e.options.map((e) => `'${e}'`).join(" | ")}` : e.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
			case "invalid_element": return `Invalid value in ${e.origin}`;
			default: return "Invalid input";
		}
	};
};
function TD() {
	return { localeError: wD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/eo.js
var ED = () => {
	let e = {
		string: {
			unit: "karaktrojn",
			verb: "havi"
		},
		file: {
			unit: "bajtojn",
			verb: "havi"
		},
		array: {
			unit: "elementojn",
			verb: "havi"
		},
		set: {
			unit: "elementojn",
			verb: "havi"
		},
		map: {
			unit: "elementojn",
			verb: "havi"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "enigo",
		email: "retadreso",
		url: "URL",
		emoji: "emoĝio",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO-datotempo",
		date: "ISO-dato",
		time: "ISO-tempo",
		duration: "ISO-daŭro",
		ipv4: "IPv4-adreso",
		ipv6: "IPv6-adreso",
		mac: "MAC-adreso",
		cidrv4: "IPv4-rango",
		cidrv6: "IPv6-rango",
		base64: "64-ume kodita karaktraro",
		base64url: "URL-64-ume kodita karaktraro",
		json_string: "JSON-karaktraro",
		e164: "E.164-nombro",
		credit_card: "kreditkarta numero",
		jwt: "JWT",
		template_literal: "enigo"
	}, r = {
		nan: "NaN",
		number: "nombro",
		array: "tabelo",
		null: "senvalora"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Nevalida enigo: atendiĝis instanceof ${e.expected}, riceviĝis ${i}` : `Nevalida enigo: atendiĝis ${t}, riceviĝis ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Nevalida enigo: atendiĝis ${L(e.values[0])}` : `Nevalida opcio: atendiĝis unu el ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Tro granda: atendiĝis ke ${e.origin ?? "valoro"} havu ${n}${e.maximum.toString()} ${r.unit ?? "elementojn"}` : `Tro granda: atendiĝis ke ${e.origin ?? "valoro"} havu ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Tro malgranda: atendiĝis ke ${e.origin} havu ${n}${e.minimum.toString()} ${r.unit}` : `Tro malgranda: atendiĝis ke ${e.origin} estu ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Nevalida karaktraro: devas komenciĝi per "${t.prefix}"` : t.format === "ends_with" ? `Nevalida karaktraro: devas finiĝi per "${t.suffix}"` : t.format === "includes" ? `Nevalida karaktraro: devas inkluzivi "${t.includes}"` : t.format === "regex" ? `Nevalida karaktraro: devas kongrui kun la modelo ${t.pattern}` : `Nevalida ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Nevalida nombro: devas esti oblo de ${e.divisor}`;
			case "unrecognized_keys": return `Nekonata${e.keys.length > 1 ? "j" : ""} ŝlosilo${e.keys.length > 1 ? "j" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Nevalida ŝlosilo en ${e.origin}`;
			case "invalid_union": return "Nevalida enigo";
			case "invalid_element": return `Nevalida valoro en ${e.origin}`;
			default: return "Nevalida enigo";
		}
	};
};
function DD() {
	return { localeError: ED() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/es.js
var OD = () => {
	let e = {
		string: {
			unit: "caracteres",
			verb: "tener"
		},
		file: {
			unit: "bytes",
			verb: "tener"
		},
		array: {
			unit: "elementos",
			verb: "tener"
		},
		set: {
			unit: "elementos",
			verb: "tener"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "entrada",
		email: "dirección de correo electrónico",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "fecha y hora ISO",
		date: "fecha ISO",
		time: "hora ISO",
		duration: "duración ISO",
		ipv4: "dirección IPv4",
		ipv6: "dirección IPv6",
		mac: "dirección MAC",
		cidrv4: "rango IPv4",
		cidrv6: "rango IPv6",
		base64: "cadena codificada en base64",
		base64url: "URL codificada en base64",
		json_string: "cadena JSON",
		e164: "número E.164",
		credit_card: "número de tarjeta de crédito",
		jwt: "JWT",
		template_literal: "entrada"
	}, r = {
		nan: "NaN",
		string: "texto",
		number: "número",
		boolean: "booleano",
		array: "arreglo",
		object: "objeto",
		set: "conjunto",
		file: "archivo",
		date: "fecha",
		bigint: "número grande",
		symbol: "símbolo",
		undefined: "indefinido",
		null: "nulo",
		function: "función",
		map: "mapa",
		record: "registro",
		tuple: "tupla",
		enum: "enumeración",
		union: "unión",
		literal: "literal",
		promise: "promesa",
		void: "vacío",
		never: "nunca",
		unknown: "desconocido",
		any: "cualquiera"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Entrada inválida: se esperaba instanceof ${e.expected}, recibido ${i}` : `Entrada inválida: se esperaba ${t}, recibido ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Entrada inválida: se esperaba ${L(e.values[0])}` : `Opción inválida: se esperaba una de ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", i = t(e.origin), a = r[e.origin] ?? e.origin;
				return i ? `Demasiado grande: se esperaba que ${a ?? "valor"} tuviera ${n}${e.maximum.toString()} ${i.unit ?? "elementos"}` : `Demasiado grande: se esperaba que ${a ?? "valor"} fuera ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", i = t(e.origin), a = r[e.origin] ?? e.origin;
				return i ? `Demasiado pequeño: se esperaba que ${a} tuviera ${n}${e.minimum.toString()} ${i.unit}` : `Demasiado pequeño: se esperaba que ${a} fuera ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Cadena inválida: debe comenzar con "${t.prefix}"` : t.format === "ends_with" ? `Cadena inválida: debe terminar en "${t.suffix}"` : t.format === "includes" ? `Cadena inválida: debe incluir "${t.includes}"` : t.format === "regex" ? `Cadena inválida: debe coincidir con el patrón ${t.pattern}` : `Inválido ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Número inválido: debe ser múltiplo de ${e.divisor}`;
			case "unrecognized_keys": return `Llave${e.keys.length > 1 ? "s" : ""} desconocida${e.keys.length > 1 ? "s" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Llave inválida en ${r[e.origin] ?? e.origin}`;
			case "invalid_union": return "Entrada inválida";
			case "invalid_element": return `Valor inválido en ${r[e.origin] ?? e.origin}`;
			default: return "Entrada inválida";
		}
	};
};
function kD() {
	return { localeError: OD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/fa.js
var AD = () => {
	let e = {
		string: {
			unit: "کاراکتر",
			verb: "داشته باشد"
		},
		file: {
			unit: "بایت",
			verb: "داشته باشد"
		},
		array: {
			unit: "آیتم",
			verb: "داشته باشد"
		},
		set: {
			unit: "آیتم",
			verb: "داشته باشد"
		},
		map: {
			unit: "آیتم",
			verb: "داشته باشد"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ورودی",
		email: "آدرس ایمیل",
		url: "URL",
		emoji: "ایموجی",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "تاریخ و زمان ایزو",
		date: "تاریخ ایزو",
		time: "زمان ایزو",
		duration: "مدت زمان ایزو",
		ipv4: "IPv4 آدرس",
		ipv6: "IPv6 آدرس",
		mac: "MAC آدرس",
		cidrv4: "IPv4 دامنه",
		cidrv6: "IPv6 دامنه",
		base64: "base64-encoded رشته",
		base64url: "base64url-encoded رشته",
		json_string: "JSON رشته",
		e164: "E.164 عدد",
		credit_card: "شماره کارت اعتباری",
		jwt: "JWT",
		template_literal: "ورودی"
	}, r = {
		nan: "NaN",
		number: "عدد",
		array: "آرایه"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `ورودی نامعتبر: می‌بایست instanceof ${e.expected} می‌بود، ${i} دریافت شد` : `ورودی نامعتبر: می‌بایست ${t} می‌بود، ${i} دریافت شد`;
			}
			case "invalid_value": return e.values.length === 1 ? `ورودی نامعتبر: می‌بایست ${L(e.values[0])} می‌بود` : `گزینه نامعتبر: می‌بایست یکی از ${N(e.values, "|")} می‌بود`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `خیلی بزرگ: ${e.origin ?? "مقدار"} باید ${n}${e.maximum.toString()} ${r.unit ?? "عنصر"} باشد` : `خیلی بزرگ: ${e.origin ?? "مقدار"} باید ${n}${e.maximum.toString()} باشد`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `خیلی کوچک: ${e.origin} باید ${n}${e.minimum.toString()} ${r.unit} باشد` : `خیلی کوچک: ${e.origin} باید ${n}${e.minimum.toString()} باشد`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `رشته نامعتبر: باید با "${t.prefix}" شروع شود` : t.format === "ends_with" ? `رشته نامعتبر: باید با "${t.suffix}" تمام شود` : t.format === "includes" ? `رشته نامعتبر: باید شامل "${t.includes}" باشد` : t.format === "regex" ? `رشته نامعتبر: باید با الگوی ${t.pattern} مطابقت داشته باشد` : `${n[t.format] ?? e.format} نامعتبر`;
			}
			case "not_multiple_of": return `عدد نامعتبر: باید مضرب ${e.divisor} باشد`;
			case "unrecognized_keys": return `کلید${e.keys.length > 1 ? "های" : ""} ناشناس: ${N(e.keys, ", ")}`;
			case "invalid_key": return `کلید ناشناس در ${e.origin}`;
			case "invalid_union": return "ورودی نامعتبر";
			case "invalid_element": return `مقدار نامعتبر در ${e.origin}`;
			default: return "ورودی نامعتبر";
		}
	};
};
function jD() {
	return { localeError: AD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/fi.js
var MD = () => {
	let e = {
		string: {
			unit: "merkkiä",
			subject: "merkkijonon"
		},
		file: {
			unit: "tavua",
			subject: "tiedoston"
		},
		array: {
			unit: "alkiota",
			subject: "listan"
		},
		set: {
			unit: "alkiota",
			subject: "joukon"
		},
		map: {
			unit: "alkiota",
			subject: "kuvauksen"
		},
		number: {
			unit: "",
			subject: "luvun"
		},
		bigint: {
			unit: "",
			subject: "suuren kokonaisluvun"
		},
		int: {
			unit: "",
			subject: "kokonaisluvun"
		},
		date: {
			unit: "",
			subject: "päivämäärän"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "säännöllinen lauseke",
		email: "sähköpostiosoite",
		url: "URL-osoite",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO-aikaleima",
		date: "ISO-päivämäärä",
		time: "ISO-aika",
		duration: "ISO-kesto",
		ipv4: "IPv4-osoite",
		ipv6: "IPv6-osoite",
		mac: "MAC-osoite",
		cidrv4: "IPv4-alue",
		cidrv6: "IPv6-alue",
		base64: "base64-koodattu merkkijono",
		base64url: "base64url-koodattu merkkijono",
		json_string: "JSON-merkkijono",
		e164: "E.164-luku",
		credit_card: "luottokortin numero",
		jwt: "JWT",
		template_literal: "templaattimerkkijono"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Virheellinen tyyppi: odotettiin instanceof ${e.expected}, oli ${i}` : `Virheellinen tyyppi: odotettiin ${t}, oli ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Virheellinen syöte: täytyy olla ${L(e.values[0])}` : `Virheellinen valinta: täytyy olla yksi seuraavista: ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Liian suuri: ${r.subject} täytyy olla ${n}${e.maximum.toString()} ${r.unit}`.trim() : `Liian suuri: arvon täytyy olla ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Liian pieni: ${r.subject} täytyy olla ${n}${e.minimum.toString()} ${r.unit}`.trim() : `Liian pieni: arvon täytyy olla ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Virheellinen syöte: täytyy alkaa "${t.prefix}"` : t.format === "ends_with" ? `Virheellinen syöte: täytyy loppua "${t.suffix}"` : t.format === "includes" ? `Virheellinen syöte: täytyy sisältää "${t.includes}"` : t.format === "regex" ? `Virheellinen syöte: täytyy vastata säännöllistä lauseketta ${t.pattern}` : `Virheellinen ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Virheellinen luku: täytyy olla luvun ${e.divisor} monikerta`;
			case "unrecognized_keys": return `${e.keys.length > 1 ? "Tuntemattomat avaimet" : "Tuntematon avain"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return "Virheellinen avain tietueessa";
			case "invalid_union": return "Virheellinen unioni";
			case "invalid_element": return "Virheellinen arvo joukossa";
			default: return "Virheellinen syöte";
		}
	};
};
function ND() {
	return { localeError: MD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/fr.js
var PD = () => {
	let e = {
		string: {
			unit: "caractères",
			verb: "avoir"
		},
		file: {
			unit: "octets",
			verb: "avoir"
		},
		array: {
			unit: "éléments",
			verb: "avoir"
		},
		set: {
			unit: "éléments",
			verb: "avoir"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "expression régulière",
		email: "adresse e-mail",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "date et heure ISO",
		date: "date ISO",
		time: "heure ISO",
		duration: "durée ISO",
		ipv4: "adresse IPv4",
		ipv6: "adresse IPv6",
		mac: "adresse MAC",
		cidrv4: "plage IPv4",
		cidrv6: "plage IPv6",
		base64: "chaîne de caractères encodée en base64",
		base64url: "chaîne de caractères encodée en base64url",
		json_string: "chaîne de caractères JSON",
		e164: "numéro au format E.164",
		credit_card: "numéro de carte de crédit",
		jwt: "JWT",
		template_literal: "entrée"
	}, r = {
		string: "chaîne de caractères",
		number: "nombre",
		int: "entier",
		boolean: "booléen",
		bigint: "grand entier",
		symbol: "symbole",
		undefined: "indéfini",
		null: "null",
		never: "jamais",
		void: "vide",
		date: "date",
		array: "tableau",
		object: "objet",
		tuple: "tuple",
		record: "record",
		map: "map",
		set: "ensemble",
		file: "fichier",
		nonoptional: "non optionnel",
		nan: "NaN",
		function: "fonction"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Entrée invalide : instance de ${e.expected} attendu, ${i} reçu` : `Entrée invalide : ${t} attendu, ${i} reçu`;
			}
			case "invalid_value": return e.values.length === 1 ? `Entrée invalide : ${L(e.values[0])} attendu` : `Option invalide : une valeur parmi ${N(e.values, "|")} attendue`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", i = t(e.origin);
				return i ? `Trop grand : ${r[e.origin] ?? "valeur"} doit ${i.verb} ${n}${e.maximum.toString()} ${i.unit ?? "élément(s)"}` : `Trop grand : ${r[e.origin] ?? "valeur"} doit être ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", i = t(e.origin);
				return i ? `Trop petit : ${r[e.origin] ?? "valeur"} doit ${i.verb} ${n}${e.minimum.toString()} ${i.unit}` : `Trop petit : ${r[e.origin] ?? "valeur"} doit être ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Chaîne de caractères invalide : doit commencer par "${t.prefix}"` : t.format === "ends_with" ? `Chaîne de caractères invalide : doit se terminer par "${t.suffix}"` : t.format === "includes" ? `Chaîne de caractères invalide : doit inclure "${t.includes}"` : t.format === "regex" ? `Chaîne de caractères invalide : doit correspondre au motif ${t.pattern}` : `${n[t.format] ?? e.format} invalide`;
			}
			case "not_multiple_of": return `Nombre invalide : doit être un multiple de ${e.divisor}`;
			case "unrecognized_keys": return `Clé${e.keys.length > 1 ? "s" : ""} non reconnue${e.keys.length > 1 ? "s" : ""} : ${N(e.keys, ", ")}`;
			case "invalid_key": return `Clé invalide dans ${e.origin}`;
			case "invalid_union": return "Entrée invalide";
			case "invalid_element": return `Valeur invalide dans ${e.origin}`;
			default: return "Entrée invalide";
		}
	};
};
function FD() {
	return { localeError: PD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/fr-CA.js
var ID = () => {
	let e = {
		string: {
			unit: "caractères",
			verb: "avoir"
		},
		file: {
			unit: "octets",
			verb: "avoir"
		},
		array: {
			unit: "éléments",
			verb: "avoir"
		},
		set: {
			unit: "éléments",
			verb: "avoir"
		},
		map: {
			unit: "éléments",
			verb: "avoir"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "entrée",
		email: "adresse courriel",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "date-heure ISO",
		date: "date ISO",
		time: "heure ISO",
		duration: "durée ISO",
		ipv4: "adresse IPv4",
		ipv6: "adresse IPv6",
		mac: "adresse MAC",
		cidrv4: "plage IPv4",
		cidrv6: "plage IPv6",
		base64: "chaîne encodée en base64",
		base64url: "chaîne encodée en base64url",
		json_string: "chaîne JSON",
		e164: "numéro E.164",
		credit_card: "numéro de carte de crédit",
		jwt: "JWT",
		template_literal: "entrée"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Entrée invalide : attendu instanceof ${e.expected}, reçu ${i}` : `Entrée invalide : attendu ${t}, reçu ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Entrée invalide : attendu ${L(e.values[0])}` : `Option invalide : attendu l'une des valeurs suivantes ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "≤" : "<", r = t(e.origin);
				return r ? `Trop grand : attendu que ${e.origin ?? "la valeur"} ait ${n}${e.maximum.toString()} ${r.unit}` : `Trop grand : attendu que ${e.origin ?? "la valeur"} soit ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? "≥" : ">", r = t(e.origin);
				return r ? `Trop petit : attendu que ${e.origin} ait ${n}${e.minimum.toString()} ${r.unit}` : `Trop petit : attendu que ${e.origin} soit ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Chaîne invalide : doit commencer par "${t.prefix}"` : t.format === "ends_with" ? `Chaîne invalide : doit se terminer par "${t.suffix}"` : t.format === "includes" ? `Chaîne invalide : doit inclure "${t.includes}"` : t.format === "regex" ? `Chaîne invalide : doit correspondre au motif ${t.pattern}` : `${n[t.format] ?? e.format} invalide`;
			}
			case "not_multiple_of": return `Nombre invalide : doit être un multiple de ${e.divisor}`;
			case "unrecognized_keys": return `Clé${e.keys.length > 1 ? "s" : ""} non reconnue${e.keys.length > 1 ? "s" : ""} : ${N(e.keys, ", ")}`;
			case "invalid_key": return `Clé invalide dans ${e.origin}`;
			case "invalid_union": return "Entrée invalide";
			case "invalid_element": return `Valeur invalide dans ${e.origin}`;
			default: return "Entrée invalide";
		}
	};
};
function LD() {
	return { localeError: ID() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/gu.js
var RD = () => {
	let e = {
		string: {
			unit: "અક્ષર",
			verb: "હોવા જોઈએ"
		},
		file: {
			unit: "બાયટ",
			verb: "હોવા જોઈએ"
		},
		array: {
			unit: "આઇટમ",
			verb: "હોવા જોઈએ"
		},
		set: {
			unit: "આઇટમ",
			verb: "હોવા જોઈએ"
		},
		map: {
			unit: "એન્ટ્રી",
			verb: "હોવા જોઈએ"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ઇનપુટ",
		email: "ઈમેઇલ એડ્રેસ",
		url: "URL",
		emoji: "ઇમોજી",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO તારીખ અને સમય",
		date: "ISO તારીખ",
		time: "ISO સમય",
		duration: "ISO અવધિ",
		ipv4: "IPv4 એડ્રેસ",
		ipv6: "IPv6 એડ્રેસ",
		mac: "MAC એડ્રેસ",
		cidrv4: "IPv4 શ્રેણી",
		cidrv6: "IPv6 શ્રેણી",
		base64: "base64-એન્કોડેડ સ્ટ્રિંગ",
		base64url: "base64url-એન્કોડેડ સ્ટ્રિંગ",
		json_string: "JSON સ્ટ્રિંગ",
		e164: "E.164 નંબર",
		credit_card: "ક્રેડિટ કાર્ડ નંબર",
		jwt: "JWT",
		template_literal: "ઇનપુટ"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input);
				return `અમાન્ય ઇનપુટ: અપેક્ષિત ${t}, પ્રાપ્ત ${r[n] ?? n}`;
			}
			case "invalid_value": return e.values.length === 1 ? `અમાન્ય ઇનપુટ: અપેક્ષિત ${L(e.values[0])}` : `અમાન્ય વિકલ્પ: ${N(e.values, " | ")} માધ્યમથી એક અપેક્ષિત`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `ખૂબ મોટું: ${e.origin ?? "મૂલ્ય"} ${n}${e.maximum.toString()} ${r.unit ?? "એલિમેન્ટ"} હોવા જોઈએ` : `ખૂબ મોટું: ${e.origin ?? "મૂલ્ય"} ${n}${e.maximum.toString()} હોવું જોઈએ`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `ખૂબ નાનું: ${e.origin} ${n}${e.minimum.toString()} ${r.unit} હોવા જોઈએ` : `ખૂબ નાનું: ${e.origin} ${n}${e.minimum.toString()} હોવું જોઈએ`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `અમાન્ય સ્ટ્રિંગ: "${t.prefix}" થી શરૂ થવું જોઈએ` : t.format === "ends_with" ? `અમાન્ય સ્ટ્રિંગ: "${t.suffix}" પર સમાપ્ત થવું જોઈએ` : t.format === "includes" ? `અમાન્ય સ્ટ્રિંગ: "${t.includes}" શામેલ હોવું જોઈએ` : t.format === "regex" ? `અમાન્ય સ્ટ્રિંગ: પેટર્ન ${t.pattern} સાથે મેળ ખાવું જોઈએ` : `અમાન્ય ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `અમાન્ય નંબર: ${e.divisor} નો ગુણાંક હોવો જોઈએ`;
			case "unrecognized_keys": return `ઓળખી શકાતા નહીં તે કી${e.keys.length > 1 ? "ઓ" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} માં અમાન્ય કી`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `અમાન્ય ડિસ્ક્રિમિનેટર મૂલ્ય. અપેક્ષિત ${e.options.map((e) => `'${e}'`).join(" | ")}` : "અમાન્ય ઇનપુટ";
			case "invalid_element": return `${e.origin} માં અમાન્ય મૂલ્ય`;
			default: return "અમાન્ય ઇનપુટ";
		}
	};
};
function zD() {
	return { localeError: RD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/he.js
var BD = () => {
	let e = {
		string: {
			label: "מחרוזת",
			gender: "f"
		},
		number: {
			label: "מספר",
			gender: "m"
		},
		boolean: {
			label: "ערך בוליאני",
			gender: "m"
		},
		bigint: {
			label: "BigInt",
			gender: "m"
		},
		date: {
			label: "תאריך",
			gender: "m"
		},
		array: {
			label: "מערך",
			gender: "m"
		},
		object: {
			label: "אובייקט",
			gender: "m"
		},
		null: {
			label: "ערך ריק (null)",
			gender: "m"
		},
		undefined: {
			label: "ערך לא מוגדר (undefined)",
			gender: "m"
		},
		symbol: {
			label: "סימבול (Symbol)",
			gender: "m"
		},
		function: {
			label: "פונקציה",
			gender: "f"
		},
		map: {
			label: "מפה (Map)",
			gender: "f"
		},
		set: {
			label: "קבוצה (Set)",
			gender: "f"
		},
		file: {
			label: "קובץ",
			gender: "m"
		},
		promise: {
			label: "Promise",
			gender: "m"
		},
		NaN: {
			label: "NaN",
			gender: "m"
		},
		unknown: {
			label: "ערך לא ידוע",
			gender: "m"
		},
		value: {
			label: "ערך",
			gender: "m"
		}
	}, t = {
		string: {
			unit: "תווים",
			shortLabel: "קצר",
			longLabel: "ארוך"
		},
		file: {
			unit: "בייטים",
			shortLabel: "קטן",
			longLabel: "גדול"
		},
		array: {
			unit: "פריטים",
			shortLabel: "קטן",
			longLabel: "גדול"
		},
		set: {
			unit: "פריטים",
			shortLabel: "קטן",
			longLabel: "גדול"
		},
		number: {
			unit: "",
			shortLabel: "קטן",
			longLabel: "גדול"
		}
	}, n = (t) => t ? e[t] : void 0, r = (t) => {
		let r = n(t);
		return r ? r.label : t ?? e.unknown.label;
	}, i = (e) => `ה${r(e)}`, a = (e) => (n(e)?.gender ?? "m") === "f" ? "צריכה להיות" : "צריך להיות", o = (e) => e ? t[e] ?? null : null, s = {
		regex: {
			label: "קלט",
			gender: "m"
		},
		email: {
			label: "כתובת אימייל",
			gender: "f"
		},
		url: {
			label: "כתובת רשת",
			gender: "f"
		},
		emoji: {
			label: "אימוג'י",
			gender: "m"
		},
		uuid: {
			label: "UUID",
			gender: "m"
		},
		uuidv4: {
			label: "UUIDv4",
			gender: "m"
		},
		uuidv6: {
			label: "UUIDv6",
			gender: "m"
		},
		nanoid: {
			label: "nanoid",
			gender: "m"
		},
		guid: {
			label: "GUID",
			gender: "m"
		},
		cuid: {
			label: "cuid",
			gender: "m"
		},
		cuid2: {
			label: "cuid2",
			gender: "m"
		},
		ulid: {
			label: "ULID",
			gender: "m"
		},
		xid: {
			label: "XID",
			gender: "m"
		},
		ksuid: {
			label: "KSUID",
			gender: "m"
		},
		datetime: {
			label: "תאריך וזמן ISO",
			gender: "m"
		},
		date: {
			label: "תאריך ISO",
			gender: "m"
		},
		time: {
			label: "זמן ISO",
			gender: "m"
		},
		duration: {
			label: "משך זמן ISO",
			gender: "m"
		},
		ipv4: {
			label: "כתובת IPv4",
			gender: "f"
		},
		ipv6: {
			label: "כתובת IPv6",
			gender: "f"
		},
		mac: {
			label: "כתובת MAC",
			gender: "f"
		},
		cidrv4: {
			label: "טווח IPv4",
			gender: "m"
		},
		cidrv6: {
			label: "טווח IPv6",
			gender: "m"
		},
		base64: {
			label: "מחרוזת בבסיס 64",
			gender: "f"
		},
		base64url: {
			label: "מחרוזת בבסיס 64 לכתובות רשת",
			gender: "f"
		},
		json_string: {
			label: "מחרוזת JSON",
			gender: "f"
		},
		e164: {
			label: "מספר E.164",
			gender: "m"
		},
		credit_card: {
			label: "מספר כרטיס אשראי",
			gender: "m"
		},
		jwt: {
			label: "JWT",
			gender: "m"
		},
		template_literal: {
			label: "קלט",
			gender: "m"
		},
		ends_with: {
			label: "קלט",
			gender: "m"
		},
		includes: {
			label: "קלט",
			gender: "m"
		},
		lowercase: {
			label: "קלט",
			gender: "m"
		},
		starts_with: {
			label: "קלט",
			gender: "m"
		},
		uppercase: {
			label: "קלט",
			gender: "m"
		}
	}, c = { nan: "NaN" };
	return (t) => {
		switch (t.code) {
			case "invalid_type": {
				let n = t.expected, i = c[n ?? ""] ?? r(n), a = R(t.input), o = c[a] ?? e[a]?.label ?? a;
				return /^[A-Z]/.test(t.expected) ? `קלט לא תקין: צריך להיות instanceof ${t.expected}, התקבל ${o}` : `קלט לא תקין: צריך להיות ${i}, התקבל ${o}`;
			}
			case "invalid_value": {
				if (t.values.length === 1) return `ערך לא תקין: הערך חייב להיות ${L(t.values[0])}`;
				let e = t.values.map((e) => L(e));
				if (t.values.length === 2) return `ערך לא תקין: האפשרויות המתאימות הן ${e[0]} או ${e[1]}`;
				let n = e[e.length - 1];
				return `ערך לא תקין: האפשרויות המתאימות הן ${e.slice(0, -1).join(", ")} או ${n}`;
			}
			case "too_big": {
				let e = o(t.origin), n = i(t.origin ?? "value");
				if (t.origin === "string") return `${e?.longLabel ?? "ארוך"} מדי: ${n} צריכה להכיל ${t.maximum.toString()} ${e?.unit ?? ""} ${t.inclusive ? "או פחות" : "לכל היותר"}`.trim();
				if (t.origin === "number") return `גדול מדי: ${n} צריך להיות ${t.inclusive ? `קטן או שווה ל-${t.maximum}` : `קטן מ-${t.maximum}`}`;
				if (t.origin === "array" || t.origin === "set") return `גדול מדי: ${n} ${t.origin === "set" ? "צריכה" : "צריך"} להכיל ${t.inclusive ? `${t.maximum} ${e?.unit ?? ""} או פחות` : `פחות מ-${t.maximum} ${e?.unit ?? ""}`}`.trim();
				let r = t.inclusive ? "<=" : "<", s = a(t.origin ?? "value");
				return e?.unit ? `${e.longLabel} מדי: ${n} ${s} ${r}${t.maximum.toString()} ${e.unit}` : `${e?.longLabel ?? "גדול"} מדי: ${n} ${s} ${r}${t.maximum.toString()}`;
			}
			case "too_small": {
				let e = o(t.origin), n = i(t.origin ?? "value");
				if (t.origin === "string") return `${e?.shortLabel ?? "קצר"} מדי: ${n} צריכה להכיל ${t.minimum.toString()} ${e?.unit ?? ""} ${t.inclusive ? "או יותר" : "לפחות"}`.trim();
				if (t.origin === "number") return `קטן מדי: ${n} צריך להיות ${t.inclusive ? `גדול או שווה ל-${t.minimum}` : `גדול מ-${t.minimum}`}`;
				if (t.origin === "array" || t.origin === "set") {
					let r = t.origin === "set" ? "צריכה" : "צריך";
					return t.minimum === 1 && t.inclusive ? `קטן מדי: ${n} ${r} להכיל ${t.origin, "לפחות פריט אחד"}` : `קטן מדי: ${n} ${r} להכיל ${t.inclusive ? `${t.minimum} ${e?.unit ?? ""} או יותר` : `יותר מ-${t.minimum} ${e?.unit ?? ""}`}`.trim();
				}
				let r = t.inclusive ? ">=" : ">", s = a(t.origin ?? "value");
				return e?.unit ? `${e.shortLabel} מדי: ${n} ${s} ${r}${t.minimum.toString()} ${e.unit}` : `${e?.shortLabel ?? "קטן"} מדי: ${n} ${s} ${r}${t.minimum.toString()}`;
			}
			case "invalid_format": {
				let e = t;
				if (e.format === "starts_with") return `המחרוזת חייבת להתחיל ב "${e.prefix}"`;
				if (e.format === "ends_with") return `המחרוזת חייבת להסתיים ב "${e.suffix}"`;
				if (e.format === "includes") return `המחרוזת חייבת לכלול "${e.includes}"`;
				if (e.format === "regex") return `המחרוזת חייבת להתאים לתבנית ${e.pattern}`;
				let n = s[e.format];
				return `${n?.label ?? e.format} לא ${(n?.gender ?? "m") === "f" ? "תקינה" : "תקין"}`;
			}
			case "not_multiple_of": return `מספר לא תקין: חייב להיות מכפלה של ${t.divisor}`;
			case "unrecognized_keys": return `מפתח${t.keys.length > 1 ? "ות" : ""} לא מזוה${t.keys.length > 1 ? "ים" : "ה"}: ${N(t.keys, ", ")}`;
			case "invalid_key": return "שדה לא תקין באובייקט";
			case "invalid_union": return "קלט לא תקין";
			case "invalid_element": return `ערך לא תקין ב${i(t.origin ?? "array")}`;
			default: return "קלט לא תקין";
		}
	};
};
function VD() {
	return { localeError: BD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/hi.js
var HD = () => {
	let e = {
		string: {
			unit: "अक्षर",
			verb: "रखने के लिए"
		},
		file: {
			unit: "बाइट्स",
			verb: "रखने के लिए"
		},
		array: {
			unit: "तत्व",
			verb: "रखने के लिए"
		},
		set: {
			unit: "तत्व",
			verb: "रखने के लिए"
		},
		map: {
			unit: "प्रविष्टियाँ",
			verb: "रखने के लिए"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "इनपुट",
		email: "ईमेल पता",
		url: "URL",
		emoji: "इमोजी",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO तिथि और समय",
		date: "ISO तिथि",
		time: "ISO समय",
		duration: "ISO अवधि",
		ipv4: "IPv4 पता",
		ipv6: "IPv6 पता",
		mac: "MAC पता",
		cidrv4: "IPv4 श्रेणी",
		cidrv6: "IPv6 श्रेणी",
		base64: "Base64-एन्कोडेड स्ट्रिंग",
		base64url: "Base64URL-एन्कोडेड स्ट्रिंग",
		json_string: "JSON स्ट्रिंग",
		e164: "E.164 संख्या",
		credit_card: "क्रेडिट कार्ड संख्या",
		jwt: "JWT",
		template_literal: "इनपुट"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input);
				return `अमान्य इनपुट: अपेक्षित ${t}, प्राप्त ${r[n] ?? n}`;
			}
			case "invalid_value": return e.values.length === 1 ? `अमान्य इनपुट: अपेक्षित ${L(e.values[0])}` : `अमान्य विकल्प: अपेक्षित मानों में से एक ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `बहुत बड़ा: अपेक्षित था कि ${e.origin ?? "मान"} में ${n}${e.maximum} ${r.unit} हों` : `बहुत बड़ा: अपेक्षित था कि ${e.origin ?? "मान"} ${n}${e.maximum} हो`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `बहुत छोटा: अपेक्षित था कि ${e.origin} में ${n}${e.minimum} ${r.unit} हों` : `बहुत छोटा: अपेक्षित था कि ${e.origin} ${n}${e.minimum} हो`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `अमान्य स्ट्रिंग: "${t.prefix}" से शुरू होना चाहिए` : t.format === "ends_with" ? `अमान्य स्ट्रिंग: "${t.suffix}" पर समाप्त होना चाहिए` : t.format === "includes" ? `अमान्य स्ट्रिंग: इसमें "${t.includes}" शामिल होना चाहिए` : t.format === "regex" ? `अमान्य स्ट्रिंग: पैटर्न ${t.pattern} से मेल खाना चाहिए` : `अमान्य ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `अमान्य संख्या: यह ${e.divisor} का गुणज होना चाहिए`;
			case "unrecognized_keys": return `अपरिचित कुंजी${e.keys.length > 1 ? "याँ" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `अमान्य कुंजी: ${e.origin} में`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `अमान्य डिस्क्रिमिनेटर मान: अपेक्षित ${e.options.map((e) => `'${e}'`).join(" | ")}` : "अमान्य इनपुट";
			case "invalid_element": return `अमान्य मान: ${e.origin} में`;
			default: return "अमान्य इनपुट";
		}
	};
};
function UD() {
	return { localeError: HD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/hr.js
var WD = () => {
	let e = {
		string: {
			unit: "znakova",
			verb: "imati"
		},
		file: {
			unit: "bajtova",
			verb: "imati"
		},
		array: {
			unit: "stavki",
			verb: "imati"
		},
		set: {
			unit: "stavki",
			verb: "imati"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "unos",
		email: "email adresa",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datum i vrijeme",
		date: "ISO datum",
		time: "ISO vrijeme",
		duration: "ISO trajanje",
		ipv4: "IPv4 adresa",
		ipv6: "IPv6 adresa",
		mac: "MAC adresa",
		cidrv4: "IPv4 raspon",
		cidrv6: "IPv6 raspon",
		base64: "base64 kodirani tekst",
		base64url: "base64url kodirani tekst",
		json_string: "JSON tekst",
		e164: "E.164 broj",
		credit_card: "broj kreditne kartice",
		jwt: "JWT",
		template_literal: "unos"
	}, r = {
		nan: "NaN",
		string: "tekst",
		number: "broj",
		boolean: "boolean",
		array: "niz",
		object: "objekt",
		set: "skup",
		file: "datoteka",
		date: "datum",
		bigint: "bigint",
		symbol: "simbol",
		undefined: "undefined",
		null: "null",
		function: "funkcija",
		map: "mapa"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Neispravan unos: očekuje se instanceof ${e.expected}, a primljeno je ${i}` : `Neispravan unos: očekuje se ${t}, a primljeno je ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Neispravna vrijednost: očekivano ${L(e.values[0])}` : `Neispravna opcija: očekivano jedno od ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", i = t(e.origin), a = r[e.origin] ?? e.origin;
				return i ? `Preveliko: očekivano da ${a ?? "vrijednost"} ima ${n}${e.maximum.toString()} ${i.unit ?? "elemenata"}` : `Preveliko: očekivano da ${a ?? "vrijednost"} bude ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", i = t(e.origin), a = r[e.origin] ?? e.origin;
				return i ? `Premalo: očekivano da ${a} ima ${n}${e.minimum.toString()} ${i.unit}` : `Premalo: očekivano da ${a} bude ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Neispravan tekst: mora započinjati s "${t.prefix}"` : t.format === "ends_with" ? `Neispravan tekst: mora završavati s "${t.suffix}"` : t.format === "includes" ? `Neispravan tekst: mora sadržavati "${t.includes}"` : t.format === "regex" ? `Neispravan tekst: mora odgovarati uzorku ${t.pattern}` : `Neispravna ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Neispravan broj: mora biti višekratnik od ${e.divisor}`;
			case "unrecognized_keys": return `Neprepoznat${e.keys.length > 1 ? "i ključevi" : " ključ"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Neispravan ključ u ${r[e.origin] ?? e.origin}`;
			case "invalid_union": return "Neispravan unos";
			case "invalid_element": return `Neispravna vrijednost u ${r[e.origin] ?? e.origin}`;
			default: return "Neispravan unos";
		}
	};
};
function GD() {
	return { localeError: WD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/hu.js
var KD = () => {
	let e = {
		string: {
			unit: "karakter",
			verb: "legyen"
		},
		file: {
			unit: "byte",
			verb: "legyen"
		},
		array: {
			unit: "elem",
			verb: "legyen"
		},
		set: {
			unit: "elem",
			verb: "legyen"
		},
		map: {
			unit: "elem",
			verb: "legyen"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "bemenet",
		email: "email cím",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO időbélyeg",
		date: "ISO dátum",
		time: "ISO idő",
		duration: "ISO időintervallum",
		ipv4: "IPv4 cím",
		ipv6: "IPv6 cím",
		mac: "MAC cím",
		cidrv4: "IPv4 tartomány",
		cidrv6: "IPv6 tartomány",
		base64: "base64-kódolt string",
		base64url: "base64url-kódolt string",
		json_string: "JSON string",
		e164: "E.164 szám",
		credit_card: "hitelkártyaszám",
		jwt: "JWT",
		template_literal: "bemenet"
	}, r = {
		nan: "NaN",
		number: "szám",
		array: "tömb"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Érvénytelen bemenet: a várt érték instanceof ${e.expected}, a kapott érték ${i}` : `Érvénytelen bemenet: a várt érték ${t}, a kapott érték ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Érvénytelen bemenet: a várt érték ${L(e.values[0])}` : `Érvénytelen opció: valamelyik érték várt ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Túl nagy: ${e.origin ?? "érték"} mérete túl nagy ${n}${e.maximum.toString()} ${r.unit ?? "elem"}` : `Túl nagy: a bemeneti érték ${e.origin ?? "érték"} túl nagy: ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Túl kicsi: a bemeneti érték ${e.origin} mérete túl kicsi ${n}${e.minimum.toString()} ${r.unit}` : `Túl kicsi: a bemeneti érték ${e.origin} túl kicsi ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Érvénytelen string: "${t.prefix}" értékkel kell kezdődnie` : t.format === "ends_with" ? `Érvénytelen string: "${t.suffix}" értékkel kell végződnie` : t.format === "includes" ? `Érvénytelen string: "${t.includes}" értéket kell tartalmaznia` : t.format === "regex" ? `Érvénytelen string: ${t.pattern} mintának kell megfelelnie` : `Érvénytelen ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Érvénytelen szám: ${e.divisor} többszörösének kell lennie`;
			case "unrecognized_keys": return `Ismeretlen kulcs${e.keys.length > 1 ? "s" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Érvénytelen kulcs ${e.origin}`;
			case "invalid_union": return "Érvénytelen bemenet";
			case "invalid_element": return `Érvénytelen érték: ${e.origin}`;
			default: return "Érvénytelen bemenet";
		}
	};
};
function qD() {
	return { localeError: KD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/hy.js
function JD(e, t, n) {
	return Math.abs(e) === 1 ? t : n;
}
function YD(e) {
	if (!e) return "";
	let t = [
		"ա",
		"ե",
		"ը",
		"ի",
		"ո",
		"ու",
		"օ"
	], n = e[e.length - 1];
	return e + (t.includes(n) ? "ն" : "ը");
}
var XD = () => {
	let e = {
		string: {
			unit: {
				one: "նշան",
				many: "նշաններ"
			},
			verb: "ունենալ"
		},
		file: {
			unit: {
				one: "բայթ",
				many: "բայթեր"
			},
			verb: "ունենալ"
		},
		array: {
			unit: {
				one: "տարր",
				many: "տարրեր"
			},
			verb: "ունենալ"
		},
		set: {
			unit: {
				one: "տարր",
				many: "տարրեր"
			},
			verb: "ունենալ"
		},
		map: {
			unit: {
				one: "տարր",
				many: "տարրեր"
			},
			verb: "ունենալ"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "մուտք",
		email: "էլ. հասցե",
		url: "URL",
		emoji: "էմոջի",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO ամսաթիվ և ժամ",
		date: "ISO ամսաթիվ",
		time: "ISO ժամ",
		duration: "ISO տևողություն",
		ipv4: "IPv4 հասցե",
		ipv6: "IPv6 հասցե",
		mac: "MAC հասցե",
		cidrv4: "IPv4 միջակայք",
		cidrv6: "IPv6 միջակայք",
		base64: "base64 ձևաչափով տող",
		base64url: "base64url ձևաչափով տող",
		json_string: "JSON տող",
		e164: "E.164 համար",
		credit_card: "կրեդիտ քարտի համար",
		jwt: "JWT",
		template_literal: "մուտք"
	}, r = {
		nan: "NaN",
		number: "թիվ",
		array: "զանգված"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Սխալ մուտքագրում․ սպասվում էր instanceof ${e.expected}, ստացվել է ${i}` : `Սխալ մուտքագրում․ սպասվում էր ${t}, ստացվել է ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Սխալ մուտքագրում․ սպասվում էր ${L(e.values[1])}` : `Սխալ տարբերակ․ սպասվում էր հետևյալներից մեկը՝ ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				if (r) {
					let t = JD(Number(e.maximum), r.unit.one, r.unit.many);
					return `Չափազանց մեծ արժեք․ սպասվում է, որ ${YD(e.origin ?? "արժեք")} կունենա ${n}${e.maximum.toString()} ${t}`;
				}
				return `Չափազանց մեծ արժեք․ սպասվում է, որ ${YD(e.origin ?? "արժեք")} լինի ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				if (r) {
					let t = JD(Number(e.minimum), r.unit.one, r.unit.many);
					return `Չափազանց փոքր արժեք․ սպասվում է, որ ${YD(e.origin)} կունենա ${n}${e.minimum.toString()} ${t}`;
				}
				return `Չափազանց փոքր արժեք․ սպասվում է, որ ${YD(e.origin)} լինի ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Սխալ տող․ պետք է սկսվի "${t.prefix}"-ով` : t.format === "ends_with" ? `Սխալ տող․ պետք է ավարտվի "${t.suffix}"-ով` : t.format === "includes" ? `Սխալ տող․ պետք է պարունակի "${t.includes}"` : t.format === "regex" ? `Սխալ տող․ պետք է համապատասխանի ${t.pattern} ձևաչափին` : `Սխալ ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Սխալ թիվ․ պետք է բազմապատիկ լինի ${e.divisor}-ի`;
			case "unrecognized_keys": return `Չճանաչված բանալի${e.keys.length > 1 ? "ներ" : ""}. ${N(e.keys, ", ")}`;
			case "invalid_key": return `Սխալ բանալի ${YD(e.origin)}-ում`;
			case "invalid_union": return "Սխալ մուտքագրում";
			case "invalid_element": return `Սխալ արժեք ${YD(e.origin)}-ում`;
			default: return "Սխալ մուտքագրում";
		}
	};
};
function ZD() {
	return { localeError: XD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/id.js
var QD = () => {
	let e = {
		string: {
			unit: "karakter",
			verb: "memiliki"
		},
		file: {
			unit: "byte",
			verb: "memiliki"
		},
		array: {
			unit: "item",
			verb: "memiliki"
		},
		set: {
			unit: "item",
			verb: "memiliki"
		},
		map: {
			unit: "item",
			verb: "memiliki"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "alamat email",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "tanggal dan waktu format ISO",
		date: "tanggal format ISO",
		time: "jam format ISO",
		duration: "durasi format ISO",
		ipv4: "alamat IPv4",
		ipv6: "alamat IPv6",
		mac: "alamat MAC",
		cidrv4: "rentang alamat IPv4",
		cidrv6: "rentang alamat IPv6",
		base64: "string dengan enkode base64",
		base64url: "string dengan enkode base64url",
		json_string: "string JSON",
		e164: "angka E.164",
		credit_card: "nomor kartu kredit",
		jwt: "JWT",
		template_literal: "input"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Input tidak valid: diharapkan instanceof ${e.expected}, diterima ${i}` : `Input tidak valid: diharapkan ${t}, diterima ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Input tidak valid: diharapkan ${L(e.values[0])}` : `Pilihan tidak valid: diharapkan salah satu dari ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Terlalu besar: diharapkan ${e.origin ?? "value"} memiliki ${n}${e.maximum.toString()} ${r.unit ?? "elemen"}` : `Terlalu besar: diharapkan ${e.origin ?? "value"} menjadi ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Terlalu kecil: diharapkan ${e.origin} memiliki ${n}${e.minimum.toString()} ${r.unit}` : `Terlalu kecil: diharapkan ${e.origin} menjadi ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `String tidak valid: harus dimulai dengan "${t.prefix}"` : t.format === "ends_with" ? `String tidak valid: harus berakhir dengan "${t.suffix}"` : t.format === "includes" ? `String tidak valid: harus menyertakan "${t.includes}"` : t.format === "regex" ? `String tidak valid: harus sesuai pola ${t.pattern}` : `${n[t.format] ?? e.format} tidak valid`;
			}
			case "not_multiple_of": return `Angka tidak valid: harus kelipatan dari ${e.divisor}`;
			case "unrecognized_keys": return `Kunci tidak dikenali ${e.keys.length > 1 ? "s" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Kunci tidak valid di ${e.origin}`;
			case "invalid_union": return "Input tidak valid";
			case "invalid_element": return `Nilai tidak valid di ${e.origin}`;
			default: return "Input tidak valid";
		}
	};
};
function $D() {
	return { localeError: QD() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/is.js
var eO = () => {
	let e = {
		string: {
			unit: "stafi",
			verb: "að hafa"
		},
		file: {
			unit: "bæti",
			verb: "að hafa"
		},
		array: {
			unit: "hluti",
			verb: "að hafa"
		},
		set: {
			unit: "hluti",
			verb: "að hafa"
		},
		map: {
			unit: "hluti",
			verb: "að hafa"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "gildi",
		email: "netfang",
		url: "vefslóð",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO dagsetning og tími",
		date: "ISO dagsetning",
		time: "ISO tími",
		duration: "ISO tímalengd",
		ipv4: "IPv4 address",
		ipv6: "IPv6 address",
		mac: "MAC address",
		cidrv4: "IPv4 range",
		cidrv6: "IPv6 range",
		base64: "base64-encoded strengur",
		base64url: "base64url-encoded strengur",
		json_string: "JSON strengur",
		e164: "E.164 tölugildi",
		credit_card: "kreditkortanúmer",
		jwt: "JWT",
		template_literal: "gildi"
	}, r = {
		nan: "NaN",
		number: "númer",
		array: "fylki"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Rangt gildi: Þú slóst inn ${i} þar sem á að vera instanceof ${e.expected}` : `Rangt gildi: Þú slóst inn ${i} þar sem á að vera ${t}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Rangt gildi: gert ráð fyrir ${L(e.values[0])}` : `Ógilt val: má vera eitt af eftirfarandi ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Of stórt: gert er ráð fyrir að ${e.origin ?? "gildi"} hafi ${n}${e.maximum.toString()} ${r.unit ?? "hluti"}` : `Of stórt: gert er ráð fyrir að ${e.origin ?? "gildi"} sé ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Of lítið: gert er ráð fyrir að ${e.origin} hafi ${n}${e.minimum.toString()} ${r.unit}` : `Of lítið: gert er ráð fyrir að ${e.origin} sé ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ógildur strengur: verður að byrja á "${t.prefix}"` : t.format === "ends_with" ? `Ógildur strengur: verður að enda á "${t.suffix}"` : t.format === "includes" ? `Ógildur strengur: verður að innihalda "${t.includes}"` : t.format === "regex" ? `Ógildur strengur: verður að fylgja mynstri ${t.pattern}` : `Rangt ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Röng tala: verður að vera margfeldi af ${e.divisor}`;
			case "unrecognized_keys": return `Óþekkt ${e.keys.length > 1 ? "ir lyklar" : "ur lykill"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Rangur lykill í ${e.origin}`;
			case "invalid_union": return "Rangt gildi";
			case "invalid_element": return `Rangt gildi í ${e.origin}`;
			default: return "Rangt gildi";
		}
	};
};
function tO() {
	return { localeError: eO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/it.js
var nO = () => {
	let e = {
		string: {
			unit: "caratteri",
			verb: "avere"
		},
		file: {
			unit: "byte",
			verb: "avere"
		},
		array: {
			unit: "elementi",
			verb: "avere"
		},
		set: {
			unit: "elementi",
			verb: "avere"
		},
		map: {
			unit: "elementi",
			verb: "avere"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "indirizzo email",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "data e ora ISO",
		date: "data ISO",
		time: "ora ISO",
		duration: "durata ISO",
		ipv4: "indirizzo IPv4",
		ipv6: "indirizzo IPv6",
		mac: "indirizzo MAC",
		cidrv4: "intervallo IPv4",
		cidrv6: "intervallo IPv6",
		base64: "stringa codificata in base64",
		base64url: "URL codificata in base64",
		json_string: "stringa JSON",
		e164: "numero E.164",
		credit_card: "numero di carta di credito",
		jwt: "JWT",
		template_literal: "input"
	}, r = {
		nan: "NaN",
		number: "numero",
		array: "vettore"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Input non valido: atteso instanceof ${e.expected}, ricevuto ${i}` : `Input non valido: atteso ${t}, ricevuto ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Input non valido: atteso ${L(e.values[0])}` : `Opzione non valida: atteso uno tra ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Troppo grande: ${e.origin ?? "valore"} deve avere ${n}${e.maximum.toString()} ${r.unit ?? "elementi"}` : `Troppo grande: ${e.origin ?? "valore"} deve essere ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Troppo piccolo: ${e.origin} deve avere ${n}${e.minimum.toString()} ${r.unit}` : `Troppo piccolo: ${e.origin} deve essere ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Stringa non valida: deve iniziare con "${t.prefix}"` : t.format === "ends_with" ? `Stringa non valida: deve terminare con "${t.suffix}"` : t.format === "includes" ? `Stringa non valida: deve includere "${t.includes}"` : t.format === "regex" ? `Stringa non valida: deve corrispondere al pattern ${t.pattern}` : `Input non valido: ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Numero non valido: deve essere un multiplo di ${e.divisor}`;
			case "unrecognized_keys": return `Chiav${e.keys.length > 1 ? "i" : "e"} non riconosciut${e.keys.length > 1 ? "e" : "a"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Chiave non valida in ${e.origin}`;
			case "invalid_union": return "Input non valido";
			case "invalid_element": return `Valore non valido in ${e.origin}`;
			default: return "Input non valido";
		}
	};
};
function rO() {
	return { localeError: nO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/ja.js
var iO = () => {
	let e = {
		string: {
			unit: "文字",
			verb: "である"
		},
		file: {
			unit: "バイト",
			verb: "である"
		},
		array: {
			unit: "要素",
			verb: "である"
		},
		set: {
			unit: "要素",
			verb: "である"
		},
		map: {
			unit: "要素",
			verb: "である"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "入力値",
		email: "メールアドレス",
		url: "URL",
		emoji: "絵文字",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO日時",
		date: "ISO日付",
		time: "ISO時刻",
		duration: "ISO期間",
		ipv4: "IPv4アドレス",
		ipv6: "IPv6アドレス",
		mac: "MACアドレス",
		cidrv4: "IPv4範囲",
		cidrv6: "IPv6範囲",
		base64: "base64エンコード文字列",
		base64url: "base64urlエンコード文字列",
		json_string: "JSON文字列",
		e164: "E.164番号",
		credit_card: "クレジットカード番号",
		jwt: "JWT",
		template_literal: "入力値"
	}, r = {
		nan: "NaN",
		number: "数値",
		array: "配列"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `無効な入力: instanceof ${e.expected}が期待されましたが、${i}が入力されました` : `無効な入力: ${t}が期待されましたが、${i}が入力されました`;
			}
			case "invalid_value": return e.values.length === 1 ? `無効な入力: ${L(e.values[0])}が期待されました` : `無効な選択: ${N(e.values, "、")}のいずれかである必要があります`;
			case "too_big": {
				let n = e.inclusive ? "以下である" : "より小さい", r = t(e.origin);
				return r ? `大きすぎる値: ${e.origin ?? "値"}は${e.maximum.toString()}${r.unit ?? "要素"}${n}必要があります` : `大きすぎる値: ${e.origin ?? "値"}は${e.maximum.toString()}${n}必要があります`;
			}
			case "too_small": {
				let n = e.inclusive ? "以上である" : "より大きい", r = t(e.origin);
				return r ? `小さすぎる値: ${e.origin}は${e.minimum.toString()}${r.unit}${n}必要があります` : `小さすぎる値: ${e.origin}は${e.minimum.toString()}${n}必要があります`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `無効な文字列: "${t.prefix}"で始まる必要があります` : t.format === "ends_with" ? `無効な文字列: "${t.suffix}"で終わる必要があります` : t.format === "includes" ? `無効な文字列: "${t.includes}"を含む必要があります` : t.format === "regex" ? `無効な文字列: パターン${t.pattern}に一致する必要があります` : `無効な${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `無効な数値: ${e.divisor}の倍数である必要があります`;
			case "unrecognized_keys": return `認識されていないキー${e.keys.length > 1 ? "群" : ""}: ${N(e.keys, "、")}`;
			case "invalid_key": return `${e.origin}内の無効なキー`;
			case "invalid_union": return "無効な入力";
			case "invalid_element": return `${e.origin}内の無効な値`;
			default: return "無効な入力";
		}
	};
};
function aO() {
	return { localeError: iO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/ka.js
var oO = () => {
	let e = {
		string: {
			unit: "სიმბოლო",
			verb: "უნდა შეიცავდეს"
		},
		file: {
			unit: "ბაიტი",
			verb: "უნდა შეიცავდეს"
		},
		array: {
			unit: "ელემენტი",
			verb: "უნდა შეიცავდეს"
		},
		set: {
			unit: "ელემენტი",
			verb: "უნდა შეიცავდეს"
		},
		map: {
			unit: "ელემენტი",
			verb: "უნდა შეიცავდეს"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "შეყვანა",
		email: "ელ-ფოსტის მისამართი",
		url: "URL",
		emoji: "ემოჯი",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "თარიღი-დრო",
		date: "თარიღი",
		time: "დრო",
		duration: "ხანგრძლივობა",
		ipv4: "IPv4 მისამართი",
		ipv6: "IPv6 მისამართი",
		mac: "MAC მისამართი",
		cidrv4: "IPv4 დიაპაზონი",
		cidrv6: "IPv6 დიაპაზონი",
		base64: "base64-კოდირებული ველი",
		base64url: "base64url-კოდირებული ველი",
		json_string: "JSON ველი",
		e164: "E.164 ნომერი",
		credit_card: "საკრედიტო ბარათის ნომერი",
		jwt: "JWT",
		template_literal: "შეყვანა"
	}, r = {
		nan: "NaN",
		number: "რიცხვი",
		string: "ველი",
		boolean: "ბულეანი",
		function: "ფუნქცია",
		array: "მასივი"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `არასწორი შეყვანა: მოსალოდნელი instanceof ${e.expected}, მიღებული ${i}` : `არასწორი შეყვანა: მოსალოდნელი ${t}, მიღებული ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `არასწორი შეყვანა: მოსალოდნელი ${L(e.values[0])}` : `არასწორი ვარიანტი: მოსალოდნელია ერთ-ერთი ${N(e.values, "|")}-დან`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `ზედმეტად დიდი: მოსალოდნელი ${e.origin ?? "მნიშვნელობა"} ${r.verb} ${n}${e.maximum.toString()} ${r.unit}` : `ზედმეტად დიდი: მოსალოდნელი ${e.origin ?? "მნიშვნელობა"} იყოს ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `ზედმეტად პატარა: მოსალოდნელი ${e.origin} ${r.verb} ${n}${e.minimum.toString()} ${r.unit}` : `ზედმეტად პატარა: მოსალოდნელი ${e.origin} იყოს ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `არასწორი ველი: უნდა იწყებოდეს "${t.prefix}"-ით` : t.format === "ends_with" ? `არასწორი ველი: უნდა მთავრდებოდეს "${t.suffix}"-ით` : t.format === "includes" ? `არასწორი ველი: უნდა შეიცავდეს "${t.includes}"-ს` : t.format === "regex" ? `არასწორი ველი: უნდა შეესაბამებოდეს შაბლონს ${t.pattern}` : `არასწორი ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `არასწორი რიცხვი: უნდა იყოს ${e.divisor}-ის ჯერადი`;
			case "unrecognized_keys": return `უცნობი გასაღებ${e.keys.length > 1 ? "ები" : "ი"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `არასწორი გასაღები ${e.origin}-ში`;
			case "invalid_union": return "არასწორი შეყვანა";
			case "invalid_element": return `არასწორი მნიშვნელობა ${e.origin}-ში`;
			default: return "არასწორი შეყვანა";
		}
	};
};
function sO() {
	return { localeError: oO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/km.js
var cO = () => {
	let e = {
		string: {
			unit: "តួអក្សរ",
			verb: "គួរមាន"
		},
		file: {
			unit: "បៃ",
			verb: "គួរមាន"
		},
		array: {
			unit: "ធាតុ",
			verb: "គួរមាន"
		},
		set: {
			unit: "ធាតុ",
			verb: "គួរមាន"
		},
		map: {
			unit: "ធាតុ",
			verb: "គួរមាន"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ទិន្នន័យបញ្ចូល",
		email: "អាសយដ្ឋានអ៊ីមែល",
		url: "URL",
		emoji: "សញ្ញាអារម្មណ៍",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "កាលបរិច្ឆេទ និងម៉ោង ISO",
		date: "កាលបរិច្ឆេទ ISO",
		time: "ម៉ោង ISO",
		duration: "រយៈពេល ISO",
		ipv4: "អាសយដ្ឋាន IPv4",
		ipv6: "អាសយដ្ឋាន IPv6",
		mac: "អាសយដ្ឋាន MAC",
		cidrv4: "ដែនអាសយដ្ឋាន IPv4",
		cidrv6: "ដែនអាសយដ្ឋាន IPv6",
		base64: "ខ្សែអក្សរអ៊ិកូដ base64",
		base64url: "ខ្សែអក្សរអ៊ិកូដ base64url",
		json_string: "ខ្សែអក្សរ JSON",
		e164: "លេខ E.164",
		credit_card: "លេខប័ណ្ណឥណទាន",
		jwt: "JWT",
		template_literal: "ទិន្នន័យបញ្ចូល"
	}, r = {
		nan: "NaN",
		number: "លេខ",
		array: "អារេ (Array)",
		null: "គ្មានតម្លៃ (null)"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `ទិន្នន័យបញ្ចូលមិនត្រឹមត្រូវ៖ ត្រូវការ instanceof ${e.expected} ប៉ុន្តែទទួលបាន ${i}` : `ទិន្នន័យបញ្ចូលមិនត្រឹមត្រូវ៖ ត្រូវការ ${t} ប៉ុន្តែទទួលបាន ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `ទិន្នន័យបញ្ចូលមិនត្រឹមត្រូវ៖ ត្រូវការ ${L(e.values[0])}` : `ជម្រើសមិនត្រឹមត្រូវ៖ ត្រូវជាមួយក្នុងចំណោម ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `ធំពេក៖ ត្រូវការ ${e.origin ?? "តម្លៃ"} ${n} ${e.maximum.toString()} ${r.unit ?? "ធាតុ"}` : `ធំពេក៖ ត្រូវការ ${e.origin ?? "តម្លៃ"} ${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `តូចពេក៖ ត្រូវការ ${e.origin} ${n} ${e.minimum.toString()} ${r.unit}` : `តូចពេក៖ ត្រូវការ ${e.origin} ${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវចាប់ផ្តើមដោយ "${t.prefix}"` : t.format === "ends_with" ? `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវបញ្ចប់ដោយ "${t.suffix}"` : t.format === "includes" ? `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវមាន "${t.includes}"` : t.format === "regex" ? `ខ្សែអក្សរមិនត្រឹមត្រូវ៖ ត្រូវតែផ្គូផ្គងនឹងទម្រង់ដែលបានកំណត់ ${t.pattern}` : `មិនត្រឹមត្រូវ៖ ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `លេខមិនត្រឹមត្រូវ៖ ត្រូវតែជាពហុគុណនៃ ${e.divisor}`;
			case "unrecognized_keys": return `រកឃើញសោមិនស្គាល់៖ ${N(e.keys, ", ")}`;
			case "invalid_key": return `សោមិនត្រឹមត្រូវនៅក្នុង ${e.origin}`;
			case "invalid_union": return "ទិន្នន័យមិនត្រឹមត្រូវ";
			case "invalid_element": return `ទិន្នន័យមិនត្រឹមត្រូវនៅក្នុង ${e.origin}`;
			default: return "ទិន្នន័យមិនត្រឹមត្រូវ";
		}
	};
};
function lO() {
	return { localeError: cO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/kh.js
function uO() {
	return lO();
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/kn.js
var dO = () => {
	let e = {
		string: {
			unit: "ಅಕ್ಷರಗಳು",
			verb: "ಹೊಂದಲು"
		},
		file: {
			unit: "ಬೈಟ್‌ಗಳು",
			verb: "ಹೊಂದಲು"
		},
		array: {
			unit: "ವಸ್ತುಗಳು",
			verb: "ಹೊಂದಲು"
		},
		set: {
			unit: "ವಸ್ತುಗಳು",
			verb: "ಹೊಂದಲು"
		},
		map: {
			unit: "entries",
			verb: "ಹೊಂದಲು"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ಇನ್ಪುಟ್",
		email: "email ವಿಳಾಸ",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO ದಿನಾಂಕದ ಸಮಯ",
		date: "ISO ದಿನಾಂಕ",
		time: "ISO ಸಮಯ",
		duration: "ISO ಅವಧಿ",
		ipv4: "IPv4 ವಿಳಾಸ",
		ipv6: "IPv6 ವಿಳಾಸ",
		mac: "MAC ವಿಳಾಸ",
		cidrv4: "IPv4 ವ್ಯಾಪ್ತಿಯ",
		cidrv6: "IPv6 ವ್ಯಾಪ್ತಿಯ",
		base64: "base64-encodedಸ್ಟ್ರಿಂಗ್",
		base64url: "base64url-encodedಸ್ಟ್ರಿಂಗ್",
		json_string: "JSONಸ್ಟ್ರಿಂಗ್",
		e164: "E.164 ಸಂಖ್ಯೆ",
		credit_card: "ಕ್ರೆಡಿಟ್ ಕಾರ್ಡ್ ಸಂಖ್ಯೆ",
		jwt: "JWT",
		template_literal: "ಇನ್ಪುಟ್"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input);
				return `ಅಮಾನ್ಯ ಇನ್‌ಪುಟ್: ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${t}, ಸ್ವೀಕರಿಸಿದನು ${r[n] ?? n}`;
			}
			case "invalid_value": return e.values.length === 1 ? `ಅಮಾನ್ಯ ಇನ್‌ಪುಟ್: ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${L(e.values[0])}` : `ಅಮಾನ್ಯ ಆಯ್ಕೆ: ಇವುಗಳಲ್ಲಿ ಒಂದನ್ನು ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `ತುಂಬಾ ದೊಡ್ಡದು: ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${e.origin ?? "value"} ಹೊಂದಲು ${n}${e.maximum.toString()} ${r.unit ?? "ಅಂಶಗಳು"}` : `ತುಂಬಾ ದೊಡ್ಡದು: ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${e.origin ?? "value"} ಎಂದು ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `ತುಂಬಾ ಚಿಕ್ಕದು: ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${e.origin} ಹೊಂದಲು ${n}${e.minimum.toString()} ${r.unit}` : `ತುಂಬಾ ಚಿಕ್ಕದು: ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${e.origin} ಎಂದು ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `ಅಮಾನ್ಯವಾದ ಸ್ಟ್ರಿಂಗ್: ಇದರೊಂದಿಗೆ ಪ್ರಾರಂಭಿಸಬೇಕು "${t.prefix}"` : t.format === "ends_with" ? `ಅಮಾನ್ಯವಾದ ಸ್ಟ್ರಿಂಗ್: ಇದರೊಂದಿಗೆ ಕೊನೆಗೊಳ್ಳಬೇಕು "${t.suffix}"` : t.format === "includes" ? `ಅಮಾನ್ಯ ಸ್ಟ್ರಿಂಗ್: ಒಳಗೊಂಡಿರಬೇಕು "${t.includes}"` : t.format === "regex" ? `ಅಮಾನ್ಯವಾದ ಸ್ಟ್ರಿಂಗ್: ಮಾದರಿಗೆ ಹೊಂದಿಕೆಯಾಗಬೇಕು ${t.pattern}` : `ಅಮಾನ್ಯ ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `ಅಮಾನ್ಯ ಸಂಖ್ಯೆ: ಬಹುಸಂಖ್ಯೆಯಾಗಿರಬೇಕು ${e.divisor}`;
			case "unrecognized_keys": return `ಗುರುತಿಸಲಾಗದ ಕೀ ${e.keys.length > 1 ? "s" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `ಅಮಾನ್ಯವಾದ ಕೀ ಇನ್ ${e.origin}`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `ಅಮಾನ್ಯ ತಾರತಮ್ಯ ಮೌಲ್ಯ. ನಿರೀಕ್ಷಿಸಲಾಗಿದೆ ${e.options.map((e) => `'${e}'`).join(" | ")}` : "ಅಮಾನ್ಯ ಇನ್‌ಪುಟ್";
			case "invalid_element": return `ರಲ್ಲಿ ಅಮಾನ್ಯ ಮೌಲ್ಯ ${e.origin}`;
			default: return "ಅಮಾನ್ಯ ಇನ್‌ಪುಟ್";
		}
	};
};
function fO() {
	return { localeError: dO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/ko.js
var pO = () => {
	let e = {
		string: {
			unit: "문자",
			verb: "to have"
		},
		file: {
			unit: "바이트",
			verb: "to have"
		},
		array: {
			unit: "개",
			verb: "to have"
		},
		set: {
			unit: "개",
			verb: "to have"
		},
		map: {
			unit: "개",
			verb: "to have"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "입력",
		email: "이메일 주소",
		url: "URL",
		emoji: "이모지",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO 날짜시간",
		date: "ISO 날짜",
		time: "ISO 시간",
		duration: "ISO 기간",
		ipv4: "IPv4 주소",
		ipv6: "IPv6 주소",
		mac: "MAC 주소",
		cidrv4: "IPv4 범위",
		cidrv6: "IPv6 범위",
		base64: "base64 인코딩 문자열",
		base64url: "base64url 인코딩 문자열",
		json_string: "JSON 문자열",
		e164: "E.164 번호",
		credit_card: "신용카드 번호",
		jwt: "JWT",
		template_literal: "입력"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `잘못된 입력: 예상 타입은 instanceof ${e.expected}, 받은 타입은 ${i}입니다` : `잘못된 입력: 예상 타입은 ${t}, 받은 타입은 ${i}입니다`;
			}
			case "invalid_value": return e.values.length === 1 ? `잘못된 입력: 값은 ${L(e.values[0])} 이어야 합니다` : `잘못된 옵션: ${N(e.values, "또는 ")} 중 하나여야 합니다`;
			case "too_big": {
				let n = e.inclusive ? "이하" : "미만", r = n === "미만" ? "이어야 합니다" : "여야 합니다", i = t(e.origin), a = i?.unit ?? "요소";
				return i ? `${e.origin ?? "값"}이 너무 큽니다: ${e.maximum.toString()}${a} ${n}${r}` : `${e.origin ?? "값"}이 너무 큽니다: ${e.maximum.toString()} ${n}${r}`;
			}
			case "too_small": {
				let n = e.inclusive ? "이상" : "초과", r = n === "이상" ? "이어야 합니다" : "여야 합니다", i = t(e.origin), a = i?.unit ?? "요소";
				return i ? `${e.origin ?? "값"}이 너무 작습니다: ${e.minimum.toString()}${a} ${n}${r}` : `${e.origin ?? "값"}이 너무 작습니다: ${e.minimum.toString()} ${n}${r}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `잘못된 문자열: "${t.prefix}"(으)로 시작해야 합니다` : t.format === "ends_with" ? `잘못된 문자열: "${t.suffix}"(으)로 끝나야 합니다` : t.format === "includes" ? `잘못된 문자열: "${t.includes}"을(를) 포함해야 합니다` : t.format === "regex" ? `잘못된 문자열: 정규식 ${t.pattern} 패턴과 일치해야 합니다` : `잘못된 ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `잘못된 숫자: ${e.divisor}의 배수여야 합니다`;
			case "unrecognized_keys": return `인식할 수 없는 키: ${N(e.keys, ", ")}`;
			case "invalid_key": return `잘못된 키: ${e.origin}`;
			case "invalid_union": return "잘못된 입력";
			case "invalid_element": return `잘못된 값: ${e.origin}`;
			default: return "잘못된 입력";
		}
	};
};
function mO() {
	return { localeError: pO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/lt.js
var hO = (e) => e.charAt(0).toUpperCase() + e.slice(1);
function gO(e) {
	let t = Math.abs(e), n = t % 10, r = t % 100;
	return r >= 11 && r <= 19 || n === 0 ? "many" : n === 1 ? "one" : "few";
}
var _O = () => {
	let e = {
		string: {
			unit: {
				one: "simbolis",
				few: "simboliai",
				many: "simbolių"
			},
			verb: {
				smaller: {
					inclusive: "turi būti ne ilgesnė kaip",
					notInclusive: "turi būti trumpesnė kaip"
				},
				bigger: {
					inclusive: "turi būti ne trumpesnė kaip",
					notInclusive: "turi būti ilgesnė kaip"
				}
			}
		},
		file: {
			unit: {
				one: "baitas",
				few: "baitai",
				many: "baitų"
			},
			verb: {
				smaller: {
					inclusive: "turi būti ne didesnis kaip",
					notInclusive: "turi būti mažesnis kaip"
				},
				bigger: {
					inclusive: "turi būti ne mažesnis kaip",
					notInclusive: "turi būti didesnis kaip"
				}
			}
		},
		array: {
			unit: {
				one: "elementą",
				few: "elementus",
				many: "elementų"
			},
			verb: {
				smaller: {
					inclusive: "turi turėti ne daugiau kaip",
					notInclusive: "turi turėti mažiau kaip"
				},
				bigger: {
					inclusive: "turi turėti ne mažiau kaip",
					notInclusive: "turi turėti daugiau kaip"
				}
			}
		},
		set: {
			unit: {
				one: "elementą",
				few: "elementus",
				many: "elementų"
			},
			verb: {
				smaller: {
					inclusive: "turi turėti ne daugiau kaip",
					notInclusive: "turi turėti mažiau kaip"
				},
				bigger: {
					inclusive: "turi turėti ne mažiau kaip",
					notInclusive: "turi turėti daugiau kaip"
				}
			}
		}
	};
	function t(t, n, r, i) {
		let a = e[t] ?? null;
		return a === null ? a : {
			unit: a.unit[n],
			verb: a.verb[i][r ? "inclusive" : "notInclusive"]
		};
	}
	let n = {
		regex: "įvestis",
		email: "el. pašto adresas",
		url: "URL",
		emoji: "jaustukas",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO data ir laikas",
		date: "ISO data",
		time: "ISO laikas",
		duration: "ISO trukmė",
		ipv4: "IPv4 adresas",
		ipv6: "IPv6 adresas",
		mac: "MAC adresas",
		cidrv4: "IPv4 tinklo prefiksas (CIDR)",
		cidrv6: "IPv6 tinklo prefiksas (CIDR)",
		base64: "base64 užkoduota eilutė",
		base64url: "base64url užkoduota eilutė",
		json_string: "JSON eilutė",
		e164: "E.164 numeris",
		credit_card: "kredito kortelės numeris",
		jwt: "JWT",
		template_literal: "įvestis"
	}, r = {
		nan: "NaN",
		number: "skaičius",
		bigint: "sveikasis skaičius",
		string: "eilutė",
		boolean: "loginė reikšmė",
		undefined: "neapibrėžta reikšmė",
		function: "funkcija",
		symbol: "simbolis",
		array: "masyvas",
		object: "objektas",
		null: "nulinė reikšmė"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Gautas tipas ${i}, o tikėtasi - instanceof ${e.expected}` : `Gautas tipas ${i}, o tikėtasi - ${t}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Privalo būti ${L(e.values[0])}` : `Privalo būti vienas iš ${N(e.values, "|")} pasirinkimų`;
			case "too_big": {
				let n = r[e.origin] ?? e.origin, i = t(e.origin, gO(Number(e.maximum)), e.inclusive ?? !1, "smaller");
				if (i?.verb) return `${hO(n ?? e.origin ?? "reikšmė")} ${i.verb} ${e.maximum.toString()} ${i.unit ?? "elementų"}`;
				let a = e.inclusive ? "ne didesnis kaip" : "mažesnis kaip";
				return `${hO(n ?? e.origin ?? "reikšmė")} turi būti ${a} ${e.maximum.toString()} ${i?.unit}`;
			}
			case "too_small": {
				let n = r[e.origin] ?? e.origin, i = t(e.origin, gO(Number(e.minimum)), e.inclusive ?? !1, "bigger");
				if (i?.verb) return `${hO(n ?? e.origin ?? "reikšmė")} ${i.verb} ${e.minimum.toString()} ${i.unit ?? "elementų"}`;
				let a = e.inclusive ? "ne mažesnis kaip" : "didesnis kaip";
				return `${hO(n ?? e.origin ?? "reikšmė")} turi būti ${a} ${e.minimum.toString()} ${i?.unit}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Eilutė privalo prasidėti "${t.prefix}"` : t.format === "ends_with" ? `Eilutė privalo pasibaigti "${t.suffix}"` : t.format === "includes" ? `Eilutė privalo įtraukti "${t.includes}"` : t.format === "regex" ? `Eilutė privalo atitikti ${t.pattern}` : `Neteisingas ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Skaičius privalo būti ${e.divisor} kartotinis.`;
			case "unrecognized_keys": return `Neatpažint${e.keys.length > 1 ? "i" : "as"} rakt${e.keys.length > 1 ? "ai" : "as"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return "Rastas klaidingas raktas";
			case "invalid_union": return "Klaidinga įvestis";
			case "invalid_element": return `${hO(r[e.origin] ?? e.origin ?? e.origin ?? "reikšmė")} turi klaidingą įvestį`;
			default: return "Klaidinga įvestis";
		}
	};
};
function vO() {
	return { localeError: _O() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/mk.js
var yO = () => {
	let e = {
		string: {
			unit: "знаци",
			verb: "да имаат"
		},
		file: {
			unit: "бајти",
			verb: "да имаат"
		},
		array: {
			unit: "ставки",
			verb: "да имаат"
		},
		set: {
			unit: "ставки",
			verb: "да имаат"
		},
		map: {
			unit: "ставки",
			verb: "да имаат"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "внес",
		email: "адреса на е-пошта",
		url: "URL",
		emoji: "емоџи",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO датум и време",
		date: "ISO датум",
		time: "ISO време",
		duration: "ISO времетраење",
		ipv4: "IPv4 адреса",
		ipv6: "IPv6 адреса",
		mac: "MAC адреса",
		cidrv4: "IPv4 опсег",
		cidrv6: "IPv6 опсег",
		base64: "base64-енкодирана низа",
		base64url: "base64url-енкодирана низа",
		json_string: "JSON низа",
		e164: "E.164 број",
		credit_card: "број на кредитна картичка",
		jwt: "JWT",
		template_literal: "внес"
	}, r = {
		nan: "NaN",
		number: "број",
		array: "низа"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Грешен внес: се очекува instanceof ${e.expected}, примено ${i}` : `Грешен внес: се очекува ${t}, примено ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Invalid input: expected ${L(e.values[0])}` : `Грешана опција: се очекува една ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Премногу голем: се очекува ${e.origin ?? "вредноста"} да има ${n}${e.maximum.toString()} ${r.unit ?? "елементи"}` : `Премногу голем: се очекува ${e.origin ?? "вредноста"} да биде ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Премногу мал: се очекува ${e.origin} да има ${n}${e.minimum.toString()} ${r.unit}` : `Премногу мал: се очекува ${e.origin} да биде ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Неважечка низа: мора да започнува со "${t.prefix}"` : t.format === "ends_with" ? `Неважечка низа: мора да завршува со "${t.suffix}"` : t.format === "includes" ? `Неважечка низа: мора да вклучува "${t.includes}"` : t.format === "regex" ? `Неважечка низа: мора да одгоара на патернот ${t.pattern}` : `Invalid ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Грешен број: мора да биде делив со ${e.divisor}`;
			case "unrecognized_keys": return `${e.keys.length > 1 ? "Непрепознаени клучеви" : "Непрепознаен клуч"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Грешен клуч во ${e.origin}`;
			case "invalid_union": return "Грешен внес";
			case "invalid_element": return `Грешна вредност во ${e.origin}`;
			default: return "Грешен внес";
		}
	};
};
function bO() {
	return { localeError: yO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/ms.js
var xO = () => {
	let e = {
		string: {
			unit: "aksara",
			verb: "mempunyai"
		},
		file: {
			unit: "bait",
			verb: "mempunyai"
		},
		array: {
			unit: "elemen",
			verb: "mempunyai"
		},
		set: {
			unit: "elemen",
			verb: "mempunyai"
		},
		map: {
			unit: "elemen",
			verb: "mempunyai"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "alamat e-mel",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "tarikh masa ISO",
		date: "tarikh ISO",
		time: "masa ISO",
		duration: "tempoh ISO",
		ipv4: "alamat IPv4",
		ipv6: "alamat IPv6",
		mac: "alamat MAC",
		cidrv4: "julat IPv4",
		cidrv6: "julat IPv6",
		base64: "string dikodkan base64",
		base64url: "string dikodkan base64url",
		json_string: "string JSON",
		e164: "nombor E.164",
		credit_card: "nombor kad kredit",
		jwt: "JWT",
		template_literal: "input"
	}, r = {
		nan: "NaN",
		number: "nombor"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Input tidak sah: dijangka instanceof ${e.expected}, diterima ${i}` : `Input tidak sah: dijangka ${t}, diterima ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Input tidak sah: dijangka ${L(e.values[0])}` : `Pilihan tidak sah: dijangka salah satu daripada ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Terlalu besar: dijangka ${e.origin ?? "nilai"} ${r.verb} ${n}${e.maximum.toString()} ${r.unit ?? "elemen"}` : `Terlalu besar: dijangka ${e.origin ?? "nilai"} adalah ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Terlalu kecil: dijangka ${e.origin} ${r.verb} ${n}${e.minimum.toString()} ${r.unit}` : `Terlalu kecil: dijangka ${e.origin} adalah ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `String tidak sah: mesti bermula dengan "${t.prefix}"` : t.format === "ends_with" ? `String tidak sah: mesti berakhir dengan "${t.suffix}"` : t.format === "includes" ? `String tidak sah: mesti mengandungi "${t.includes}"` : t.format === "regex" ? `String tidak sah: mesti sepadan dengan corak ${t.pattern}` : `${n[t.format] ?? e.format} tidak sah`;
			}
			case "not_multiple_of": return `Nombor tidak sah: perlu gandaan ${e.divisor}`;
			case "unrecognized_keys": return `Kunci tidak dikenali: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Kunci tidak sah dalam ${e.origin}`;
			case "invalid_union": return "Input tidak sah";
			case "invalid_element": return `Nilai tidak sah dalam ${e.origin}`;
			default: return "Input tidak sah";
		}
	};
};
function SO() {
	return { localeError: xO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/ne.js
var CO = () => {
	let e = {
		string: {
			unit: "अक्षर",
			verb: "हुनुपर्छ"
		},
		file: {
			unit: "बाइट",
			verb: "हुनुपर्छ"
		},
		array: {
			unit: "तत्व",
			verb: "हुनुपर्छ"
		},
		set: {
			unit: "तत्व",
			verb: "हुनुपर्छ"
		},
		map: {
			unit: "प्रविष्टि",
			verb: "हुनुपर्छ"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "इनपुट",
		email: "इमेल ठेगाना",
		url: "URL",
		emoji: "इमोजी",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO मिति र समय",
		date: "ISO मिति",
		time: "ISO समय",
		duration: "ISO अवधि",
		ipv4: "IPv4 ठेगाना",
		ipv6: "IPv6 ठेगाना",
		mac: "MAC ठेगाना",
		cidrv4: "IPv4 दायरा",
		cidrv6: "IPv6 दायरा",
		base64: "base64-इन्कोड गरिएको स्ट्रिङ",
		base64url: "base64url-इन्कोड गरिएको स्ट्रिङ",
		json_string: "JSON स्ट्रिङ",
		e164: "E.164 नम्बर",
		credit_card: "क्रेडिट कार्ड नम्बर",
		jwt: "JWT",
		template_literal: "इनपुट"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input);
				return `अमान्य इनपुट: अपेक्षित ${t}, प्राप्त ${r[n] ?? n}`;
			}
			case "invalid_value": return e.values.length === 1 ? `अमान्य इनपुट: अपेक्षित ${L(e.values[0])}` : `अमान्य विकल्प: अपेक्षित मानहरू मध्ये एक ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `धेरै ठूलो: ${e.origin ?? "मान"} मा ${n}${e.maximum.toString()} ${r.unit} ${r.verb}` : `धेरै ठूलो: ${e.origin ?? "मान"} ${n}${e.maximum.toString()} हुनुपर्छ`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `धेरै सानो: ${e.origin} मा ${n}${e.minimum.toString()} ${r.unit} ${r.verb}` : `धेरै सानो: ${e.origin} ${n}${e.minimum.toString()} हुनुपर्छ`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `अमान्य स्ट्रिङ: "${t.prefix}" बाट सुरु हुनुपर्छ` : t.format === "ends_with" ? `अमान्य स्ट्रिङ: "${t.suffix}" मा समाप्त हुनुपर्छ` : t.format === "includes" ? `अमान्य स्ट्रिङ: "${t.includes}" समावेश हुनुपर्छ` : t.format === "regex" ? `अमान्य स्ट्रिङ: ढाँचा ${t.pattern} सँग मेल खानुपर्छ` : `अमान्य ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `अमान्य संख्या: ${e.divisor} को गुणज हुनुपर्छ`;
			case "unrecognized_keys": return `अपरिचित कुञ्जी${e.keys.length > 1 ? "हरू" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `अमान्य कुञ्जी: ${e.origin} मा`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `अमान्य डिस्क्रिमिनेटर मान: अपेक्षित ${e.options.map((e) => `'${e}'`).join(" | ")}` : "अमान्य इनपुट";
			case "invalid_element": return `अमान्य मान: ${e.origin} मा`;
			default: return "अमान्य इनपुट";
		}
	};
};
function wO() {
	return { localeError: CO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/nl.js
var TO = () => {
	let e = {
		string: {
			unit: "tekens",
			verb: "heeft"
		},
		file: {
			unit: "bytes",
			verb: "heeft"
		},
		array: {
			unit: "elementen",
			verb: "heeft"
		},
		set: {
			unit: "elementen",
			verb: "heeft"
		},
		map: {
			unit: "elementen",
			verb: "heeft"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "invoer",
		email: "emailadres",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datum en tijd",
		date: "ISO datum",
		time: "ISO tijd",
		duration: "ISO duur",
		ipv4: "IPv4-adres",
		ipv6: "IPv6-adres",
		mac: "MAC-adres",
		cidrv4: "IPv4-bereik",
		cidrv6: "IPv6-bereik",
		base64: "base64-gecodeerde tekst",
		base64url: "base64 URL-gecodeerde tekst",
		json_string: "JSON string",
		e164: "E.164-nummer",
		credit_card: "creditcardnummer",
		jwt: "JWT",
		template_literal: "invoer"
	}, r = {
		nan: "NaN",
		number: "getal"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Ongeldige invoer: verwacht instanceof ${e.expected}, ontving ${i}` : `Ongeldige invoer: verwacht ${t}, ontving ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Ongeldige invoer: verwacht ${L(e.values[0])}` : `Ongeldige optie: verwacht één van ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin), i = e.origin === "date" ? "laat" : e.origin === "string" ? "lang" : "groot";
				return r ? `Te ${i}: verwacht dat ${e.origin ?? "waarde"} ${n}${e.maximum.toString()} ${r.unit ?? "elementen"} ${r.verb}` : `Te ${i}: verwacht dat ${e.origin ?? "waarde"} ${n}${e.maximum.toString()} is`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin), i = e.origin === "date" ? "vroeg" : e.origin === "string" ? "kort" : "klein";
				return r ? `Te ${i}: verwacht dat ${e.origin} ${n}${e.minimum.toString()} ${r.unit} ${r.verb}` : `Te ${i}: verwacht dat ${e.origin} ${n}${e.minimum.toString()} is`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ongeldige tekst: moet met "${t.prefix}" beginnen` : t.format === "ends_with" ? `Ongeldige tekst: moet op "${t.suffix}" eindigen` : t.format === "includes" ? `Ongeldige tekst: moet "${t.includes}" bevatten` : t.format === "regex" ? `Ongeldige tekst: moet overeenkomen met patroon ${t.pattern}` : `Ongeldig: ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Ongeldig getal: moet een veelvoud van ${e.divisor} zijn`;
			case "unrecognized_keys": return `Onbekende key${e.keys.length > 1 ? "s" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Ongeldige key in ${e.origin}`;
			case "invalid_union": return "Ongeldige invoer";
			case "invalid_element": return `Ongeldige waarde in ${e.origin}`;
			default: return "Ongeldige invoer";
		}
	};
};
function EO() {
	return { localeError: TO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/nn.js
var DO = () => {
	let e = {
		string: {
			unit: "teikn",
			verb: "å ha"
		},
		file: {
			unit: "bytes",
			verb: "å ha"
		},
		array: {
			unit: "element",
			verb: "å innehalde"
		},
		set: {
			unit: "element",
			verb: "å innehalde"
		},
		map: {
			unit: "element",
			verb: "å innehalde"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "e-postadresse",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO dato- og klokkeslett",
		date: "ISO-dato",
		time: "ISO-klokkeslett",
		duration: "ISO-varigheit",
		ipv4: "IPv4-adresse",
		ipv6: "IPv6-adresse",
		mac: "MAC-adresse",
		cidrv4: "IPv4-spekter",
		cidrv6: "IPv6-spekter",
		base64: "base64-enkoda streng",
		base64url: "base64url-enkoda streng",
		json_string: "JSON-streng",
		e164: "E.164-nummer",
		credit_card: "kredittkortnummer",
		jwt: "JWT",
		template_literal: "input"
	}, r = {
		nan: "NaN",
		number: "tal",
		array: "liste"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Ugyldig input: forventa instanceof ${e.expected}, fekk ${i}` : `Ugyldig input: forventa ${t}, fekk ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Ugyldig verdi: forventa ${L(e.values[0])}` : `Ugyldig val: forventa eitt av ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `For stor(t): forventa ${e.origin ?? "value"} til å ha ${n}${e.maximum.toString()} ${r.unit ?? "element"}` : `For stor(t): forventa ${e.origin ?? "value"} til å ha ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `For lite(n): forventa ${e.origin} til å ha ${n}${e.minimum.toString()} ${r.unit}` : `For lite(n): forventa ${e.origin} til å ha ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ugyldig streng: må starte med "${t.prefix}"` : t.format === "ends_with" ? `Ugyldig streng: må slutte med "${t.suffix}"` : t.format === "includes" ? `Ugyldig streng: må innehalde "${t.includes}"` : t.format === "regex" ? `Ugyldig streng: må matche mønsteret ${t.pattern}` : `Ugyldig ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Ugyldig tal: må vere eit multiplum av ${e.divisor}`;
			case "unrecognized_keys": return `${e.keys.length > 1 ? "Ukjende nøklar" : "Ukjend nøkkel"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Ugyldig nøkkel i ${e.origin}`;
			case "invalid_union": return "Ugyldig input";
			case "invalid_element": return `Ugyldig verdi i ${e.origin}`;
			default: return "Ugyldig input";
		}
	};
};
function OO() {
	return { localeError: DO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/no.js
var kO = () => {
	let e = {
		string: {
			unit: "tegn",
			verb: "å ha"
		},
		file: {
			unit: "bytes",
			verb: "å ha"
		},
		array: {
			unit: "elementer",
			verb: "å inneholde"
		},
		set: {
			unit: "elementer",
			verb: "å inneholde"
		},
		map: {
			unit: "elementer",
			verb: "å inneholde"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "input",
		email: "e-postadresse",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO dato- og klokkeslett",
		date: "ISO-dato",
		time: "ISO-klokkeslett",
		duration: "ISO-varighet",
		ipv4: "IPv4-adresse",
		ipv6: "IPv6-adresse",
		mac: "MAC-adresse",
		cidrv4: "IPv4-spekter",
		cidrv6: "IPv6-spekter",
		base64: "base64-enkodet streng",
		base64url: "base64url-enkodet streng",
		json_string: "JSON-streng",
		e164: "E.164-nummer",
		credit_card: "kredittkortnummer",
		jwt: "JWT",
		template_literal: "input"
	}, r = {
		nan: "NaN",
		number: "tall",
		array: "liste"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Ugyldig input: forventet instanceof ${e.expected}, fikk ${i}` : `Ugyldig input: forventet ${t}, fikk ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Ugyldig verdi: forventet ${L(e.values[0])}` : `Ugyldig valg: forventet en av ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `For stor(t): forventet ${e.origin ?? "value"} til å ha ${n}${e.maximum.toString()} ${r.unit ?? "elementer"}` : `For stor(t): forventet ${e.origin ?? "value"} til å ha ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `For lite(n): forventet ${e.origin} til å ha ${n}${e.minimum.toString()} ${r.unit}` : `For lite(n): forventet ${e.origin} til å ha ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ugyldig streng: må starte med "${t.prefix}"` : t.format === "ends_with" ? `Ugyldig streng: må ende med "${t.suffix}"` : t.format === "includes" ? `Ugyldig streng: må inneholde "${t.includes}"` : t.format === "regex" ? `Ugyldig streng: må matche mønsteret ${t.pattern}` : `Ugyldig ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Ugyldig tall: må være et multiplum av ${e.divisor}`;
			case "unrecognized_keys": return `${e.keys.length > 1 ? "Ukjente nøkler" : "Ukjent nøkkel"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Ugyldig nøkkel i ${e.origin}`;
			case "invalid_union": return "Ugyldig input";
			case "invalid_element": return `Ugyldig verdi i ${e.origin}`;
			default: return "Ugyldig input";
		}
	};
};
function AO() {
	return { localeError: kO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/ota.js
var jO = () => {
	let e = {
		string: {
			unit: "harf",
			verb: "olmalıdır"
		},
		file: {
			unit: "bayt",
			verb: "olmalıdır"
		},
		array: {
			unit: "unsur",
			verb: "olmalıdır"
		},
		set: {
			unit: "unsur",
			verb: "olmalıdır"
		},
		map: {
			unit: "unsur",
			verb: "olmalıdır"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "giren",
		email: "epostagâh",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO hengâmı",
		date: "ISO tarihi",
		time: "ISO zamanı",
		duration: "ISO müddeti",
		ipv4: "IPv4 nişânı",
		ipv6: "IPv6 nişânı",
		mac: "MAC nişânı",
		cidrv4: "IPv4 menzili",
		cidrv6: "IPv6 menzili",
		base64: "base64-şifreli metin",
		base64url: "base64url-şifreli metin",
		json_string: "JSON metin",
		e164: "E.164 sayısı",
		credit_card: "i'tibâr kartı numarası",
		jwt: "JWT",
		template_literal: "giren"
	}, r = {
		nan: "NaN",
		number: "numara",
		array: "saf",
		null: "gayb"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Fâsit giren: umulan instanceof ${e.expected}, alınan ${i}` : `Fâsit giren: umulan ${t}, alınan ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Fâsit giren: umulan ${L(e.values[0])}` : `Fâsit tercih: mûteberler ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Fazla büyük: ${e.origin ?? "value"}, ${n}${e.maximum.toString()} ${r.unit ?? "elements"} sahip olmalıydı.` : `Fazla büyük: ${e.origin ?? "value"}, ${n}${e.maximum.toString()} olmalıydı.`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Fazla küçük: ${e.origin}, ${n}${e.minimum.toString()} ${r.unit} sahip olmalıydı.` : `Fazla küçük: ${e.origin}, ${n}${e.minimum.toString()} olmalıydı.`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Fâsit metin: "${t.prefix}" ile başlamalı.` : t.format === "ends_with" ? `Fâsit metin: "${t.suffix}" ile bitmeli.` : t.format === "includes" ? `Fâsit metin: "${t.includes}" ihtivâ etmeli.` : t.format === "regex" ? `Fâsit metin: ${t.pattern} nakşına uymalı.` : `Fâsit ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Fâsit sayı: ${e.divisor} katı olmalıydı.`;
			case "unrecognized_keys": return `Tanınmayan anahtar ${e.keys.length > 1 ? "s" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} için tanınmayan anahtar var.`;
			case "invalid_union": return "Giren tanınamadı.";
			case "invalid_element": return `${e.origin} için tanınmayan kıymet var.`;
			default: return "Kıymet tanınamadı.";
		}
	};
};
function MO() {
	return { localeError: jO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/ps.js
var NO = () => {
	let e = {
		string: {
			unit: "توکي",
			verb: "ولري"
		},
		file: {
			unit: "بایټس",
			verb: "ولري"
		},
		array: {
			unit: "توکي",
			verb: "ولري"
		},
		set: {
			unit: "توکي",
			verb: "ولري"
		},
		map: {
			unit: "توکي",
			verb: "ولري"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ورودي",
		email: "بریښنالیک",
		url: "یو آر ال",
		emoji: "ایموجي",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "نیټه او وخت",
		date: "نېټه",
		time: "وخت",
		duration: "موده",
		ipv4: "د IPv4 پته",
		ipv6: "د IPv6 پته",
		mac: "د MAC پته",
		cidrv4: "د IPv4 ساحه",
		cidrv6: "د IPv6 ساحه",
		base64: "base64-encoded متن",
		base64url: "base64url-encoded متن",
		json_string: "JSON متن",
		e164: "د E.164 شمېره",
		credit_card: "د کریډیټ کارت شمیره",
		jwt: "JWT",
		template_literal: "ورودي"
	}, r = {
		nan: "NaN",
		number: "عدد",
		array: "ارې"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `ناسم ورودي: باید instanceof ${e.expected} وای, مګر ${i} ترلاسه شو` : `ناسم ورودي: باید ${t} وای, مګر ${i} ترلاسه شو`;
			}
			case "invalid_value": return e.values.length === 1 ? `ناسم ورودي: باید ${L(e.values[0])} وای` : `ناسم انتخاب: باید یو له ${N(e.values, "|")} څخه وای`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `ډیر لوی: ${e.origin ?? "ارزښت"} باید ${n}${e.maximum.toString()} ${r.unit ?? "عنصرونه"} ولري` : `ډیر لوی: ${e.origin ?? "ارزښت"} باید ${n}${e.maximum.toString()} وي`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `ډیر کوچنی: ${e.origin} باید ${n}${e.minimum.toString()} ${r.unit} ولري` : `ډیر کوچنی: ${e.origin} باید ${n}${e.minimum.toString()} وي`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `ناسم متن: باید د "${t.prefix}" سره پیل شي` : t.format === "ends_with" ? `ناسم متن: باید د "${t.suffix}" سره پای ته ورسيږي` : t.format === "includes" ? `ناسم متن: باید "${t.includes}" ولري` : t.format === "regex" ? `ناسم متن: باید د ${t.pattern} سره مطابقت ولري` : `${n[t.format] ?? e.format} ناسم دی`;
			}
			case "not_multiple_of": return `ناسم عدد: باید د ${e.divisor} مضرب وي`;
			case "unrecognized_keys": return `ناسم ${e.keys.length > 1 ? "کلیډونه" : "کلیډ"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `ناسم کلیډ په ${e.origin} کې`;
			case "invalid_union": return "ناسمه ورودي";
			case "invalid_element": return `ناسم عنصر په ${e.origin} کې`;
			default: return "ناسمه ورودي";
		}
	};
};
function PO() {
	return { localeError: NO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/pl.js
var FO = () => {
	let e = {
		string: {
			unit: "znaków",
			verb: "mieć"
		},
		file: {
			unit: "bajtów",
			verb: "mieć"
		},
		array: {
			unit: "elementów",
			verb: "mieć"
		},
		set: {
			unit: "elementów",
			verb: "mieć"
		},
		map: {
			unit: "elementów",
			verb: "mieć"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "wyrażenie",
		email: "adres email",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "data i godzina w formacie ISO",
		date: "data w formacie ISO",
		time: "godzina w formacie ISO",
		duration: "czas trwania ISO",
		ipv4: "adres IPv4",
		ipv6: "adres IPv6",
		mac: "adres MAC",
		cidrv4: "zakres IPv4",
		cidrv6: "zakres IPv6",
		base64: "ciąg znaków zakodowany w formacie base64",
		base64url: "ciąg znaków zakodowany w formacie base64url",
		json_string: "ciąg znaków w formacie JSON",
		e164: "liczba E.164",
		credit_card: "numer karty kredytowej",
		jwt: "JWT",
		template_literal: "wejście"
	}, r = {
		nan: "NaN",
		number: "liczba",
		array: "tablica"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Nieprawidłowe dane wejściowe: oczekiwano instanceof ${e.expected}, otrzymano ${i}` : `Nieprawidłowe dane wejściowe: oczekiwano ${t}, otrzymano ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Nieprawidłowe dane wejściowe: oczekiwano ${L(e.values[0])}` : `Nieprawidłowa opcja: oczekiwano jednej z wartości ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Za duża wartość: oczekiwano, że ${e.origin ?? "wartość"} będzie mieć ${n}${e.maximum.toString()} ${r.unit ?? "elementów"}` : `Zbyt duż(y/a/e): oczekiwano, że ${e.origin ?? "wartość"} będzie wynosić ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Za mała wartość: oczekiwano, że ${e.origin ?? "wartość"} będzie mieć ${n}${e.minimum.toString()} ${r.unit ?? "elementów"}` : `Zbyt mał(y/a/e): oczekiwano, że ${e.origin ?? "wartość"} będzie wynosić ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Nieprawidłowy ciąg znaków: musi zaczynać się od "${t.prefix}"` : t.format === "ends_with" ? `Nieprawidłowy ciąg znaków: musi kończyć się na "${t.suffix}"` : t.format === "includes" ? `Nieprawidłowy ciąg znaków: musi zawierać "${t.includes}"` : t.format === "regex" ? `Nieprawidłowy ciąg znaków: musi odpowiadać wzorcowi ${t.pattern}` : `Nieprawidłow(y/a/e) ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Nieprawidłowa liczba: musi być wielokrotnością ${e.divisor}`;
			case "unrecognized_keys": return `Nierozpoznane klucze${e.keys.length > 1 ? "s" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Nieprawidłowy klucz w ${e.origin}`;
			case "invalid_union": return "Nieprawidłowe dane wejściowe";
			case "invalid_element": return `Nieprawidłowa wartość w ${e.origin}`;
			default: return "Nieprawidłowe dane wejściowe";
		}
	};
};
function IO() {
	return { localeError: FO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/pt.js
var LO = () => {
	let e = {
		string: { unit: "caracteres" },
		file: { unit: "bytes" },
		array: { unit: "elementos" },
		set: { unit: "elementos" },
		map: { unit: "entradas" }
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "a entrada",
		email: "o endereço de e-mail",
		url: "o URL",
		emoji: "o emoji",
		uuid: "o UUID",
		uuidv4: "o UUIDv4",
		uuidv6: "o UUIDv6",
		nanoid: "o nanoid",
		guid: "o GUID",
		cuid: "o cuid",
		cuid2: "o cuid2",
		ulid: "o ULID",
		xid: "o XID",
		ksuid: "o KSUID",
		datetime: "a data e hora ISO",
		date: "a data ISO",
		time: "a hora ISO",
		duration: "a duração ISO",
		ipv4: "o endereço IPv4",
		ipv6: "o endereço IPv6",
		mac: "o endereço MAC",
		cidrv4: "o intervalo de endereços IPv4",
		cidrv6: "o intervalo de endereços IPv6",
		base64: "o texto codificado em base64",
		base64url: "o texto codificado em base64url",
		json_string: "o texto JSON",
		e164: "o número E.164",
		credit_card: "o número de cartão de crédito",
		jwt: "o JWT",
		template_literal: "a entrada"
	}, r = {
		masculine: {
			definite: "o",
			indefinite: "um"
		},
		feminine: {
			definite: "a",
			indefinite: "uma"
		}
	}, i = {
		string: {
			name: "texto",
			articles: r.masculine
		},
		number: {
			name: "número",
			articles: r.masculine
		},
		int: {
			name: "número inteiro",
			articles: r.masculine
		},
		boolean: {
			name: "valor booleano",
			articles: r.masculine
		},
		bigint: {
			name: "número bigint",
			articles: r.masculine
		},
		symbol: {
			name: "símbolo",
			articles: r.masculine
		},
		undefined: {
			name: "valor \"undefined\"",
			articles: r.masculine
		},
		null: {
			name: "valor \"nulo\"",
			articles: r.masculine
		},
		never: {
			name: "valor \"never\"",
			articles: r.masculine
		},
		void: {
			name: "valor \"void\"",
			articles: r.masculine
		},
		date: {
			name: "data",
			articles: r.feminine
		},
		array: {
			name: "vetor",
			articles: r.masculine
		},
		object: {
			name: "objeto",
			articles: r.masculine
		},
		tuple: {
			name: "tuplo",
			articles: r.masculine
		},
		record: {
			name: "registo",
			articles: r.masculine
		},
		map: {
			name: "mapa",
			articles: r.masculine
		},
		set: {
			name: "conjunto",
			articles: r.masculine
		},
		file: {
			name: "ficheiro",
			articles: r.masculine
		},
		nonoptional: {
			name: "valor não opcional",
			articles: r.masculine
		},
		nan: {
			name: "valor \"NaN\"",
			articles: r.masculine
		},
		function: {
			name: "função",
			articles: r.feminine
		}
	};
	function a(e, t) {
		let n = i[e] ?? {
			name: `valor "${e}"`,
			articles: r.masculine
		};
		return `${n.articles[t]} ${n.name}`;
	}
	return (e) => {
		switch (e.code) {
			case "invalid_type": return `Entrada inválida: esperava ${a(e.expected, "indefinite")}, recebeu ${a(R(e.input), "indefinite")}`;
			case "invalid_value": return e.values.length === 1 ? `Entrada inválida: esperava ${L(e.values[0])}` : `Opção inválida: esperava uma das seguintes opções: ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Demasiado grande: esperava que ${a(e.origin, "definite")} tivesse ${n} ${e.maximum.toString()} ${r.unit ?? "elementos"}` : `Demasiado grande: esperava que ${a(e.origin, "definite")} fosse ${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Demasiado pequeno: esperava que ${a(e.origin, "definite")} tivesse ${n} ${e.minimum.toString()} ${r.unit ?? "elementos"}` : `Demasiado pequeno: esperava que ${a(e.origin, "definite")} fosse ${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Texto inválido: deve começar por "${t.prefix}"` : t.format === "ends_with" ? `Texto inválido: deve terminar em "${t.suffix}"` : t.format === "includes" ? `Texto inválido: deve incluir "${t.includes}"` : t.format === "regex" ? `Texto inválido: deve corresponder ao padrão ${t.pattern}` : `Formato d${n[t.format] ?? e.format} inválido`;
			}
			case "not_multiple_of": return `Número inválido: deve ser múltiplo de ${e.divisor}`;
			case "unrecognized_keys": {
				let t = e.keys.length > 1 ? "s" : "";
				return `Chave${t} inválida${t}: ${N(e.keys, ", ")}`;
			}
			case "invalid_key": return `Entrada inválida n${a(e.origin, "definite")}`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `Valor de discriminação inválido. Esperava ${e.options.map((e) => `'${e}'`).join(" | ")}` : "Entrada inválida";
			case "invalid_element": return `Entrada inválida n${a(e.origin, "definite")}`;
			default: return "Entrada inválida";
		}
	};
};
function RO() {
	return { localeError: LO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/pt-BR.js
var zO = () => {
	let e = {
		string: { unit: "caracteres" },
		file: { unit: "bytes" },
		array: { unit: "elementos" },
		set: { unit: "elementos" },
		map: { unit: "entradas" }
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "a entrada",
		email: "o endereço de e-mail",
		url: "o URL",
		emoji: "o emoji",
		uuid: "o UUID",
		uuidv4: "o UUIDv4",
		uuidv6: "o UUIDv6",
		nanoid: "o nanoid",
		guid: "o GUID",
		cuid: "o cuid",
		cuid2: "o cuid2",
		ulid: "o ULID",
		xid: "o XID",
		ksuid: "o KSUID",
		datetime: "a data e hora ISO",
		date: "a data ISO",
		time: "a hora ISO",
		duration: "a duração ISO",
		ipv4: "o endereço IPv4",
		ipv6: "o endereço IPv6",
		mac: "o endereço MAC",
		cidrv4: "a faixa de endereços IPv4",
		cidrv6: "a faixa de endereços IPv6",
		base64: "o texto codificado em base64",
		base64url: "o texto codificado em base64url",
		json_string: "o texto JSON",
		e164: "o número E.164",
		credit_card: "o número de cartão de crédito",
		jwt: "o JWT",
		template_literal: "a entrada"
	}, r = {
		masculine: {
			definite: "o",
			indefinite: "um"
		},
		feminine: {
			definite: "a",
			indefinite: "uma"
		}
	}, i = {
		string: {
			name: "texto",
			articles: r.masculine
		},
		number: {
			name: "número",
			articles: r.masculine
		},
		int: {
			name: "número inteiro",
			articles: r.masculine
		},
		boolean: {
			name: "valor booleano",
			articles: r.masculine
		},
		bigint: {
			name: "número bigint",
			articles: r.masculine
		},
		symbol: {
			name: "símbolo",
			articles: r.masculine
		},
		undefined: {
			name: "valor \"undefined\"",
			articles: r.masculine
		},
		null: {
			name: "valor \"nulo\"",
			articles: r.masculine
		},
		never: {
			name: "valor \"never\"",
			articles: r.masculine
		},
		void: {
			name: "valor \"void\"",
			articles: r.masculine
		},
		date: {
			name: "data",
			articles: r.feminine
		},
		array: {
			name: "vetor",
			articles: r.masculine
		},
		object: {
			name: "objeto",
			articles: r.masculine
		},
		tuple: {
			name: "tupla",
			articles: r.feminine
		},
		record: {
			name: "registro",
			articles: r.masculine
		},
		map: {
			name: "mapa",
			articles: r.masculine
		},
		set: {
			name: "conjunto",
			articles: r.masculine
		},
		file: {
			name: "arquivo",
			articles: r.masculine
		},
		nonoptional: {
			name: "valor não opcional",
			articles: r.masculine
		},
		nan: {
			name: "valor \"NaN\"",
			articles: r.masculine
		},
		function: {
			name: "função",
			articles: r.feminine
		}
	};
	function a(e, t) {
		let n = i[e] ?? {
			name: `valor "${e}"`,
			articles: r.masculine
		};
		return `${n.articles[t]} ${n.name}`;
	}
	return (e) => {
		switch (e.code) {
			case "invalid_type": return `Entrada inválida: esperava ${a(e.expected, "indefinite")}, recebeu ${a(R(e.input), "indefinite")}`;
			case "invalid_value": return e.values.length === 1 ? `Entrada inválida: esperava ${L(e.values[0])}` : `Opção inválida: esperava uma das seguintes opções: ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Grande demais: esperava que ${a(e.origin, "definite")} tivesse ${n} ${e.maximum.toString()} ${r.unit ?? "elementos"}` : `Grande demais: esperava que ${a(e.origin, "definite")} fosse ${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Pequeno demais: esperava que ${a(e.origin, "definite")} tivesse ${n} ${e.minimum.toString()} ${r.unit ?? "elementos"}` : `Pequeno demais: esperava que ${a(e.origin, "definite")} fosse ${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Texto inválido: deve começar com "${t.prefix}"` : t.format === "ends_with" ? `Texto inválido: deve terminar com "${t.suffix}"` : t.format === "includes" ? `Texto inválido: deve incluir "${t.includes}"` : t.format === "regex" ? `Texto inválido: deve corresponder ao padrão ${t.pattern}` : `Formato d${n[t.format] ?? e.format} inválido`;
			}
			case "not_multiple_of": return `Número inválido: deve ser múltiplo de ${e.divisor}`;
			case "unrecognized_keys": {
				let t = e.keys.length > 1 ? "s" : "";
				return `Chave${t} inválida${t}: ${N(e.keys, ", ")}`;
			}
			case "invalid_key": return `Entrada inválida n${a(e.origin, "definite")}`;
			case "invalid_union": return e.options && Array.isArray(e.options) && e.options.length > 0 ? `Valor de discriminação inválido. Esperava ${e.options.map((e) => `'${e}'`).join(" | ")}` : "Entrada inválida";
			case "invalid_element": return `Entrada inválida n${a(e.origin, "definite")}`;
			default: return "Entrada inválida";
		}
	};
};
function BO() {
	return { localeError: zO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/ro.js
var VO = () => {
	let e = {
		string: {
			unit: "caractere",
			verb: "să aibă"
		},
		file: {
			unit: "octeți",
			verb: "să aibă"
		},
		array: {
			unit: "elemente",
			verb: "să aibă"
		},
		set: {
			unit: "elemente",
			verb: "să aibă"
		},
		map: {
			unit: "intrări",
			verb: "să aibă"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "intrare",
		email: "adresă de email",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "dată și oră ISO",
		date: "dată ISO",
		time: "oră ISO",
		duration: "durată ISO",
		ipv4: "adresă IPv4",
		ipv6: "adresă IPv6",
		mac: "adresă MAC",
		cidrv4: "interval IPv4",
		cidrv6: "interval IPv6",
		base64: "șir codat base64",
		base64url: "șir codat base64url",
		json_string: "șir JSON",
		e164: "număr E.164",
		credit_card: "număr de card de credit",
		jwt: "JWT",
		template_literal: "intrare"
	}, r = {
		nan: "NaN",
		string: "șir",
		number: "număr",
		boolean: "boolean",
		function: "funcție",
		array: "matrice",
		object: "obiect",
		undefined: "nedefinit",
		symbol: "simbol",
		bigint: "număr mare",
		void: "void",
		never: "never",
		map: "hartă",
		set: "set"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input);
				return `Intrare invalidă: așteptat ${t}, primit ${r[n] ?? n}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Intrare invalidă: așteptat ${L(e.values[0])}` : `Opțiune invalidă: așteptat una dintre ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Prea mare: așteptat ca ${e.origin ?? "valoarea"} ${r.verb} ${n}${e.maximum.toString()} ${r.unit ?? "elemente"}` : `Prea mare: așteptat ca ${e.origin ?? "valoarea"} să fie ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Prea mic: așteptat ca ${e.origin} ${r.verb} ${n}${e.minimum.toString()} ${r.unit}` : `Prea mic: așteptat ca ${e.origin} să fie ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Șir invalid: trebuie să înceapă cu "${t.prefix}"` : t.format === "ends_with" ? `Șir invalid: trebuie să se termine cu "${t.suffix}"` : t.format === "includes" ? `Șir invalid: trebuie să includă "${t.includes}"` : t.format === "regex" ? `Șir invalid: trebuie să se potrivească cu modelul ${t.pattern}` : `Format invalid: ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Număr invalid: trebuie să fie multiplu de ${e.divisor}`;
			case "unrecognized_keys": return `Chei nerecunoscute: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Cheie invalidă în ${e.origin}`;
			case "invalid_union": return "Intrare invalidă";
			case "invalid_element": return `Valoare invalidă în ${e.origin}`;
			default: return "Intrare invalidă";
		}
	};
};
function HO() {
	return { localeError: VO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/ru.js
function UO(e, t, n, r) {
	let i = Math.abs(e), a = i % 10, o = i % 100;
	return o >= 11 && o <= 19 ? r : a === 1 ? t : a >= 2 && a <= 4 ? n : r;
}
var WO = () => {
	let e = {
		string: {
			unit: {
				one: "символ",
				few: "символа",
				many: "символов"
			},
			verb: "иметь"
		},
		file: {
			unit: {
				one: "байт",
				few: "байта",
				many: "байт"
			},
			verb: "иметь"
		},
		array: {
			unit: {
				one: "элемент",
				few: "элемента",
				many: "элементов"
			},
			verb: "иметь"
		},
		set: {
			unit: {
				one: "элемент",
				few: "элемента",
				many: "элементов"
			},
			verb: "иметь"
		},
		map: {
			unit: {
				one: "элемент",
				few: "элемента",
				many: "элементов"
			},
			verb: "иметь"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ввод",
		email: "email адрес",
		url: "URL",
		emoji: "эмодзи",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO дата и время",
		date: "ISO дата",
		time: "ISO время",
		duration: "ISO длительность",
		ipv4: "IPv4 адрес",
		ipv6: "IPv6 адрес",
		mac: "MAC адрес",
		cidrv4: "IPv4 диапазон",
		cidrv6: "IPv6 диапазон",
		base64: "строка в формате base64",
		base64url: "строка в формате base64url",
		json_string: "JSON строка",
		e164: "номер E.164",
		credit_card: "номер кредитной карты",
		jwt: "JWT",
		template_literal: "ввод"
	}, r = {
		nan: "NaN",
		number: "число",
		array: "массив"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Неверный ввод: ожидалось instanceof ${e.expected}, получено ${i}` : `Неверный ввод: ожидалось ${t}, получено ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Неверный ввод: ожидалось ${L(e.values[0])}` : `Неверный вариант: ожидалось одно из ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				if (r) {
					let t = UO(Number(e.maximum), r.unit.one, r.unit.few, r.unit.many);
					return `Слишком большое значение: ожидалось, что ${e.origin ?? "значение"} будет иметь ${n}${e.maximum.toString()} ${t}`;
				}
				return `Слишком большое значение: ожидалось, что ${e.origin ?? "значение"} будет ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				if (r) {
					let t = UO(Number(e.minimum), r.unit.one, r.unit.few, r.unit.many);
					return `Слишком маленькое значение: ожидалось, что ${e.origin} будет иметь ${n}${e.minimum.toString()} ${t}`;
				}
				return `Слишком маленькое значение: ожидалось, что ${e.origin} будет ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Неверная строка: должна начинаться с "${t.prefix}"` : t.format === "ends_with" ? `Неверная строка: должна заканчиваться на "${t.suffix}"` : t.format === "includes" ? `Неверная строка: должна содержать "${t.includes}"` : t.format === "regex" ? `Неверная строка: должна соответствовать шаблону ${t.pattern}` : `Неверный ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Неверное число: должно быть кратным ${e.divisor}`;
			case "unrecognized_keys": return `Нераспознанн${e.keys.length > 1 ? "ые" : "ый"} ключ${e.keys.length > 1 ? "и" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Неверный ключ в ${e.origin}`;
			case "invalid_union": return "Неверные входные данные";
			case "invalid_element": return `Неверное значение в ${e.origin}`;
			default: return "Неверные входные данные";
		}
	};
};
function GO() {
	return { localeError: WO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/sk.js
var KO = () => {
	let e = {
		string: {
			unit: "znakov",
			verb: "mať"
		},
		file: {
			unit: "bajtov",
			verb: "mať"
		},
		array: {
			unit: "prvkov",
			verb: "mať"
		},
		set: {
			unit: "prvkov",
			verb: "mať"
		},
		map: {
			unit: "položiek",
			verb: "mať"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "regulárny výraz",
		email: "e-mailová adresa",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "dátum a čas vo formáte ISO",
		date: "dátum vo formáte ISO",
		time: "čas vo formáte ISO",
		duration: "doba trvania ISO",
		ipv4: "IPv4 adresa",
		ipv6: "IPv6 adresa",
		mac: "MAC adresa",
		cidrv4: "rozsah IPv4",
		cidrv6: "rozsah IPv6",
		base64: "reťazec zakódovaný vo formáte base64",
		base64url: "reťazec zakódovaný vo formáte base64url",
		json_string: "reťazec vo formáte JSON",
		e164: "číslo E.164",
		credit_card: "číslo kreditnej karty",
		jwt: "JWT",
		template_literal: "vstup"
	}, r = {
		nan: "NaN",
		number: "číslo",
		string: "reťazec",
		function: "funkcia",
		array: "pole"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Neplatný vstup: očakávané instanceof ${e.expected}, obdržané ${i}` : `Neplatný vstup: očakávané ${t}, obdržané ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Neplatný vstup: očakávané ${L(e.values[0])}` : `Neplatný vstup: očakávaná jedna z hodnôt ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Hodnota je príliš veľká: ${e.origin ?? "hodnota"} musí mať ${n}${e.maximum.toString()} ${r.unit ?? "prvkov"}` : `Hodnota je príliš veľká: ${e.origin ?? "hodnota"} musí byť ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Hodnota je príliš malá: ${e.origin ?? "hodnota"} musí mať ${n}${e.minimum.toString()} ${r.unit ?? "prvkov"}` : `Hodnota je príliš malá: ${e.origin ?? "hodnota"} musí byť ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Neplatný reťazec: musí začínať na "${t.prefix}"` : t.format === "ends_with" ? `Neplatný reťazec: musí končiť na "${t.suffix}"` : t.format === "includes" ? `Neplatný reťazec: musí obsahovať "${t.includes}"` : t.format === "regex" ? `Neplatný reťazec: musí zodpovedať vzoru ${t.pattern}` : `Neplatný formát ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Neplatné číslo: musí byť násobkom ${e.divisor}`;
			case "unrecognized_keys": return `Neznáme klúče: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Neplatný klúč v ${e.origin}`;
			case "invalid_union": return "Neplatný vstup";
			case "invalid_element": return `Neplatná hodnota v ${e.origin}`;
			default: return "Neplatný vstup";
		}
	};
};
function qO() {
	return { localeError: KO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/sl.js
var JO = () => {
	let e = {
		string: {
			unit: "znakov",
			verb: "imeti"
		},
		file: {
			unit: "bajtov",
			verb: "imeti"
		},
		array: {
			unit: "elementov",
			verb: "imeti"
		},
		set: {
			unit: "elementov",
			verb: "imeti"
		},
		map: {
			unit: "elementov",
			verb: "imeti"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "vnos",
		email: "e-poštni naslov",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datum in čas",
		date: "ISO datum",
		time: "ISO čas",
		duration: "ISO trajanje",
		ipv4: "IPv4 naslov",
		ipv6: "IPv6 naslov",
		mac: "MAC naslov",
		cidrv4: "obseg IPv4",
		cidrv6: "obseg IPv6",
		base64: "base64 kodiran niz",
		base64url: "base64url kodiran niz",
		json_string: "JSON niz",
		e164: "E.164 številka",
		credit_card: "številka kreditne kartice",
		jwt: "JWT",
		template_literal: "vnos"
	}, r = {
		nan: "NaN",
		number: "število",
		array: "tabela"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Neveljaven vnos: pričakovano instanceof ${e.expected}, prejeto ${i}` : `Neveljaven vnos: pričakovano ${t}, prejeto ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Neveljaven vnos: pričakovano ${L(e.values[0])}` : `Neveljavna možnost: pričakovano eno izmed ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Preveliko: pričakovano, da bo ${e.origin ?? "vrednost"} imelo ${n}${e.maximum.toString()} ${r.unit ?? "elementov"}` : `Preveliko: pričakovano, da bo ${e.origin ?? "vrednost"} ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Premajhno: pričakovano, da bo ${e.origin} imelo ${n}${e.minimum.toString()} ${r.unit}` : `Premajhno: pričakovano, da bo ${e.origin} ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Neveljaven niz: mora se začeti z "${t.prefix}"` : t.format === "ends_with" ? `Neveljaven niz: mora se končati z "${t.suffix}"` : t.format === "includes" ? `Neveljaven niz: mora vsebovati "${t.includes}"` : t.format === "regex" ? `Neveljaven niz: mora ustrezati vzorcu ${t.pattern}` : `Neveljaven ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Neveljavno število: mora biti večkratnik ${e.divisor}`;
			case "unrecognized_keys": return `Neprepoznan${e.keys.length > 1 ? "i ključi" : " ključ"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Neveljaven ključ v ${e.origin}`;
			case "invalid_union": return "Neveljaven vnos";
			case "invalid_element": return `Neveljavna vrednost v ${e.origin}`;
			default: return "Neveljaven vnos";
		}
	};
};
function YO() {
	return { localeError: JO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/sv.js
var XO = () => {
	let e = {
		string: {
			unit: "tecken",
			verb: "att ha"
		},
		file: {
			unit: "bytes",
			verb: "att ha"
		},
		array: {
			unit: "objekt",
			verb: "att innehålla"
		},
		set: {
			unit: "objekt",
			verb: "att innehålla"
		},
		map: {
			unit: "objekt",
			verb: "att innehålla"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "reguljärt uttryck",
		email: "e-postadress",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO-datum och tid",
		date: "ISO-datum",
		time: "ISO-tid",
		duration: "ISO-varaktighet",
		ipv4: "IPv4-adress",
		ipv6: "IPv6-adress",
		mac: "MAC-adress",
		cidrv4: "IPv4-spektrum",
		cidrv6: "IPv6-spektrum",
		base64: "base64-kodad sträng",
		base64url: "base64url-kodad sträng",
		json_string: "JSON-sträng",
		e164: "E.164-nummer",
		credit_card: "kreditkortsnummer",
		jwt: "JWT",
		template_literal: "mall-literal"
	}, r = {
		nan: "NaN",
		number: "antal",
		array: "lista"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Ogiltig inmatning: förväntat instanceof ${e.expected}, fick ${i}` : `Ogiltig inmatning: förväntat ${t}, fick ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Ogiltig inmatning: förväntat ${L(e.values[0])}` : `Ogiltigt val: förväntade en av ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `För stor(t): förväntade ${e.origin ?? "värdet"} att ha ${n}${e.maximum.toString()} ${r.unit ?? "element"}` : `För stor(t): förväntat ${e.origin ?? "värdet"} att ha ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `För lite(t): förväntade ${e.origin ?? "värdet"} att ha ${n}${e.minimum.toString()} ${r.unit}` : `För lite(t): förväntade ${e.origin ?? "värdet"} att ha ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ogiltig sträng: måste börja med "${t.prefix}"` : t.format === "ends_with" ? `Ogiltig sträng: måste sluta med "${t.suffix}"` : t.format === "includes" ? `Ogiltig sträng: måste innehålla "${t.includes}"` : t.format === "regex" ? `Ogiltig sträng: måste matcha mönstret "${t.pattern}"` : `Ogiltig(t) ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Ogiltigt tal: måste vara en multipel av ${e.divisor}`;
			case "unrecognized_keys": return `${e.keys.length > 1 ? "Okända nycklar" : "Okänd nyckel"}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Ogiltig nyckel i ${e.origin ?? "värdet"}`;
			case "invalid_union": return "Ogiltig input";
			case "invalid_element": return `Ogiltigt värde i ${e.origin ?? "värdet"}`;
			default: return "Ogiltig input";
		}
	};
};
function ZO() {
	return { localeError: XO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/ta.js
var QO = () => {
	let e = {
		string: {
			unit: "எழுத்துக்கள்",
			verb: "கொண்டிருக்க வேண்டும்"
		},
		file: {
			unit: "பைட்டுகள்",
			verb: "கொண்டிருக்க வேண்டும்"
		},
		array: {
			unit: "உறுப்புகள்",
			verb: "கொண்டிருக்க வேண்டும்"
		},
		set: {
			unit: "உறுப்புகள்",
			verb: "கொண்டிருக்க வேண்டும்"
		},
		map: {
			unit: "உறுப்புகள்",
			verb: "கொண்டிருக்க வேண்டும்"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "உள்ளீடு",
		email: "மின்னஞ்சல் முகவரி",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO தேதி நேரம்",
		date: "ISO தேதி",
		time: "ISO நேரம்",
		duration: "ISO கால அளவு",
		ipv4: "IPv4 முகவரி",
		ipv6: "IPv6 முகவரி",
		mac: "MAC முகவரி",
		cidrv4: "IPv4 வரம்பு",
		cidrv6: "IPv6 வரம்பு",
		base64: "base64-encoded சரம்",
		base64url: "base64url-encoded சரம்",
		json_string: "JSON சரம்",
		e164: "E.164 எண்",
		credit_card: "கடன் அட்டை எண்",
		jwt: "JWT",
		template_literal: "input"
	}, r = {
		nan: "NaN",
		number: "எண்",
		array: "அணி",
		null: "வெறுமை"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `தவறான உள்ளீடு: எதிர்பார்க்கப்பட்டது instanceof ${e.expected}, பெறப்பட்டது ${i}` : `தவறான உள்ளீடு: எதிர்பார்க்கப்பட்டது ${t}, பெறப்பட்டது ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `தவறான உள்ளீடு: எதிர்பார்க்கப்பட்டது ${L(e.values[0])}` : `தவறான விருப்பம்: எதிர்பார்க்கப்பட்டது ${N(e.values, "|")} இல் ஒன்று`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `மிக பெரியது: எதிர்பார்க்கப்பட்டது ${e.origin ?? "மதிப்பு"} ${n}${e.maximum.toString()} ${r.unit ?? "உறுப்புகள்"} ஆக இருக்க வேண்டும்` : `மிக பெரியது: எதிர்பார்க்கப்பட்டது ${e.origin ?? "மதிப்பு"} ${n}${e.maximum.toString()} ஆக இருக்க வேண்டும்`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `மிகச் சிறியது: எதிர்பார்க்கப்பட்டது ${e.origin} ${n}${e.minimum.toString()} ${r.unit} ஆக இருக்க வேண்டும்` : `மிகச் சிறியது: எதிர்பார்க்கப்பட்டது ${e.origin} ${n}${e.minimum.toString()} ஆக இருக்க வேண்டும்`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `தவறான சரம்: "${t.prefix}" இல் தொடங்க வேண்டும்` : t.format === "ends_with" ? `தவறான சரம்: "${t.suffix}" இல் முடிவடைய வேண்டும்` : t.format === "includes" ? `தவறான சரம்: "${t.includes}" ஐ உள்ளடக்க வேண்டும்` : t.format === "regex" ? `தவறான சரம்: ${t.pattern} முறைபாட்டுடன் பொருந்த வேண்டும்` : `தவறான ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `தவறான எண்: ${e.divisor} இன் பலமாக இருக்க வேண்டும்`;
			case "unrecognized_keys": return `அடையாளம் தெரியாத விசை${e.keys.length > 1 ? "கள்" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} இல் தவறான விசை`;
			case "invalid_union": return "தவறான உள்ளீடு";
			case "invalid_element": return `${e.origin} இல் தவறான மதிப்பு`;
			default: return "தவறான உள்ளீடு";
		}
	};
};
function $O() {
	return { localeError: QO() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/th.js
var ek = () => {
	let e = {
		string: {
			unit: "ตัวอักษร",
			verb: "ควรมี"
		},
		file: {
			unit: "ไบต์",
			verb: "ควรมี"
		},
		array: {
			unit: "รายการ",
			verb: "ควรมี"
		},
		set: {
			unit: "รายการ",
			verb: "ควรมี"
		},
		map: {
			unit: "รายการ",
			verb: "ควรมี"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ข้อมูลที่ป้อน",
		email: "ที่อยู่อีเมล",
		url: "URL",
		emoji: "อิโมจิ",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "วันที่เวลาแบบ ISO",
		date: "วันที่แบบ ISO",
		time: "เวลาแบบ ISO",
		duration: "ช่วงเวลาแบบ ISO",
		ipv4: "ที่อยู่ IPv4",
		ipv6: "ที่อยู่ IPv6",
		mac: "ที่อยู่ MAC",
		cidrv4: "ช่วง IP แบบ IPv4",
		cidrv6: "ช่วง IP แบบ IPv6",
		base64: "ข้อความแบบ Base64",
		base64url: "ข้อความแบบ Base64 สำหรับ URL",
		json_string: "ข้อความแบบ JSON",
		e164: "เบอร์โทรศัพท์ระหว่างประเทศ (E.164)",
		credit_card: "หมายเลขบัตรเครดิต",
		jwt: "โทเคน JWT",
		template_literal: "ข้อมูลที่ป้อน"
	}, r = {
		nan: "NaN",
		number: "ตัวเลข",
		array: "อาร์เรย์ (Array)",
		null: "ไม่มีค่า (null)"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `ประเภทข้อมูลไม่ถูกต้อง: ควรเป็น instanceof ${e.expected} แต่ได้รับ ${i}` : `ประเภทข้อมูลไม่ถูกต้อง: ควรเป็น ${t} แต่ได้รับ ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `ค่าไม่ถูกต้อง: ควรเป็น ${L(e.values[0])}` : `ตัวเลือกไม่ถูกต้อง: ควรเป็นหนึ่งใน ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "ไม่เกิน" : "น้อยกว่า", r = t(e.origin);
				return r ? `เกินกำหนด: ${e.origin ?? "ค่า"} ควรมี${n} ${e.maximum.toString()} ${r.unit ?? "รายการ"}` : `เกินกำหนด: ${e.origin ?? "ค่า"} ควรมี${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? "อย่างน้อย" : "มากกว่า", r = t(e.origin);
				return r ? `น้อยกว่ากำหนด: ${e.origin} ควรมี${n} ${e.minimum.toString()} ${r.unit}` : `น้อยกว่ากำหนด: ${e.origin} ควรมี${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `รูปแบบไม่ถูกต้อง: ข้อความต้องขึ้นต้นด้วย "${t.prefix}"` : t.format === "ends_with" ? `รูปแบบไม่ถูกต้อง: ข้อความต้องลงท้ายด้วย "${t.suffix}"` : t.format === "includes" ? `รูปแบบไม่ถูกต้อง: ข้อความต้องมี "${t.includes}" อยู่ในข้อความ` : t.format === "regex" ? `รูปแบบไม่ถูกต้อง: ต้องตรงกับรูปแบบที่กำหนด ${t.pattern}` : `รูปแบบไม่ถูกต้อง: ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `ตัวเลขไม่ถูกต้อง: ต้องเป็นจำนวนที่หารด้วย ${e.divisor} ได้ลงตัว`;
			case "unrecognized_keys": return `พบคีย์ที่ไม่รู้จัก: ${N(e.keys, ", ")}`;
			case "invalid_key": return `คีย์ไม่ถูกต้องใน ${e.origin}`;
			case "invalid_union": return "ข้อมูลไม่ถูกต้อง: ไม่ตรงกับรูปแบบยูเนียนที่กำหนดไว้";
			case "invalid_element": return `ข้อมูลไม่ถูกต้องใน ${e.origin}`;
			default: return "ข้อมูลไม่ถูกต้อง";
		}
	};
};
function tk() {
	return { localeError: ek() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/tk.js
var nk = () => {
	let e = {
		string: {
			unit: "simwol",
			verb: "bolmaly"
		},
		file: {
			unit: "baýt",
			verb: "bolmaly"
		},
		array: {
			unit: "elementler",
			verb: "bolmaly"
		},
		set: {
			unit: "elementler",
			verb: "bolmaly"
		},
		map: {
			unit: "elementler",
			verb: "bolmaly"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "giriş",
		email: "e-poçta salgysy",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO sene we wagt",
		date: "ISO sene",
		time: "ISO wagt",
		duration: "ISO wagt aralygy",
		ipv4: "IPv4 salgysy",
		ipv6: "IPv6 salgysy",
		mac: "MAC salgysy",
		cidrv4: "IPv4 aralygy",
		cidrv6: "IPv6 aralygy",
		base64: "base64 bilen şifrlenen setir",
		base64url: "base64url bilen şifrlenen setir",
		json_string: "JSON setiri",
		e164: "E.164 nomeri",
		credit_card: "kredit kartynyň nomeri",
		jwt: "JWT",
		template_literal: "şablon"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input);
				return `Nädogry baha: garaşylan ${t} ýerine ${r[n] ?? n} alyndy`;
			}
			case "invalid_value": return e.values.length === 1 ? `Nädogry baha: ${L(e.values[0])} bolmaly` : `Nädogry saýlaw: aşakdakylardan biri bolmaly: ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Has uly: garaşylýan ${e.origin ?? "baha"} ${n} ${e.maximum.toString()} ${r.unit ?? "element"}` : `Has uly: garaşylýan ${e.origin ?? "baha"} ${n} ${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Has kiçi: garaşylýan ${e.origin} ${n} ${e.minimum.toString()} ${r.unit}` : `Has kiçi: garaşylýan ${e.origin} ${n} ${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Nädogry setir: "${t.prefix}" bilen başlamaly` : t.format === "ends_with" ? `Nädogry setir: "${t.suffix}" bilen gutarmaly` : t.format === "includes" ? `Nädogry setir: "${t.includes}" saklamaly` : t.format === "regex" ? `Nädogry setir: ${t.pattern} nusga laýyk bolmaly` : `Nädogry ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Nädogry san: ${e.divisor} bilen galyndysyz bölünmeli`;
			case "unrecognized_keys": return `Tanalmaýan açar${e.keys.length > 1 ? "lar" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} içinde nädogry açar`;
			case "invalid_union": return "Nädogry baha";
			case "invalid_element": return `${e.origin} içinde nädogry baha`;
			default: return "Nädogry baha";
		}
	};
};
function rk() {
	return { localeError: nk() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/tr.js
var ik = () => {
	let e = {
		string: {
			unit: "karakter",
			verb: "olmalı"
		},
		file: {
			unit: "bayt",
			verb: "olmalı"
		},
		array: {
			unit: "öğe",
			verb: "olmalı"
		},
		set: {
			unit: "öğe",
			verb: "olmalı"
		},
		map: {
			unit: "öğe",
			verb: "olmalı"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "girdi",
		email: "e-posta adresi",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO tarih ve saat",
		date: "ISO tarih",
		time: "ISO saat",
		duration: "ISO süre",
		ipv4: "IPv4 adresi",
		ipv6: "IPv6 adresi",
		mac: "MAC adresi",
		cidrv4: "IPv4 aralığı",
		cidrv6: "IPv6 aralığı",
		base64: "base64 ile şifrelenmiş metin",
		base64url: "base64url ile şifrelenmiş metin",
		json_string: "JSON dizesi",
		e164: "E.164 sayısı",
		credit_card: "kredi kartı numarası",
		jwt: "JWT",
		template_literal: "Şablon dizesi"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Geçersiz değer: beklenen instanceof ${e.expected}, alınan ${i}` : `Geçersiz değer: beklenen ${t}, alınan ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Geçersiz değer: beklenen ${L(e.values[0])}` : `Geçersiz seçenek: aşağıdakilerden biri olmalı: ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Çok büyük: beklenen ${e.origin ?? "değer"} ${n}${e.maximum.toString()} ${r.unit ?? "öğe"}` : `Çok büyük: beklenen ${e.origin ?? "değer"} ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Çok küçük: beklenen ${e.origin} ${n}${e.minimum.toString()} ${r.unit}` : `Çok küçük: beklenen ${e.origin} ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Geçersiz metin: "${t.prefix}" ile başlamalı` : t.format === "ends_with" ? `Geçersiz metin: "${t.suffix}" ile bitmeli` : t.format === "includes" ? `Geçersiz metin: "${t.includes}" içermeli` : t.format === "regex" ? `Geçersiz metin: ${t.pattern} desenine uymalı` : `Geçersiz ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Geçersiz sayı: ${e.divisor} ile tam bölünebilmeli`;
			case "unrecognized_keys": return `Tanınmayan anahtar${e.keys.length > 1 ? "lar" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} içinde geçersiz anahtar`;
			case "invalid_union": return "Geçersiz değer";
			case "invalid_element": return `${e.origin} içinde geçersiz değer`;
			default: return "Geçersiz değer";
		}
	};
};
function ak() {
	return { localeError: ik() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/uk.js
var ok = () => {
	let e = {
		string: {
			unit: "символів",
			verb: "матиме"
		},
		file: {
			unit: "байтів",
			verb: "матиме"
		},
		array: {
			unit: "елементів",
			verb: "матиме"
		},
		set: {
			unit: "елементів",
			verb: "матиме"
		},
		map: {
			unit: "елементів",
			verb: "матиме"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "вхідні дані",
		email: "адреса електронної пошти",
		url: "URL",
		emoji: "емодзі",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "дата та час ISO",
		date: "дата ISO",
		time: "час ISO",
		duration: "тривалість ISO",
		ipv4: "адреса IPv4",
		ipv6: "адреса IPv6",
		mac: "адреса MAC",
		cidrv4: "діапазон IPv4",
		cidrv6: "діапазон IPv6",
		base64: "рядок у кодуванні base64",
		base64url: "рядок у кодуванні base64url",
		json_string: "рядок JSON",
		e164: "номер E.164",
		credit_card: "номер кредитної картки",
		jwt: "JWT",
		template_literal: "вхідні дані"
	}, r = {
		nan: "NaN",
		number: "число",
		array: "масив"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Неправильні вхідні дані: очікується instanceof ${e.expected}, отримано ${i}` : `Неправильні вхідні дані: очікується ${t}, отримано ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Неправильні вхідні дані: очікується ${L(e.values[0])}` : `Неправильна опція: очікується одне з ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Занадто велике: очікується, що ${e.origin ?? "значення"} ${r.verb} ${n}${e.maximum.toString()} ${r.unit ?? "елементів"}` : `Занадто велике: очікується, що ${e.origin ?? "значення"} буде ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Занадто мале: очікується, що ${e.origin} ${r.verb} ${n}${e.minimum.toString()} ${r.unit}` : `Занадто мале: очікується, що ${e.origin} буде ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Неправильний рядок: повинен починатися з "${t.prefix}"` : t.format === "ends_with" ? `Неправильний рядок: повинен закінчуватися на "${t.suffix}"` : t.format === "includes" ? `Неправильний рядок: повинен містити "${t.includes}"` : t.format === "regex" ? `Неправильний рядок: повинен відповідати шаблону ${t.pattern}` : `Неправильний ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Неправильне число: повинно бути кратним ${e.divisor}`;
			case "unrecognized_keys": return `Нерозпізнаний ключ${e.keys.length > 1 ? "і" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Неправильний ключ у ${e.origin}`;
			case "invalid_union": return "Неправильні вхідні дані";
			case "invalid_element": return `Неправильне значення у ${e.origin}`;
			default: return "Неправильні вхідні дані";
		}
	};
};
function sk() {
	return { localeError: ok() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/ua.js
function ck() {
	return sk();
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/ur.js
var lk = () => {
	let e = {
		string: {
			unit: "حروف",
			verb: "ہونا"
		},
		file: {
			unit: "بائٹس",
			verb: "ہونا"
		},
		array: {
			unit: "آئٹمز",
			verb: "ہونا"
		},
		set: {
			unit: "آئٹمز",
			verb: "ہونا"
		},
		map: {
			unit: "آئٹمز",
			verb: "ہونا"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ان پٹ",
		email: "ای میل ایڈریس",
		url: "یو آر ایل",
		emoji: "ایموجی",
		uuid: "یو یو آئی ڈی",
		uuidv4: "یو یو آئی ڈی وی 4",
		uuidv6: "یو یو آئی ڈی وی 6",
		nanoid: "نینو آئی ڈی",
		guid: "جی یو آئی ڈی",
		cuid: "سی یو آئی ڈی",
		cuid2: "سی یو آئی ڈی 2",
		ulid: "یو ایل آئی ڈی",
		xid: "ایکس آئی ڈی",
		ksuid: "کے ایس یو آئی ڈی",
		datetime: "آئی ایس او ڈیٹ ٹائم",
		date: "آئی ایس او تاریخ",
		time: "آئی ایس او وقت",
		duration: "آئی ایس او مدت",
		ipv4: "آئی پی وی 4 ایڈریس",
		ipv6: "آئی پی وی 6 ایڈریس",
		mac: "ایم اے سی ایڈریس",
		cidrv4: "آئی پی وی 4 رینج",
		cidrv6: "آئی پی وی 6 رینج",
		base64: "بیس 64 ان کوڈڈ سٹرنگ",
		base64url: "بیس 64 یو آر ایل ان کوڈڈ سٹرنگ",
		json_string: "جے ایس او این سٹرنگ",
		e164: "ای 164 نمبر",
		credit_card: "کریڈٹ کارڈ نمبر",
		jwt: "جے ڈبلیو ٹی",
		template_literal: "ان پٹ"
	}, r = {
		nan: "NaN",
		number: "نمبر",
		array: "آرے",
		null: "نل"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `غلط ان پٹ: instanceof ${e.expected} متوقع تھا، ${i} موصول ہوا` : `غلط ان پٹ: ${t} متوقع تھا، ${i} موصول ہوا`;
			}
			case "invalid_value": return e.values.length === 1 ? `غلط ان پٹ: ${L(e.values[0])} متوقع تھا` : `غلط آپشن: ${N(e.values, "|")} میں سے ایک متوقع تھا`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `بہت بڑا: ${e.origin ?? "ویلیو"} کے ${n}${e.maximum.toString()} ${r.unit ?? "عناصر"} ہونے متوقع تھے` : `بہت بڑا: ${e.origin ?? "ویلیو"} کا ${n}${e.maximum.toString()} ہونا متوقع تھا`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `بہت چھوٹا: ${e.origin} کے ${n}${e.minimum.toString()} ${r.unit} ہونے متوقع تھے` : `بہت چھوٹا: ${e.origin} کا ${n}${e.minimum.toString()} ہونا متوقع تھا`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `غلط سٹرنگ: "${t.prefix}" سے شروع ہونا چاہیے` : t.format === "ends_with" ? `غلط سٹرنگ: "${t.suffix}" پر ختم ہونا چاہیے` : t.format === "includes" ? `غلط سٹرنگ: "${t.includes}" شامل ہونا چاہیے` : t.format === "regex" ? `غلط سٹرنگ: پیٹرن ${t.pattern} سے میچ ہونا چاہیے` : `غلط ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `غلط نمبر: ${e.divisor} کا مضاعف ہونا چاہیے`;
			case "unrecognized_keys": return `غیر تسلیم شدہ کی${e.keys.length > 1 ? "ز" : ""}: ${N(e.keys, "، ")}`;
			case "invalid_key": return `${e.origin} میں غلط کی`;
			case "invalid_union": return "غلط ان پٹ";
			case "invalid_element": return `${e.origin} میں غلط ویلیو`;
			default: return "غلط ان پٹ";
		}
	};
};
function uk() {
	return { localeError: lk() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/uz.js
var dk = () => {
	let e = {
		string: {
			unit: "belgi",
			verb: "bo‘lishi kerak"
		},
		file: {
			unit: "bayt",
			verb: "bo‘lishi kerak"
		},
		array: {
			unit: "element",
			verb: "bo‘lishi kerak"
		},
		set: {
			unit: "element",
			verb: "bo‘lishi kerak"
		},
		map: {
			unit: "yozuv",
			verb: "bo‘lishi kerak"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "kirish",
		email: "elektron pochta manzili",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO sana va vaqti",
		date: "ISO sana",
		time: "ISO vaqt",
		duration: "ISO davomiylik",
		ipv4: "IPv4 manzil",
		ipv6: "IPv6 manzil",
		mac: "MAC manzil",
		cidrv4: "IPv4 diapazon",
		cidrv6: "IPv6 diapazon",
		base64: "base64 kodlangan satr",
		base64url: "base64url kodlangan satr",
		json_string: "JSON satr",
		e164: "E.164 raqam",
		credit_card: "kredit karta raqami",
		jwt: "JWT",
		template_literal: "kirish"
	}, r = {
		nan: "NaN",
		number: "raqam",
		array: "massiv"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Noto‘g‘ri kirish: kutilgan instanceof ${e.expected}, qabul qilingan ${i}` : `Noto‘g‘ri kirish: kutilgan ${t}, qabul qilingan ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Noto‘g‘ri kirish: kutilgan ${L(e.values[0])}` : `Noto‘g‘ri variant: quyidagilardan biri kutilgan ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Juda katta: kutilgan ${e.origin ?? "qiymat"} ${n}${e.maximum.toString()} ${r.unit} ${r.verb}` : `Juda katta: kutilgan ${e.origin ?? "qiymat"} ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Juda kichik: kutilgan ${e.origin} ${n}${e.minimum.toString()} ${r.unit} ${r.verb}` : `Juda kichik: kutilgan ${e.origin} ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Noto‘g‘ri satr: "${t.prefix}" bilan boshlanishi kerak` : t.format === "ends_with" ? `Noto‘g‘ri satr: "${t.suffix}" bilan tugashi kerak` : t.format === "includes" ? `Noto‘g‘ri satr: "${t.includes}" ni o‘z ichiga olishi kerak` : t.format === "regex" ? `Noto‘g‘ri satr: ${t.pattern} shabloniga mos kelishi kerak` : `Noto‘g‘ri ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Noto‘g‘ri raqam: ${e.divisor} ning karralisi bo‘lishi kerak`;
			case "unrecognized_keys": return `Noma’lum kalit${e.keys.length > 1 ? "lar" : ""}: ${N(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} dagi kalit noto‘g‘ri`;
			case "invalid_union": return "Noto‘g‘ri kirish";
			case "invalid_element": return `${e.origin} da noto‘g‘ri qiymat`;
			default: return "Noto‘g‘ri kirish";
		}
	};
};
function fk() {
	return { localeError: dk() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/vi.js
var pk = () => {
	let e = {
		string: {
			unit: "ký tự",
			verb: "có"
		},
		file: {
			unit: "byte",
			verb: "có"
		},
		array: {
			unit: "phần tử",
			verb: "có"
		},
		set: {
			unit: "phần tử",
			verb: "có"
		},
		map: {
			unit: "phần tử",
			verb: "có"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "đầu vào",
		email: "địa chỉ email",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ngày giờ ISO",
		date: "ngày ISO",
		time: "giờ ISO",
		duration: "khoảng thời gian ISO",
		ipv4: "địa chỉ IPv4",
		ipv6: "địa chỉ IPv6",
		mac: "địa chỉ MAC",
		cidrv4: "dải IPv4",
		cidrv6: "dải IPv6",
		base64: "chuỗi mã hóa base64",
		base64url: "chuỗi mã hóa base64url",
		json_string: "chuỗi JSON",
		e164: "số E.164",
		credit_card: "số thẻ tín dụng",
		jwt: "JWT",
		template_literal: "đầu vào"
	}, r = {
		nan: "NaN",
		number: "số",
		array: "mảng"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Đầu vào không hợp lệ: mong đợi instanceof ${e.expected}, nhận được ${i}` : `Đầu vào không hợp lệ: mong đợi ${t}, nhận được ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Đầu vào không hợp lệ: mong đợi ${L(e.values[0])}` : `Tùy chọn không hợp lệ: mong đợi một trong các giá trị ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Quá lớn: mong đợi ${e.origin ?? "giá trị"} ${r.verb} ${n}${e.maximum.toString()} ${r.unit ?? "phần tử"}` : `Quá lớn: mong đợi ${e.origin ?? "giá trị"} ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Quá nhỏ: mong đợi ${e.origin} ${r.verb} ${n}${e.minimum.toString()} ${r.unit}` : `Quá nhỏ: mong đợi ${e.origin} ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Chuỗi không hợp lệ: phải bắt đầu bằng "${t.prefix}"` : t.format === "ends_with" ? `Chuỗi không hợp lệ: phải kết thúc bằng "${t.suffix}"` : t.format === "includes" ? `Chuỗi không hợp lệ: phải bao gồm "${t.includes}"` : t.format === "regex" ? `Chuỗi không hợp lệ: phải khớp với mẫu ${t.pattern}` : `${n[t.format] ?? e.format} không hợp lệ`;
			}
			case "not_multiple_of": return `Số không hợp lệ: phải là bội số của ${e.divisor}`;
			case "unrecognized_keys": return `Khóa không được nhận dạng: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Khóa không hợp lệ trong ${e.origin}`;
			case "invalid_union": return "Đầu vào không hợp lệ";
			case "invalid_element": return `Giá trị không hợp lệ trong ${e.origin}`;
			default: return "Đầu vào không hợp lệ";
		}
	};
};
function mk() {
	return { localeError: pk() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/zh-CN.js
var hk = () => {
	let e = {
		string: {
			unit: "字符",
			verb: "包含"
		},
		file: {
			unit: "字节",
			verb: "包含"
		},
		array: {
			unit: "项",
			verb: "包含"
		},
		set: {
			unit: "项",
			verb: "包含"
		},
		map: {
			unit: "项",
			verb: "包含"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "输入",
		email: "电子邮件",
		url: "URL",
		emoji: "表情符号",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO日期时间",
		date: "ISO日期",
		time: "ISO时间",
		duration: "ISO时长",
		ipv4: "IPv4地址",
		ipv6: "IPv6地址",
		mac: "MAC地址",
		cidrv4: "IPv4网段",
		cidrv6: "IPv6网段",
		base64: "base64编码字符串",
		base64url: "base64url编码字符串",
		json_string: "JSON字符串",
		e164: "E.164号码",
		credit_card: "信用卡号",
		jwt: "JWT",
		template_literal: "输入"
	}, r = {
		nan: "NaN",
		number: "数字",
		array: "数组",
		null: "空值(null)"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `无效输入：期望 instanceof ${e.expected}，实际接收 ${i}` : `无效输入：期望 ${t}，实际接收 ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `无效输入：期望 ${L(e.values[0])}` : `无效选项：期望以下之一 ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `数值过大：期望 ${e.origin ?? "值"} ${n}${e.maximum.toString()} ${r.unit ?? "个元素"}` : `数值过大：期望 ${e.origin ?? "值"} ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `数值过小：期望 ${e.origin} ${n}${e.minimum.toString()} ${r.unit}` : `数值过小：期望 ${e.origin} ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `无效字符串：必须以 "${t.prefix}" 开头` : t.format === "ends_with" ? `无效字符串：必须以 "${t.suffix}" 结尾` : t.format === "includes" ? `无效字符串：必须包含 "${t.includes}"` : t.format === "regex" ? `无效字符串：必须满足正则表达式 ${t.pattern}` : `无效${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `无效数字：必须是 ${e.divisor} 的倍数`;
			case "unrecognized_keys": return `出现未知的键(key): ${N(e.keys, ", ")}`;
			case "invalid_key": return `${e.origin} 中的键(key)无效`;
			case "invalid_union": return "无效输入";
			case "invalid_element": return `${e.origin} 中包含无效值(value)`;
			default: return "无效输入";
		}
	};
};
function gk() {
	return { localeError: hk() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/zh-TW.js
var _k = () => {
	let e = {
		string: {
			unit: "字元",
			verb: "擁有"
		},
		file: {
			unit: "位元組",
			verb: "擁有"
		},
		array: {
			unit: "項目",
			verb: "擁有"
		},
		set: {
			unit: "項目",
			verb: "擁有"
		},
		map: {
			unit: "項目",
			verb: "擁有"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "輸入",
		email: "郵件地址",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO 日期時間",
		date: "ISO 日期",
		time: "ISO 時間",
		duration: "ISO 期間",
		ipv4: "IPv4 位址",
		ipv6: "IPv6 位址",
		mac: "MAC 位址",
		cidrv4: "IPv4 範圍",
		cidrv6: "IPv6 範圍",
		base64: "base64 編碼字串",
		base64url: "base64url 編碼字串",
		json_string: "JSON 字串",
		e164: "E.164 數值",
		credit_card: "信用卡號",
		jwt: "JWT",
		template_literal: "輸入"
	}, r = { nan: "NaN" };
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `無效的輸入值：預期為 instanceof ${e.expected}，但收到 ${i}` : `無效的輸入值：預期為 ${t}，但收到 ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `無效的輸入值：預期為 ${L(e.values[0])}` : `無效的選項：預期為以下其中之一 ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `數值過大：預期 ${e.origin ?? "值"} 應為 ${n}${e.maximum.toString()} ${r.unit ?? "個元素"}` : `數值過大：預期 ${e.origin ?? "值"} 應為 ${n}${e.maximum.toString()}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `數值過小：預期 ${e.origin} 應為 ${n}${e.minimum.toString()} ${r.unit}` : `數值過小：預期 ${e.origin} 應為 ${n}${e.minimum.toString()}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `無效的字串：必須以 "${t.prefix}" 開頭` : t.format === "ends_with" ? `無效的字串：必須以 "${t.suffix}" 結尾` : t.format === "includes" ? `無效的字串：必須包含 "${t.includes}"` : t.format === "regex" ? `無效的字串：必須符合格式 ${t.pattern}` : `無效的 ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `無效的數字：必須為 ${e.divisor} 的倍數`;
			case "unrecognized_keys": return `無法識別的鍵值${e.keys.length > 1 ? "們" : ""}：${N(e.keys, "、")}`;
			case "invalid_key": return `${e.origin} 中有無效的鍵值`;
			case "invalid_union": return "無效的輸入值";
			case "invalid_element": return `${e.origin} 中有無效的值`;
			default: return "無效的輸入值";
		}
	};
};
function vk() {
	return { localeError: _k() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/yo.js
var yk = () => {
	let e = {
		string: {
			unit: "àmi",
			verb: "ní"
		},
		file: {
			unit: "bytes",
			verb: "ní"
		},
		array: {
			unit: "nkan",
			verb: "ní"
		},
		set: {
			unit: "nkan",
			verb: "ní"
		},
		map: {
			unit: "nkan",
			verb: "ní"
		}
	};
	function t(t) {
		return e[t] ?? null;
	}
	let n = {
		regex: "ẹ̀rọ ìbáwọlé",
		email: "àdírẹ́sì ìmẹ́lì",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "àkókò ISO",
		date: "ọjọ́ ISO",
		time: "àkókò ISO",
		duration: "àkókò tó pé ISO",
		ipv4: "àdírẹ́sì IPv4",
		ipv6: "àdírẹ́sì IPv6",
		mac: "àdírẹ́sì MAC",
		cidrv4: "àgbègbè IPv4",
		cidrv6: "àgbègbè IPv6",
		base64: "ọ̀rọ̀ tí a kọ́ ní base64",
		base64url: "ọ̀rọ̀ base64url",
		json_string: "ọ̀rọ̀ JSON",
		e164: "nọ́mbà E.164",
		credit_card: "nọmba kaadi gbese",
		jwt: "JWT",
		template_literal: "ẹ̀rọ ìbáwọlé"
	}, r = {
		nan: "NaN",
		number: "nọ́mbà",
		array: "akopọ"
	};
	return (e) => {
		switch (e.code) {
			case "invalid_type": {
				let t = r[e.expected] ?? e.expected, n = R(e.input), i = r[n] ?? n;
				return /^[A-Z]/.test(e.expected) ? `Ìbáwọlé aṣìṣe: a ní láti fi instanceof ${e.expected}, àmọ̀ a rí ${i}` : `Ìbáwọlé aṣìṣe: a ní láti fi ${t}, àmọ̀ a rí ${i}`;
			}
			case "invalid_value": return e.values.length === 1 ? `Ìbáwọlé aṣìṣe: a ní láti fi ${L(e.values[0])}` : `Àṣàyàn aṣìṣe: yan ọ̀kan lára ${N(e.values, "|")}`;
			case "too_big": {
				let n = e.inclusive ? "<=" : "<", r = t(e.origin);
				return r ? `Tó pọ̀ jù: a ní láti jẹ́ pé ${e.origin ?? "iye"} ${r.verb} ${n}${e.maximum} ${r.unit}` : `Tó pọ̀ jù: a ní láti jẹ́ ${n}${e.maximum}`;
			}
			case "too_small": {
				let n = e.inclusive ? ">=" : ">", r = t(e.origin);
				return r ? `Kéré ju: a ní láti jẹ́ pé ${e.origin} ${r.verb} ${n}${e.minimum} ${r.unit}` : `Kéré ju: a ní láti jẹ́ ${n}${e.minimum}`;
			}
			case "invalid_format": {
				let t = e;
				return t.format === "starts_with" ? `Ọ̀rọ̀ aṣìṣe: gbọ́dọ̀ bẹ̀rẹ̀ pẹ̀lú "${t.prefix}"` : t.format === "ends_with" ? `Ọ̀rọ̀ aṣìṣe: gbọ́dọ̀ parí pẹ̀lú "${t.suffix}"` : t.format === "includes" ? `Ọ̀rọ̀ aṣìṣe: gbọ́dọ̀ ní "${t.includes}"` : t.format === "regex" ? `Ọ̀rọ̀ aṣìṣe: gbọ́dọ̀ bá àpẹẹrẹ mu ${t.pattern}` : `Aṣìṣe: ${n[t.format] ?? e.format}`;
			}
			case "not_multiple_of": return `Nọ́mbà aṣìṣe: gbọ́dọ̀ jẹ́ èyà pípín ti ${e.divisor}`;
			case "unrecognized_keys": return `Bọtìnì àìmọ̀: ${N(e.keys, ", ")}`;
			case "invalid_key": return `Bọtìnì aṣìṣe nínú ${e.origin}`;
			case "invalid_union": return "Ìbáwọlé aṣìṣe";
			case "invalid_element": return `Iye aṣìṣe nínú ${e.origin}`;
			default: return "Ìbáwọlé aṣìṣe";
		}
	};
};
function bk() {
	return { localeError: yk() };
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/index.js
var xk = /* @__PURE__ */ T({
	ar: () => nD,
	az: () => iD,
	be: () => sD,
	bg: () => lD,
	bn: () => dD,
	ca: () => pD,
	ckb: () => hD,
	cs: () => _D,
	da: () => yD,
	de: () => xD,
	el: () => CD,
	en: () => TD,
	eo: () => DD,
	es: () => kD,
	fa: () => jD,
	fi: () => ND,
	fr: () => FD,
	frCA: () => LD,
	gu: () => zD,
	he: () => VD,
	hi: () => UD,
	hr: () => GD,
	hu: () => qD,
	hy: () => ZD,
	id: () => $D,
	is: () => tO,
	it: () => rO,
	ja: () => aO,
	ka: () => sO,
	kh: () => uO,
	km: () => lO,
	kn: () => fO,
	ko: () => mO,
	lt: () => vO,
	mk: () => bO,
	ms: () => SO,
	ne: () => wO,
	nl: () => EO,
	nn: () => OO,
	no: () => AO,
	ota: () => MO,
	pl: () => IO,
	ps: () => PO,
	pt: () => RO,
	ptBR: () => BO,
	ro: () => HO,
	ru: () => GO,
	sk: () => qO,
	sl: () => YO,
	sv: () => ZO,
	ta: () => $O,
	th: () => tk,
	tk: () => rk,
	tr: () => ak,
	ua: () => ck,
	uk: () => sk,
	ur: () => uk,
	uz: () => fk,
	vi: () => mk,
	yo: () => bk,
	zhCN: () => gk,
	zhTW: () => vk
}), Sk, Ck = /*@__PURE__*/ Symbol("ZodOutput"), wk = /*@__PURE__*/ Symbol("ZodInput"), Tk = class {
	constructor() {
		this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
	}
	add(e, ...t) {
		let n = t[0];
		return this._map.set(e, n), n && typeof n == "object" && "id" in n && this._idmap.set(n.id, e), this;
	}
	clear() {
		return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
	}
	remove(e) {
		let t = this._map.get(e);
		return t && typeof t == "object" && "id" in t && this._idmap.delete(t.id), this._map.delete(e), this;
	}
	get(e) {
		let t = e._zod.parent;
		if (t) {
			let n = { ...this.get(t) ?? {} };
			delete n.id;
			let r = {
				...n,
				...this._map.get(e)
			};
			return Object.keys(r).length ? r : void 0;
		}
		return this._map.get(e);
	}
	has(e) {
		return this._map.has(e);
	}
};
function Ek() {
	return new Tk();
}
(Sk = globalThis).__zod_globalRegistry ?? (Sk.__zod_globalRegistry = Ek());
var Dk = globalThis.__zod_globalRegistry, Ok = Symbol.for("zod.compile.invalid"), kk = Symbol.for("zod.compile.fallback"), Ak = class extends Error {
	constructor(e = "z.compile does not support async refinements, transforms, or checks") {
		super(e), this.name = "ZodCompileAsyncError";
	}
}, G = class extends Error {
	constructor(e, t = !0) {
		super(`z.compile does not support ${e}; this schema must use the runtime parser`), this.name = "ZodCompileUnsupportedError", this.islandable = t;
	}
};
function jk(e, t) {
	try {
		return Pk(e, { assertOnly: !0 });
	} catch {
		return t;
	}
}
function Mk(e, t) {
	try {
		let t = Pk(e), n = F(e), r = e._zod.run, i = r.__originalRun ?? r, a = (e, n) => {
			if (n?.async || n?.direction === "backward" || n?.skipChecks || n?.[kk] || n && eD(n, e.value)) return i(e, n);
			let r = t(e.value);
			return r === Ok ? (n && (n[kk] = !0), i(e, n)) : (e.value = r, e);
		};
		return a.__originalRun = i, n._zod.bag.fallbackRun = i, n._zod.bag.validator = jk(e, t), n._zod.run = a, r.__originalRun || Nk(n, e, t), n;
	} catch (n) {
		if (t?.strict) throw n;
		return e;
	}
}
function Nk(e, t, n) {
	let r = e, i = t;
	if (typeof i.safeParse == "function") {
		let e = i.safeParse;
		r.safeParse = (t, r) => {
			let i = n(t);
			return i === Ok ? e(t, r) : {
				success: !0,
				data: i
			};
		};
	}
	if (typeof i.parse == "function") {
		let e = i.parse;
		r.parse = (t, r) => {
			let i = n(t);
			return i === Ok ? e(t, r) : i;
		};
	}
}
function Pk(e, t) {
	let n = !0;
	try {
		n = JE(e);
	} catch {}
	if (n) throw new G("a schema whose subtree contains a reference cycle");
	let r = {
		constants: /* @__PURE__ */ new Map(),
		constantCounter: 0,
		varCounter: 0
	}, i = new Pw(["input"]), a = J(i, r, e, "input", !t?.assertOnly);
	i.write(a === null ? "return true;" : `return ${a};`);
	let o = ["INVALID", ...r.constants.keys()], s = [Ok, ...r.constants.values()], c = i.content.join("\n"), l = t?.debug ? o.length > 0 ? `// Constants: ${o.join(", ")}\n${c}` : c : "", u = Function, d = `return (input) => {\n${c}\n}`, f;
	try {
		f = new u(...o, d)(...s);
	} catch (e) {
		throw new G(`this schema (generated code failed to evaluate: ${e.message})`);
	}
	return t?.debug && (f.code = l), f;
}
function K(e, t) {
	for (let [n, r] of e.constants) if (r === t) return n;
	let n = `c${e.constantCounter++}`;
	return e.constants.set(n, t), n;
}
function q(e) {
	return `v${e.varCounter++}`;
}
function Fk(e, t) {
	let n = e._zod.run({
		value: t,
		issues: []
	}, {});
	if (n && typeof n.then == "function") return Ok;
	let r = n;
	return r.issues.length === 0 ? r.value : Ok;
}
function Ik(e, t, n, r, i = !0) {
	let a = e.content.length, o = t.constants.size, s = t.constantCounter, c = t.varCounter;
	try {
		return J(e, t, n, r, i);
	} catch (i) {
		if (!(i instanceof G) || !i.islandable) throw i;
		if (e.content.length = a, t.constants.size > o) {
			let e = Array.from(t.constants.keys()).slice(o);
			for (let n of e) t.constants.delete(n);
		}
		return t.constantCounter = s, t.varCounter = c, Lk(e, t, n, r);
	}
}
function Lk(e, t, n, r) {
	let i = K(t, n), a = K(t, Fk), o = q(t);
	return e.write(`const ${o} = ${a}(${i}, ${r});`), e.write(`if (${o} === INVALID) return INVALID;`), o;
}
var Rk = /* @__PURE__ */ new Set([
	"max_size",
	"min_size",
	"size_equals",
	"max_length",
	"min_length",
	"length_equals"
]);
function zk(e, t, n, r) {
	let i = n._zod.def.checks;
	if (!i || i.length === 0) return r;
	let a = r;
	for (let n of i) {
		let r = n._zod.def;
		if (r.when && !Rk.has(r.check)) throw new G("check with a custom \"when\" condition");
		switch (r.check) {
			case "greater_than":
				Uk(e, t, r, a);
				break;
			case "less_than":
				Wk(e, t, r, a);
				break;
			case "multiple_of":
				Gk(e, t, r, a);
				break;
			case "number_format":
				Kk(e, r, a);
				break;
			case "min_length": {
				let n = Vk(r.minimum, "min_length"), i = Bk(e, t, a, `${a}.length >= ${n} && ${a}.length < ${r.minimum * 2}`);
				e.write(`if (${i} < ${n}) return INVALID;`);
				break;
			}
			case "max_length": {
				let n = Vk(r.maximum, "max_length"), i = Bk(e, t, a, `${a}.length > ${n}`);
				e.write(`if (${i} > ${n}) return INVALID;`);
				break;
			}
			case "length_equals": {
				let n = Vk(r.length, "length_equals"), i = Bk(e, t, a, `${a}.length >= ${n} && ${a}.length <= ${r.length * 2}`);
				e.write(`if (${i} !== ${n}) return INVALID;`);
				break;
			}
			case "min_size":
				e.write(`if (${a}.size < ${Vk(r.minimum, "min_size")}) return INVALID;`);
				break;
			case "max_size":
				e.write(`if (${a}.size > ${Vk(r.maximum, "max_size")}) return INVALID;`);
				break;
			case "size_equals":
				e.write(`if (${a}.size !== ${Vk(r.size, "size_equals")}) return INVALID;`);
				break;
			case "string_format":
				a = tA(e, t, r, a);
				break;
			case "custom":
				a = $k(e, t, n, a);
				break;
			case "bigint_format":
				qk(e, r, a);
				break;
			case "mime_type":
				Jk(e, t, r, a);
				break;
			case "property":
				Yk(e, t, r, a);
				break;
			case "overwrite": {
				let r = q(t);
				Xk(e, t, n, a, r), a = r;
				break;
			}
			default: throw new G(`check type ${r.check}`);
		}
	}
	return a;
}
function Bk(e, t, n, r) {
	let i = K(t, Dx), a = q(t);
	return e.write(`const ${a} = typeof ${n} === "string" && ${r} ? ${i}(${n}) : ${n}.length;`), a;
}
function Vk(e, t) {
	if (typeof e != "number" || !Number.isFinite(e)) throw new G(`${t} bound of type ${typeof e}`);
	return `${e}`;
}
function Hk(e, t) {
	if (typeof t == "bigint") return `${t}n`;
	if (typeof t == "number") {
		if (Number.isNaN(t)) throw new G("comparison check with NaN bound");
		return `${t}`;
	}
	if (t instanceof Date) {
		if (Number.isNaN(t.getTime())) throw new G("comparison check with Invalid Date bound");
		return K(e, t);
	}
	throw new G(`comparison check bound of type ${typeof t}`);
}
function Uk(e, t, n, r) {
	let i = n.inclusive ? "<" : "<=";
	e.write(`if (${r} ${i} ${Hk(t, n.value)}) return INVALID;`);
}
function Wk(e, t, n, r) {
	let i = n.inclusive ? ">" : ">=";
	e.write(`if (${r} ${i} ${Hk(t, n.value)}) return INVALID;`);
}
function Gk(e, t, n, r) {
	if (typeof n.value == "bigint") {
		if (n.value === BigInt(0)) throw new G("multiple_of check with a zero divisor");
		e.write(`if (${r} % ${n.value}n !== 0n) return INVALID;`);
	} else {
		let i = K(t, Vb);
		e.write(`if (${i}(${r}, ${Vk(n.value, "multiple_of")}) !== 0) return INVALID;`);
	}
}
function Kk(e, t, n) {
	let r = t.format;
	switch (r) {
		case "safeint":
			e.write(`if (!Number.isSafeInteger(${n})) return INVALID;`);
			break;
		case "int32":
			e.write(`if (!Number.isInteger(${n}) || ${n} < -2147483648 || ${n} > 2147483647) return INVALID;`);
			break;
		case "uint32":
			e.write(`if (!Number.isInteger(${n}) || ${n} < 0 || ${n} > 4294967295) return INVALID;`);
			break;
		case "float32":
			e.write(`if (!Number.isFinite(${n}) || ${n} < -3.4028234663852886e38 || ${n} > 3.4028234663852886e38) return INVALID;`);
			break;
		case "float64":
			e.write(`if (!Number.isFinite(${n})) return INVALID;`);
			break;
		default: throw new G(`number format ${r}`);
	}
}
function qk(e, t, n) {
	let r = t.format;
	if (r) switch (r) {
		case "int64":
			e.write(`if (${n} < -9223372036854775808n || ${n} > 9223372036854775807n) return INVALID;`);
			break;
		case "uint64":
			e.write(`if (${n} < 0n || ${n} > 18446744073709551615n) return INVALID;`);
			break;
		default: throw new G(`bigint format ${r}`);
	}
}
function Jk(e, t, n, r) {
	let i = n.mime;
	if (i && i.length > 0) {
		let n = K(t, new Set(i));
		e.write(`if (!${n}.has(${r}.type)) return INVALID;`);
	}
}
function Yk(e, t, n, r) {
	let i = `${r}[${JSON.stringify(n.property)}]`;
	J(e, t, n.schema, i);
}
function Xk(e, t, n, r, i) {
	let a = n._zod.def.tx;
	if (!a) throw new G("overwrite check without a transform function");
	if (BA(a)) throw new Ak("z.compile: async overwrite transforms are not supported");
	let o = K(t, a);
	e.write(`const ${i} = ${o}(${r});`);
}
function Zk() {
	throw new tS();
}
function Qk(e) {
	this.issues.push(e);
}
function $k(e, t, n, r) {
	let i = n._zod.def;
	if (i.fn) {
		if (BA(i.fn)) throw new Ak("z.compile: async .refine() predicates are not supported");
		let n = K(t, i.fn), a = K(t, Zk), o = q(t);
		return e.write(`const ${o} = ${n}(${r});`), e.write(`if (${o} instanceof Promise) ${a}();`), e.write(`if (!${o}) return INVALID;`), r;
	}
	if (n._zod.check) {
		if (BA(n._zod.check)) throw new Ak("z.compile: async .superRefine() / check functions are not supported");
		let i = n._zod.check, a = K(t, (e) => {
			let t = {
				value: e,
				issues: [],
				addIssue: Qk
			};
			return i(t) instanceof Promise && Zk(), t.issues.length === 0 ? t.value : Ok;
		}), o = q(t);
		return e.write(`const ${o} = ${a}(${r});`), e.write(`if (${o} === INVALID) return INVALID;`), o;
	}
	throw new G("custom check without a predicate or check function");
}
var eA = /* @__PURE__ */ new Set([
	"cidrv4",
	"cuid",
	"cuid2",
	"date",
	"datetime",
	"duration",
	"e164",
	"email",
	"emoji",
	"ends_with",
	"guid",
	"includes",
	"ipv4",
	"ksuid",
	"lowercase",
	"mac",
	"nanoid",
	"regex",
	"starts_with",
	"time",
	"ulid",
	"uppercase",
	"uuid",
	"xid"
]);
function tA(e, t, n, r) {
	let i = n.format;
	if (i === "base64") {
		let n = K(t, pT);
		return e.write(`if (!${n}(${r})) return INVALID;`), r;
	}
	if (i === "base64url") {
		let n = K(t, hT);
		return e.write(`if (!${n}(${r})) return INVALID;`), r;
	}
	if (i === "jwt") {
		let i = K(t, ST), a = K(t, n.alg ?? null);
		return e.write(`if (!${i}(${r}, ${a})) return INVALID;`), r;
	}
	if (i === "ipv6") {
		let n = K(t, sT);
		return e.write(`if (!${n}(${r})) return INVALID;`), r;
	}
	if (i === "cidrv6") {
		let n = K(t, dT);
		return e.write(`if (!${n}(${r})) return INVALID;`), r;
	}
	if (i === "credit_card") {
		let n = K(t, bT);
		return e.write(`if (!${n}(${r})) return INVALID;`), r;
	}
	let a = n;
	if (i === "url" || i === "httpurl" || a.normalize || a.hostname !== void 0 || a.protocol !== void 0) {
		let i = K(t, Hw), o = K(t, n), s = q(t), c = q(t);
		if (e.write(`const ${s} = ${r}.trim();`), e.write(`const ${c} = ${i}(${s}, ${o});`), e.write(`if (typeof ${c} === "number") return INVALID;`), a.hostname !== void 0) {
			let n = K(t, Gw);
			e.write(`if (!${n}(${c}, ${o}.hostname)) return INVALID;`);
		}
		if (a.protocol !== void 0) {
			let n = K(t, Kw);
			e.write(`if (!${n}(${c}, ${o}.protocol)) return INVALID;`);
		}
		let l = q(t), u = a.normalize ? `${c}.href` : `${K(t, Ww)}(${s})`;
		return e.write(`const ${l} = ${u};`), l;
	}
	let o = n.fn;
	if (o) {
		if (BA(o)) throw new G(`async string format ${i}`);
		let n = K(t, o);
		return e.write(`if (!${n}(${r})) return INVALID;`), r;
	}
	if (eA.has(i) && n.pattern) {
		let i = K(t, n.pattern);
		return e.write(`${i}.lastIndex = 0;`), e.write(`if (!${i}.test(${r})) return INVALID;`), r;
	}
	let s = n.format;
	switch (s) {
		case "regex": throw new G("regex format without a pattern");
		case "lowercase":
			e.write(`if (${r} !== ${r}.toLowerCase()) return INVALID;`);
			break;
		case "uppercase":
			e.write(`if (${r} !== ${r}.toUpperCase()) return INVALID;`);
			break;
		case "includes":
			e.write(`if (!${r}.includes(${Xb(n.includes)})) return INVALID;`);
			break;
		case "starts_with": {
			let t = n.prefix;
			e.write(`if (${r}.slice(0, ${t.length}) !== ${Xb(t)}) return INVALID;`);
			break;
		}
		case "ends_with": {
			let t = n.suffix;
			e.write(`if (${r}.slice(-${t.length}) !== ${Xb(t)}) return INVALID;`);
			break;
		}
		default: throw new G(`string format ${s}`);
	}
	return r;
}
function J(e, t, n, r, i = !0) {
	let a = n._zod.def, o = a.type;
	if (a.coerce) throw new G(`coercion (z.coerce.${o}())`);
	let s = i || !!a.checks?.length, c;
	switch (o) {
		case "string":
			c = nA(e, t, n, r);
			break;
		case "number":
			c = rA(e, n, r);
			break;
		case "boolean":
			c = iA(e, r);
			break;
		case "bigint":
			c = aA(e, n, r);
			break;
		case "symbol":
			c = oA(e, r);
			break;
		case "undefined":
			c = sA(e, r);
			break;
		case "null":
			c = cA(e, r);
			break;
		case "any":
		case "unknown":
			c = r;
			break;
		case "never":
			e.write("return INVALID;"), c = r;
			break;
		case "void":
			c = lA(e, r);
			break;
		case "nan":
			c = uA(e, r);
			break;
		case "date":
			c = dA(e, r);
			break;
		case "object":
			c = fA(e, t, n, r, s);
			break;
		case "optional":
			c = pA(e, t, n, r, s);
			break;
		case "nullable":
			c = yA(e, t, n, r, s);
			break;
		case "array":
			c = bA(e, t, n, r, s);
			break;
		case "literal":
			c = xA(e, t, n, r);
			break;
		case "enum":
			c = SA(e, t, n, r);
			break;
		case "readonly": {
			let i = CA(e, t, n, r), a = q(t);
			e.write(`const ${a} = Object.freeze(${i});`), c = a;
			break;
		}
		case "success":
			CA(e, t, n, r), c = "true";
			break;
		case "default":
		case "prefault":
			c = wA(e, t, n, r);
			break;
		case "nonoptional":
			c = TA(e, t, n, r);
			break;
		case "tuple":
			c = EA(e, t, n, r);
			break;
		case "union":
			c = OA(e, t, n, r);
			break;
		case "intersection":
			c = jA(e, t, n, r);
			break;
		case "record":
			c = MA(e, t, n, r);
			break;
		case "map":
			c = PA(e, t, n, r);
			break;
		case "set":
			c = FA(e, t, n, r);
			break;
		case "file":
			c = IA(e, r);
			break;
		case "template_literal":
			c = LA(e, t, n, r);
			break;
		case "lazy":
			c = RA(e, t, n, r);
			break;
		case "pipe":
			c = zA(e, t, n, r);
			break;
		case "custom":
			c = VA(e, t, n, r);
			break;
		case "transform":
			c = WA(e, t, n, r);
			break;
		case "catch":
			c = UA(e, t, n, r);
			break;
		default: throw new G(`schema type ${o}`);
	}
	return c === null ? null : zk(e, t, n, c);
}
function nA(e, t, n, r) {
	e.write(`if (typeof ${r} !== "string") return INVALID;`);
	let i = n._zod.def;
	return i.format === void 0 ? r : tA(e, t, i, r);
}
function rA(e, t, n) {
	e.write(`if (typeof ${n} !== "number" || !Number.isFinite(${n})) return INVALID;`);
	let r = t._zod.def;
	return r.check === "number_format" && r.format && Kk(e, { format: r.format }, n), n;
}
function iA(e, t) {
	return e.write(`if (typeof ${t} !== "boolean") return INVALID;`), t;
}
function aA(e, t, n) {
	e.write(`if (typeof ${n} !== "bigint") return INVALID;`);
	let r = t._zod.def;
	if (r.format) switch (r.format) {
		case "int64":
			e.write(`if (${n} < -9223372036854775808n || ${n} > 9223372036854775807n) return INVALID;`);
			break;
		case "uint64": e.write(`if (${n} < 0n || ${n} > 18446744073709551615n) return INVALID;`);
	}
	return n;
}
function oA(e, t) {
	return e.write(`if (typeof ${t} !== "symbol") return INVALID;`), t;
}
function sA(e, t) {
	return e.write(`if (${t} !== undefined) return INVALID;`), t;
}
function cA(e, t) {
	return e.write(`if (${t} !== null) return INVALID;`), t;
}
function lA(e, t) {
	return e.write(`if (${t} !== undefined) return INVALID;`), t;
}
function uA(e, t) {
	return e.write(`if (typeof ${t} !== "number" || !Number.isNaN(${t})) return INVALID;`), t;
}
function dA(e, t) {
	return e.write(`if (!(${t} instanceof Date) || Number.isNaN(${t}.getTime())) return INVALID;`), t;
}
function fA(e, t, n, r, i = !0) {
	let a = n._zod.def;
	e.write(`if (typeof ${r} !== "object" || ${r} === null || Array.isArray(${r})) return INVALID;`);
	let o = a.shape, s = Object.keys(o), c = Object.getOwnPropertySymbols(o), l = c.length ? [...s, ...c] : s, u = (e) => typeof e == "symbol" ? K(t, e) : Xb(e), d = (e) => typeof e == "symbol" ? `[${u(e)}]` : Xb(e), f = o;
	if (s.includes("__proto__")) throw new G("object shape key \"__proto__\"");
	let p = /* @__PURE__ */ new Map();
	for (let n of l) {
		let a = f[n], o = u(n), s = q(t);
		if (e.write(`const ${s} = ${r}[${o}];`), a._zod.optin !== void 0) {
			let i = q(t);
			e.write(`let ${i} = (() => {`), e.indented((e) => {
				let n = Ik(e, t, a, s);
				e.write(`return ${n};`);
			}), e.write("})();"), a._zod.optout === "optional" ? (e.write(`if (${i} === INVALID) {`), e.indented((e) => {
				e.write(`if (${o} in ${r}) return INVALID;`), e.write(`${i} = undefined;`);
			}), e.write("}")) : e.write(`if (${i} === INVALID) return INVALID;`), p.set(n, i);
		} else {
			hA(a) && e.write(`if (!(${o} in ${r})) return INVALID;`);
			let c = Ik(e, t, a, s, i);
			c !== null && p.set(n, c);
		}
	}
	let m = a.catchall, h = "none";
	if (m) {
		let t = m._zod.def.type;
		if (t === "never") {
			let t = s.map((e) => `k !== ${Xb(e)}`).join(" && ") || "true";
			e.write(`for (const k in ${r}) {`), e.indented((e) => {
				e.write(`if (${t}) return INVALID;`);
			}), e.write("}");
		} else h = (t === "unknown" || t === "any") && !m._zod.def.checks?.length ? "passthrough" : "schema";
	}
	let g = q(t), ee = l.some((e) => vA(f[e]) || _A(f[e]));
	if (!i) {
		if (h === "schema") {
			let n = s.length > 0 ? K(t, new Set(s)) : null;
			e.write(`for (const k in ${r}) {`), e.indented((e) => {
				e.write("if (k === \"__proto__\") continue;"), n && e.write(`if (${n}.has(k)) continue;`);
				let i = q(t);
				e.write(`const ${i} = ${r}[k];`), Ik(e, t, m, i, !1);
			}), e.write("}");
		}
		return null;
	}
	if (ee) {
		e.write(`const ${g} = {};`);
		for (let t of l) {
			let n = u(t), i = p.get(t);
			_A(f[t]) ? e.write(`if (${n} in ${r}) ${g}[${n}] = ${i};`) : vA(f[t]) ? e.write(`if (${i} !== undefined || ${n} in ${r}) ${g}[${n}] = ${i};`) : e.write(`${g}[${n}] = ${i};`);
		}
	} else {
		let t = l.map((e) => `${d(e)}: ${p.get(e)}`).join(", ");
		e.write(`const ${g} = { ${t} };`);
	}
	if (h !== "none") {
		let n = s.length > 0 ? K(t, new Set(s)) : null;
		e.write(`for (const k in ${r}) {`), e.indented((e) => {
			if (e.write("if (k === \"__proto__\") continue;"), n && e.write(`if (${n}.has(k)) continue;`), h === "passthrough") e.write(`${g}[k] = ${r}[k];`);
			else {
				let n = q(t);
				e.write(`const ${n} = ${r}[k];`);
				let i = Ik(e, t, m, n);
				e.write(`${g}[k] = ${i};`);
			}
		}), e.write("}");
	}
	return g;
}
function pA(e, t, n, r, i = !0) {
	let a = n._zod.def;
	if (mA(n)) return J(e, t, a.innerType, r, i);
	if (a.innerType._zod.optin === "defaulted") {
		let n = q(t), i = q(t);
		return e.write(`let ${n};`), e.write(`if (${r} === undefined) {`), e.indented((e) => {
			e.write(`const ${i} = (() => {`), e.indented((e) => {
				let n = J(e, t, a.innerType, r);
				e.write(`return ${n};`);
			}), e.write("})();"), e.write(`if (${i} !== INVALID) ${n} = ${i};`);
		}), e.write("} else {"), e.indented((e) => {
			let i = J(e, t, a.innerType, r);
			e.write(`${n} = ${i};`);
		}), e.write("}"), n;
	}
	let o = i ? q(t) : null;
	return o && e.write(`let ${o};`), e.write(`if (${r} !== undefined) {`), e.indented((e) => {
		let n = J(e, t, a.innerType, r, i);
		o && n !== null && e.write(`${o} = ${n};`);
	}), e.write("}"), o;
}
function mA(e) {
	return e._zod.traits?.has("$ZodExactOptional") === !0;
}
function hA(e) {
	return e._zod.optin === void 0 && gA(e);
}
function gA(e) {
	if (e._zod.def.coerce) return !0;
	let t = e._zod.def;
	switch (t.type) {
		case "any":
		case "unknown":
		case "undefined":
		case "void":
		case "default":
		case "prefault":
		case "transform":
		case "custom":
		case "lazy": return !0;
		case "string":
		case "number":
		case "boolean":
		case "bigint":
		case "symbol":
		case "null":
		case "never":
		case "nan":
		case "date":
		case "object":
		case "array":
		case "tuple":
		case "record":
		case "map":
		case "set":
		case "file":
		case "template_literal": return !1;
		case "nonoptional": return t.innerType ? gA(t.innerType) : !1;
		case "literal": return !!t.values?.includes(void 0);
		case "enum": return !!e._zod.values?.has(void 0);
		case "optional":
		case "nullable":
		case "readonly":
		case "success": return !t.innerType || gA(t.innerType);
		case "catch": return !0;
		case "union": return !t.options || t.options.some(gA);
		case "intersection": return !t.left || !t.right || gA(t.left) && gA(t.right);
		case "pipe": return !t.in || gA(t.in);
		default: return !0;
	}
}
function _A(e) {
	return e._zod.optin === "optional" && e._zod.optout === "optional";
}
function vA(e) {
	let t = e._zod.def;
	switch (t.type) {
		case "string":
		case "number":
		case "boolean":
		case "bigint":
		case "symbol":
		case "null":
		case "nan":
		case "date":
		case "object":
		case "array":
		case "tuple":
		case "record":
		case "map":
		case "set":
		case "file":
		case "template_literal":
		case "never":
		case "success": return !1;
		case "literal": return !!t.values?.includes(void 0);
		case "enum": return !!e._zod.values?.has(void 0);
		case "optional": return !0;
		case "nullable":
		case "readonly":
		case "nonoptional": return !t.innerType || vA(t.innerType);
		case "union": return !t.options || t.options.some(vA);
		case "intersection": return !t.left || !t.right || vA(t.left) || vA(t.right);
		case "pipe": return !t.out || vA(t.out);
		default: return !0;
	}
}
function yA(e, t, n, r, i = !0) {
	let a = n._zod.def, o = i ? q(t) : null;
	return o && e.write(`let ${o} = null;`), e.write(`if (${r} !== null) {`), e.indented((e) => {
		let n = J(e, t, a.innerType, r, i);
		o && n !== null && e.write(`${o} = ${n};`);
	}), e.write("}"), o;
}
function bA(e, t, n, r, i = !0) {
	let a = n._zod.def;
	e.write(`if (!Array.isArray(${r})) return INVALID;`);
	let o = i ? q(t) : null, s = q(t), c = q(t);
	return o && e.write(`const ${o} = new Array(${r}.length);`), e.write(`for (let ${s} = 0; ${s} < ${r}.length; ${s}++) {`), e.indented((e) => {
		e.write(`const ${c} = ${r}[${s}];`);
		let n = Ik(e, t, a.element, c, i);
		o && n !== null && e.write(`${o}[${s}] = ${n};`);
	}), e.write("}"), o;
}
function xA(e, t, n, r) {
	let i = n._zod.def.values;
	if (i.length !== 1) {
		let n = K(t, new Set(i));
		return e.write(`if (!${n}.has(${r})) return INVALID;`), r;
	}
	let a = i[0];
	if (typeof a == "number" && Number.isNaN(a)) {
		let n = K(t, new Set(i));
		return e.write(`if (!${n}.has(${r})) return INVALID;`), r;
	}
	if (typeof a == "string") e.write(`if (${r} !== ${Xb(a)}) return INVALID;`);
	else if (typeof a == "number" || typeof a == "boolean") e.write(`if (${r} !== ${a}) return INVALID;`);
	else if (a === null) e.write(`if (${r} !== null) return INVALID;`);
	else if (a === void 0) e.write(`if (${r} !== undefined) return INVALID;`);
	else if (typeof a == "bigint") e.write(`if (${r} !== ${a}n) return INVALID;`);
	else throw new G(`literal type ${typeof a}`);
	return r;
}
function SA(e, t, n, r) {
	let i = n._zod.values;
	if (!i) throw new G("enum schema without enumerated values");
	let a = K(t, i);
	return e.write(`if (!${a}.has(${r})) return INVALID;`), r;
}
function CA(e, t, n, r) {
	let i = n._zod.def;
	return J(e, t, i.innerType, r);
}
function wA(e, t, n, r) {
	let i = n._zod.def, a = Object.getOwnPropertyDescriptor(n._zod.def, "defaultValue") ? () => n._zod.def.defaultValue : void 0;
	if (n._zod.def.type === "prefault") {
		if (!a) return J(e, t, i.innerType, r);
		let n = K(t, a), o = q(t);
		return e.write(`let ${o} = ${r};`), e.write(`if (${r} === undefined) ${o} = ${n}();`), J(e, t, i.innerType, o);
	}
	let o = q(t);
	if (a) {
		let n = K(t, a), s = K(t, nx);
		e.write(`let ${o};`), e.write(`if (${r} === undefined) {`), e.indented((e) => {
			e.write(`${o} = ${s}(${n}());`);
		}), e.write("} else {"), e.indented((e) => {
			let a = J(e, t, i.innerType, r);
			e.write(`${o} = ${a} === undefined ? ${s}(${n}()) : ${a};`);
		}), e.write("}");
	} else e.write(`let ${o};`), e.write(`if (${r} !== undefined) {`), e.indented((e) => {
		let n = J(e, t, i.innerType, r);
		e.write(`${o} = ${n};`);
	}), e.write("}");
	return o;
}
function TA(e, t, n, r) {
	let i = n._zod.def, a = J(e, t, i.innerType, r), o = q(t);
	return e.write(`const ${o} = ${a};`), e.write(`if (${o} === undefined) return INVALID;`), o;
}
function EA(e, t, n, r) {
	let i = n._zod.def, a = i.items, o = i.rest;
	e.write(`if (!Array.isArray(${r})) return INVALID;`);
	let s = DA(a, "optin"), c = DA(a, "optout");
	o ? e.write(`if (${r}.length < ${s}) return INVALID;`) : e.write(`if (${r}.length < ${s} || ${r}.length > ${a.length}) return INVALID;`);
	let l = q(t);
	e.write(`const ${l} = [];`);
	for (let n = 0; n < a.length; n++) {
		let i = a[n];
		if (n >= c) e.write(`if (${l}.length === ${n}) {`), e.indented((e) => {
			e.write(`if (${n} < ${r}.length) {`), e.indented((e) => {
				let a = q(t);
				e.write(`const ${a} = ${r}[${n}];`);
				let o = Ik(e, t, i, a);
				e.write(`${l}[${n}] = ${o};`);
			}), e.write("} else {"), e.indented((e) => {
				if (_A(i)) {
					e.write(`${l}.length = ${n};`);
					return;
				}
				let r = q(t), a = q(t);
				e.write(`const ${r} = undefined;`), e.write(`const ${a} = (() => {`), e.indented((e) => {
					let n = Ik(e, t, i, r);
					e.write(`return ${n};`);
				}), e.write("})();"), e.write(`if (${a} === INVALID || ${a} === undefined) ${l}.length = ${n};`), e.write(`else ${l}[${n}] = ${a};`);
			}), e.write("}");
		}), e.write("}");
		else {
			let a = q(t);
			e.write(`const ${a} = ${r}[${n}];`);
			let o = Ik(e, t, i, a);
			e.write(`${l}[${n}] = ${o};`);
		}
	}
	if (o) {
		let n = q(t), i = q(t);
		e.write(`for (let ${n} = ${a.length}; ${n} < ${r}.length; ${n}++) {`), e.indented((e) => {
			e.write(`const ${i} = ${r}[${n}];`);
			let a = Ik(e, t, o, i);
			e.write(`${l}[${n}] = ${a};`);
		}), e.write("}");
	}
	return l;
}
function DA(e, t) {
	for (let n = e.length - 1; n >= 0; n--) if (!(t === "optin" ? e[n]._zod.optin !== void 0 : e[n]._zod.optout === "optional")) return n + 1;
	return 0;
}
function OA(e, t, n, r) {
	let i = n._zod.def, a = i.options;
	if (i.discriminator) return kA(e, t, i, r);
	if (i.inclusive === !1) throw new G("exclusive unions (z.xor)");
	if (a.length === 0) return e.write("return INVALID;"), r;
	if (a.length === 1) return J(e, t, a[0], r);
	if (a.every((e) => e._zod.def.type === "literal" && !e._zod.def.checks?.length)) {
		let n = K(t, new Set(a.flatMap((e) => e._zod.def.values)));
		return e.write(`if (!${n}.has(${r})) return INVALID;`), r;
	}
	let o = q(t);
	e.write(`let ${o};`);
	for (let n = 0; n < a.length; n++) {
		let i = a[n];
		n === 0 ? e.write(`${o} = (() => {`) : e.write(`if (${o} === INVALID) ${o} = (() => {`), e.indented((e) => {
			let n = J(e, t, i, r);
			e.write(`return ${n};`);
		}), e.write("})();");
	}
	return e.write(`if (${o} === INVALID) return INVALID;`), o;
}
function kA(e, t, n, r) {
	if (n.unionFallback) throw new G("discriminated union with unionFallback");
	if (n.options.length === 0) return e.write("return INVALID;"), r;
	let i = q(t), a = q(t);
	e.write(`const ${i} = ${r}?.[${Xb(n.discriminator)}];`), e.write(`let ${a};`);
	let o = !0, s = /* @__PURE__ */ new Set();
	for (let c of n.options) {
		let l = c._zod.propValues?.[n.discriminator];
		if (!l || l.size === 0) throw new G("discriminated union option without static discriminator values");
		for (let e of l) {
			if (s.has(e)) throw new G(`duplicate discriminator value ${String(e)}`);
			s.add(e);
		}
		let u = Array.from(l, (e) => AA(t, i, e)), d = o ? "if" : "else if";
		e.write(`${d} (${u.join(" || ")}) {`), e.indented((e) => {
			let n = J(e, t, c, r);
			e.write(`${a} = ${n};`);
		}), e.write("}"), o = !1;
	}
	return e.write("else { return INVALID; }"), a;
}
function AA(e, t, n) {
	if (typeof n == "string") return `${t} === ${Xb(n)}`;
	if (typeof n == "number") return Number.isNaN(n) ? `Number.isNaN(${t})` : `${t} === ${n}`;
	if (typeof n == "boolean") return `${t} === ${n}`;
	if (n === null) return `${t} === null`;
	if (n === void 0) return `${t} === undefined`;
	if (typeof n == "bigint") return `${t} === ${n}n`;
	if (typeof n == "symbol") return `${t} === ${K(e, n)}`;
	throw new G(`literal discriminator value ${String(n)}`);
}
function jA(e, t, n, r) {
	let i = n._zod.def, a = Ik(e, t, i.left, r), o = Ik(e, t, i.right, r), s = K(t, eE), c = q(t);
	return e.write(`const ${c} = ${s}(${a}, ${o});`), e.write(`if (!${c}.valid) return INVALID;`), `${c}.data`;
}
function MA(e, t, n, r) {
	let i = n._zod.def, a = K(t, tx);
	e.write(`if (!${a}(${r})) return INVALID;`);
	let o = q(t), s = q(t), c = q(t);
	e.write(`const ${o} = {};`);
	let l = i, u = l.partial ? void 0 : i.keyType._zod.values;
	if (u) {
		let n = [];
		for (let a of u) {
			if (typeof a != "string" && typeof a != "number" && typeof a != "symbol") throw new G(`record key value ${String(a)}`);
			let s = typeof a == "number" ? a.toString() : a;
			if (s === "__proto__") throw new G("record key \"__proto__\"");
			n.push(s);
			let c = K(t, a), l = J(e, t, i.keyType, c), u = q(t);
			e.write(`const ${u} = ${r}[${NA(t, s)}];`);
			let d = Ik(e, t, i.valueType, u);
			e.write(`${o}[${l}] = ${d};`);
		}
		let a = K(t, new Set(n));
		return e.write(`for (const ${s} in ${r}) {`), e.indented((e) => {
			e.write(`if (${a}.has(${s})) continue;`), l.mode === "loose" ? e.write(`if (${s} !== "__proto__") ${o}[${s}] = ${r}[${s}];`) : e.write("return INVALID;");
		}), e.write("}"), o;
	}
	let d = i.keyType._zod.def;
	if (!(d.type === "string" && d.format === void 0 && !d.coerce && (d.checks?.length ?? 0) === 0)) {
		let n = i.mode === "loose", a = K(t, Pk(i.keyType)), c = K(t, zC), l = K(t, Object.prototype.propertyIsEnumerable), u = q(t);
		return e.write(`for (const ${s} of Reflect.ownKeys(${r})) {`), e.indented((e) => {
			e.write(`if (${s} === "__proto__") continue;`), e.write(`if (!${l}.call(${r}, ${s})) continue;`), e.write(`let ${u} = ${a}(${s});`), e.write(`if (${u} === INVALID && typeof ${s} === "string" && ${c}.test(${s})) ${u} = ${a}(Number(${s}));`), n ? e.write(`if (${u} === INVALID) { ${o}[${s}] = ${r}[${s}]; continue; }`) : e.write(`if (${u} === INVALID) return INVALID;`), e.write(`if (${u} === "__proto__") continue;`);
			let d = q(t);
			e.write(`const ${d} = ${r}[${s}];`);
			let f = Ik(e, t, i.valueType, d);
			e.write(`${o}[${u}] = ${f};`);
		}), e.write("}"), o;
	}
	let f = K(t, Object.prototype.propertyIsEnumerable);
	return e.write(`for (const ${s} of Reflect.ownKeys(${r})) {`), e.indented((e) => {
		e.write(`if (${s} === "__proto__") continue;`), e.write(`if (!${f}.call(${r}, ${s})) continue;`), e.write(`if (typeof ${s} !== "string") return INVALID;`), e.write(`const ${c} = ${r}[${s}];`);
		let n = Ik(e, t, i.valueType, c);
		e.write(`${o}[${s}] = ${n};`);
	}), e.write("}"), o;
}
function NA(e, t) {
	return typeof t == "string" ? Xb(t) : K(e, t);
}
function PA(e, t, n, r) {
	let i = n._zod.def;
	e.write(`if (!(${r} instanceof Map)) return INVALID;`);
	let a = q(t), o = q(t), s = q(t);
	return e.write(`const ${a} = new Map();`), e.write(`for (const [${o}, ${s}] of ${r}) {`), e.indented((e) => {
		let n = J(e, t, i.keyType, o), r = J(e, t, i.valueType, s);
		e.write(`${a}.set(${n}, ${r});`);
	}), e.write("}"), a;
}
function FA(e, t, n, r) {
	let i = n._zod.def;
	e.write(`if (!(${r} instanceof Set)) return INVALID;`);
	let a = q(t), o = q(t);
	return e.write(`const ${a} = new Set();`), e.write(`for (const ${o} of ${r}) {`), e.indented((e) => {
		let n = J(e, t, i.valueType, o);
		e.write(`${a}.add(${n});`);
	}), e.write("}"), a;
}
function IA(e, t) {
	return e.write(`if (!(${t} instanceof File)) return INVALID;`), t;
}
function LA(e, t, n, r) {
	e.write(`if (typeof ${r} !== "string") return INVALID;`);
	let i = n._zod.pattern;
	if (i) {
		let n = K(t, i);
		e.write(`${n}.lastIndex = 0;`), e.write(`if (!${n}.test(${r})) return INVALID;`);
	}
	return r;
}
function RA(e, t, n, r) {
	let i = n._zod.def, a = K(t, i.getter), o = K(t, { parser: null });
	e.write(`if (!${o}.parser) {`), e.indented((e) => {
		e.write(`const inner = ${a}();`), e.write(`${o}.parser = function(input) {`), e.indented((e) => {
			e.write("const result = inner._zod.run({ value: input, issues: [] }, {});"), e.write("return result.issues.length === 0 ? result.value : INVALID;");
		}), e.write("};");
	}), e.write("}");
	let s = q(t);
	return e.write(`const ${s} = ${o}.parser(${r});`), e.write(`if (${s} === INVALID) return INVALID;`), s;
}
function zA(e, t, n, r) {
	let i = n._zod.def, a = J(e, t, i.in, r);
	if (i.transform) {
		if (BA(i.transform)) throw new Ak("z.compile: async transforms in pipes are not supported");
		let n = i.transform, r = K(t, (e) => {
			let t = {
				value: e,
				issues: [],
				addIssue: Qk
			}, r = n(e, t);
			return r instanceof Promise ? Ok : t.issues.length === 0 ? r : Ok;
		}), o = q(t);
		return e.write(`const ${o} = ${r}(${a});`), e.write(`if (${o} === INVALID) return INVALID;`), J(e, t, i.out, o);
	}
	return J(e, t, i.out, a);
}
function BA(e) {
	return typeof e == "function" && (e.constructor.name === "AsyncFunction" || e[Symbol.toStringTag] === "AsyncFunction");
}
function VA(e, t, n, r) {
	let i = n._zod.def;
	if (i.fn) {
		if (BA(i.fn)) throw new Ak("z.compile: async custom predicates are not supported");
		let n = K(t, i.fn), a = K(t, Zk), o = q(t);
		e.write(`const ${o} = ${n}(${r});`), e.write(`if (${o} instanceof Promise) ${a}();`), e.write(`if (!${o}) return INVALID;`);
	} else throw new G("custom schema without a predicate function");
	return r;
}
function HA(e, t, n) {
	let r = e._zod.run({
		value: n,
		issues: []
	}, {});
	if (r && typeof r.then == "function") return Ok;
	let i = r;
	return i.issues.length === 0 ? i.value : t();
}
function UA(e, t, n, r) {
	let i = n._zod.def;
	if (!i.catchValue["~constantCatch"]) throw new G("catch with a callback (only a constant catch value compiles)", !1);
	let a = q(t);
	e.write(`let ${a} = (() => {`), e.indented((e) => {
		let n = Ik(e, t, i.innerType, r);
		e.write(`return ${n};`);
	}), e.write("})();");
	let o = K(t, i.innerType), s = K(t, i.catchValue), c = K(t, HA);
	return e.write(`if (${a} === INVALID) {`), e.indented((e) => {
		e.write(`${a} = ${c}(${o}, ${s}, ${r});`), e.write(`if (${a} === INVALID) return INVALID;`);
	}), e.write("}"), a;
}
function WA(e, t, n, r) {
	let i = n._zod.def;
	if (i.transform) {
		if (BA(i.transform)) throw new Ak("z.compile: async transforms are not supported");
		let n = i.transform, a = K(t, (e) => {
			let t = {
				value: e,
				issues: [],
				addIssue: Qk
			}, r = n(e, t);
			return r instanceof Promise ? Ok : t.issues.length === 0 ? r : Ok;
		}), o = q(t);
		return e.write(`const ${o} = ${a}(${r});`), e.write(`if (${o} === INVALID) return INVALID;`), o;
	}
	return r;
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function GA(e, t) {
	return new e({
		type: "string",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function KA(e, t) {
	return new e({
		type: "string",
		coerce: !0,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function qA(e, t) {
	return new e({
		type: "string",
		format: "email",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function JA(e, t) {
	return new e({
		type: "string",
		format: "guid",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function YA(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function XA(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		version: "v4",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ZA(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		version: "v6",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function QA(e, t) {
	return new e({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: !1,
		version: "v7",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function $A(e, t) {
	return new e({
		type: "string",
		format: "url",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ej(e, t) {
	return new e({
		type: "string",
		format: "emoji",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function tj(e, t) {
	return new e({
		type: "string",
		format: "nanoid",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function nj(e, t) {
	return new e({
		type: "string",
		format: "cuid",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function rj(e, t) {
	return new e({
		type: "string",
		format: "cuid2",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function ij(e, t) {
	return new e({
		type: "string",
		format: "ulid",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function aj(e, t) {
	return new e({
		type: "string",
		format: "xid",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function oj(e, t) {
	return new e({
		type: "string",
		format: "ksuid",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function sj(e, t) {
	return new e({
		type: "string",
		format: "ipv4",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function cj(e, t) {
	return new e({
		type: "string",
		format: "ipv6",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function lj(e, t) {
	return new e({
		type: "string",
		format: "mac",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function uj(e, t) {
	return new e({
		type: "string",
		format: "cidrv4",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function dj(e, t) {
	return new e({
		type: "string",
		format: "cidrv6",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function fj(e, t) {
	return new e({
		type: "string",
		format: "base64",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function pj(e, t) {
	return new e({
		type: "string",
		format: "base64url",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function mj(e, t) {
	return new e({
		type: "string",
		format: "e164",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function hj(e, t) {
	return new e({
		type: "string",
		format: "credit_card",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function gj(e, t) {
	return new e({
		type: "string",
		format: "jwt",
		check: "string_format",
		abort: !1,
		...I(t)
	});
}
var _j = {
	Any: null,
	Minute: -1,
	Second: 0,
	Millisecond: 3,
	Microsecond: 6
};
// @__NO_SIDE_EFFECTS__
function vj(e, t) {
	return new e({
		type: "string",
		format: "datetime",
		check: "string_format",
		offset: !1,
		local: !1,
		precision: null,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function yj(e, t) {
	return new e({
		type: "string",
		format: "date",
		check: "string_format",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function bj(e, t) {
	return new e({
		type: "string",
		format: "time",
		check: "string_format",
		precision: null,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function xj(e, t) {
	return new e({
		type: "string",
		format: "duration",
		check: "string_format",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Sj(e, t) {
	return new e({
		type: "number",
		checks: [],
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Cj(e, t) {
	return new e({
		type: "number",
		coerce: !0,
		checks: [],
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function wj(e, t) {
	return new e({
		type: "number",
		check: "number_format",
		abort: !1,
		format: "safeint",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Tj(e, t) {
	return new e({
		type: "number",
		check: "number_format",
		abort: !1,
		format: "float32",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ej(e, t) {
	return new e({
		type: "number",
		check: "number_format",
		abort: !1,
		format: "float64",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Dj(e, t) {
	return new e({
		type: "number",
		check: "number_format",
		abort: !1,
		format: "int32",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Oj(e, t) {
	return new e({
		type: "number",
		check: "number_format",
		abort: !1,
		format: "uint32",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function kj(e, t) {
	return new e({
		type: "boolean",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Aj(e, t) {
	return new e({
		type: "boolean",
		coerce: !0,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function jj(e, t) {
	return new e({
		type: "bigint",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Mj(e, t) {
	return new e({
		type: "bigint",
		coerce: !0,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Nj(e, t) {
	return new e({
		type: "bigint",
		check: "bigint_format",
		abort: !1,
		format: "int64",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Pj(e, t) {
	return new e({
		type: "bigint",
		check: "bigint_format",
		abort: !1,
		format: "uint64",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Fj(e, t) {
	return new e({
		type: "symbol",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Ij(e, t) {
	return new e({
		type: "undefined",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Lj(e, t) {
	return new e({
		type: "null",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Rj(e) {
	return new e({ type: "any" });
}
// @__NO_SIDE_EFFECTS__
function zj(e) {
	return new e({ type: "unknown" });
}
// @__NO_SIDE_EFFECTS__
function Bj(e, t) {
	return new e({
		type: "never",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Vj(e, t) {
	return new e({
		type: "void",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Hj(e, t) {
	return new e({
		type: "date",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Uj(e, t) {
	return new e({
		type: "date",
		coerce: !0,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Wj(e, t) {
	return new e({
		type: "nan",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function Gj(e, t) {
	return new fw({
		check: "less_than",
		...I(t),
		value: e,
		inclusive: !1
	});
}
// @__NO_SIDE_EFFECTS__
function Kj(e, t) {
	return new fw({
		check: "less_than",
		...I(t),
		value: e,
		inclusive: !0
	});
}
// @__NO_SIDE_EFFECTS__
function qj(e, t) {
	return new pw({
		check: "greater_than",
		...I(t),
		value: e,
		inclusive: !1
	});
}
// @__NO_SIDE_EFFECTS__
function Jj(e, t) {
	return new pw({
		check: "greater_than",
		...I(t),
		value: e,
		inclusive: !0
	});
}
// @__NO_SIDE_EFFECTS__
function Yj(e) {
	return /* @__PURE__ */ qj(0, e);
}
// @__NO_SIDE_EFFECTS__
function Xj(e) {
	return /* @__PURE__ */ Gj(0, e);
}
// @__NO_SIDE_EFFECTS__
function Zj(e) {
	return /* @__PURE__ */ Kj(0, e);
}
// @__NO_SIDE_EFFECTS__
function Qj(e) {
	return /* @__PURE__ */ Jj(0, e);
}
// @__NO_SIDE_EFFECTS__
function $j(e, t) {
	return new mw({
		check: "multiple_of",
		...I(t),
		value: e
	});
}
// @__NO_SIDE_EFFECTS__
function eM(e, t) {
	return new _w({
		check: "max_size",
		...I(t),
		maximum: e
	});
}
// @__NO_SIDE_EFFECTS__
function tM(e, t) {
	return new vw({
		check: "min_size",
		...I(t),
		minimum: e
	});
}
// @__NO_SIDE_EFFECTS__
function nM(e, t) {
	return new yw({
		check: "size_equals",
		...I(t),
		size: e
	});
}
// @__NO_SIDE_EFFECTS__
function rM(e, t) {
	return new bw({
		check: "max_length",
		...I(t),
		maximum: e
	});
}
// @__NO_SIDE_EFFECTS__
function iM(e, t) {
	return new xw({
		check: "min_length",
		...I(t),
		minimum: e
	});
}
// @__NO_SIDE_EFFECTS__
function aM(e, t) {
	return new Sw({
		check: "length_equals",
		...I(t),
		length: e
	});
}
// @__NO_SIDE_EFFECTS__
function oM(e, t) {
	return new ww({
		check: "string_format",
		format: "regex",
		...I(t),
		pattern: e
	});
}
// @__NO_SIDE_EFFECTS__
function sM(e) {
	return new Tw({
		check: "string_format",
		format: "lowercase",
		...I(e)
	});
}
// @__NO_SIDE_EFFECTS__
function cM(e) {
	return new Ew({
		check: "string_format",
		format: "uppercase",
		...I(e)
	});
}
// @__NO_SIDE_EFFECTS__
function lM(e, t) {
	return new Dw({
		check: "string_format",
		format: "includes",
		...I(t),
		includes: e
	});
}
// @__NO_SIDE_EFFECTS__
function uM(e, t) {
	return new Ow({
		check: "string_format",
		format: "starts_with",
		...I(t),
		prefix: e
	});
}
// @__NO_SIDE_EFFECTS__
function dM(e, t) {
	return new kw({
		check: "string_format",
		format: "ends_with",
		...I(t),
		suffix: e
	});
}
// @__NO_SIDE_EFFECTS__
function fM(e, t, n) {
	return new jw({
		check: "property",
		property: e,
		schema: t,
		...I(n)
	});
}
// @__NO_SIDE_EFFECTS__
function pM(e) {
	return Object.entries(e).map(([e, t]) => new jw({
		check: "property",
		property: e,
		schema: t
	}));
}
// @__NO_SIDE_EFFECTS__
function mM(e, t) {
	return new Mw({
		check: "mime_type",
		mime: e,
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function hM(e) {
	return new Nw({
		check: "overwrite",
		tx: e
	});
}
// @__NO_SIDE_EFFECTS__
function gM(e) {
	return /* @__PURE__ */ hM((t) => t.normalize(e));
}
// @__NO_SIDE_EFFECTS__
function _M() {
	return /* @__PURE__ */ hM((e) => e.trim());
}
// @__NO_SIDE_EFFECTS__
function vM() {
	return /* @__PURE__ */ hM((e) => e.toLowerCase());
}
// @__NO_SIDE_EFFECTS__
function yM() {
	return /* @__PURE__ */ hM((e) => e.toUpperCase());
}
// @__NO_SIDE_EFFECTS__
function bM() {
	return /* @__PURE__ */ hM((e) => Zb(e));
}
// @__NO_SIDE_EFFECTS__
function xM(e, t, n) {
	return new e({
		type: "array",
		element: t,
		...I(n)
	});
}
// @__NO_SIDE_EFFECTS__
function SM(e, t, n) {
	return new e({
		type: "union",
		options: t,
		...I(n)
	});
}
function CM(e, t, n) {
	return new e({
		type: "union",
		options: t,
		inclusive: !1,
		...I(n)
	});
}
// @__NO_SIDE_EFFECTS__
function wM(e, t, n, r) {
	return new e({
		type: "union",
		options: n,
		discriminator: t,
		...I(r)
	});
}
// @__NO_SIDE_EFFECTS__
function TM(e, t, n) {
	return new e({
		type: "intersection",
		left: t,
		right: n
	});
}
// @__NO_SIDE_EFFECTS__
function EM(e, t, n, r) {
	let i = n instanceof U;
	return new e({
		type: "tuple",
		items: t,
		rest: i ? n : null,
		...I(i ? r : n)
	});
}
// @__NO_SIDE_EFFECTS__
function DM(e, t, n, r) {
	return new e({
		type: "record",
		keyType: t,
		valueType: n,
		...I(r)
	});
}
// @__NO_SIDE_EFFECTS__
function OM(e, t, n, r) {
	return new e({
		type: "map",
		keyType: t,
		valueType: n,
		...I(r)
	});
}
// @__NO_SIDE_EFFECTS__
function kM(e, t, n) {
	return new e({
		type: "set",
		valueType: t,
		...I(n)
	});
}
// @__NO_SIDE_EFFECTS__
function AM(e, t, n) {
	return new e({
		type: "enum",
		entries: Array.isArray(t) ? Object.fromEntries(t.map((e) => [e, e])) : t,
		...I(n)
	});
}
// @__NO_SIDE_EFFECTS__
function jM(e, t, n) {
	return new e({
		type: "enum",
		entries: t,
		...I(n)
	});
}
// @__NO_SIDE_EFFECTS__
function MM(e, t, n) {
	return new e({
		type: "literal",
		values: Array.isArray(t) ? t : [t],
		...I(n)
	});
}
// @__NO_SIDE_EFFECTS__
function NM(e, t) {
	return new e({
		type: "file",
		...I(t)
	});
}
// @__NO_SIDE_EFFECTS__
function PM(e, t) {
	return new e({
		type: "transform",
		transform: t
	});
}
// @__NO_SIDE_EFFECTS__
function FM(e, t) {
	return new e({
		type: "optional",
		innerType: t
	});
}
// @__NO_SIDE_EFFECTS__
function IM(e, t) {
	return new e({
		type: "nullable",
		innerType: t
	});
}
// @__NO_SIDE_EFFECTS__
function LM(e, t, n) {
	return new e({
		type: "default",
		innerType: t,
		get defaultValue() {
			return typeof n == "function" ? n() : nx(n);
		}
	});
}
// @__NO_SIDE_EFFECTS__
function RM(e, t, n) {
	return new e({
		type: "nonoptional",
		innerType: t,
		...I(n)
	});
}
// @__NO_SIDE_EFFECTS__
function zM(e, t) {
	return new e({
		type: "success",
		innerType: t
	});
}
// @__NO_SIDE_EFFECTS__
function BM(e, t, n) {
	return new e({
		type: "catch",
		innerType: t,
		catchValue: typeof n == "function" ? n : Jx(n)
	});
}
// @__NO_SIDE_EFFECTS__
function VM(e, t, n) {
	return new e({
		type: "pipe",
		in: t,
		out: n
	});
}
// @__NO_SIDE_EFFECTS__
function HM(e, t) {
	return new e({
		type: "readonly",
		innerType: t
	});
}
// @__NO_SIDE_EFFECTS__
function UM(e, t, n) {
	return new e({
		type: "template_literal",
		parts: t,
		...I(n)
	});
}
// @__NO_SIDE_EFFECTS__
function WM(e, t) {
	return new e({
		type: "lazy",
		getter: t
	});
}
// @__NO_SIDE_EFFECTS__
function GM(e, t) {
	return new e({
		type: "promise",
		innerType: t
	});
}
// @__NO_SIDE_EFFECTS__
function KM(e, t, n) {
	let r = I(n);
	return r.abort ??= !0, new e({
		type: "custom",
		check: "custom",
		fn: t,
		...r
	});
}
// @__NO_SIDE_EFFECTS__
function qM(e, t, n) {
	return new e({
		type: "custom",
		check: "custom",
		fn: t,
		...I(n)
	});
}
// @__NO_SIDE_EFFECTS__
function JM(e, t) {
	let n = /* @__PURE__ */ YM((t) => (t.addIssue = (e) => {
		if (typeof e == "string") t.issues.push(kx(e, t.value, n._zod.def));
		else {
			let r = e;
			r.fatal && (r.continue = !1), r.code ??= "custom", "input" in r || (r.input = t.value), r.inst ??= n, r.continue ??= !n._zod.def.abort, t.issues.push(kx(r));
		}
	}, e(t.value, t)), t);
	return n;
}
// @__NO_SIDE_EFFECTS__
function YM(e, t) {
	let n = new H({
		check: "custom",
		...I(t)
	});
	return n._zod.check = e, n;
}
// @__NO_SIDE_EFFECTS__
function XM(e) {
	let t = new H({ check: "describe" });
	return t._zod.onattach = [(t) => {
		let n = Dk.get(t) ?? {};
		Dk.add(t, {
			...n,
			description: e
		});
	}], t._zod.check = () => {}, t;
}
// @__NO_SIDE_EFFECTS__
function ZM(e) {
	let t = new H({ check: "meta" });
	return t._zod.onattach = [(t) => {
		let n = Dk.get(t) ?? {};
		Dk.add(t, {
			...n,
			...e
		});
	}], t._zod.check = () => {}, t;
}
// @__NO_SIDE_EFFECTS__
function QM(e, t) {
	let n = I(t), r = n.truthy ?? [
		"true",
		"1",
		"yes",
		"on",
		"y",
		"enabled"
	], i = n.falsy ?? [
		"false",
		"0",
		"no",
		"off",
		"n",
		"disabled"
	];
	n.case !== "sensitive" && (r = r.map((e) => typeof e == "string" ? e.toLowerCase() : e), i = i.map((e) => typeof e == "string" ? e.toLowerCase() : e));
	let a = new Set(r), o = new Set(i), s = e.Codec ?? AE, c = e.Boolean ?? DT, l = new s({
		type: "pipe",
		in: new (e.String ?? Rw)({
			type: "string",
			error: n.error
		}),
		out: new c({
			type: "boolean",
			error: n.error
		}),
		transform: ((e, t) => {
			let r = e;
			return n.case !== "sensitive" && (r = r.toLowerCase()), a.has(r) ? !0 : !o.has(r) && (t.issues.push({
				code: "invalid_value",
				expected: "stringbool",
				values: [...a, ...o],
				input: t.value,
				inst: l,
				continue: !1
			}), {});
		}),
		reverseTransform: ((e, t) => e === !0 ? r[0] || "true" : i[0] || "false"),
		error: n.error
	});
	return l._zod.bag.truthy = r, l._zod.bag.falsy = i, l._zod.bag.case = n.case ?? "insensitive", l;
}
// @__NO_SIDE_EFFECTS__
function $M(e, t, n, r = {}) {
	let i = I(r), a = {
		check: "string_format",
		type: "string",
		format: t,
		fn: typeof n == "function" ? n : (e) => n.test(e),
		...i
	};
	return n instanceof RegExp && (a.pattern = n), new e(a);
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/to-json-schema.js
function eN(e, ...t) {
	for (let n of t) for (let t of Reflect.ownKeys(n)) Object.prototype.propertyIsEnumerable.call(n, t) && P(e, t, n[t]);
	return e;
}
function tN(e) {
	let t = e?.target ?? "draft-2020-12";
	return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
		processors: e.processors ?? {},
		metadataRegistry: e?.metadata ?? Dk,
		target: t,
		unrepresentable: e?.unrepresentable ?? "throw",
		override: e?.override ?? (() => {}),
		io: e?.io ?? "output",
		counter: 0,
		seen: /* @__PURE__ */ new Map(),
		sharedDefsExtractedFor: void 0,
		sharedEmitDoneFor: void 0,
		cycles: e?.cycles ?? "ref",
		reused: e?.reused ?? "inline",
		intersections: [],
		deferred: [],
		external: e?.external ?? void 0
	};
}
function Y(e, t, n, r, i) {
	let a = typeof t.unrepresentable == "function" ? t.unrepresentable({
		zodSchema: e,
		path: r.path,
		message: i
	}) : t.unrepresentable;
	if (a === "any") return !1;
	if (a === void 0 || a === "throw") throw Error(i);
	return Object.assign(n, a), !0;
}
function X(e, t, n = {
	path: [],
	schemaPath: []
}) {
	var r;
	let i = e._zod.def, a = t.seen.get(e);
	if (a) return a.count++, n.schemaPath.includes(e) && (a.cycle = n.path), a.schema;
	let o = {
		schema: {},
		count: 1,
		cycle: void 0,
		path: n.path
	};
	t.seen.set(e, o), t.sharedDefsExtractedFor = void 0, t.sharedEmitDoneFor = void 0;
	let s = e._zod.toJSONSchema?.();
	if (s) o.schema = s;
	else {
		let r = {
			...n,
			schemaPath: [...n.schemaPath, e],
			path: n.path
		};
		if (e._zod.processJSONSchema) e._zod.processJSONSchema(t, o.schema, r);
		else {
			let n = o.schema, a = t.processors[i.type];
			if (!a) throw Error(`[toJSONSchema]: Non-representable type encountered: ${i.type}`);
			a(e, t, n, r);
		}
		let a = e._zod.parent;
		a && (o.ref ||= a, X(a, t, r), t.seen.get(a).isParent = !0);
	}
	let c = t.metadataRegistry.get(e);
	return c && eN(o.schema, c), t.io === "input" && dN(e) && (delete o.schema.examples, delete o.schema.default), t.io === "input" && "_prefault" in o.schema && ((r = o.schema).default ?? (r.default = o.schema._prefault)), delete o.schema._prefault, t.seen.get(e).schema;
}
function nN(e) {
	return e.replace(/~/g, "~0").replace(/\//g, "~1");
}
function rN(e, t) {
	let n = e.seen.get(t);
	if (!n) throw Error("Unprocessed schema. This is a bug in Zod.");
	if (e.external && e.sharedDefsExtractedFor === e.external) return;
	let r = /* @__PURE__ */ new Map();
	for (let t of e.seen.entries()) {
		let n = e.metadataRegistry.get(t[0])?.id;
		if (n) {
			let e = r.get(n);
			if (e && e !== t[0]) throw Error(`Duplicate schema id "${n}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
			r.set(n, t[0]);
		}
	}
	let i = (t) => {
		let r = e.target === "draft-2020-12" ? "$defs" : "definitions";
		if (e.external) {
			let n = e.external.registry.get(t[0])?.id, i = e.external.uri ?? ((e) => e);
			if (n) return { ref: i(n) };
			let a = t[1].defId ?? t[1].schema.id ?? `schema${e.counter++}`;
			return t[1].defId = a, {
				defId: a,
				ref: `${i("__shared")}#/${r}/${nN(a)}`
			};
		}
		let i = `#/${r}/`;
		if (t[1] === n && !t[1].schema.id) return { ref: "#" };
		let a = t[1].schema.id ?? `__schema${e.counter++}`;
		return {
			defId: a,
			ref: i + nN(a)
		};
	}, a = (e) => {
		if (e[1].schema.$ref) return;
		let t = e[1], { ref: n, defId: r } = i(e);
		t.def = { ...t.schema }, r && (t.defId = r);
		let a = t.schema;
		for (let e in a) delete a[e];
		a.$ref = n;
	};
	if (e.cycles === "throw") for (let t of e.seen.entries()) {
		let e = t[1];
		if (e.cycle) throw Error(`Cycle detected: #/${e.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
	}
	for (let n of e.seen.entries()) {
		let r = n[1];
		if (t === n[0]) {
			a(n);
			continue;
		}
		if (e.external) {
			let r = e.external.registry.get(n[0])?.id;
			if (t !== n[0] && r) {
				a(n);
				continue;
			}
		}
		if (e.metadataRegistry.get(n[0])?.id) {
			a(n);
			continue;
		}
		if (r.cycle) {
			a(n);
			continue;
		}
		if (r.count > 1 && e.reused === "ref") {
			a(n);
			continue;
		}
	}
	e.external && (e.sharedDefsExtractedFor = e.external);
}
function iN(e) {
	let t = e.anyOf;
	if (!Array.isArray(t) || t.length === 0 || e.type !== void 0) return;
	let n = [];
	for (let e of t) {
		if (!e || typeof e != "object") return;
		iN(e);
		let t = Object.keys(e);
		if (t.length !== 1 || t[0] !== "type") return;
		let r = e.type;
		for (let e of Array.isArray(r) ? r : [r]) {
			if (typeof e != "string") return;
			n.includes(e) || n.push(e);
		}
	}
	delete e.anyOf, e.type = n.length === 1 ? n[0] : n;
}
var aN = /* @__PURE__ */ new Set([
	"type",
	"properties",
	"required",
	"additionalProperties"
]), oN = ["oneOf", "anyOf"];
function sN(e) {
	let t = e.additionalProperties;
	return t === void 0 || t === !1 || typeof t != "object" || !t ? null : Object.keys(t).length ? t : null;
}
function cN(e) {
	let t = [];
	for (let n of e) {
		if (typeof n != "object" || n.type !== "object") return null;
		for (let e in n) if (!aN.has(e)) return null;
		t.push(n);
	}
	let n = {}, r = /* @__PURE__ */ new Set();
	for (let e of t) {
		for (let r in e.properties) {
			if (Object.prototype.hasOwnProperty.call(n, r)) continue;
			let e = [];
			for (let n of t) {
				let t = n.properties?.[r] ?? sN(n);
				t != null && (e.some((e) => JSON.stringify(e) === JSON.stringify(t)) || e.push(t));
			}
			P(n, r, e.length === 1 ? e[0] : cN(e) ?? { allOf: e });
		}
		for (let t of e.required ?? []) r.add(t);
	}
	let i = {
		type: "object",
		properties: n
	};
	if (r.size && (i.required = [...r]), t.every((e) => e.additionalProperties === !1)) i.additionalProperties = !1;
	else {
		let e = [];
		for (let n of t) {
			let t = sN(n);
			t && !e.some((e) => JSON.stringify(e) === JSON.stringify(t)) && e.push(t);
		}
		e.length === 1 ? i.additionalProperties = e[0] : e.length > 1 && (i.additionalProperties = { allOf: e });
	}
	return i;
}
function lN(e) {
	let t = e.allOf;
	if (!Array.isArray(t) || t.length < 2) return;
	for (let t of aN) if (t in e) return;
	let n = t.filter((e) => oN.some((t) => Array.isArray(e[t]))), r = null;
	if (!n.length) r = cN(t);
	else {
		let e = n[0], i = oN.find((t) => Array.isArray(e[t]));
		if (Object.keys(e).length !== 1) return;
		let a = t.filter((t) => t !== e), o = e[i].map((e) => cN([...a, e]));
		if (o.some((e) => !e)) return;
		r = { [i]: o };
	}
	r && (delete e.allOf, eN(e, r));
}
function uN(e, t) {
	let n = e.seen.get(t);
	if (!n) throw Error("Unprocessed schema. This is a bug in Zod.");
	let r = (t) => {
		let n = e.seen.get(t);
		if (n.ref === null) return;
		let i = n.def ?? n.schema, a = { ...i }, o = n.ref;
		if (n.ref = null, o) {
			r(o);
			let n = e.seen.get(o), s = n.schema;
			if (s.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (i.allOf = i.allOf ?? [], i.allOf.push(s)) : eN(i, s), eN(i, a), t._zod.parent === o) for (let e in i) e !== "$ref" && e !== "allOf" && (e in a || delete i[e]);
			if (s.$ref && n.def) for (let e in i) e !== "$ref" && e !== "allOf" && e in n.def && JSON.stringify(i[e]) === JSON.stringify(n.def[e]) && delete i[e];
		}
		let s = t._zod.parent;
		if (s && s !== o) {
			r(s);
			let t = e.seen.get(s);
			if (t?.schema.$ref && (i.$ref = t.schema.$ref, t.def)) for (let e in i) e !== "$ref" && e !== "allOf" && e in t.def && JSON.stringify(i[e]) === JSON.stringify(t.def[e]) && delete i[e];
		}
		e.override({
			zodSchema: t,
			jsonSchema: i,
			path: n.path ?? []
		});
	};
	if (!e.external || e.sharedEmitDoneFor !== e.external) {
		for (let t of [...e.seen.entries()].reverse()) r(t[0]);
		if (e.target !== "openapi-3.0") for (let t of e.seen.entries()) iN(t[1].def ?? t[1].schema);
		for (let t of e.deferred) t();
		if (e.intersections.length) {
			let t = /* @__PURE__ */ new Map();
			for (let n of e.seen.values()) for (let e of [n.schema, n.def]) {
				let n = e?.allOf;
				if (!Array.isArray(n)) continue;
				let r = t.get(n);
				r ? r.push(e) : t.set(n, [e]);
			}
			for (let n of e.intersections) for (let e of t.get(n) ?? []) lN(e);
		}
	}
	let i = {};
	if (e.target === "draft-2020-12" ? i.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? i.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? i.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
		let n = e.external.registry.get(t)?.id;
		if (!n) throw Error("Schema is missing an `id` property");
		i.$id = e.external.uri(n);
	}
	eN(i, n.defId ? n.schema : n.def ?? n.schema);
	let a = e.metadataRegistry.get(t)?.id;
	a !== void 0 && i.id === a && delete i.id;
	let o = e.external?.defs ?? {};
	if (!e.external || e.sharedEmitDoneFor !== e.external) for (let t of e.seen.entries()) {
		let e = t[1];
		e.def && e.defId && (e.def.id === e.defId && delete e.def.id, P(o, e.defId, e.def));
	}
	e.external && (e.sharedEmitDoneFor = e.external), e.external || Object.keys(o).length > 0 && (e.target === "draft-2020-12" ? i.$defs = o : i.definitions = o);
	try {
		let n = JSON.parse(JSON.stringify(i));
		return Object.defineProperty(n, "~standard", {
			value: {
				...t["~standard"],
				jsonSchema: {
					input: pN(t, "input", e.processors),
					output: pN(t, "output", e.processors)
				}
			},
			enumerable: !1,
			writable: !1
		}), n;
	} catch {
		throw Error("Error converting schema to JSON.");
	}
}
function dN(e, t) {
	let n = t ?? { seen: /* @__PURE__ */ new Set() };
	if (n.seen.has(e)) return !1;
	n.seen.add(e);
	let r = e._zod.def;
	if (r.type === "transform") return !0;
	if (r.type === "array") return dN(r.element, n);
	if (r.type === "set") return dN(r.valueType, n);
	if (r.type === "lazy") return dN(r.getter(), n);
	if (r.type === "promise" || r.type === "optional" || r.type === "nonoptional" || r.type === "nullable" || r.type === "readonly" || r.type === "default" || r.type === "prefault" || r.type === "catch") return dN(r.innerType, n);
	if (r.type === "intersection") return dN(r.left, n) || dN(r.right, n);
	if (r.type === "record" || r.type === "map") return dN(r.keyType, n) || dN(r.valueType, n);
	if (r.type === "pipe") return e._zod.traits.has("$ZodCodec") ? !0 : dN(r.in, n) || dN(r.out, n);
	if (r.type === "object") {
		for (let e in r.shape) if (dN(r.shape[e], n)) return !0;
		return !1;
	}
	if (r.type === "union") {
		for (let e of r.options) if (dN(e, n)) return !0;
		return !1;
	}
	if (r.type === "tuple") {
		for (let e of r.items) if (dN(e, n)) return !0;
		return !!(r.rest && dN(r.rest, n));
	}
	return !1;
}
var fN = (e, t = {}) => (n) => {
	let r = tN({
		...n,
		processors: t
	});
	return X(e, r), rN(r, e), uN(r, e);
}, pN = (e, t, n = {}) => (r) => {
	let { libraryOptions: i, target: a } = r ?? {}, o = tN({
		...i ?? {},
		target: a,
		io: t,
		processors: n
	});
	return X(e, o), rN(o, e), uN(o, e);
}, mN = {
	guid: "uuid",
	url: "uri",
	datetime: "date-time",
	json_string: "json-string",
	regex: ""
}, hN = (e, t, n, r) => {
	let i = n;
	i.type = "string";
	let { minimum: a, maximum: o, format: s, patterns: c, contentEncoding: l, laxFormat: u } = e._zod.bag;
	if (typeof a == "number" && (i.minLength = a), typeof o == "number" && (i.maxLength = o), s && (i.format = mN[s] ?? s, i.format === "" && delete i.format, (s === "time" || u) && delete i.format), l && (i.contentEncoding = l), c && c.size > 0) {
		let e = [...c];
		e.length === 1 ? i.pattern = e[0].source : e.length > 1 && (i.allOf = [...e.map((e) => ({
			...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
			pattern: e.source
		}))]);
	}
}, gN = (e, t, n, r) => {
	let i = n, { minimum: a, maximum: o, format: s, multipleOf: c, exclusiveMaximum: l, exclusiveMinimum: u } = e._zod.bag;
	i.type = typeof s == "string" && s.includes("int") ? "integer" : "number";
	let d = typeof u == "number" && u >= (a ?? -Infinity), f = typeof l == "number" && l <= (o ?? Infinity), p = t.target === "draft-04" || t.target === "openapi-3.0";
	d ? p ? (i.minimum = u, i.exclusiveMinimum = !0) : i.exclusiveMinimum = u : typeof a == "number" && (i.minimum = a), f ? p ? (i.maximum = l, i.exclusiveMaximum = !0) : i.exclusiveMaximum = l : typeof o == "number" && (i.maximum = o), typeof c == "number" && (Number.isFinite(c) && c !== 0 ? i.multipleOf = Math.abs(c) : Y(e, t, i, r, `A multipleOf divisor of ${c} cannot be represented in JSON Schema`));
}, _N = (e, t, n, r) => {
	n.type = "boolean";
}, vN = (e, t, n, r) => {
	Y(e, t, n, r, "BigInt cannot be represented in JSON Schema");
}, yN = (e, t, n, r) => {
	Y(e, t, n, r, "Symbols cannot be represented in JSON Schema");
}, bN = (e, t, n, r) => {
	t.target === "openapi-3.0" ? (n.type = "string", n.nullable = !0, n.enum = [null]) : n.type = "null";
}, xN = (e, t, n, r) => {
	Y(e, t, n, r, "Undefined cannot be represented in JSON Schema");
}, SN = (e, t, n, r) => {
	Y(e, t, n, r, "Void cannot be represented in JSON Schema");
}, CN = (e, t, n, r) => {
	n.not = {};
}, wN = (e, t, n, r) => {}, TN = (e, t, n, r) => {}, EN = (e, t, n, r) => {
	Y(e, t, n, r, "Date cannot be represented in JSON Schema");
}, DN = (e, t, n, r) => {
	let i = e._zod.def, a = Ib(i.entries);
	if (a.length === 0) {
		n.not = {};
		return;
	}
	a.every((e) => typeof e == "number") && (n.type = "number"), a.every((e) => typeof e == "string") && (n.type = "string"), n.enum = a;
}, ON = (e, t, n, r) => {
	let i = e._zod.def;
	if (i.values.length === 0) {
		n.not = {};
		return;
	}
	let a = [];
	for (let o of i.values) if (o === void 0) {
		if (Y(e, t, n, r, "Literal `undefined` cannot be represented in JSON Schema")) return;
	} else if (typeof o == "bigint") {
		if (Y(e, t, n, r, "BigInt literals cannot be represented in JSON Schema")) return;
		a.push(Number(o));
	} else a.push(o);
	if (a.length !== 0) {
		if (a.length === 1) {
			let e = a[0];
			n.type = e === null ? "null" : typeof e, t.target === "draft-04" || t.target === "openapi-3.0" ? n.enum = [e] : n.const = e;
		} else a.every((e) => typeof e == "number") && (n.type = "number"), a.every((e) => typeof e == "string") && (n.type = "string"), a.every((e) => typeof e == "boolean") && (n.type = "boolean"), a.every((e) => e === null) && (n.type = "null"), n.enum = a;
	}
}, kN = (e, t, n, r) => {
	Y(e, t, n, r, "NaN cannot be represented in JSON Schema");
}, AN = (e, t, n, r) => {
	let i = n, a = e._zod.pattern;
	if (!a) throw Error("Pattern not found in template literal");
	i.type = "string", i.pattern = a.source;
}, jN = (e, t, n, r) => {
	let i = n, a = {
		type: "string",
		format: "binary",
		contentEncoding: "binary"
	}, { minimum: o, maximum: s, mime: c } = e._zod.bag;
	o !== void 0 && (a.minLength = o), s !== void 0 && (a.maxLength = s), c ? c.length === 1 ? (a.contentMediaType = c[0], Object.assign(i, a)) : (Object.assign(i, a), i.anyOf = c.map((e) => ({ contentMediaType: e }))) : Object.assign(i, a);
}, MN = (e, t, n, r) => {
	n.type = "boolean";
}, NN = (e, t, n, r) => {
	Y(e, t, n, r, "Custom types cannot be represented in JSON Schema");
}, PN = (e, t, n, r) => {
	Y(e, t, n, r, "Function types cannot be represented in JSON Schema");
}, FN = (e, t, n, r) => {
	Y(e, t, n, r, "Transforms cannot be represented in JSON Schema");
}, IN = (e, t, n, r) => {
	Y(e, t, n, r, "Map cannot be represented in JSON Schema");
}, LN = (e, t, n, r) => {
	Y(e, t, n, r, "Set cannot be represented in JSON Schema");
}, RN = (e, t, n, r) => {
	let i = n, a = e._zod.def, { minimum: o, maximum: s } = e._zod.bag;
	typeof o == "number" && (i.minItems = o), typeof s == "number" && (i.maxItems = s), i.type = "array", i.items = X(a.element, t, {
		...r,
		path: [...r.path, "items"]
	});
};
function zN(e) {
	let t = e._zod.def;
	return t.type === "pipe" && t.in._zod.traits.has("$ZodTransform") ? zN(t.out) : t.type === "catch" ? zN(t.innerType) : e._zod.optin;
}
var BN = (e, t, n, r) => {
	let i = n, a = e._zod.def, o = a.shape;
	if (Object.getOwnPropertySymbols(o).length && Y(e, t, i, r, "Symbol keys cannot be represented in JSON Schema")) return;
	i.type = "object", i.properties = {};
	for (let e in o) P(i.properties, e, X(o[e], t, {
		...r,
		path: [
			...r.path,
			"properties",
			e
		]
	}));
	let s = new Set(Object.keys(o)), c = new Set([...s].filter((e) => {
		let n = a.shape[e];
		return t.io === "input" ? zN(n) === void 0 : n._zod.optout === void 0;
	}));
	c.size > 0 && (i.required = Array.from(c)), a.catchall?._zod.def.type === "never" ? i.additionalProperties = !1 : a.catchall ? a.catchall && (i.additionalProperties = X(a.catchall, t, {
		...r,
		path: [...r.path, "additionalProperties"]
	})) : t.io === "output" && (i.additionalProperties = !1);
}, VN = (e, t, n, r) => {
	let i = e._zod.def, a = i.inclusive === !1, o = i.options.map((e, n) => X(e, t, {
		...r,
		path: [
			...r.path,
			a ? "oneOf" : "anyOf",
			n
		]
	}));
	a ? n.oneOf = o : n.anyOf = o;
}, HN = (e, t, n, r) => {
	let i = e._zod.def, a = X(i.left, t, {
		...r,
		path: [
			...r.path,
			"allOf",
			0
		]
	}), o = X(i.right, t, {
		...r,
		path: [
			...r.path,
			"allOf",
			1
		]
	}), s = (e) => "allOf" in e && Object.keys(e).length === 1, c = [...s(a) ? a.allOf : [a], ...s(o) ? o.allOf : [o]];
	n.allOf = c, t.intersections.push(c);
}, UN = (e, t, n, r) => {
	let i = n, a = e._zod.def;
	i.type = "array";
	let o = t.target === "draft-2020-12" ? "prefixItems" : "items", s = t.target === "draft-2020-12" || t.target === "openapi-3.0" ? "items" : "additionalItems", c = a.items.map((e, n) => X(e, t, {
		...r,
		path: [
			...r.path,
			o,
			n
		]
	})), l = a.rest ? X(a.rest, t, {
		...r,
		path: [
			...r.path,
			s,
			...t.target === "openapi-3.0" ? [a.items.length] : []
		]
	}) : null, u = a.items.length;
	for (; u > 0;) {
		let e = a.items[u - 1];
		if (!(t.io === "input" ? zN(e) !== void 0 : e._zod.optout === "optional")) break;
		u--;
	}
	let d = a.items.length, f = !a.rest;
	t.target === "draft-2020-12" ? (i.prefixItems = c, f ? i.items = !1 : l && (i.items = l), u > 0 && (i.minItems = u), f && (i.maxItems = d)) : t.target === "openapi-3.0" ? (i.items = { anyOf: c }, l && i.items.anyOf.push(l), u > 0 && (i.minItems = u), f && (i.maxItems = d)) : (i.items = c, f ? i.additionalItems = !1 : l && (i.additionalItems = l), u > 0 && (i.minItems = u), f && (i.maxItems = d));
	let { minimum: p, maximum: m } = e._zod.bag;
	typeof p == "number" && (i.minItems = p), typeof m == "number" && (i.maxItems = m);
};
function WN(e, t, n) {
	if (t.$ref) {
		if (n.has(t)) return t;
		n.add(t);
		let r = e.get(t)?.def;
		if (!r) return t;
		let i = WN(e, r, n);
		return i === r ? t : i;
	}
	for (let r of ["anyOf", "oneOf"]) {
		let i = t[r];
		if (!Array.isArray(i)) continue;
		let a = i.map((t) => WN(e, t, n));
		a.some((e, t) => e !== i[t]) && (t = {
			...t,
			[r]: a
		});
	}
	let r = Array.isArray(t.type) ? t.type : [t.type], i = !r.includes("string") && r.some((e) => e === "number" || e === "integer"), a = t.enum ?? (t.const === void 0 ? void 0 : [t.const]);
	if (!i && !a?.some((e) => typeof e == "number")) return t;
	let { minimum: o, maximum: s, exclusiveMinimum: c, exclusiveMaximum: l, multipleOf: u, format: d, id: f, ...p } = t;
	return p.enum ? p.enum = p.enum.map((e) => typeof e == "number" ? String(e) : e) : typeof p.const == "number" && (p.const = String(p.const)), i ? (p.type = "string", a || (p.pattern = (r.includes("number") ? zC : RC).source), p) : p;
}
var GN = /* @__PURE__ */ new WeakMap();
function KN(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.seen.values()) n.def && !t.has(n.schema) && t.set(n.schema, n);
	let n = /* @__PURE__ */ new Map();
	for (let r of GN.get(e) ?? []) {
		let i = e.seen.get(r), a = (i?.def ?? i?.schema)?.propertyNames;
		if (!a || a === !0 || n.has(a)) continue;
		let o = WN(t, a, /* @__PURE__ */ new Set());
		o !== a && n.set(a, o);
	}
	if (n.size) for (let t of e.seen.values()) for (let e of [t.schema, t.def]) {
		let t = e && n.get(e.propertyNames);
		t && (e.propertyNames = t);
	}
}
var qN = (e, t, n, r) => {
	let i = n, a = e._zod.def;
	i.type = "object";
	let o = a.keyType, s = o._zod.bag?.patterns;
	if (a.mode === "loose" && s && s.size > 0) {
		let e = X(a.valueType, t, {
			...r,
			path: [
				...r.path,
				"patternProperties",
				"*"
			]
		});
		i.patternProperties = {};
		for (let t of s) P(i.patternProperties, t.source, e);
	} else {
		if (t.target === "draft-07" || t.target === "draft-2020-12") {
			i.propertyNames = X(a.keyType, t, {
				...r,
				path: [...r.path, "propertyNames"]
			});
			let n = GN.get(t);
			n || (n = [], GN.set(t, n), t.deferred.push(() => KN(t))), n.push(e);
		}
		i.additionalProperties = X(a.valueType, t, {
			...r,
			path: [...r.path, "additionalProperties"]
		});
	}
	let c = o._zod.values, l = t.io === "input" && zN(a.valueType) !== void 0;
	if (c && !a.partial && !l) {
		let e = [...c].filter((e) => typeof e == "string" || typeof e == "number");
		e.length > 0 && (i.required = e.map(String));
	}
}, JN = (e, t, n, r) => {
	let i = e._zod.def, a = X(i.innerType, t, r), o = t.seen.get(e);
	t.target === "openapi-3.0" ? (o.ref = i.innerType, n.nullable = !0) : n.anyOf = [a, { type: "null" }];
}, YN = (e, t, n, r) => {
	let i = e._zod.def;
	X(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
}, XN = Symbol();
function ZN(e, t, n, r, i) {
	let a = !1, o = JSON.stringify(e, (e, t) => typeof t == "bigint" ? (a = !0, null) : t);
	return a ? (Y(t, n, r, i, "BigInt defaults cannot be represented in JSON Schema"), XN) : JSON.parse(o);
}
var QN = (e, t, n, r) => {
	let i = e._zod.def;
	X(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
	let o = ZN(i.defaultValue, e, t, n, r);
	o !== XN && (n.default = o);
}, $N = (e, t, n, r) => {
	let i = e._zod.def;
	X(i.innerType, t, r);
	let a = t.seen.get(e);
	if (a.ref = i.innerType, t.io !== "input") return;
	let o = ZN(i.defaultValue, e, t, n, r);
	o !== XN && (n._prefault = o);
}, eP = (e, t, n, r) => {
	let i = e._zod.def;
	X(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
	let o;
	try {
		o = i.catchValue(void 0);
	} catch {
		Y(e, t, n, r, "Dynamic catch values are not supported in JSON Schema");
		return;
	}
	n.default = o;
}, tP = (e, t, n, r) => {
	let i = e._zod.def, a = i.in._zod.traits.has("$ZodTransform"), o = t.io === "input" ? a ? i.out : i.in : i.out;
	X(o, t, r);
	let s = t.seen.get(e);
	s.ref = o;
}, nP = (e, t, n, r) => {
	let i = e._zod.def;
	X(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType, n.readOnly = !0;
}, rP = (e, t, n, r) => {
	let i = e._zod.def;
	X(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
}, iP = (e, t, n, r) => {
	let i = e._zod.def;
	X(i.innerType, t, r);
	let a = t.seen.get(e);
	a.ref = i.innerType;
}, aP = (e, t, n, r) => {
	let i = e._zod.innerType;
	X(i, t, r);
	let a = t.seen.get(e);
	a.ref = i;
}, oP = {
	string: hN,
	number: gN,
	boolean: _N,
	bigint: vN,
	symbol: yN,
	null: bN,
	undefined: xN,
	void: SN,
	never: CN,
	any: wN,
	unknown: TN,
	date: EN,
	enum: DN,
	literal: ON,
	nan: kN,
	template_literal: AN,
	file: jN,
	success: MN,
	custom: NN,
	function: PN,
	transform: FN,
	map: IN,
	set: LN,
	array: RN,
	object: BN,
	union: VN,
	intersection: HN,
	tuple: UN,
	record: qN,
	nullable: JN,
	nonoptional: YN,
	default: QN,
	prefault: $N,
	catch: eP,
	pipe: tP,
	readonly: nP,
	promise: rP,
	optional: iP,
	lazy: aP
};
function sP(e, t) {
	if ("_idmap" in e) {
		let n = e, r = tN({
			...t,
			processors: oP
		}), i = {};
		for (let e of n._idmap.entries()) {
			let [t, n] = e;
			X(n, r);
		}
		let a = {};
		r.external = {
			registry: n,
			uri: t?.uri,
			defs: i
		};
		for (let e of n._idmap.entries()) {
			let [t, n] = e;
			rN(r, n), P(a, t, uN(r, n));
		}
		return Object.keys(i).length > 0 && (a.__shared = { [r.target === "draft-2020-12" ? "$defs" : "definitions"]: i }), { schemas: a };
	}
	let n = tN({
		...t,
		processors: oP
	});
	return X(e, n), rN(n, e), uN(n, e);
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/json-schema-generator.js
var cP = class {
	get metadataRegistry() {
		return this.ctx.metadataRegistry;
	}
	get target() {
		return this.ctx.target;
	}
	get unrepresentable() {
		return this.ctx.unrepresentable;
	}
	get override() {
		return this.ctx.override;
	}
	get io() {
		return this.ctx.io;
	}
	get counter() {
		return this.ctx.counter;
	}
	set counter(e) {
		this.ctx.counter = e;
	}
	get seen() {
		return this.ctx.seen;
	}
	constructor(e) {
		let t = e?.target ?? "draft-2020-12";
		t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), this.ctx = tN({
			processors: oP,
			target: t,
			...e?.metadata && { metadata: e.metadata },
			...e?.unrepresentable && { unrepresentable: e.unrepresentable },
			...e?.override && { override: e.override },
			...e?.io && { io: e.io }
		});
	}
	process(e, t = {
		path: [],
		schemaPath: []
	}) {
		return X(e, this.ctx, t);
	}
	emit(e, t) {
		t && (t.cycles && (this.ctx.cycles = t.cycles), t.reused && (this.ctx.reused = t.reused), t.external && (this.ctx.external = t.external)), this.ctx.sharedDefsExtractedFor = void 0, this.ctx.sharedEmitDoneFor = void 0, rN(this.ctx, e);
		let { "~standard": n, ...r } = uN(this.ctx, e);
		return r;
	}
}, lP = /* @__PURE__ */ T({}), uP = /* @__PURE__ */ T({
	$ZodAny: () => NT,
	$ZodArray: () => zT,
	$ZodAsyncError: () => tS,
	$ZodBase64: () => mT,
	$ZodBase64URL: () => gT,
	$ZodBigInt: () => OT,
	$ZodBigIntFormat: () => kT,
	$ZodBoolean: () => DT,
	$ZodCIDRv4: () => uT,
	$ZodCIDRv6: () => fT,
	$ZodCUID: () => Xw,
	$ZodCUID2: () => Zw,
	$ZodCatch: () => EE,
	$ZodCheck: () => H,
	$ZodCheckBigIntFormat: () => gw,
	$ZodCheckEndsWith: () => kw,
	$ZodCheckGreaterThan: () => pw,
	$ZodCheckIncludes: () => Dw,
	$ZodCheckLengthEquals: () => Sw,
	$ZodCheckLessThan: () => fw,
	$ZodCheckLowerCase: () => Tw,
	$ZodCheckMaxLength: () => bw,
	$ZodCheckMaxSize: () => _w,
	$ZodCheckMimeType: () => Mw,
	$ZodCheckMinLength: () => xw,
	$ZodCheckMinSize: () => vw,
	$ZodCheckMultipleOf: () => mw,
	$ZodCheckNumberFormat: () => hw,
	$ZodCheckOverwrite: () => Nw,
	$ZodCheckProperty: () => jw,
	$ZodCheckRegex: () => ww,
	$ZodCheckSizeEquals: () => yw,
	$ZodCheckStartsWith: () => Ow,
	$ZodCheckStringFormat: () => Cw,
	$ZodCheckUpperCase: () => Ew,
	$ZodCodec: () => AE,
	$ZodCreditCard: () => xT,
	$ZodCustom: () => BE,
	$ZodCustomStringFormat: () => wT,
	$ZodCyclicError: () => HE,
	$ZodDate: () => LT,
	$ZodDefault: () => yE,
	$ZodDiscriminatedUnion: () => QT,
	$ZodE164: () => _T,
	$ZodEmail: () => Vw,
	$ZodEmoji: () => Jw,
	$ZodEncodeError: () => nS,
	$ZodEnum: () => dE,
	$ZodError: () => dS,
	$ZodExactOptional: () => _E,
	$ZodFile: () => pE,
	$ZodFunction: () => LE,
	$ZodGUID: () => zw,
	$ZodIPv4: () => aT,
	$ZodIPv6: () => cT,
	$ZodISODate: () => nT,
	$ZodISODateTime: () => tT,
	$ZodISODuration: () => iT,
	$ZodISOTime: () => rT,
	$ZodIntersection: () => $T,
	$ZodJWT: () => CT,
	$ZodKSUID: () => eT,
	$ZodLazy: () => zE,
	$ZodLiteral: () => fE,
	$ZodMAC: () => lT,
	$ZodMap: () => sE,
	$ZodNaN: () => DE,
	$ZodNanoID: () => Yw,
	$ZodNever: () => FT,
	$ZodNonOptional: () => SE,
	$ZodNull: () => MT,
	$ZodNullable: () => vE,
	$ZodNumber: () => TT,
	$ZodNumberFormat: () => ET,
	$ZodObject: () => GT,
	$ZodObjectJIT: () => KT,
	$ZodOptional: () => gE,
	$ZodPipe: () => OE,
	$ZodPrefault: () => xE,
	$ZodPreprocess: () => NE,
	$ZodPromise: () => RE,
	$ZodReadonly: () => PE,
	$ZodRealError: () => fS,
	$ZodRecord: () => oE,
	$ZodRegistry: () => Tk,
	$ZodSet: () => lE,
	$ZodString: () => Rw,
	$ZodStringFormat: () => W,
	$ZodSuccess: () => wE,
	$ZodSymbol: () => AT,
	$ZodTemplateLiteral: () => IE,
	$ZodTransform: () => mE,
	$ZodTuple: () => nE,
	$ZodType: () => U,
	$ZodULID: () => Qw,
	$ZodURL: () => qw,
	$ZodUUID: () => Bw,
	$ZodUndefined: () => jT,
	$ZodUnion: () => JT,
	$ZodUnknown: () => PT,
	$ZodVoid: () => IT,
	$ZodXID: () => $w,
	$ZodXor: () => XT,
	$brand: () => eS,
	$constructor: () => B,
	$input: () => wk,
	$output: () => Ck,
	Doc: () => Pw,
	INVALID: () => Ok,
	JSONSchema: () => lP,
	JSONSchemaGenerator: () => cP,
	NEVER: () => Xx,
	TimePrecision: () => _j,
	URL_BAD_FORMAT: () => 1,
	URL_UNPARSEABLE: () => 2,
	ZodCompileAsyncError: () => Ak,
	ZodCompileUnsupportedError: () => G,
	_any: () => Rj,
	_array: () => xM,
	_base64: () => fj,
	_base64url: () => pj,
	_bigint: () => jj,
	_boolean: () => kj,
	_catch: () => BM,
	_check: () => YM,
	_cidrv4: () => uj,
	_cidrv6: () => dj,
	_coercedBigint: () => Mj,
	_coercedBoolean: () => Aj,
	_coercedDate: () => Uj,
	_coercedNumber: () => Cj,
	_coercedString: () => KA,
	_creditCard: () => hj,
	_cuid: () => nj,
	_cuid2: () => rj,
	_custom: () => KM,
	_date: () => Hj,
	_decode: () => FS,
	_decodeAsync: () => zS,
	_default: () => LM,
	_discriminatedUnion: () => wM,
	_e164: () => mj,
	_email: () => qA,
	_emoji: () => ej,
	_encode: () => NS,
	_encodeAsync: () => LS,
	_endsWith: () => dM,
	_enum: () => AM,
	_file: () => NM,
	_float32: () => Tj,
	_float64: () => Ej,
	_gt: () => qj,
	_gte: () => Jj,
	_guid: () => JA,
	_includes: () => lM,
	_int: () => wj,
	_int32: () => Dj,
	_int64: () => Nj,
	_intersection: () => TM,
	_ipv4: () => sj,
	_ipv6: () => cj,
	_isoDate: () => yj,
	_isoDateTime: () => vj,
	_isoDuration: () => xj,
	_isoTime: () => bj,
	_jwt: () => gj,
	_ksuid: () => oj,
	_lazy: () => WM,
	_length: () => aM,
	_literal: () => MM,
	_lowercase: () => sM,
	_lt: () => Gj,
	_lte: () => Kj,
	_mac: () => lj,
	_map: () => OM,
	_max: () => Kj,
	_maxLength: () => rM,
	_maxSize: () => eM,
	_mime: () => mM,
	_min: () => Jj,
	_minLength: () => iM,
	_minSize: () => tM,
	_multipleOf: () => $j,
	_nan: () => Wj,
	_nanoid: () => tj,
	_nativeEnum: () => jM,
	_negative: () => Xj,
	_never: () => Bj,
	_nonnegative: () => Qj,
	_nonoptional: () => RM,
	_nonpositive: () => Zj,
	_normalize: () => gM,
	_null: () => Lj,
	_nullable: () => IM,
	_number: () => Sj,
	_optional: () => FM,
	_overwrite: () => hM,
	_parse: () => bS,
	_parseAsync: () => SS,
	_pipe: () => VM,
	_positive: () => Yj,
	_promise: () => GM,
	_properties: () => pM,
	_property: () => fM,
	_readonly: () => HM,
	_record: () => DM,
	_refine: () => qM,
	_regex: () => oM,
	_safeDecode: () => US,
	_safeDecodeAsync: () => qS,
	_safeEncode: () => VS,
	_safeEncodeAsync: () => GS,
	_safeParse: () => wS,
	_safeParseAsync: () => ES,
	_set: () => kM,
	_size: () => nM,
	_slugify: () => bM,
	_startsWith: () => uM,
	_string: () => GA,
	_stringFormat: () => $M,
	_stringbool: () => QM,
	_success: () => zM,
	_superRefine: () => JM,
	_symbol: () => Fj,
	_templateLiteral: () => UM,
	_toLowerCase: () => vM,
	_toUpperCase: () => yM,
	_transform: () => PM,
	_trim: () => _M,
	_tuple: () => EM,
	_uint32: () => Oj,
	_uint64: () => Pj,
	_ulid: () => ij,
	_undefined: () => Ij,
	_union: () => SM,
	_unknown: () => zj,
	_uppercase: () => cM,
	_url: () => $A,
	_uuid: () => YA,
	_uuidv4: () => XA,
	_uuidv6: () => ZA,
	_uuidv7: () => QA,
	_void: () => Vj,
	_xid: () => aj,
	_xor: () => CM,
	clone: () => F,
	compile: () => Mk,
	compileFn: () => Pk,
	config: () => V,
	createStandardJSONSchemaMethod: () => pN,
	createToJSONSchemaMethod: () => fN,
	decode: () => IS,
	decodeAsync: () => BS,
	describe: () => XM,
	encode: () => PS,
	encodeAsync: () => RS,
	extractDefs: () => rN,
	finalize: () => uN,
	flattenError: () => mS,
	formatError: () => hS,
	getDiscriminatedOption: () => ZT,
	globalConfig: () => rS,
	globalRegistry: () => Dk,
	handleUnrepresentable: () => Y,
	initializeContext: () => tN,
	isBackEdge: () => eD,
	isRecursiveSchema: () => JE,
	isValidBase64: () => pT,
	isValidBase64URL: () => hT,
	isValidCIDRv6: () => dT,
	isValidCreditCard: () => bT,
	isValidIPv6: () => sT,
	isValidJWT: () => ST,
	locales: () => xk,
	memoizer: () => $E,
	mergeValues: () => eE,
	meta: () => ZM,
	parse: () => xS,
	parseAsync: () => CS,
	parseURLObject: () => Hw,
	prettifyError: () => vS,
	process: () => X,
	regexes: () => YS,
	registry: () => Ek,
	safeDecode: () => WS,
	safeDecodeAsync: () => JS,
	safeEncode: () => HS,
	safeEncodeAsync: () => KS,
	safeParse: () => TS,
	safeParseAsync: () => DS,
	standardProps: () => Lw,
	stripTabAndNewline: () => Ww,
	toDotPath: () => _S,
	toJSONSchema: () => sP,
	toZod: () => Mb,
	treeifyError: () => gS,
	urlHostnameOk: () => Gw,
	urlProtocolOk: () => Kw,
	util: () => kb,
	validate: () => AS,
	validateAsync: () => MS,
	version: () => Fw
}), dP = /* @__PURE__ */ T({
	endsWith: () => dM,
	gt: () => qj,
	gte: () => Jj,
	includes: () => lM,
	length: () => aM,
	lowercase: () => sM,
	lt: () => Gj,
	lte: () => Kj,
	maxLength: () => rM,
	maxSize: () => eM,
	mime: () => mM,
	minLength: () => iM,
	minSize: () => tM,
	multipleOf: () => $j,
	negative: () => Xj,
	nonnegative: () => Qj,
	nonpositive: () => Zj,
	normalize: () => gM,
	overwrite: () => hM,
	positive: () => Yj,
	properties: () => pM,
	property: () => fM,
	regex: () => oM,
	size: () => nM,
	slugify: () => bM,
	startsWith: () => uM,
	toLowerCase: () => vM,
	toUpperCase: () => yM,
	trim: () => _M,
	uppercase: () => cM
}), fP = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function pP(e, t, n) {
	Object.defineProperty(e, t, {
		configurable: !0,
		enumerable: !1,
		get() {
			let e = n(this);
			return Object.defineProperty(this, t, {
				value: e,
				configurable: !0,
				writable: !0
			}), e;
		},
		set(e) {
			Object.defineProperty(this, t, {
				value: e,
				configurable: !0,
				writable: !0
			});
		}
	});
}
var mP = (e, t) => {
	dS.init(e, t), e.name = "ZodError";
	let n = Object.getPrototypeOf(e);
	fP.has(n) || (fP.add(n), pP(n, "format", (e) => (t) => hS(e, t)), pP(n, "flatten", (e) => (t) => mS(e, t)), pP(n, "addIssue", (e) => (t) => {
		e.issues.push(t), e.message = JSON.stringify(e.issues, Lb, 2);
	}), pP(n, "addIssues", (e) => (t) => {
		e.issues.push(...t), e.message = JSON.stringify(e.issues, Lb, 2);
	}), Object.defineProperty(n, "isEmpty", {
		configurable: !0,
		enumerable: !1,
		get() {
			return this.issues.length === 0;
		}
	}));
}, hP = /*@__PURE__*/ B("ZodError", mP), gP = /*@__PURE__*/ B("ZodError", mP, void 0, { Parent: Error }), _P = /* @__PURE__ */ bS(gP), vP = /* @__PURE__ */ SS(gP), yP = /* @__PURE__ */ wS(gP), bP = /* @__PURE__ */ ES(gP), xP = /* @__PURE__ */ NS(gP), SP = /* @__PURE__ */ FS(gP), CP = /* @__PURE__ */ LS(gP), wP = /* @__PURE__ */ zS(gP), TP = /* @__PURE__ */ VS(gP), EP = /* @__PURE__ */ US(gP), DP = /* @__PURE__ */ GS(gP), OP = /* @__PURE__ */ qS(gP), kP = /* @__PURE__ */ T({
	ZodAny: () => rI,
	ZodArray: () => pI,
	ZodBase64: () => xF,
	ZodBase64URL: () => CF,
	ZodBigInt: () => KF,
	ZodBigIntFormat: () => JF,
	ZodBoolean: () => WF,
	ZodCIDRv4: () => _F,
	ZodCIDRv6: () => yF,
	ZodCUID: () => tF,
	ZodCUID2: () => rF,
	ZodCatch: () => cL,
	ZodCodec: () => mL,
	ZodCreditCard: () => DF,
	ZodCustom: () => OL,
	ZodCustomStringFormat: () => jF,
	ZodDate: () => dI,
	ZodDefault: () => eL,
	ZodDiscriminatedUnion: () => wI,
	ZodE164: () => TF,
	ZodEmail: () => zP,
	ZodEmoji: () => ZP,
	ZodEnum: () => RI,
	ZodExactOptional: () => YI,
	ZodFile: () => UI,
	ZodFunction: () => EL,
	ZodGUID: () => VP,
	ZodIPv4: () => dF,
	ZodIPv6: () => hF,
	ZodISODate: () => IP,
	ZodISODateTime: () => FP,
	ZodISODuration: () => RP,
	ZodISOTime: () => LP,
	ZodIntersection: () => EI,
	ZodJWT: () => kF,
	ZodKSUID: () => lF,
	ZodLazy: () => SL,
	ZodLiteral: () => VI,
	ZodMAC: () => pF,
	ZodMap: () => PI,
	ZodNaN: () => uL,
	ZodNanoID: () => $P,
	ZodNever: () => sI,
	ZodNonOptional: () => iL,
	ZodNull: () => tI,
	ZodNullable: () => ZI,
	ZodNumber: () => IF,
	ZodNumberFormat: () => RF,
	ZodObject: () => gI,
	ZodOptional: () => qI,
	ZodPipe: () => fL,
	ZodPrefault: () => nL,
	ZodPreprocess: () => _L,
	ZodPromise: () => wL,
	ZodReadonly: () => vL,
	ZodRecord: () => AI,
	ZodSet: () => II,
	ZodString: () => NP,
	ZodStringFormat: () => Q,
	ZodSuccess: () => oL,
	ZodSymbol: () => ZF,
	ZodTemplateLiteral: () => bL,
	ZodTransform: () => GI,
	ZodTuple: () => OI,
	ZodType: () => Z,
	ZodULID: () => aF,
	ZodURL: () => JP,
	ZodUUID: () => UP,
	ZodUndefined: () => $F,
	ZodUnion: () => bI,
	ZodUnknown: () => aI,
	ZodVoid: () => lI,
	ZodXID: () => sF,
	ZodXor: () => SI,
	_ZodString: () => MP,
	_default: () => tL,
	_function: () => DL,
	any: () => iI,
	array: () => mI,
	base64: () => SF,
	base64url: () => wF,
	bigint: () => qF,
	boolean: () => GF,
	catch: () => lL,
	check: () => kL,
	cidrv4: () => vF,
	cidrv6: () => bF,
	codec: () => hL,
	creditCard: () => OF,
	cuid: () => nF,
	cuid2: () => iF,
	custom: () => AL,
	date: () => fI,
	describe: () => NL,
	discriminatedUnion: () => TI,
	e164: () => EF,
	email: () => BP,
	emoji: () => QP,
	enum: () => zI,
	exactOptional: () => XI,
	file: () => WI,
	float32: () => BF,
	float64: () => VF,
	function: () => DL,
	guid: () => HP,
	hash: () => FF,
	hex: () => PF,
	hostname: () => NF,
	httpUrl: () => XP,
	instanceof: () => FL,
	int: () => zF,
	int32: () => HF,
	int64: () => YF,
	intersection: () => DI,
	invertCodec: () => gL,
	ipv4: () => fF,
	ipv6: () => gF,
	json: () => LL,
	jwt: () => AF,
	keyof: () => hI,
	ksuid: () => uF,
	lazy: () => CL,
	literal: () => HI,
	looseObject: () => yI,
	looseRecord: () => NI,
	mac: () => mF,
	map: () => FI,
	meta: () => PL,
	nan: () => dL,
	nanoid: () => eF,
	nativeEnum: () => BI,
	never: () => cI,
	nonoptional: () => aL,
	null: () => nI,
	nullable: () => QI,
	nullish: () => $I,
	number: () => LF,
	object: () => _I,
	optional: () => JI,
	partialRecord: () => MI,
	pipe: () => pL,
	prefault: () => rL,
	preprocess: () => RL,
	promise: () => TL,
	readonly: () => yL,
	record: () => jI,
	refine: () => jL,
	set: () => LI,
	strictObject: () => vI,
	string: () => PP,
	stringFormat: () => MF,
	stringbool: () => IL,
	success: () => sL,
	superRefine: () => ML,
	symbol: () => QF,
	templateLiteral: () => xL,
	transform: () => KI,
	tuple: () => kI,
	uint32: () => UF,
	uint64: () => XF,
	ulid: () => oF,
	undefined: () => eI,
	union: () => xI,
	unknown: () => oI,
	url: () => YP,
	uuid: () => WP,
	uuidv4: () => GP,
	uuidv6: () => KP,
	uuidv7: () => qP,
	void: () => uI,
	xid: () => cF,
	xor: () => CI
});
function AP() {
	rS.localeError || V(TD());
}
function jP() {
	rS.memoizer || V({ memoizer: $E() });
}
var Z = /*@__PURE__*/ B("ZodType", (e, t) => (AP(), U.init(e, t), e.def = t, e.type = t.type, e), {
	check(...e) {
		let t = this.def;
		return this.clone(Gb(t, { checks: [...t.checks ?? [], ...e.map((e) => typeof e == "function" ? { _zod: {
			check: e,
			def: { check: "custom" },
			onattach: []
		} } : e)] }), { parent: !0 });
	},
	with(...e) {
		return this.check(...e);
	},
	clone(e, t) {
		return F(this, e, t);
	},
	brand() {
		return this;
	},
	register(e, t) {
		return e.add(this, t), this;
	},
	refine(e, t) {
		return this.check(jL(e, t));
	},
	superRefine(e, t) {
		return this.check(ML(e, t));
	},
	overwrite(e) {
		return this.check(/* @__PURE__ */ hM(e));
	},
	optional() {
		return JI(this);
	},
	exactOptional() {
		return XI(this);
	},
	nullable() {
		return QI(this);
	},
	nullish() {
		return JI(QI(this));
	},
	nonoptional(e) {
		return aL(this, e);
	},
	array() {
		return mI(this);
	},
	or(e) {
		return xI([this, e]);
	},
	and(e) {
		return DI(this, e);
	},
	transform(e) {
		return pL(this, KI(e));
	},
	default(e) {
		return tL(this, e);
	},
	prefault(e) {
		return rL(this, e);
	},
	catch(e) {
		return lL(this, e);
	},
	pipe(e) {
		return pL(this, e);
	},
	readonly() {
		return yL(this);
	},
	describe(e) {
		let t = this.clone();
		return Dk.add(t, { description: e }), t;
	},
	meta(...e) {
		if (e.length === 0) return Dk.get(this);
		let t = this.clone();
		return Dk.add(t, e[0]), t;
	},
	isOptional() {
		return this.safeParse(void 0).success;
	},
	isNullable() {
		return this.safeParse(null).success;
	},
	apply(e, ...t) {
		return t.length === 0 ? e(this) : e(this, ...t);
	},
	get "~standard"() {
		return Bx(this, "~standard", {
			...Lw(this),
			jsonSchema: {
				input: pN(this, "input"),
				output: pN(this, "output")
			}
		});
	},
	set "~standard"(e) {
		zx(this, "~standard", e);
	},
	parse: function e(t, n) {
		return _P(this, t, n, { callee: e });
	},
	parseAsync: async function e(t, n) {
		return await vP(this, t, n, { callee: e });
	},
	safeParse(e, t) {
		return yP(this, e, t);
	},
	async safeParseAsync(e, t) {
		return bP(this, e, t);
	},
	get spa() {
		return this?.safeParseAsync;
	},
	set spa(e) {
		zx(this, "spa", e);
	},
	encode: function e(t, n) {
		return xP(this, t, n, { callee: e });
	},
	decode: function e(t, n) {
		return SP(this, t, n, { callee: e });
	},
	encodeAsync: async function e(t, n) {
		return await CP(this, t, n, { callee: e });
	},
	decodeAsync: async function e(t, n) {
		return await wP(this, t, n, { callee: e });
	},
	safeEncode(e, t) {
		return TP(this, e, t);
	},
	safeDecode(e, t) {
		return EP(this, e, t);
	},
	async safeEncodeAsync(e, t) {
		return DP(this, e, t);
	},
	async safeDecodeAsync(e, t) {
		return OP(this, e, t);
	},
	toJSONSchema(e) {
		return fN(this, {})(e);
	},
	get description() {
		return Dk.get(this)?.description;
	},
	get _def() {
		return this._zod.def;
	}
}), MP = /*@__PURE__*/ B("_ZodString", (e, t) => {
	Rw.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => hN(e, t, n, r);
	let n = e._zod.bag;
	e.format = n.format ?? null, e.minLength = n.minimum ?? null, e.maxLength = n.maximum ?? null;
}, {
	regex(...e) {
		return this.check(/* @__PURE__ */ oM(...e));
	},
	includes(...e) {
		return this.check(/* @__PURE__ */ lM(...e));
	},
	startsWith(...e) {
		return this.check(/* @__PURE__ */ uM(...e));
	},
	endsWith(...e) {
		return this.check(/* @__PURE__ */ dM(...e));
	},
	min(...e) {
		return this.check(/* @__PURE__ */ iM(...e));
	},
	max(...e) {
		return this.check(/* @__PURE__ */ rM(...e));
	},
	length(...e) {
		return this.check(/* @__PURE__ */ aM(...e));
	},
	nonempty(...e) {
		return this.check(/* @__PURE__ */ iM(1, ...e));
	},
	lowercase(e) {
		return this.check(/* @__PURE__ */ sM(e));
	},
	uppercase(e) {
		return this.check(/* @__PURE__ */ cM(e));
	},
	trim() {
		return this.check(/* @__PURE__ */ _M());
	},
	normalize(...e) {
		return this.check(/* @__PURE__ */ gM(...e));
	},
	toLowerCase() {
		return this.check(/* @__PURE__ */ vM());
	},
	toUpperCase() {
		return this.check(/* @__PURE__ */ yM());
	},
	slugify() {
		return this.check(/* @__PURE__ */ bM());
	}
}), NP = /*@__PURE__*/ B("ZodString", (e, t) => {
	Rw.init(e, t), MP.init(e, t);
}, {
	email(e) {
		return this.check(/* @__PURE__ */ qA(zP, e));
	},
	url(e) {
		return this.check(/* @__PURE__ */ $A(JP, e));
	},
	jwt(e) {
		return this.check(/* @__PURE__ */ gj(kF, e));
	},
	emoji(e) {
		return this.check(/* @__PURE__ */ ej(ZP, e));
	},
	guid(e) {
		return this.check(/* @__PURE__ */ JA(VP, e));
	},
	uuid(e) {
		return this.check(/* @__PURE__ */ YA(UP, e));
	},
	uuidv4(e) {
		return this.check(/* @__PURE__ */ XA(UP, e));
	},
	uuidv6(e) {
		return this.check(/* @__PURE__ */ ZA(UP, e));
	},
	uuidv7(e) {
		return this.check(/* @__PURE__ */ QA(UP, e));
	},
	nanoid(e) {
		return this.check(/* @__PURE__ */ tj($P, e));
	},
	cuid(e) {
		return this.check(/* @__PURE__ */ nj(tF, e));
	},
	cuid2(e) {
		return this.check(/* @__PURE__ */ rj(rF, e));
	},
	ulid(e) {
		return this.check(/* @__PURE__ */ ij(aF, e));
	},
	base64(e) {
		return this.check(/* @__PURE__ */ fj(xF, e));
	},
	base64url(e) {
		return this.check(/* @__PURE__ */ pj(CF, e));
	},
	xid(e) {
		return this.check(/* @__PURE__ */ aj(sF, e));
	},
	ksuid(e) {
		return this.check(/* @__PURE__ */ oj(lF, e));
	},
	ipv4(e) {
		return this.check(/* @__PURE__ */ sj(dF, e));
	},
	ipv6(e) {
		return this.check(/* @__PURE__ */ cj(hF, e));
	},
	cidrv4(e) {
		return this.check(/* @__PURE__ */ uj(_F, e));
	},
	cidrv6(e) {
		return this.check(/* @__PURE__ */ dj(yF, e));
	},
	e164(e) {
		return this.check(/* @__PURE__ */ mj(TF, e));
	},
	datetime(e) {
		return this.check(/* @__PURE__ */ vj(FP, e));
	},
	date(e) {
		return this.check(/* @__PURE__ */ yj(IP, e));
	},
	time(e) {
		return this.check(/* @__PURE__ */ bj(LP, e));
	},
	duration(e) {
		return this.check(/* @__PURE__ */ xj(RP, e));
	}
});
function PP(e) {
	return /* @__PURE__ */ GA(NP, e);
}
var Q = /*@__PURE__*/ B("ZodStringFormat", (e, t) => {
	W.init(e, t), MP.init(e, t);
}), FP = /*@__PURE__*/ B("ZodISODateTime", (e, t) => {
	tT.init(e, t), Q.init(e, t);
}), IP = /*@__PURE__*/ B("ZodISODate", (e, t) => {
	nT.init(e, t), Q.init(e, t);
}), LP = /*@__PURE__*/ B("ZodISOTime", (e, t) => {
	rT.init(e, t), Q.init(e, t);
}), RP = /*@__PURE__*/ B("ZodISODuration", (e, t) => {
	iT.init(e, t), Q.init(e, t);
}), zP = /*@__PURE__*/ B("ZodEmail", (e, t) => {
	Vw.init(e, t), Q.init(e, t);
});
function BP(e) {
	return /* @__PURE__ */ qA(zP, e);
}
var VP = /*@__PURE__*/ B("ZodGUID", (e, t) => {
	zw.init(e, t), Q.init(e, t);
});
function HP(e) {
	return /* @__PURE__ */ JA(VP, e);
}
var UP = /*@__PURE__*/ B("ZodUUID", (e, t) => {
	Bw.init(e, t), Q.init(e, t);
});
function WP(e) {
	return /* @__PURE__ */ YA(UP, e);
}
function GP(e) {
	return /* @__PURE__ */ XA(UP, e);
}
function KP(e) {
	return /* @__PURE__ */ ZA(UP, e);
}
function qP(e) {
	return /* @__PURE__ */ QA(UP, e);
}
var JP = /*@__PURE__*/ B("ZodURL", (e, t) => {
	qw.init(e, t), Q.init(e, t);
});
function YP(e) {
	return /* @__PURE__ */ $A(JP, e);
}
function XP(e) {
	return /* @__PURE__ */ $A(JP, {
		protocol: DC,
		hostname: EC,
		...I(e)
	});
}
var ZP = /*@__PURE__*/ B("ZodEmoji", (e, t) => {
	Jw.init(e, t), Q.init(e, t);
});
function QP(e) {
	return /* @__PURE__ */ ej(ZP, e);
}
var $P = /*@__PURE__*/ B("ZodNanoID", (e, t) => {
	Yw.init(e, t), Q.init(e, t);
});
function eF(e) {
	return /* @__PURE__ */ tj($P, e);
}
var tF = /*@__PURE__*/ B("ZodCUID", (e, t) => {
	Xw.init(e, t), Q.init(e, t);
});
function nF(e) {
	return /* @__PURE__ */ nj(tF, e);
}
var rF = /*@__PURE__*/ B("ZodCUID2", (e, t) => {
	Zw.init(e, t), Q.init(e, t);
});
function iF(e) {
	return /* @__PURE__ */ rj(rF, e);
}
var aF = /*@__PURE__*/ B("ZodULID", (e, t) => {
	Qw.init(e, t), Q.init(e, t);
});
function oF(e) {
	return /* @__PURE__ */ ij(aF, e);
}
var sF = /*@__PURE__*/ B("ZodXID", (e, t) => {
	$w.init(e, t), Q.init(e, t);
});
function cF(e) {
	return /* @__PURE__ */ aj(sF, e);
}
var lF = /*@__PURE__*/ B("ZodKSUID", (e, t) => {
	eT.init(e, t), Q.init(e, t);
});
function uF(e) {
	return /* @__PURE__ */ oj(lF, e);
}
var dF = /*@__PURE__*/ B("ZodIPv4", (e, t) => {
	aT.init(e, t), Q.init(e, t);
});
function fF(e) {
	return /* @__PURE__ */ sj(dF, e);
}
var pF = /*@__PURE__*/ B("ZodMAC", (e, t) => {
	lT.init(e, t), Q.init(e, t);
});
function mF(e) {
	return /* @__PURE__ */ lj(pF, e);
}
var hF = /*@__PURE__*/ B("ZodIPv6", (e, t) => {
	cT.init(e, t), Q.init(e, t);
});
function gF(e) {
	return /* @__PURE__ */ cj(hF, e);
}
var _F = /*@__PURE__*/ B("ZodCIDRv4", (e, t) => {
	uT.init(e, t), Q.init(e, t);
});
function vF(e) {
	return /* @__PURE__ */ uj(_F, e);
}
var yF = /*@__PURE__*/ B("ZodCIDRv6", (e, t) => {
	fT.init(e, t), Q.init(e, t);
});
function bF(e) {
	return /* @__PURE__ */ dj(yF, e);
}
var xF = /*@__PURE__*/ B("ZodBase64", (e, t) => {
	mT.init(e, t), Q.init(e, t);
});
function SF(e) {
	return /* @__PURE__ */ fj(xF, e);
}
var CF = /*@__PURE__*/ B("ZodBase64URL", (e, t) => {
	gT.init(e, t), Q.init(e, t);
});
function wF(e) {
	return /* @__PURE__ */ pj(CF, e);
}
var TF = /*@__PURE__*/ B("ZodE164", (e, t) => {
	_T.init(e, t), Q.init(e, t);
});
function EF(e) {
	return /* @__PURE__ */ mj(TF, e);
}
var DF = /*@__PURE__*/ B("ZodCreditCard", (e, t) => {
	xT.init(e, t), Q.init(e, t);
});
function OF(e) {
	return /* @__PURE__ */ hj(DF, e);
}
var kF = /*@__PURE__*/ B("ZodJWT", (e, t) => {
	CT.init(e, t), Q.init(e, t);
});
function AF(e) {
	return /* @__PURE__ */ gj(kF, e);
}
var jF = /*@__PURE__*/ B("ZodCustomStringFormat", (e, t) => {
	wT.init(e, t), Q.init(e, t);
});
function MF(e, t, n = {}) {
	return /* @__PURE__ */ $M(jF, e, t, n);
}
function NF(e) {
	return /* @__PURE__ */ $M(jF, "hostname", TC, e);
}
function PF(e) {
	return /* @__PURE__ */ $M(jF, "hex", GC, e);
}
function FF(e, t) {
	let n = `${e}_${t?.enc ?? "hex"}`, r = YS[n];
	if (!r) throw Error(`Unrecognized hash format: ${n}`);
	return /* @__PURE__ */ $M(jF, n, r, t);
}
var IF = /*@__PURE__*/ B("ZodNumber", (e, t) => {
	TT.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => gN(e, t, n, r);
	let n = e._zod.bag;
	e.minValue = Math.max(n.minimum ?? -Infinity, n.exclusiveMinimum ?? -Infinity) ?? null, e.maxValue = Math.min(n.maximum ?? Infinity, n.exclusiveMaximum ?? Infinity) ?? null, e.isInt = (n.format ?? "").includes("int") || Number.isSafeInteger(n.multipleOf ?? .5), e.isFinite = !0, e.format = n.format ?? null;
}, {
	gt(e, t) {
		return this.check(/* @__PURE__ */ qj(e, t));
	},
	gte(e, t) {
		return this.check(/* @__PURE__ */ Jj(e, t));
	},
	min(e, t) {
		return this.check(/* @__PURE__ */ Jj(e, t));
	},
	lt(e, t) {
		return this.check(/* @__PURE__ */ Gj(e, t));
	},
	lte(e, t) {
		return this.check(/* @__PURE__ */ Kj(e, t));
	},
	max(e, t) {
		return this.check(/* @__PURE__ */ Kj(e, t));
	},
	int(e) {
		return this.check(zF(e));
	},
	safe(e) {
		return this.check(zF(e));
	},
	positive(e) {
		return this.check(/* @__PURE__ */ qj(0, e));
	},
	nonnegative(e) {
		return this.check(/* @__PURE__ */ Jj(0, e));
	},
	negative(e) {
		return this.check(/* @__PURE__ */ Gj(0, e));
	},
	nonpositive(e) {
		return this.check(/* @__PURE__ */ Kj(0, e));
	},
	multipleOf(e, t) {
		return this.check(/* @__PURE__ */ $j(e, t));
	},
	step(e, t) {
		return this.check(/* @__PURE__ */ $j(e, t));
	},
	finite() {
		return this;
	}
});
function LF(e) {
	return /* @__PURE__ */ Sj(IF, e);
}
var RF = /*@__PURE__*/ B("ZodNumberFormat", (e, t) => {
	ET.init(e, t), IF.init(e, t);
});
function zF(e) {
	return /* @__PURE__ */ wj(RF, e);
}
function BF(e) {
	return /* @__PURE__ */ Tj(RF, e);
}
function VF(e) {
	return /* @__PURE__ */ Ej(RF, e);
}
function HF(e) {
	return /* @__PURE__ */ Dj(RF, e);
}
function UF(e) {
	return /* @__PURE__ */ Oj(RF, e);
}
var WF = /*@__PURE__*/ B("ZodBoolean", (e, t) => {
	DT.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => _N(e, t, n, r);
});
function GF(e) {
	return /* @__PURE__ */ kj(WF, e);
}
var KF = /*@__PURE__*/ B("ZodBigInt", (e, t) => {
	OT.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => vN(e, t, n, r);
	let n = e._zod.bag;
	e.minValue = n.minimum ?? null, e.maxValue = n.maximum ?? null, e.format = n.format ?? null;
}, {
	gte(e, t) {
		return this.check(/* @__PURE__ */ Jj(e, t));
	},
	min(e, t) {
		return this.check(/* @__PURE__ */ Jj(e, t));
	},
	gt(e, t) {
		return this.check(/* @__PURE__ */ qj(e, t));
	},
	lt(e, t) {
		return this.check(/* @__PURE__ */ Gj(e, t));
	},
	lte(e, t) {
		return this.check(/* @__PURE__ */ Kj(e, t));
	},
	max(e, t) {
		return this.check(/* @__PURE__ */ Kj(e, t));
	},
	positive(e) {
		return this.check(/* @__PURE__ */ qj(BigInt(0), e));
	},
	negative(e) {
		return this.check(/* @__PURE__ */ Gj(BigInt(0), e));
	},
	nonpositive(e) {
		return this.check(/* @__PURE__ */ Kj(BigInt(0), e));
	},
	nonnegative(e) {
		return this.check(/* @__PURE__ */ Jj(BigInt(0), e));
	},
	multipleOf(e, t) {
		return this.check(/* @__PURE__ */ $j(e, t));
	}
});
function qF(e) {
	return /* @__PURE__ */ jj(KF, e);
}
var JF = /*@__PURE__*/ B("ZodBigIntFormat", (e, t) => {
	kT.init(e, t), KF.init(e, t);
});
function YF(e) {
	return /* @__PURE__ */ Nj(JF, e);
}
function XF(e) {
	return /* @__PURE__ */ Pj(JF, e);
}
var ZF = /*@__PURE__*/ B("ZodSymbol", (e, t) => {
	AT.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => yN(e, t, n, r);
});
function QF(e) {
	return /* @__PURE__ */ Fj(ZF, e);
}
var $F = /*@__PURE__*/ B("ZodUndefined", (e, t) => {
	jT.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => xN(e, t, n, r);
});
function eI(e) {
	return /* @__PURE__ */ Ij($F, e);
}
var tI = /*@__PURE__*/ B("ZodNull", (e, t) => {
	MT.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => bN(e, t, n, r);
});
function nI(e) {
	return /* @__PURE__ */ Lj(tI, e);
}
var rI = /*@__PURE__*/ B("ZodAny", (e, t) => {
	NT.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (e, t, n) => void 0;
});
function iI() {
	return /* @__PURE__ */ Rj(rI);
}
var aI = /*@__PURE__*/ B("ZodUnknown", (e, t) => {
	PT.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (e, t, n) => void 0;
});
function oI() {
	return /* @__PURE__ */ zj(aI);
}
var sI = /*@__PURE__*/ B("ZodNever", (e, t) => {
	FT.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => CN(e, t, n, r);
});
function cI(e) {
	return /* @__PURE__ */ Bj(sI, e);
}
var lI = /*@__PURE__*/ B("ZodVoid", (e, t) => {
	IT.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => SN(e, t, n, r);
});
function uI(e) {
	return /* @__PURE__ */ Vj(lI, e);
}
var dI = /*@__PURE__*/ B("ZodDate", (e, t) => {
	LT.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => EN(e, t, n, r), e.min = (t, n) => e.check(/* @__PURE__ */ Jj(t, n)), e.max = (t, n) => e.check(/* @__PURE__ */ Kj(t, n));
	let n = e._zod.bag;
	e.minDate = n.minimum ? new Date(n.minimum) : null, e.maxDate = n.maximum ? new Date(n.maximum) : null;
});
function fI(e) {
	return /* @__PURE__ */ Hj(dI, e);
}
var pI = /*@__PURE__*/ B("ZodArray", (e, t) => {
	jP(), zT.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => RN(e, t, n, r), e.element = t.element;
}, {
	min(e, t) {
		return this.check(/* @__PURE__ */ iM(e, t));
	},
	nonempty(e) {
		return this.check(/* @__PURE__ */ iM(1, e));
	},
	max(e, t) {
		return this.check(/* @__PURE__ */ rM(e, t));
	},
	length(e, t) {
		return this.check(/* @__PURE__ */ aM(e, t));
	},
	unwrap() {
		return this.element;
	}
});
function mI(e, t) {
	return /* @__PURE__ */ xM(pI, e, t);
}
function hI(e) {
	let t = e._zod.def.shape;
	return zI(Object.keys(t));
}
var gI = /*@__PURE__*/ B("ZodObject", (e, t) => {
	jP(), KT.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => BN(e, t, n, r), Kx(e, "shape", (e) => e._zod.def.shape, !1);
}, {
	keyof() {
		return zI(Object.keys(this._zod.def.shape));
	},
	catchall(e) {
		return this.clone({
			...this._zod.def,
			catchall: e
		});
	},
	passthrough() {
		return this.clone({
			...this._zod.def,
			catchall: oI()
		});
	},
	loose() {
		return this.clone({
			...this._zod.def,
			catchall: oI()
		});
	},
	strict() {
		return this.clone({
			...this._zod.def,
			catchall: cI()
		});
	},
	strip() {
		return this.clone({
			...this._zod.def,
			catchall: void 0
		});
	},
	extend(e) {
		return mx(this, e);
	},
	safeExtend(e) {
		return hx(this, e);
	},
	merge(e) {
		return gx(this, e);
	},
	pick(e) {
		return fx(this, e);
	},
	omit(e) {
		return px(this, e);
	},
	partial(...e) {
		return _x(qI, this, e[0]);
	},
	exactPartial(...e) {
		return _x(YI, this, e[0], "exactPartial");
	},
	required(...e) {
		return vx(iL, this, e[0]);
	}
});
function _I(e, t) {
	return new gI({
		type: "object",
		shape: e ?? {},
		...I(t)
	});
}
function vI(e, t) {
	return new gI({
		type: "object",
		shape: e,
		catchall: cI(),
		...I(t)
	});
}
function yI(e, t) {
	return new gI({
		type: "object",
		shape: e,
		catchall: oI(),
		...I(t)
	});
}
var bI = /*@__PURE__*/ B("ZodUnion", (e, t) => {
	JT.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => VN(e, t, n, r), e.options = t.options;
});
function xI(e, t) {
	return new bI({
		type: "union",
		options: e,
		...I(t)
	});
}
var SI = /*@__PURE__*/ B("ZodXor", (e, t) => {
	bI.init(e, t), XT.init(e, t), e._zod.processJSONSchema = (t, n, r) => VN(e, t, n, r), e.options = t.options;
});
function CI(e, t) {
	return new SI({
		type: "union",
		options: e,
		inclusive: !1,
		...I(t)
	});
}
var wI = /*@__PURE__*/ B("ZodDiscriminatedUnion", (e, t) => {
	bI.init(e, t), QT.init(e, t);
});
function TI(e, t, n) {
	return new wI({
		type: "union",
		options: t,
		discriminator: e,
		...I(n)
	});
}
var EI = /*@__PURE__*/ B("ZodIntersection", (e, t) => {
	$T.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => HN(e, t, n, r);
});
function DI(e, t) {
	return new EI({
		type: "intersection",
		left: e,
		right: t
	});
}
var OI = /*@__PURE__*/ B("ZodTuple", (e, t) => {
	jP(), nE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => UN(e, t, n, r);
}, {
	rest(e) {
		return this.clone({
			...this._zod.def,
			rest: e
		});
	},
	partial() {
		let e = this._zod.def;
		if (e.checks?.length) throw Error(".partial() cannot be used on tuple schemas containing refinements");
		return this.clone({
			...e,
			items: e.items.map((e) => new qI({
				type: "optional",
				innerType: e
			}))
		});
	}
});
function kI(e, t, n) {
	let r = t instanceof U;
	return new OI({
		type: "tuple",
		items: e,
		rest: r ? t : null,
		...I(r ? n : t)
	});
}
var AI = /*@__PURE__*/ B("ZodRecord", (e, t) => {
	jP(), oE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => qN(e, t, n, r), e.keyType = t.keyType, e.valueType = t.valueType;
});
function jI(e, t, n) {
	return !t || !t._zod ? new AI({
		type: "record",
		keyType: PP(),
		valueType: e,
		...I(t)
	}) : new AI({
		type: "record",
		keyType: e,
		valueType: t,
		...I(n)
	});
}
function MI(e, t, n) {
	return new AI({
		type: "record",
		keyType: e,
		valueType: t,
		...I(n),
		partial: !0
	});
}
function NI(e, t, n) {
	return new AI({
		type: "record",
		keyType: e,
		valueType: t,
		mode: "loose",
		...I(n)
	});
}
var PI = /*@__PURE__*/ B("ZodMap", (e, t) => {
	jP(), sE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => IN(e, t, n, r), e.keyType = t.keyType, e.valueType = t.valueType, e.min = (...t) => e.check(/* @__PURE__ */ tM(...t)), e.nonempty = (t) => e.check(/* @__PURE__ */ tM(1, t)), e.max = (...t) => e.check(/* @__PURE__ */ eM(...t)), e.size = (...t) => e.check(/* @__PURE__ */ nM(...t));
});
function FI(e, t, n) {
	return new PI({
		type: "map",
		keyType: e,
		valueType: t,
		...I(n)
	});
}
var II = /*@__PURE__*/ B("ZodSet", (e, t) => {
	jP(), lE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => LN(e, t, n, r), e.min = (...t) => e.check(/* @__PURE__ */ tM(...t)), e.nonempty = (t) => e.check(/* @__PURE__ */ tM(1, t)), e.max = (...t) => e.check(/* @__PURE__ */ eM(...t)), e.size = (...t) => e.check(/* @__PURE__ */ nM(...t));
});
function LI(e, t) {
	return new II({
		type: "set",
		valueType: e,
		...I(t)
	});
}
var RI = /*@__PURE__*/ B("ZodEnum", (e, t) => {
	dE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => DN(e, t, n, r), e.enum = t.entries, e.options = Object.values(t.entries);
	let n = new Set(Object.keys(t.entries));
	e.extract = (e, r) => {
		let i = {};
		for (let r of e) if (n.has(r)) i[r] = t.entries[r];
		else throw Error(`Key ${r} not found in enum`);
		return new RI({
			...t,
			checks: [],
			...I(r),
			entries: i
		});
	}, e.exclude = (e, r) => {
		let i = { ...t.entries };
		for (let t of e) if (n.has(t)) delete i[t];
		else throw Error(`Key ${t} not found in enum`);
		return new RI({
			...t,
			checks: [],
			...I(r),
			entries: i
		});
	};
});
function zI(e, t) {
	return new RI({
		type: "enum",
		entries: Array.isArray(e) ? Object.fromEntries(e.map((e) => [e, e])) : e,
		...I(t)
	});
}
function BI(e, t) {
	return new RI({
		type: "enum",
		entries: e,
		...I(t)
	});
}
var VI = /*@__PURE__*/ B("ZodLiteral", (e, t) => {
	fE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => ON(e, t, n, r), e.values = new Set(t.values), Object.defineProperty(e, "value", { get() {
		if (t.values.length > 1) throw Error("This schema contains multiple valid literal values. Use `.values` instead.");
		return t.values[0];
	} });
});
function HI(e, t) {
	return new VI({
		type: "literal",
		values: Array.isArray(e) ? e : [e],
		...I(t)
	});
}
var UI = /*@__PURE__*/ B("ZodFile", (e, t) => {
	pE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => jN(e, t, n, r), e.min = (t, n) => e.check(/* @__PURE__ */ tM(t, n)), e.max = (t, n) => e.check(/* @__PURE__ */ eM(t, n)), e.mime = (t, n) => e.check(/* @__PURE__ */ mM(Array.isArray(t) ? t : [t], n));
});
function WI(e) {
	return /* @__PURE__ */ NM(UI, e);
}
var GI = /*@__PURE__*/ B("ZodTransform", (e, t) => {
	jP(), mE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => FN(e, t, n, r), e._zod.parse = (n, r) => {
		if (r.direction === "backward") throw new nS(e.constructor.name);
		n.addIssue = (r) => {
			if (typeof r == "string") n.issues.push(kx(r, n.value, t));
			else {
				let t = r;
				t.fatal && (t.continue = !1), t.code ??= "custom", "input" in t || (t.input = n.value), t.inst ??= e, n.issues.push(kx(t));
			}
		};
		let i = t.transform(n.value, n);
		return i instanceof Promise ? i.then((e) => (n.value = e, n)) : (n.value = i, n);
	};
});
function KI(e) {
	return new GI({
		type: "transform",
		transform: e
	});
}
var qI = /*@__PURE__*/ B("ZodOptional", (e, t) => {
	gE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => iP(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function JI(e) {
	return new qI({
		type: "optional",
		innerType: e
	});
}
var YI = /*@__PURE__*/ B("ZodExactOptional", (e, t) => {
	_E.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => iP(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function XI(e) {
	return new YI({
		type: "optional",
		innerType: e
	});
}
var ZI = /*@__PURE__*/ B("ZodNullable", (e, t) => {
	vE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => JN(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function QI(e) {
	return new ZI({
		type: "nullable",
		innerType: e
	});
}
function $I(e) {
	return JI(QI(e));
}
var eL = /*@__PURE__*/ B("ZodDefault", (e, t) => {
	yE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => QN(e, t, n, r), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function tL(e, t) {
	return new eL({
		type: "default",
		innerType: e,
		get defaultValue() {
			return typeof t == "function" ? t() : nx(t);
		}
	});
}
var nL = /*@__PURE__*/ B("ZodPrefault", (e, t) => {
	xE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => $N(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function rL(e, t) {
	return new nL({
		type: "prefault",
		innerType: e,
		get defaultValue() {
			return typeof t == "function" ? t() : nx(t);
		}
	});
}
var iL = /*@__PURE__*/ B("ZodNonOptional", (e, t) => {
	SE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => YN(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function aL(e, t) {
	return new iL({
		type: "nonoptional",
		innerType: e,
		...I(t)
	});
}
var oL = /*@__PURE__*/ B("ZodSuccess", (e, t) => {
	wE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => MN(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function sL(e) {
	return new oL({
		type: "success",
		innerType: e
	});
}
var cL = /*@__PURE__*/ B("ZodCatch", (e, t) => {
	EE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => eP(e, t, n, r), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function lL(e, t) {
	return new cL({
		type: "catch",
		innerType: e,
		catchValue: typeof t == "function" ? t : Jx(t)
	});
}
var uL = /*@__PURE__*/ B("ZodNaN", (e, t) => {
	DE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => kN(e, t, n, r);
});
function dL(e) {
	return /* @__PURE__ */ Wj(uL, e);
}
var fL = /*@__PURE__*/ B("ZodPipe", (e, t) => {
	OE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => tP(e, t, n, r), e.in = t.in, e.out = t.out;
});
function pL(e, t) {
	return new fL({
		type: "pipe",
		in: e,
		out: t
	});
}
var mL = /*@__PURE__*/ B("ZodCodec", (e, t) => {
	fL.init(e, t), AE.init(e, t);
});
function hL(e, t, n) {
	return new mL({
		type: "pipe",
		in: e,
		out: t,
		transform: n.decode,
		reverseTransform: n.encode
	});
}
function gL(e) {
	let t = e._zod.def;
	return new mL({
		type: "pipe",
		in: t.out,
		out: t.in,
		transform: t.reverseTransform,
		reverseTransform: t.transform
	});
}
var _L = /*@__PURE__*/ B("ZodPreprocess", (e, t) => {
	fL.init(e, t), NE.init(e, t);
}), vL = /*@__PURE__*/ B("ZodReadonly", (e, t) => {
	PE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => nP(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function yL(e) {
	return new vL({
		type: "readonly",
		innerType: e
	});
}
var bL = /*@__PURE__*/ B("ZodTemplateLiteral", (e, t) => {
	IE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => AN(e, t, n, r);
});
function xL(e, t) {
	return new bL({
		type: "template_literal",
		parts: e,
		...I(t)
	});
}
var SL = /*@__PURE__*/ B("ZodLazy", (e, t) => {
	zE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => aP(e, t, n, r), e.unwrap = () => e._zod.def.getter();
});
function CL(e) {
	return new SL({
		type: "lazy",
		getter: e
	});
}
var wL = /*@__PURE__*/ B("ZodPromise", (e, t) => {
	RE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => rP(e, t, n, r), e.unwrap = () => e._zod.def.innerType;
});
function TL(e) {
	return new wL({
		type: "promise",
		innerType: e
	});
}
var EL = /*@__PURE__*/ B("ZodFunction", (e, t) => {
	LE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => PN(e, t, n, r);
});
function DL(e) {
	return new EL({
		type: "function",
		input: Array.isArray(e?.input) ? kI(e?.input) : e?.input ?? mI(oI()),
		output: e?.output ?? oI()
	});
}
var OL = /*@__PURE__*/ B("ZodCustom", (e, t) => {
	BE.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (t, n, r) => NN(e, t, n, r);
});
function kL(e) {
	let t = new H({ check: "custom" });
	return t._zod.check = e, t;
}
function AL(e, t) {
	return /* @__PURE__ */ KM(OL, e ?? (() => !0), t);
}
function jL(e, t = {}) {
	return /* @__PURE__ */ qM(OL, e, t);
}
function ML(e, t) {
	return /* @__PURE__ */ JM(e, t);
}
var NL = XM, PL = ZM;
function FL(e, t = {}) {
	let n = new OL({
		type: "custom",
		check: "custom",
		fn: (t) => t instanceof e,
		abort: !0,
		...I(t)
	});
	return n._zod.bag.Class = e, n._zod.check = (t) => {
		t.value instanceof e || t.issues.push({
			code: "invalid_type",
			expected: e.name,
			input: t.value,
			inst: n,
			path: [...n._zod.def.path ?? []]
		});
	}, n;
}
var IL = (...e) => /* @__PURE__ */ QM({
	Codec: mL,
	Boolean: WF,
	String: NP
}, ...e);
function LL(e) {
	let t = CL(() => xI([
		PP(e),
		LF(),
		GF(),
		nI(),
		mI(t),
		jI(PP(), t)
	]));
	return t;
}
function RL(e, t) {
	return new _L({
		type: "pipe",
		in: KI(e),
		out: t
	});
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/classic/compat.js
var zL = {
	invalid_type: "invalid_type",
	too_big: "too_big",
	too_small: "too_small",
	invalid_format: "invalid_format",
	not_multiple_of: "not_multiple_of",
	unrecognized_keys: "unrecognized_keys",
	invalid_union: "invalid_union",
	invalid_key: "invalid_key",
	invalid_element: "invalid_element",
	invalid_value: "invalid_value",
	custom: "custom"
};
function BL(e) {
	V({ customError: e });
}
function VL() {
	return V().customError;
}
var HL;
HL ||= {};
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/classic/iso.js
var UL = /* @__PURE__ */ T({
	ZodISODate: () => IP,
	ZodISODateTime: () => FP,
	ZodISODuration: () => RP,
	ZodISOTime: () => LP,
	date: () => GL,
	datetime: () => WL,
	duration: () => qL,
	time: () => KL
});
function WL(e) {
	return /* @__PURE__ */ vj(FP, e);
}
function GL(e) {
	return /* @__PURE__ */ yj(IP, e);
}
function KL(e) {
	return /* @__PURE__ */ bj(LP, e);
}
function qL(e) {
	return /* @__PURE__ */ xj(RP, e);
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/classic/from-json-schema.js
var $ = {
	...kP,
	...dP,
	iso: UL
}, JL = /*@__PURE__*/ new Set(/* @__PURE__ */ "$schema.$ref.$defs.definitions.$id.id.$comment.$anchor.$vocabulary.$dynamicRef.$dynamicAnchor.type.enum.const.anyOf.oneOf.allOf.not.properties.required.additionalProperties.patternProperties.propertyNames.minProperties.maxProperties.items.prefixItems.additionalItems.minItems.maxItems.uniqueItems.contains.minContains.maxContains.minLength.maxLength.pattern.format.minimum.maximum.exclusiveMinimum.exclusiveMaximum.multipleOf.description.default.contentEncoding.contentMediaType.contentSchema.unevaluatedItems.unevaluatedProperties.if.then.else.dependentSchemas.dependentRequired.nullable.readOnly".split("."));
function YL(e, t) {
	let n = e.$schema;
	return n === "https://json-schema.org/draft/2020-12/schema" ? "draft-2020-12" : n === "http://json-schema.org/draft-07/schema#" ? "draft-7" : n === "http://json-schema.org/draft-04/schema#" ? "draft-4" : t ?? "draft-2020-12";
}
function XL(e, t) {
	return e.map((e, n) => n < t ? e : e.optional());
}
function ZL(e) {
	return e.replace(/~1/g, "/").replace(/~0/g, "~");
}
function QL(e, t) {
	if (!e.startsWith("#")) throw Error("External $ref is not supported, only local refs (#/...) are allowed");
	let n = e.slice(1).split("/").filter(Boolean);
	if (n.length === 0) return t.rootSchema;
	let r = t.version === "draft-2020-12" ? "$defs" : "definitions";
	if (n[0] === r) {
		let r = n[1] === void 0 ? void 0 : ZL(n[1]);
		if (!r || !t.defs[r]) throw Error(`Reference not found: ${e}`);
		return t.defs[r];
	}
	throw Error(`Reference not found: ${e}`);
}
function $L(e, t) {
	return $.transform((e) => e).check((e) => {
		let n = e.value;
		if (!(typeof n != "object" || !n || Array.isArray(n))) for (let r of Object.getOwnPropertyNames(n)) {
			let n = t.safeParse(r);
			n.success || e.issues.push({
				code: "invalid_key",
				origin: "record",
				issues: n.error.issues,
				input: r,
				path: [r],
				continue: !0
			});
		}
	}).pipe(e);
}
function eR(e, t) {
	if (e !== !1) return e === void 0 || e === !0 ? $.any() : rR(e, t);
}
var tR = /^(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d+)?(?:Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)$/;
function nR(e, t) {
	if (e.not !== void 0) {
		if (typeof e.not == "object" && Object.keys(e.not).length === 0) return $.never();
		throw Error("not is not supported in Zod (except { not: {} } for never)");
	}
	if (e.unevaluatedItems !== void 0) throw Error("unevaluatedItems is not supported");
	if (e.unevaluatedProperties !== void 0) throw Error("unevaluatedProperties is not supported");
	if (e.if !== void 0 || e.then !== void 0 || e.else !== void 0) throw Error("Conditional schemas (if/then/else) are not supported");
	if (e.dependentSchemas !== void 0 || e.dependentRequired !== void 0) throw Error("dependentSchemas and dependentRequired are not supported");
	if (e.$ref) {
		let n = e.$ref;
		if (t.refs.has(n)) return t.refs.get(n);
		if (t.processing.has(n)) return $.lazy(() => {
			if (!t.refs.has(n)) throw Error(`Circular reference not resolved: ${n}`);
			return t.refs.get(n);
		});
		t.processing.add(n);
		let r = rR(QL(n, t), t);
		return t.refs.set(n, r), t.processing.delete(n), r;
	}
	if (e.enum !== void 0) {
		let n = e.enum;
		if (t.version === "openapi-3.0" && e.nullable === !0 && n.length === 1 && n[0] === null) return $.null();
		if (n.length === 0) return $.never();
		if (n.length === 1) return $.literal(n[0]);
		if (n.every((e) => typeof e == "string")) return $.enum(n);
		let r = n.map((e) => $.literal(e));
		return r.length < 2 ? r[0] : $.union([
			r[0],
			r[1],
			...r.slice(2)
		]);
	}
	if (e.const !== void 0) return $.literal(e.const);
	let n = e.type;
	if (Array.isArray(n)) {
		let r = n.map((n) => nR({
			...e,
			type: n
		}, t));
		return r.length === 0 ? $.never() : r.length === 1 ? r[0] : $.union(r);
	}
	if (!n) return $.any();
	let r;
	switch (n) {
		case "string": {
			let t = $.string();
			if (e.format) {
				let n = e.format;
				n === "email" ? t = t.check($.email()) : n === "uri" || n === "uri-reference" ? t = t.check($.url()) : n === "uuid" || n === "guid" ? t = t.check($.uuid()) : n === "date-time" ? t = t.check($.iso.datetime({ offset: !0 })) : n === "date" ? t = t.check($.iso.date()) : n === "time" ? t = t.check($.regex(tR)) : n === "duration" ? t = t.check($.iso.duration()) : n === "hostname" ? t = t.check($.hostname()) : n === "ipv4" ? t = t.check($.ipv4()) : n === "ipv6" ? t = t.check($.ipv6()) : n === "mac" ? t = t.check($.mac()) : n === "cidr" ? t = t.check($.cidrv4()) : n === "cidr-v6" ? t = t.check($.cidrv6()) : n === "base64" ? t = t.check($.base64()) : n === "base64url" ? t = t.check($.base64url()) : n === "e164" ? t = t.check($.e164()) : n === "credit_card" ? t = t.check($.creditCard()) : n === "jwt" ? t = t.check($.jwt()) : n === "emoji" ? t = t.check($.emoji()) : n === "nanoid" ? t = t.check($.nanoid()) : n === "cuid" ? t = t.check($.cuid()) : n === "cuid2" ? t = t.check($.cuid2()) : n === "ulid" ? t = t.check($.ulid()) : n === "xid" ? t = t.check($.xid()) : n === "ksuid" && (t = t.check($.ksuid()));
			}
			typeof e.minLength == "number" && (t = t.min(e.minLength)), typeof e.maxLength == "number" && (t = t.max(e.maxLength)), e.pattern && (t = t.regex(new RegExp(e.pattern))), r = t;
			break;
		}
		case "number":
		case "integer": {
			let t = n === "integer" ? $.number().int() : $.number();
			typeof e.minimum == "number" && e.exclusiveMinimum !== !0 && (t = t.min(e.minimum)), typeof e.maximum == "number" && e.exclusiveMaximum !== !0 && (t = t.max(e.maximum)), typeof e.exclusiveMinimum == "number" ? t = t.gt(e.exclusiveMinimum) : e.exclusiveMinimum === !0 && typeof e.minimum == "number" && (t = t.gt(e.minimum)), typeof e.exclusiveMaximum == "number" ? t = t.lt(e.exclusiveMaximum) : e.exclusiveMaximum === !0 && typeof e.maximum == "number" && (t = t.lt(e.maximum)), typeof e.multipleOf == "number" && (t = t.multipleOf(e.multipleOf)), r = t;
			break;
		}
		case "boolean":
			r = $.boolean();
			break;
		case "null":
			r = $.null();
			break;
		case "object": {
			let n = {}, i = e.properties || {}, a = new Set(e.required || []), o = typeof e.additionalProperties == "object" ? rR(e.additionalProperties, t) : void 0;
			for (let [e, r] of Object.entries(i)) {
				let i = rR(r, t);
				P(n, e, a.has(e) ? i : i.optional());
			}
			if (e.patternProperties) {
				let i = e.patternProperties, a = Object.keys(i), o = [];
				for (let e of a) {
					let n = rR(i[e], t), r = $.string().regex(new RegExp(e));
					o.push($.looseRecord(r, n));
				}
				let s = [];
				if (Object.keys(n).length > 0 && s.push($.object(n).passthrough()), s.push(...o), s.length === 0) r = $.object({}).passthrough();
				else if (s.length === 1) r = s[0];
				else {
					let e = $.intersection(s[0], s[1]);
					for (let t = 2; t < s.length; t++) e = $.intersection(e, s[t]);
					r = e;
				}
				if (e.additionalProperties === !1) {
					let e = Object.keys(n), t = a.map((e) => new RegExp(e)), i = r;
					r = r.check((n) => {
						if (!tx(n.value)) return;
						let r = [];
						for (let i of Object.keys(n.value)) e.includes(i) || t.some((e) => e.test(i)) || r.push(i);
						r.length && n.issues.push({
							code: "unrecognized_keys",
							keys: r,
							input: n.value,
							inst: i
						});
					});
				}
			} else {
				let t = $.object(n);
				r = e.additionalProperties === !1 ? t.strict() : o ? t.catchall(o) : t.passthrough();
			}
			if (e.propertyNames !== void 0 && e.propertyNames !== !0) {
				let n = typeof e.propertyNames == "object" && e.propertyNames.type === void 0 ? {
					type: "string",
					...e.propertyNames
				} : e.propertyNames;
				r = $L(r, rR(n, t));
			}
			break;
		}
		case "array": {
			let n = e.prefixItems, i = e.items;
			if (n && Array.isArray(n)) {
				let a = typeof e.minItems == "number" ? e.minItems : 0, o = XL(n.map((e) => rR(e, t)), a), s = Array.isArray(i) ? void 0 : eR(i, t), c = $.tuple(o);
				r = s ? c.rest(s) : c, typeof e.minItems == "number" && (r = r.check($.minLength(e.minItems))), typeof e.maxItems == "number" && (r = r.check($.maxLength(e.maxItems)));
			} else if (Array.isArray(i)) {
				let n = typeof e.minItems == "number" ? e.minItems : 0, a = XL(i.map((e) => rR(e, t)), n), o = eR(e.additionalItems, t), s = $.tuple(a);
				r = o ? s.rest(o) : s, typeof e.minItems == "number" && (r = r.check($.minLength(e.minItems))), typeof e.maxItems == "number" && (r = r.check($.maxLength(e.maxItems)));
			} else if (i !== void 0) {
				let n = rR(i, t), a = $.array(n);
				typeof e.minItems == "number" && (a = a.min(e.minItems)), typeof e.maxItems == "number" && (a = a.max(e.maxItems)), r = a;
			} else r = $.array($.any());
			break;
		}
		default: throw Error(`Unsupported type: ${n}`);
	}
	return r;
}
function rR(e, t) {
	if (typeof e == "boolean") return e ? $.any() : $.never();
	let n = nR(e, t), r = e.type || e.enum !== void 0 || e.const !== void 0;
	if (e.anyOf && Array.isArray(e.anyOf)) {
		let i = e.anyOf.map((e) => rR(e, t)), a = $.union(i);
		n = r ? $.intersection(n, a) : a;
	}
	if (e.oneOf && Array.isArray(e.oneOf)) {
		let i = e.oneOf.map((e) => rR(e, t)), a = $.xor(i);
		n = r ? $.intersection(n, a) : a;
	}
	if (e.allOf && Array.isArray(e.allOf)) {
		if (e.allOf.length === 0) n = r ? n : $.any();
		else {
			let i = r ? n : rR(e.allOf[0], t), a = +!r;
			for (let n = a; n < e.allOf.length; n++) i = $.intersection(i, rR(e.allOf[n], t));
			n = i;
		}
	}
	e.nullable === !0 && t.version === "openapi-3.0" && (n = $.nullable(n)), e.readOnly === !0 && (n = $.readonly(n)), e.default !== void 0 && (n = n.default(e.default));
	let i = {};
	for (let t of [
		"$id",
		"id",
		"$comment",
		"$anchor",
		"$vocabulary",
		"$dynamicRef",
		"$dynamicAnchor"
	]) t in e && (i[t] = e[t]);
	for (let t of [
		"contentEncoding",
		"contentMediaType",
		"contentSchema"
	]) t in e && (i[t] = e[t]);
	e.propertyNames !== void 0 && e.type === "object" && e.$ref === void 0 && (i.propertyNames = e.propertyNames);
	for (let t of Object.keys(e)) JL.has(t) || P(i, t, e[t]);
	return Object.keys(i).length > 0 && t.registry.add(n, i), e.description && (n = n.describe(e.description)), n;
}
function iR(e, t) {
	if (typeof e == "boolean") return e ? $.any() : $.never();
	let n;
	try {
		n = JSON.parse(JSON.stringify(e));
	} catch {
		throw Error("fromJSONSchema input is not valid JSON (possibly cyclic); use $defs/$ref for recursive schemas");
	}
	let r = {
		version: YL(n, t?.defaultTarget),
		defs: n.$defs || n.definitions || {},
		refs: /* @__PURE__ */ new Map(),
		processing: /* @__PURE__ */ new Set(),
		rootSchema: n,
		registry: t?.registry ?? Dk
	};
	return rR(n, r);
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/visit.js
var aR = Symbol("z.visit/resolving");
function oR(e, t) {
	let n = typeof t == "function" ? t : (e, n) => {
		let r = t[e._zod.def.type];
		return r ? r(e, n) : e;
	}, r = /* @__PURE__ */ new Map();
	function i(e) {
		let t = r.get(e);
		if (t === aR) return new zE({
			type: "lazy",
			getter: () => r.get(e)
		});
		if (t !== void 0) return t;
		r.set(e, aR);
		let i = a(e), o = n(i, i !== e);
		return r.set(e, o), o;
	}
	function a(e) {
		let t = e._zod.def;
		switch (t.type) {
			case "object": {
				let n = t.shape, r = Object.keys(n), a = !1, o = {};
				for (let e of r) {
					let t = i(n[e]);
					t !== n[e] && (a = !0), o[e] = t;
				}
				let s = t.catchall;
				return t.catchall && (s = i(t.catchall), s !== t.catchall && (a = !0)), a ? F(e, {
					...t,
					shape: o,
					catchall: s
				}) : e;
			}
			case "array": {
				let n = i(t.element);
				return n === t.element ? e : F(e, {
					...t,
					element: n
				});
			}
			case "tuple": {
				let n = t.items, r = !1, a = [];
				for (let e of n) {
					let t = i(e);
					t !== e && (r = !0), a.push(t);
				}
				let o = t.rest;
				return t.rest && (o = i(t.rest), o !== t.rest && (r = !0)), r ? F(e, {
					...t,
					items: a,
					rest: o
				}) : e;
			}
			case "record":
			case "map": {
				let n = i(t.keyType), r = i(t.valueType);
				return n === t.keyType && r === t.valueType ? e : F(e, {
					...t,
					keyType: n,
					valueType: r
				});
			}
			case "set": {
				let n = i(t.valueType);
				return n === t.valueType ? e : F(e, {
					...t,
					valueType: n
				});
			}
			case "union": {
				let n = t.options, r = !1, a = [];
				for (let e of n) {
					let t = i(e);
					t !== e && (r = !0), a.push(t);
				}
				return r ? F(e, {
					...t,
					options: a
				}) : e;
			}
			case "intersection": {
				let n = i(t.left), r = i(t.right);
				return n === t.left && r === t.right ? e : F(e, {
					...t,
					left: n,
					right: r
				});
			}
			case "optional":
			case "nullable":
			case "default":
			case "prefault":
			case "catch":
			case "readonly":
			case "nonoptional":
			case "promise":
			case "success": {
				let n = i(t.innerType);
				return n === t.innerType ? e : F(e, {
					...t,
					innerType: n
				});
			}
			case "pipe": {
				let n = i(t.in), r = i(t.out);
				return n === t.in && r === t.out ? e : F(e, {
					...t,
					in: n,
					out: r
				});
			}
			case "function": {
				let n = i(t.input), r = i(t.output);
				return n === t.input && r === t.output ? e : F(e, {
					...t,
					input: n,
					output: r
				});
			}
			case "lazy": {
				let n = t.getter, { _cachedInner: r, ...a } = t;
				return F(e, {
					...a,
					getter: () => i(n())
				});
			}
			case "template_literal":
			case "string":
			case "number":
			case "int":
			case "boolean":
			case "bigint":
			case "symbol":
			case "undefined":
			case "null":
			case "void":
			case "never":
			case "any":
			case "unknown":
			case "date":
			case "nan":
			case "enum":
			case "literal":
			case "file":
			case "transform":
			case "custom": return e;
			default: return e;
		}
	}
	return i(e);
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/classic/deep-partial.js
function sR(e) {
	return oR(e, {
		object: (e) => e.partial(),
		union: (e) => {
			let t = e._zod.def;
			return t.discriminator === void 0 ? e : xI(t.options);
		}
	});
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/classic/in-out.js
function cR(e, t) {
	if (!t?.length) return e;
	let n = e._zod.def;
	return F(e, Gb(n, { checks: [...n.checks ?? [], ...t] }), { parent: !0 });
}
function lR(e) {
	return cR(e.out, e.checks);
}
function uR(e) {
	return e.in._zod.traits.has("$ZodTransform") ? lR(e) : e.in;
}
function dR(e) {
	return oR(e, {
		pipe: (e) => uR(e._zod.def),
		default: (e, t) => t ? JI(e._zod.def.innerType) : e,
		catch: (e, t) => t ? e._zod.def.innerType : e
	});
}
function fR(e) {
	return oR(e, {
		pipe: (e) => lR(e._zod.def),
		prefault: (e, t) => t ? e._zod.def.innerType : e
	});
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/classic/coerce.js
var pR = /* @__PURE__ */ T({
	bigint: () => _R,
	boolean: () => gR,
	date: () => vR,
	number: () => hR,
	string: () => mR
});
function mR(e) {
	return /* @__PURE__ */ KA(NP, e);
}
function hR(e) {
	return /* @__PURE__ */ Cj(IF, e);
}
function gR(e) {
	return /* @__PURE__ */ Aj(WF, e);
}
function _R(e) {
	return /* @__PURE__ */ Mj(KF, e);
}
function vR(e) {
	return /* @__PURE__ */ Uj(dI, e);
}
//#endregion
//#region ../../node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/classic/external.js
var yR = /* @__PURE__ */ T({
	$brand: () => eS,
	$input: () => wk,
	$output: () => Ck,
	NEVER: () => Xx,
	TimePrecision: () => _j,
	ZodAny: () => rI,
	ZodArray: () => pI,
	ZodBase64: () => xF,
	ZodBase64URL: () => CF,
	ZodBigInt: () => KF,
	ZodBigIntFormat: () => JF,
	ZodBoolean: () => WF,
	ZodCIDRv4: () => _F,
	ZodCIDRv6: () => yF,
	ZodCUID: () => tF,
	ZodCUID2: () => rF,
	ZodCatch: () => cL,
	ZodCodec: () => mL,
	ZodCompileAsyncError: () => Ak,
	ZodCompileUnsupportedError: () => G,
	ZodCreditCard: () => DF,
	ZodCustom: () => OL,
	ZodCustomStringFormat: () => jF,
	ZodDate: () => dI,
	ZodDefault: () => eL,
	ZodDiscriminatedUnion: () => wI,
	ZodE164: () => TF,
	ZodEmail: () => zP,
	ZodEmoji: () => ZP,
	ZodEnum: () => RI,
	ZodError: () => hP,
	ZodExactOptional: () => YI,
	ZodFile: () => UI,
	ZodFirstPartyTypeKind: () => HL,
	ZodFunction: () => EL,
	ZodGUID: () => VP,
	ZodIPv4: () => dF,
	ZodIPv6: () => hF,
	ZodISODate: () => IP,
	ZodISODateTime: () => FP,
	ZodISODuration: () => RP,
	ZodISOTime: () => LP,
	ZodIntersection: () => EI,
	ZodIssueCode: () => zL,
	ZodJWT: () => kF,
	ZodKSUID: () => lF,
	ZodLazy: () => SL,
	ZodLiteral: () => VI,
	ZodMAC: () => pF,
	ZodMap: () => PI,
	ZodNaN: () => uL,
	ZodNanoID: () => $P,
	ZodNever: () => sI,
	ZodNonOptional: () => iL,
	ZodNull: () => tI,
	ZodNullable: () => ZI,
	ZodNumber: () => IF,
	ZodNumberFormat: () => RF,
	ZodObject: () => gI,
	ZodOptional: () => qI,
	ZodPipe: () => fL,
	ZodPrefault: () => nL,
	ZodPreprocess: () => _L,
	ZodPromise: () => wL,
	ZodReadonly: () => vL,
	ZodRealError: () => gP,
	ZodRecord: () => AI,
	ZodSet: () => II,
	ZodString: () => NP,
	ZodStringFormat: () => Q,
	ZodSuccess: () => oL,
	ZodSymbol: () => ZF,
	ZodTemplateLiteral: () => bL,
	ZodTransform: () => GI,
	ZodTuple: () => OI,
	ZodType: () => Z,
	ZodULID: () => aF,
	ZodURL: () => JP,
	ZodUUID: () => UP,
	ZodUndefined: () => $F,
	ZodUnion: () => bI,
	ZodUnknown: () => aI,
	ZodVoid: () => lI,
	ZodXID: () => sF,
	ZodXor: () => SI,
	_ZodString: () => MP,
	_default: () => tL,
	_function: () => DL,
	any: () => iI,
	array: () => mI,
	base64: () => SF,
	base64url: () => wF,
	bigint: () => qF,
	boolean: () => GF,
	catch: () => lL,
	check: () => kL,
	cidrv4: () => vF,
	cidrv6: () => bF,
	clone: () => F,
	codec: () => hL,
	coerce: () => pR,
	compile: () => Mk,
	config: () => V,
	core: () => uP,
	creditCard: () => OF,
	cuid: () => nF,
	cuid2: () => iF,
	custom: () => AL,
	date: () => fI,
	decode: () => SP,
	decodeAsync: () => wP,
	deepPartial: () => sR,
	describe: () => NL,
	discriminatedUnion: () => TI,
	e164: () => EF,
	email: () => BP,
	emoji: () => QP,
	encode: () => xP,
	encodeAsync: () => CP,
	endsWith: () => dM,
	enum: () => zI,
	exactOptional: () => XI,
	file: () => WI,
	flattenError: () => mS,
	float32: () => BF,
	float64: () => VF,
	formatError: () => hS,
	fromJSONSchema: () => iR,
	function: () => DL,
	getDiscriminatedOption: () => ZT,
	getErrorMap: () => VL,
	globalRegistry: () => Dk,
	gt: () => qj,
	gte: () => Jj,
	guid: () => HP,
	hash: () => FF,
	hex: () => PF,
	hostname: () => NF,
	httpUrl: () => XP,
	includes: () => lM,
	input: () => dR,
	instanceof: () => FL,
	int: () => zF,
	int32: () => HF,
	int64: () => YF,
	intersection: () => DI,
	invertCodec: () => gL,
	ipv4: () => fF,
	ipv6: () => gF,
	iso: () => UL,
	json: () => LL,
	jwt: () => AF,
	keyof: () => hI,
	ksuid: () => uF,
	lazy: () => CL,
	length: () => aM,
	literal: () => HI,
	locales: () => xk,
	looseObject: () => yI,
	looseRecord: () => NI,
	lowercase: () => sM,
	lt: () => Gj,
	lte: () => Kj,
	mac: () => mF,
	map: () => FI,
	maxLength: () => rM,
	maxSize: () => eM,
	memoizer: () => $E,
	meta: () => PL,
	mime: () => mM,
	minLength: () => iM,
	minSize: () => tM,
	multipleOf: () => $j,
	nan: () => dL,
	nanoid: () => eF,
	nativeEnum: () => BI,
	negative: () => Xj,
	never: () => cI,
	nonnegative: () => Qj,
	nonoptional: () => aL,
	nonpositive: () => Zj,
	normalize: () => gM,
	null: () => nI,
	nullable: () => QI,
	nullish: () => $I,
	number: () => LF,
	object: () => _I,
	optional: () => JI,
	output: () => fR,
	overwrite: () => hM,
	parse: () => _P,
	parseAsync: () => vP,
	partialRecord: () => MI,
	pipe: () => pL,
	positive: () => Yj,
	prefault: () => rL,
	preprocess: () => RL,
	prettifyError: () => vS,
	promise: () => TL,
	properties: () => pM,
	property: () => fM,
	readonly: () => yL,
	record: () => jI,
	refine: () => jL,
	regex: () => oM,
	regexes: () => YS,
	registry: () => Ek,
	safeDecode: () => EP,
	safeDecodeAsync: () => OP,
	safeEncode: () => TP,
	safeEncodeAsync: () => DP,
	safeParse: () => yP,
	safeParseAsync: () => bP,
	set: () => LI,
	setErrorMap: () => BL,
	size: () => nM,
	slugify: () => bM,
	startsWith: () => uM,
	strictObject: () => vI,
	string: () => PP,
	stringFormat: () => MF,
	stringbool: () => IL,
	success: () => sL,
	superRefine: () => ML,
	symbol: () => QF,
	templateLiteral: () => xL,
	toJSONSchema: () => sP,
	toLowerCase: () => vM,
	toUpperCase: () => yM,
	toZod: () => Mb,
	transform: () => KI,
	treeifyError: () => gS,
	trim: () => _M,
	tuple: () => kI,
	uint32: () => UF,
	uint64: () => XF,
	ulid: () => oF,
	undefined: () => eI,
	union: () => xI,
	unknown: () => oI,
	uppercase: () => cM,
	url: () => YP,
	util: () => kb,
	uuid: () => WP,
	uuidv4: () => GP,
	uuidv6: () => KP,
	uuidv7: () => qP,
	validate: () => AS,
	validateAsync: () => MS,
	void: () => uI,
	xid: () => cF,
	xor: () => CI
});
sr(), wd(), m_(), Sr(), Or(), _d(), If(), sl(), qg(), Am(), tg(), fv(), hv(), mp(), Sv(), jf(), Ev(), gr(), Rd(), Xv(), Bn(), sr(), ju(), md(), gd(), Ml();
//#endregion
export { rl as ANT_DESIGN_LOCALE, Zy as AccessControl, Yy as AccessControlRoles, fb as AntdApp, Cd as BasicButton, pb as BasicContent, bb as BasicTable, vv as DEFAULT_TENANT, yu as EmbeddedIcon, p as ErrorBoundary, bu as ExternalIcon, mb as FormAvatarItem, _b as FormTreeItem, p_ as Iframe, xu as LayoutCenterIcon, Ff as LayoutEffects, Su as LayoutLeftIcon, Cu as LayoutRightIcon, wu as MixedNavigationIcon, Tu as OutsidePageIcon, br as PageError, Eu as ProfileCardIcon, ad as RiAccountCircleLine, od as RiContrastFill, sd as RiFullscreenExitLine, cd as RiFullscreenLine, ld as RiMailCheckLine, ud as RiMoonIcon, dd as RiReactjsLine, fd as RiSunIcon, pd as RiUserSettingsLine, Du as ServerErrorIcon, Ou as SideNavigationIcon, bv as TENANT_HEADER, yv as TENANT_QUERY_PARAM, ku as TopNavigationIcon, Au as TwoColumnNavigationIcon, Jy as accessControlCodes, Ty as bindingDiff, gv as bootstrapTenant, wy as canAssignRole, Cy as canDeleteRole, Sy as canEditRoleBindings, _v as currentTenant, wb as defineModule, Ay as fetchAddMenuItem, Hy as fetchAddRoleItem, ir as fetchAsyncRoutes, yy as fetchChangePassword, My as fetchDeleteMenuItem, Wy as fetchDeleteRoleItem, by as fetchLdapLogin, nr as fetchLogin, vy as fetchLoginMethods, rr as fetchLogout, Ky as fetchMenuByRoleId, ky as fetchMenuList, ly as fetchRbacAdminResetPassword, _y as fetchRbacContactDetail, gy as fetchRbacContacts, ry as fetchRbacCreateRole, sy as fetchRbacCreateUser, ay as fetchRbacDeleteRole, dy as fetchRbacOplog, fy as fetchRbacOplogPost, ny as fetchRbacPermissionList, ty as fetchRbacRoleList, uy as fetchRbacSetForbidden, py as fetchRbacSettings, iy as fetchRbacUpdateBindings, my as fetchRbacUpdateSetting, cy as fetchRbacUpdateUserRoles, oy as fetchRbacUserList, or as fetchRefreshToken, Vy as fetchRoleList, Gy as fetchRoleMenu, hy as fetchSolutionRoutes, jy as fetchUpdateMenuItem, Uy as fetchUpdateRoleItem, ar as fetchUserInfo, Al as filterTree, Ob as getAllExpandedKeys, hr as getAppInfo, Sb as getBooleanOptions, Lg as getHostRoutes, Dg as getModule, Og as getModuleRoutePrefix, Eg as getModules, Ld as getRedirectPath, zg as getRegisteredApiPrefix, Rg as getRegisteredStore, Ig as getRoutes, xb as getYesNoOptions, Ey as groupByModule, Oy as groupSettingsByModule, Ol as handleTree, Tg as loadAll, jl as mapTree, hd as menuIcons, Fn as notify, qy as permissionPrefix, M as request, wv as resolveApiBase, Xh as resolveRoutePath, Ln as resolveSiteBase, xy as roleLabel, nl as setupI18n, kl as traverseTreeValues, Bg as unloadModule, Xy as useAccess, j as useAccessStore, mv as useAuthStore, Dr as usePreferences, Om as useSlotNodes, Tb as useSolutionRoutes, Cb as useTabKey, pp as useTabsStore, xv as useTenantStore, Af as useUserStore, Rn as withSiteBase, yR as z };
