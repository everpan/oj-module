import { StyleProvider } from "@ant-design/cssinjs";
import { ProConfigProvider, enUSIntl, zhCNIntl } from "@ant-design/pro-components";
import { ANT_DESIGN_LOCALE, AntdApp, ErrorBoundary, LayoutEffects, PageError, getHostRoutes, getRoutes, loadAll, resolveApiBase, setupI18n, useAccessStore, useAuthStore, usePreferences, useUserStore } from "@oj-module/runtime";
import { MutationCache, QueryCache, QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ConfigProvider, theme } from "antd";
import { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { useTranslation } from "react-i18next";
import { Navigate, Outlet, RouterProvider, createBrowserRouter } from "react-router";
import { jsx, jsxs } from "react/jsx-runtime";
//#region \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
//#endregion
//#region shell/src/site-urls.ts
/**
* 宿主 shell 侧的站点 base 解析（子路径部署，2026-10-21）。
*
* shell 产物（`shell-dist/index.html` + `assets/*`）里的 URL 一律是**站点根绝对路径**
* （`/assets/react.js`）。`ojm build` 合并全站时按 `web.config.ts` 的 `siteBase`
* 重写 index.html 并注入 `window.__OJ_BASE__`，运行期这里读它把 modules.json
* 里的入口 / CSS / 预载 URL 补齐——否则站点挂在 `/oj` 时资源全部 404（首页白屏）。
*
* 为什么 shell 不直接 import runtime 的同名工具：本文件被 vitest 直接加载做纯函数
* 断言，而 runtime 主入口会拉进 antd/react 整棵树。规则与
* `packages/runtime/src/utils/site-base.ts` 逐条一致，由
* `tests/cli/site-base.test.ts` 用同一张用例表对撞防漂移。
*/
var ROOT_BASE = "/";
/** 归一化为「以 `/` 开头且以 `/` 结尾」；空值与 `"/"` 归为根路径 */
function normalizeSiteBase(raw) {
	if (!raw) return ROOT_BASE;
	const trimmed = raw.trim();
	if (!trimmed || trimmed === ROOT_BASE) return ROOT_BASE;
	const withLeading = trimmed.startsWith(ROOT_BASE) ? trimmed : `${ROOT_BASE}${trimmed}`;
	return withLeading.endsWith(ROOT_BASE) ? withLeading : `${withLeading}${ROOT_BASE}`;
}
/**
* 当前站点部署 base（恒以 `/` 结尾）。
*
* 优先级：`window.__OJ_BASE__`（`ojm build` 按 siteBase 注入）> `import.meta.env.BASE_URL`
* （shell 构建期固定为 `"/"`，仅在未注入时兜底，即根路径部署与 `ojm dev`）。
*/
function resolveSiteBase() {
	const injected = globalThis.__OJ_BASE__;
	if (typeof injected === "string") return normalizeSiteBase(injected);
	return normalizeSiteBase("/");
}
/** 站内绝对路径（`/modules/x/entry.js`）→ 带部署 base；已带 base 的幂等，绝对域原样 */
function withSiteBase(url, base = resolveSiteBase()) {
	if (!url.startsWith(ROOT_BASE) || url.startsWith("//")) return url;
	const normalized = normalizeSiteBase(base);
	if (normalized === ROOT_BASE || url.startsWith(normalized)) return url;
	return `${normalized.slice(0, -1)}${url}`;
}
//#endregion
//#region shell/src/manifest.ts
/**
* 把 modules.json 里的站内绝对 URL 补上部署 base（子路径部署，2026-10-21）。
*
* modules.json 是**构建期**产物（`ojm build`），URL 与站点挂载前缀无关
* （恒为 `/modules/...`）；真实前缀只有运行期才知道（`window.__OJ_BASE__`）。
* 因此在宿主拿到清单后立刻归一，后续所有消费者（信任根校验、CSS 注入、
* modulepreload、loader entry）看到的都是最终 URL——只此一处，漏改即 404 白屏。
*
* 绝对域（CDN 模块）原样保留，见 `web.config.ts` 的 `baseUrl`。
*/
function resolveModuleUrls(list, base) {
	return list.map((m) => ({
		...m,
		entry: m.entry === void 0 ? m.entry : withSiteBase(m.entry, base),
		css: m.css?.map((href) => withSiteBase(href, base)),
		chunks: m.chunks?.map((chunk) => ({
			...chunk,
			url: withSiteBase(chunk.url, base)
		}))
	}));
}
/**
* P7.7：modules.json（cli BuiltModule[]）→ loader Manifest 的字段透传。
*
* 评审 F1/F2：此前裁剪成 {name, entry}，导致 enabled 过滤（US-9 下线）
* 与 peerRuntime 校验（US-5）双双失效。清单字段必须原样透传——
* loader 侧已有 enabled/peerRuntime/dependencies 的全部消费逻辑。
*/
function toLoaderManifest(list, runtimeVersion) {
	return {
		runtimeVersion,
		modules: list.map((m) => ({
			name: m.name ?? "",
			entry: m.entry ?? "",
			enabled: m.enabled,
			dependencies: m.dependencies,
			peerRuntime: m.peerRuntime
		}))
	};
}
/** 从 shell dist 的 versions.json 提取 runtime 版本（P7.6 宿主侧真源） */
function extractRuntimeVersion(versions) {
	return versions?.["@oj-module/runtime"];
}
//#endregion
//#region shell/src/preload.ts
/**
* 待预载的 chunk 列表——仅非 lazy chunk 携带 sha384 integrity 进入；
* lazy chunk 按需加载，不受 L2 档位保护（D7）。
*/
function collectPreloads(modules) {
	const seen = /* @__PURE__ */ new Set();
	const preloads = [];
	for (const mod of modules) for (const chunk of mod.chunks ?? []) {
		if (chunk.lazy || seen.has(chunk.url)) continue;
		seen.add(chunk.url);
		preloads.push({
			href: chunk.url,
			integrity: chunk.integrity
		});
	}
	return preloads;
}
//#endregion
//#region shell/src/trust.ts
/**
* P6.1 / D10 信任根：moduleOrigins 白名单（设计文档 §4.8）。
*
* 清单与产物分目录分发布凭据是部署约束（仅 CI 可写清单目录）；
* 代码侧的对应防线是：模块资源 URL 的 origin 必须命中本白名单，
* 同源相对路径视为可信。来源未登记的模块在 loadAll 之前拒绝——
* 否则清单里出现一条恶意 entry，L2 完整性无从校验（攻击者可连同
* integrity 一起改）。
*/
/** 模块资源允许的 origin 白名单；宿主换 CDN 时在此登记后重新构建 shell */
var TRUSTED_ORIGINS = ["https://modules.cdn.example.com"];
/**
* 判定单个资源 URL 是否可信：同源相对路径或命中白名单。
*
* P7.1 修复：不得以「不含 ://」判同源——协议相对 URL（//host/x）、
* 反斜杠（https:\\host\x，WHATWG 解析为跨源）、data:/blob:（违反 C6）
* 均不含 "://"。一律经 new URL 归一化后比对 origin。
*/
function isTrustedUrl(url) {
	if (!url) return true;
	const base = typeof location === "undefined" ? "http://shell.local" : location.origin;
	try {
		const resolved = new URL(url, base);
		if (resolved.protocol !== "http:" && resolved.protocol !== "https:") return false;
		if (resolved.origin === new URL(base).origin) return true;
		return TRUSTED_ORIGINS.includes(resolved.origin);
	} catch {
		return false;
	}
}
/**
* 校验清单中全部资源 URL（entry / css / chunks[].url）。
* 任一越界即抛错并给出人话定位（模块名 + 越界 URL + 修复指引）。
*/
function assertTrustedModules(modules) {
	const offenders = [];
	for (const mod of modules) {
		const urls = [
			mod.entry ?? "",
			...mod.css ?? [],
			...(mod.chunks ?? []).map((c) => c.url)
		];
		for (const url of urls) if (!isTrustedUrl(url)) offenders.push(`${mod.name ?? "(unnamed)"}: ${url}`);
	}
	if (offenders.length > 0) throw new Error(`[shell] 模块来源未登记（moduleOrigins 白名单拒绝）：
${offenders.join("\n")}\n修复建议：该来源不在宿主内置白名单中。若是合法 CDN，请在 packages/cli/shell/src/trust.ts 的 TRUSTED_ORIGINS 登记后重新构建宿主。`);
}
//#endregion
//#region shell/src/host.tsx
/**
* 全局失败收敛（框架层唯一构造点）。
*
* 宿主是唯一构造 QueryClient 的地方：模块页面的 useQuery/useQueryClient 上下文
* 都来自此处，`ojm build` 对 shell-dist 全量合并，工程侧没有注入 defaults 的缝隙。
* 原先裸 `new QueryClient()` 走 TanStack 默认 `retry: 3`，导致「必然失败也白等 3 次
* 重试 + 请求层逐次弹 toast 刷屏」。
*
* 这里两处收敛：
* - `retry: 1`：保留一次瞬时抖动重试，去掉默认 3 次的无效等待（mutations 默认不重试）；
* - `QueryCache/MutationCache` onError：请求层 {@link handleErrorResponse} 已对
*   HTTP 错误体弹 toast，此处只兜底「请求层未触达」的失败（网络中断 / 解析异常 /
*   非响应错误），避免与其重复弹窗。
*/
function isHttpError(error) {
	const maybe = error;
	return Boolean(maybe?.response && typeof maybe.response.status === "number");
}
function surfaceQueryError(error) {
	if (isHttpError(error)) return;
	const message = error instanceof Error && /fetch|network|timeout/i.test(error.message) ? "网络异常，请检查网络连接后重试" : error instanceof Error ? error.message : "请求失败";
	window.$message?.error(message);
}
var queryClient = new QueryClient({
	defaultOptions: {
		queries: { retry: 1 },
		mutations: { retry: 0 }
	},
	queryCache: new QueryCache({ onError: surfaceQueryError }),
	mutationCache: new MutationCache({ onError: surfaceQueryError })
});
var DEMO_USER = {
	id: "1",
	avatar: "https://avatars.githubusercontent.com/u/47056890",
	username: "Admin",
	email: "",
	phoneNumber: "",
	description: "manager",
	roles: ["admin"]
};
/**
* 定角色：宿主链**没有 AuthGuard**（免登录演示能力绕开 LayoutRoot），没有任何
* 机制拉 `/web/user-info`，于是 user store 的 roles 恒为演示值或空——而模块路由
* 的角色过滤（B16，`config.requiredRoles`）与 superadmin 类前端判断都读它。
* 后果实测：seed 的 admin 账号（roles=["superadmin"]）被 `["admin"]` 挡在
* /system 路由外（404），成员资格入口也判不出来。
*
* - 有 token = 真实登录链 → 拉真实角色（must_change 悬挂期该端点仍返回 200）；
*   失败则清空，不让演示角色冒充真实权限（401 由请求层兜底跳登录）；
* - 无 token = 演示态 → 播种 DEMO_USER（与 App 链 fake 数据一致，两链显示同构）。
*/
async function hydrateUser() {
	if (!useAuthStore.getState().token) {
		useUserStore.setState(DEMO_USER);
		return;
	}
	try {
		await useUserStore.getState().getUserInfo();
	} catch (e) {
		console.warn("[shell] /web/user-info 拉取失败，角色置空", e);
		useUserStore.getState().reset();
	}
}
/**
* 登录/登出都会经 auth store reset() 清空 user store（宿主链无 AuthGuard 重新
* 拉取），token 变化即重新定角色。
*/
useAuthStore.subscribe((state, prev) => {
	if (state.token !== prev.token) hydrateUser().then(() => {
		useAccessStore.getState().setAccessStore(getRoutes());
		repatchShellRoutes();
	});
});
/**
* 宿主路由根 id：patchRoutes 重登记的 parentId（与 runtime 的 ROOT_ROUTE_ID
* 同名无碍——各自作用于各自 router 实例）。
*/
var SHELL_ROOT_ID = "shell-root";
/** Boot 建表后持有的宿主 router 实例；token 变化时按新角色快照重登记其路由表。 */
var shellRouter = null;
/**
* 宿主路由表 children：index 重定向 + 模块路由（getHostRoutes 同源重写）+
* catch-all 兜底。Boot 建表与登录后重登记共用同一构建口，保证两处同源。
*/
function buildShellChildren() {
	const hostRoutes = getHostRoutes();
	return [
		{
			index: true,
			element: /* @__PURE__ */ jsx(Navigate, {
				to: hostRoutes[0]?.path ?? "/",
				replace: true
			})
		},
		...hostRoutes,
		{
			path: "*",
			element: /* @__PURE__ */ jsx(CatchAll, {})
		}
	];
}
/**
* 按当前角色快照重登记宿主路由表（B16 回归，2026-10-24）。
*
* setAccessStore 内部的 router.patchRoutes 打的是 runtime 单例 router，而宿主
* 渲染的是本文件 Boot 里自建的 router——仅调 setAccessStore 只会更新菜单
* （access store），路由表保持 Boot 期快照。后果：Boot 期 user-info 失败
* （后端闪断/过期 token 刷新失败）→ 角色空 → requiredRoles 门禁模块被过滤出
* 路由表；随后 SPA 登录（不刷新页面）菜单回来了，但 /system/* 仍不在路由表里，
* 直达恒落 catch-all 404「返回首页」，须硬刷新才恢复。
*/
/**
* 宿主路由根（Boot 建表与登录后重登记共用同一形状，children 按当前角色快照生成）。
*
* 路由根只渲染容器（Outlet），整站 chrome 由模块自带的 ContainerLayout 提供；
* 宿主不叠加自己的 Layout chrome，避免「宿主侧栏 + 模块侧栏」双层嵌套。
* element 里同时挂 LayoutEffects（暗色类/动态标题/NProgress，与 App 链同源，偏差 4）
* 与页面级 ErrorBoundary（模块路由不经 runtime LayoutRoot，缺它时渲染抛错整页白屏）。
*/
function buildShellRoot() {
	return {
		path: "/",
		id: SHELL_ROOT_ID,
		element: /* @__PURE__ */ jsxs(ErrorBoundary, {
			FallbackComponent: PageError,
			children: [/* @__PURE__ */ jsx(LayoutEffects, {}), /* @__PURE__ */ jsx(Outlet, {})]
		}),
		children: buildShellChildren()
	};
}
function repatchShellRoutes() {
	if (!shellRouter) return;
	const internal = shellRouter._internalSetRoutes;
	if (internal) internal.call(shellRouter, [buildShellRoot()]);
	else shellRouter.patchRoutes(SHELL_ROOT_ID, buildShellChildren());
	const { pathname, search } = shellRouter.state.location;
	shellRouter.navigate(`${pathname}${search}`, { replace: true }).catch(() => {});
}
/**
* 直链兜底页（catch-all 路由元素）。无匹配路由时渲染框架 `PageError`，
* 把 title 设为框架 404 文案（`exception.notFoundTitle` = "404"），
* 观感与无权限面板同构，替代 React Router 默认的「Unexpected Application Error!」。
* 仅作观感兜底，权限判定仍由后端 403 硬执行。
*/
function CatchAll() {
	const { t } = useTranslation();
	return /* @__PURE__ */ jsx(PageError, {
		error: {
			status: 404,
			message: t("exception.notFoundTitle")
		},
		resetErrorBoundary: () => {}
	});
}
var i18nReady = false;
function ensureI18n() {
	if (!i18nReady) {
		setupI18n();
		i18nReady = true;
	}
}
/**
* 企微内 P0 早跳的目标 URL。只白名单透传 `corp` / `agent`：多企业专属链接
* `/login?corp=X&agent=Y` 从工作台打开时，后端 `resolveWecomProfile` 必须拿到
* 企业代码才能落到正确租户；不带参数会被 `corpSelf()` 吸到本企业，多家档案则
* 直接 400「已授权多家企业」。票据 / redirect / error 等一律不透传。
*
* 与 index.html 内联 BOOT_JS（build.mts）同口径——那道先执行，这里是兜底：
* 内联脚本被 CSP 拦下或抛异常时，模块加载完仍会走到这里。
*/
var EARLY_JUMP_PARAMS = ["corp", "agent"];
function wecomEarlyJumpUrl() {
	const src = new URLSearchParams(location.search);
	const pass = new URLSearchParams();
	for (const key of EARLY_JUMP_PARAMS) {
		const v = src.get(key)?.trim();
		if (v) pass.set(key, v);
	}
	const qs = pass.toString();
	return `${resolveApiBase()}/auth/wecom/login${qs ? `?${qs}` : ""}`;
}
function Boot() {
	const [router, setRouter] = useState(null);
	const [error, setError] = useState(null);
	useEffect(() => {
		let cancelled = false;
		(async () => {
			try {
				if (typeof navigator !== "undefined" && /wxwork/i.test(navigator.userAgent) && location.pathname.endsWith("/login") && !new URLSearchParams(location.search).get("wecom_ticket")) {
					window.location.assign(wecomEarlyJumpUrl());
					return;
				}
				ensureI18n();
				const base = resolveSiteBase();
				const [res, versionsRes] = await Promise.all([fetch(`${base}modules.json`), fetch(`${base}versions.json`).catch(() => null)]);
				if (!res.ok) throw new Error(`modules.json 加载失败：HTTP ${res.status}`);
				const list = resolveModuleUrls(await res.json(), base);
				const runtimeVersion = versionsRes?.ok ? extractRuntimeVersion(await versionsRes.json()) : void 0;
				if (!runtimeVersion) console.warn("[shell] 未获取到宿主 runtime 版本（versions.json 缺失），peerRuntime 校验跳过");
				assertTrustedModules(list);
				for (const mod of list) {
					if (mod.enabled === false) continue;
					for (const href of mod.css ?? []) if (!document.querySelector(`link[href="${href}"]`)) {
						const link = document.createElement("link");
						link.rel = "stylesheet";
						link.href = href;
						const firstStyle = document.head.querySelector("link[rel=\"stylesheet\"], style");
						if (firstStyle) document.head.insertBefore(link, firstStyle);
						else document.head.appendChild(link);
					}
				}
				for (const { href, integrity } of collectPreloads(list)) {
					if (document.querySelector(`link[rel="modulepreload"][href="${href}"]`)) continue;
					const link = document.createElement("link");
					link.rel = "modulepreload";
					link.href = href;
					link.integrity = integrity;
					link.crossOrigin = "anonymous";
					document.head.appendChild(link);
				}
				const manifest = toLoaderManifest(list, runtimeVersion);
				await hydrateUser();
				await loadAll(manifest);
				if (cancelled) return;
				shellRouter = createBrowserRouter([buildShellRoot()], { 
				/**
				* 子路径部署（oj `mounts: [{ prefix: /oj, web: dist, spa: true }]`）：
				* 不设 basename 时 react-router 看到的是含前缀的 `/oj/wiki/...`，
				* 匹配不到模块路由（`routes[].path` 恒为 `/wiki/...`，无模块根以外的
				* 前缀），深链刷新直接落 catch-all 404。取值同 modules.json 的
				* base（`resolveSiteBase()`），保证资源与路由用同一个前缀。
				*
				* 浏览器 URL 不受影响：react-router 只是在匹配/生成时剥/补前缀。
				*/
basename: base });
				setRouter(shellRouter);
			} catch (e) {
				if (!cancelled) setError(e instanceof Error ? e.message : String(e));
			}
		})();
		return () => {
			cancelled = true;
		};
	}, []);
	if (error) return /* @__PURE__ */ jsxs("div", {
		style: { padding: 24 },
		children: ["模块加载失败：", error]
	});
	if (!router) return /* @__PURE__ */ jsx("div", {
		style: { padding: 24 },
		children: "宿主初始化中…"
	});
	return /* @__PURE__ */ jsx(RouterProvider, { router });
}
/**
* 主题边界：ConfigProvider 响应 preferences 的暗黑/主色/圆角，与 App 链
* app.tsx 的 theme 计算同源同值（customAntd* 主题均为空对象，无需复制）。
* 此前硬编码 defaultAlgorithm——切暗黑后侧栏（tailwind dark: 类）变暗而
* antd 组件仍亮色，顶栏图标白色融进白底「消失」——playground 全量模块
* 暗黑对比（docs/prd/202609010056-playground-full-modules-plan.md）暴露。
*
* AntdApp 必须来自 @oj-module/runtime 而非 antd：runtime 版在 antd App
* 之上做两件事（设计 202609112121-shell-dark-css-vars-design）——
* ① 把 token 同步为 :root 的 `--oo-*` 变量（tailwind 语义色工具类的唯一
*   来源，缺则暗黑模式 footer 等透明露白）；② StaticAntd 挂载
*   window.$message/$modal/$notification。
*/
function HostProviders() {
	const { language, isDark, themeColorPrimary, themeRadius, sideCollapsedWidth } = usePreferences();
	return /* @__PURE__ */ jsx(StyleProvider, {
		layer: true,
		hashPriority: "high",
		children: /* @__PURE__ */ jsx(ConfigProvider, {
			locale: ANT_DESIGN_LOCALE[language],
			theme: {
				cssVar: {},
				hashed: false,
				algorithm: isDark ? theme.darkAlgorithm : theme.defaultAlgorithm,
				token: {
					borderRadius: themeRadius,
					colorPrimary: themeColorPrimary
				},
				components: { Menu: {
					darkItemBg: "#141414",
					itemBg: "#fff",
					collapsedWidth: sideCollapsedWidth
				} }
			},
			children: /* @__PURE__ */ jsx(ProConfigProvider, {
				intl: language === "en-US" ? enUSIntl : zhCNIntl,
				children: /* @__PURE__ */ jsx(AntdApp, { children: /* @__PURE__ */ jsx(QueryClientProvider, {
					client: queryClient,
					children: /* @__PURE__ */ jsx(Boot, {})
				}) })
			})
		})
	});
}
var rootElement = document.getElementById("root");
if (rootElement) createRoot(rootElement).render(/* @__PURE__ */ jsx(HostProviders, {}));
//#endregion
