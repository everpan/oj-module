{
  "alg": "Ed25519",
  "key_id": "platform.release",
  "public_key": "af47abfea1c735e29ed1a00e367fbfbfdfc2264262202dc1185f9af79ede358a",
  "value": "/DLWQjlkaCGmSzRsQtj+UaN+5J1W6OSC5nbPlFiRMua2FQEOmMfjNZsBL6/3wTjkhs4O6wk3QavVhg8IJDxyBA==",
  "canon": "v2",
  "registry_id": "oj-registry"
}
