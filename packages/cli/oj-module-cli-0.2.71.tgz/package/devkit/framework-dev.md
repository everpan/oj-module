# 框架贡献者路线（仅本仓）

> 读者：改 `packages/runtime/`、`packages/cli/` 的人。
> **业务工程里用不到本文件**——那些工程是「一棵源码树 + 一个配置」：
> `src/<模块>/{api,web}` + 工程根 `config.yaml`（历史布局为 `web/src` + `api/src`），
> 没有 `packages/`。业务开发看 `SKILL.md` + `manual.md`。

## §1 先读哪份文档

本仓已有详尽文档，**本文件不重复它们**，只做路由 + 补红线：

| 你要做的事 | 读 |
|---|---|
| 认证/路由/布局/store 怎么组织的 | `CLAUDE.md`（本仓根，架构总览） |
| 框架开发完整指南（契约层/运行时/宿主/工具链四章） | `docs/prd/framework-development-guide.md` |
| 端到端可重复验证流程 | `docs/prd/framework-verification-playbook.md` |
| 某特性的设计与评审记录 | `docs/prd/<日期>-<特性>-design.md` |
| 各阶段实战记录（骨架→注入→认证→CRUD→发布） | `docs/prd/framework-verification-playbook.md` 附录 A 基线表（playground 已下线） |
| 后端 handler 写法 | `docs/devkit/oj-api-dev/api-manual.md`（`oj-api-dev` skill 的本仓快照；用户工程侧在 `.claude/skills/oj-api-dev/`，随 oj 二进制分发） |

> **路径口径**：上表除 `CLAUDE.md` 与 `docs/devkit/oj-api-dev/` 外，都是**框架仓库内**的路径，
> 不随 `@oj-module/cli` 发货。本文件只对「能进框架仓库的人」有用——如果你是在 cli 包或
> 业务工程里读到这里，说明没有仓库上下文，那些链接按设计不可达，**不是坏链**：业务开发
> 请回 `SKILL.md` + `manual.md`。

> ⚠️ 那两份 guide 有**已知陈旧处**，以源码为准：
> dev 端口实际是 **3333**（guide 写的 5173 已过时；注意与 `ojm dev` 的前端 devServer
> **5174** 不是一回事——前者是本仓 vite，后者是业务工程 devServer）；包版本以
> `packages/*/package.json` 为准（本文件随 cli 发布，**不写死包版本号**——版本每轮 lockstep
> 都会变，写死必然漂移）。

## §2 两包结构与依赖方向

按运行环境切分，**只有一条边**：`cli → runtime`（`workspace:*`，发布时被
pnpm 改写成**精确版本**，不是 `^` 范围）。

| 包 | 面 | 内容 |
|---|---|---|
| `packages/runtime` | 浏览器 | 路由 / 布局 / store / 请求 / 组件 / module-loader，+ 契约 DSL 子路径（`./contract`、`./contract/errors`） |
| `packages/cli` | Node 工具链 | `ojm init/dev/build/preview/api/info/vendor/merge/install/enable/disable/uninstall/trust/keygen/sign/publish`，+ 预构建宿主（源码 `shell/`、产物 `shell-dist/`、模板 `templates/`、分发 devkit `devkit/`） |

- 宿主产物随 cli 发布；`ojm dev/build` 直接从 cli 包内 `shell-dist` 取宿主，
  不再依赖独立 shell 包或 monorepo 路径回退。
- **双入口别搞混**：给模块作者用的加在 `src/index.ts`；框架自己怎么启动看 `src/index.tsx`。
- `#src/*` alias 指向 `packages/runtime/src/*`（由 `packages/runtime/package.json`
  的 `imports` 字段与 vite alias **双声明**，即「模块仅 import 三类」不变式）。
- 业务工程**不打包宿主共享依赖**——宿主经 importmap 提供单例。例外是 `shared-deps.ts` 里
  标了 `bundle: true` 的重型依赖（echarts 家族 / vditor / @plane/editor）：宿主不提供，
  模块自带，见手册 §2.6。

## §3 常用命令

```bash
pnpm dev                  # 本仓开发服务器 http://localhost:3333
pnpm build                # vite build + 模块产物 + importmap 注入
pnpm test                 # vitest（happy-dom）
pnpm test:e2e             # playwright
pnpm typecheck            # tsc --noEmit
pnpm lint                 # eslint（Prettier 已禁用）
pnpm check:circular-deps  # 循环依赖检查（只扫 packages/runtime/src）
pnpm create:module        # 交互式新建模块向导

# 单包构建（改了 runtime 源码就必须跑）
pnpm --filter @oj-module/runtime build      # → dist/runtime.js + index.d.ts + contract/*
pnpm --filter @oj-module/cli build:shell    # 含 runtime 构建 + host.js + importmap + 共享资产
node packages/cli/scripts/sync-host-versions.mjs   # prepack 内容：同步 vendor/host-versions.json

# 定向测试
pnpm test tests/runtime                     # 运行时单测
pnpm test tests/runtime/runtime-exports.test.ts   # 出口冻结契约
pnpm test tests/cli                         # cli 全量（contract-* 含快照）
pnpm test tests/shell                       # 宿主全量
```

格式：**Tab 缩进、双引号、必须有分号**。`simple-git-hooks` + `lint-staged`
在 pre-commit 跑 ESLint；`commitlint` 强制 conventional commit。

## §4 红线（改动前必读）

### 4.1 四条通用红线

1. **宿主共享依赖只能有一个版本**：安装走 `catalog:`，产物走宿主（cli 内置
   `shell-dist`）importmap 单例。私自写死 `react@18` 会导致「双 React」崩溃。
   （`bundle: true` 的自打包档不在其列——它们本就由各模块自带。）
2. **`packages/runtime/dist`、`packages/cli/shell-dist` 随仓库提交**
   （`.gitignore` 为它们开了例外）。**改了源码必须重建并提交产物**，
   否则本地/CI 跑的是旧产物——历史上多次出现「方法不存在」。
3. **不要绕过门禁**：宿主的导出完整性检查、动态 require 检查、版本矩阵校验
   都是硬门，失败要查根因，别 `--no-verify` 或注释掉断言。
4. **改公开出口是破坏性变更**：runtime 出口有冻结契约测试
   （`tests/runtime/runtime-exports.test.ts`），加/删导出会让它红，属预期。

### 4.2 三道硬门禁（`assertSharedExportsComplete()`，任一不过直接构建失败）

1. **具名导出完整性**——否则浏览器抛 `does not provide an export named 'x'`（整页白屏）；
2. **裸说明符被 importmap 覆盖**——否则抛 `Failed to resolve module specifier`；
3. **无未垫片的动态 `require`**——否则抛 `Dynamic require of ... is not supported`。

> **构建成功 ≠ 能加载。** `export *` 经 external 子路径会退化成运行期对象
> （文件在、体积对、退出码 0，浏览器却白屏）。这就是门禁存在的原因。

### 4.3 新增一个共享依赖（三步，漏一处即红）

1. `packages/cli/src/shared-deps.ts` 的 `SHARED_DEPS` 登记 `{ specifier, asset, hard }`；
2. `pnpm-workspace.yaml` 的 `catalog` 登记版本；
3. 各包 `package.json` 改写成 `"catalog:"`（**不要写死版本**）。

漏改任一处，`tests/shell/host-version-drift.test.ts` 与
`tests/shell/version-gate.test.ts` 会红。

### 4.4 不变式索引

| 不变式 | 说明 |
|---|---|
| scoped request 在 onInit 绑定 | `onInit` 里绑定 scoped request |
| 契约前缀字面相等 | 路由前缀取 `manifest.yaml` 的 `name`（0.1.85 起与目录名脱钩）；uni-dev 历史形态下 `apiPrefix` 必须字面等于目录名 |
| 模块仅 import 三类（`#src` 双声明） | `#src/*` 由 package.json `imports` 与 vite alias 双声明 |
| 模块元信息从 entry.ts 解析 | 模块 name/version 从 `entry.ts` 解析（esbuild bundle + 真实 `import()`） |
| 生产产物不含 fake | 生产构建不含 fake 代码（**有测试断言产物里无 fake**） |
| 模块级权限路由注入前过滤 | 模块级 `requiredRoles` / `requiredPermissions` 在路由**注入之前**筛掉 |
| 布局显式声明 | 布局显式声明，不做隐式推导；模块不 import 布局组件 |
| 请求前缀收敛 | `ctx.utils.request` 只拿按 `apiPrefix` 收敛的 scoped client；越界、`../` 穿越、逐请求 prefix 覆盖均被拒 |
| 内置异常后备页 | 框架内置 `/exception/403\|404\|500` 后备页；exception 模块仅为可选覆盖 |
| 宿主 runtime 版本锁等 | prepack 断言宿主 runtime 版本 == `packages/runtime` 版本 |
| merge 合并多团队清单 | `ojm merge` 合并多团队清单 |
| 站点 base 单点 | 部署前缀只从 `resolveSiteBase()`（`window.__OJ_BASE__` → `BASE_URL`）取；runtime 里禁止再读 `import.meta.env.BASE_URL` |

### 4.5 守卫测试索引（改动后知道哪个会红）

| 测试 | 守护内容 |
|---|---|
| `tests/runtime/runtime-exports.test.ts` | runtime 出口冻结（加/删导出即红） |
| `tests/module/module-package-imports.test.ts` | 模块只 import 三类东西（「模块仅 import 三类」不变式） |
| `tests/module/module-required-roles.test.ts` | 模块级权限路由注入前过滤 |
| `tests/runtime/scoped-request.test.ts` | 请求前缀收敛（scoped client） |
| `tests/shell/no-fake-in-dist.test.ts` | 生产产物不含 fake |
| `tests/shell/shell-importmap.test.ts` | 门禁一致性 + runtime.js 与包 dist 一致 + 深路径回归 |
| `tests/runtime/site-base.test.ts` | 站点部署 base 单点：`import.meta.env.BASE_URL` 只许出现在 `utils/site-base.ts` |
| `tests/cli/site-base.test.ts` | 三份 base 实现（runtime / shell / cli）逐条对撞 + `index.html` 重写与 `__OJ_BASE__` 注入 |
| `tests/shell/site-urls.test.ts` | 宿主清单 entry/css/chunks 补部署前缀（子路径部署不白屏） |
| `scripts/verify-subpath.mjs`（`pnpm verify:subpath`） | 子路径部署 **e2e**：真构建 + 真 `oj serve`，核对 importmap／`__OJ_BASE__`／modules.json／深链刷新／零回归字节一致 |
| `tests/shell/host-version-drift.test.ts`、`version-gate.test.ts` | 共享依赖三处同步 |
| `tests/cli/release-manifest.test.ts` | 真跑 `pnpm pack`，守护 `workspace:*` → 精确版本改写 |
| `tests/cli/__snapshots__` | 契约代码生成快照（改 `.schema` 发射规则需同步更新） |

## §5 发布（lockstep，别用 npm publish）

**一键发布**：`node scripts/publish-packages.mjs`（lockstep 门禁 → 构建 → 守卫测试 →
runtime → cli → registry 复核；`--dry-run` 只演练）。下面的手动步骤是它的展开参考。

- **两包**同版本号（`@oj-module/runtime` + `@oj-module/cli`，两处 `package.json` 恒等），后续发版保持
  lockstep；`@plane/kit` / `@plane/editor` 不在发布集内（脚本里已注释）。
- **必须 `pnpm publish`**——用 `npm publish` 会漏出 `workspace:*` / `catalog:` 字面量。
- **顺序：先 `runtime` 后 `cli`**。`runtime` 未公开时，新 `cli` 的精确依赖会悬空，
  消费者直接装不上。
- 发布后**立刻**读 registry 可能仍是旧版本/404（CDN 传播延迟，实测约 90s）。
  最可靠的确认是**再发一次同版本**——返回
  `403 You cannot publish over the previously published versions: x.y.z` 即已成功。
  `npm view` 读镜像可能一直 404，别用它判断。
- `package.json#files` 的**取反有顺序语义**：`"!shell-dist/**/*.map"` 必须排在
  `"shell-dist"` **之后**才生效（排前面等于没写，包体 3.85MB → 10.8MB）。
  `files` 白名单内的文件无法被 `.npmignore` 排除。

## §6 本仓工作纪律

1. **文档先行**：先写计划/任务/需求/用例文档，保存后才动代码。
   文档命名 `日期+时分` 前缀，带序号时用 `phase1`/`round1`。
2. **TDD / BDD**：用例先红后绿；文档优用 BDD markdown，多条件测试编数据表格。
3. **一次逻辑一个分支**：实现或重构前先建分支。
4. **发现反常规/反常识/与业界不符的问题**，当场追加到文档并分类记录。
5. **完工更新任务状态 + 写小结段**（关键过程与耗时）。

## §7 接入发布链路（已完成）

本 devkit（`docs/devkit/`）已接进发布链路，业务工程 `ojm init` 自动拿到：

- `packages/cli/scripts/sync-devkit.mjs`（cli 的 `prepack` 第一步）：把仓库
  `docs/devkit/` 归置进 cli 包 `packages/cli/devkit/`，随 `@oj-module/cli` 发布
  （`package.json#files` 白名单已含 `devkit`）；
- `packages/cli/src/init.ts` 第 4b 步：从 cli 包内置 devkit 多拷一份到
  工程的 `.claude/skills/ojm-module-dev/`（连同企微两本手册与发布 walkthrough，共 6 个文件；
  已存在则幂等跳过）。`framework-dev.md` / `menu-rules.md` / 教学文档 / SQL 构造器 PR 记录
  只随 cli 包、不进业务工程——它们是框架贡献者或专题材料，`ojm init` 有意不分发。

`packages/cli/devkit/` 是发布副本、由 prepack 生成，已加进 `.gitignore` 不入库；
源仍是仓库 `docs/devkit/` 顶层，改文档只动那里一处。

> `docs/devkit/oj-api-dev/` 是 **oj 侧 devkit 的快照**（12 个文件，与
> `~/.local/share/oj/devkit/` 逐字节一致），仅供本仓 grep 后端手册，
> **不随 cli 包发货**（`sync-devkit.mjs` 只同步顶层文件）——用户工程的
> `oj-api-dev` skill 由 oj 二进制分发。升级本机 oj 后要同步快照：
> 从 `~/.local/share/oj/devkit/` 整目录覆盖该子目录。

> 历史记录：此处原为「待对接（未做）」，上述两步落地后即完成。

---

## 附：本 devkit 内容来源（维护者看）

`docs/devkit/` 是**自包含**的交付文档（顶层 12 个文件，全部随 cli 包发货，其中 6 个随
`ojm init` 进业务工程；含 `sql-builder-missing-capabilities-pr.md` 这份构造器能力缺口 PR 参考），
业务工程拿到即可读懂，不依赖工程仓库里的其它文档。
另有 `oj-api-dev/` 子目录是 oj 侧 devkit 的快照（oj v0.1.116 起 12 文件，仅本仓参考、不发货），
结构说明见 `README.md`。
下面的来源仅用于维护时追溯与同步，不参与交付：

| 源（本仓其它位置） | 贡献到 devkit 的内容 |
|---|---|
| `docs/202609130035-provider-guide.md` | provider 接管（覆盖框架内置功能）、案例、踩坑表、排查清单 |
| `docs/prd/ojm-api-codegen-guide.md` | 契约 → client 生成管线、`--check` 对账、豁免清单 |
| `docs/prd/oj-fullstack-tutorial.md` | 端到端上手流程 |
| `docs/prd/202609130128-client-factory-design.md` | `create<Module>Client(ctx)` 工厂语义 |
| `apps/playground-oj/docs/phase*.md` | 各阶段实战记录 |
| `packages/cli/templates/` | 可直接抄的模板形状 |
| `docs/prd/framework-development-guide.md` | 框架贡献者路线（本文件） |

改 devkit 内容时，若对应来源文档也变了，注意双向同步；反之在 devkit 里已改写为自包含表述的，以 devkit 为准。
