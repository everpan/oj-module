# 开发态模块与本地 CDN 演练场

> 一篇写给「第一次在本工程开发模块」的人的教学文档。读完之后你应该能回答三个问题：
> **① 开发中的模块要不要「安装」？② 要的话装到哪、会不会重复？③ 怎么在本地把市场链路完整跑一遍？**
> 适用版本：`@oj-module/cli` 0.2.12+（`ojm market` 子命令），运行期 `oj` ≥ 0.1.73。
> 本文按**当前模板的 module-root 布局**书写（`src/<模块>/{api,web}` + 工程根 `config.yaml`），
> 建新工程另需 `oj` ≥ 0.1.85（`--module-root`）。历史布局（`api/src` + `web/src`）对照写在括注里。

## 1. 先建立心智模型：开发态 ≠ 分发态

整个体系里存在**两套互不相干**的模块生命周期，混在一起是绝大多数困惑的来源：

| | 开发态 | 分发态 |
|---|---|---|
| 模块在哪 | 工程内源码：`src/A/api` + `src/A/web`（历史布局：`api/src/A` + `web/src/A`） | 一个 `.tgz` 包（`ojm build --bundle` 产出） |
| 谁登记它 | `ojm build` 扫描 `src/*/web/entry.ts`（`web.config.ts` 可选覆盖）→ 生成 `web/dist/modules.json` | 安装器往目标站点 upsert |
| 跑起来靠 | `ojm dev` 直跑源码，改一行刷新即见 | 安装器十阶段（下载→验签→解压→迁移→注册→热更→冒烟） |
| config 读哪份 | tracked `config.yaml` + gitignored `config.local.yaml` 深合并成 `.ojm-tmp-config.yaml`——dev 与 build 同一条链路，jwt 被本机 dev 密文覆盖 | 产物不嵌 config，部署侧自带自己的 config（tracked prod `ENC[...]` 那份） |
| 典型场景 | 你在写它 | 别人（或另一个站点）装它 |

一句话：**开发态没有「安装」这个动作**。`ojm dev` 起的站点直接扫描 `src/` 产生路由（`oj build --module-root src`）、读 `modules.json` 装配菜单——你写的模块 A 此刻「已经在跑」，只是还没打过包。

## 2. 常见问题：我开发了模块 A，怎么「安装」我自己？

### 2.1 正确答案：装到别处，不是装进你正在开发的工程

「安装自己」听起来矛盾，是因为安装这个动作的语义是**把一个包的分发产物并入一个宿主站点**。你正在开发的工程就是 A 的家，再装一遍相当于把家具搬进它已经在的屋子。

真正想验证「A 这个包能不能装、安装流程对不对」时，有三个去处，按推荐顺序：

1. **一次性隔离站点**：`ojm market trial --fixture <name>@<version>`（随机端口 + 一次性 DB + 一次性密钥 + 隔离信任库/CDN），跑完即毁，不碰你的工程、DB、信任库。这是唯一「装了也不心疼」的地方，也是最快的「这包能不能装」判据（实测 11 段全 ok 约 12 秒）。
2. **另一个工程**：`ojm install dist/A-0.1.0.tgz`（file 源，multipart 直传；`dist/` 是 `--bundle` 的默认输出目录，与后端产物 `api/dist` 无关）。
3. **市场链路**：`ojm market publish` 落 CDN → 市场页点安装（§4 全套）。

### 2.2 偏要在本工程试怎么办

先 `ojm uninstall A` 再装，且升级走安装器的重装路径、不要手工覆盖同版本文件。理由见 §3.3 的「遮蔽」。

## 3. 常见问题：装完之后路由、菜单会重复吗？

**不会重复——注册面全是 upsert（按键覆盖），不是 insert（追加）。** 但有两个坑，分开说。

### 3.1 upsert 语义：同键只有一份

| 面 | 键 | 重复安装时发生什么 |
|---|---|---|
| 路由 `sys_solution_route` | `path` | 同 path 覆写元数据、下架标记复位 |
| 角色 / 权限 | 模块 + code | 按键 upsert；**本次未声明**的条目标记下架（行保留、不删） |
| 系统设置 `sys_setting` | `key` | 按 key upsert，但**管理员改过的值永不复活** |
| `modules.json` | 模块名 | 按模块名登记，唯一条目 |

所以「菜单出现两条 A」这种事不会发生——菜单条目按模块名唯一。

> **角色名自带翻译（0.2.57 起）**：`roles[].title_key` 落库前按站点语言解析成可读文本存
> `sys_role.title`，原始 key 另存 `sys_role.title_key`。要求：key 形状 `<模块名>:role.<slug>`
> （ns 必须等于方案模块名），且两个 locale 文件里都有嵌套 key（`{"role":{"sales":"销售"}}`）。
> 解析数据源是包内 `web/modules/<name>/locales/`——`build --bundle` 自动从源码复制双语，
> 作者零动作。key 缺失/文件缺失 → title 存裸 key，**安装永不因此失败**；改 locale 文案后重新
> 打包升级，角色名即随升级更新。
>
> **权限点标题同理落库（0.2.68 起）**：`permissions[].title_key`（契约必填）随行落库
> `sys_permission.title_key`（此前只校验不落库、展示页回退裸 code）；升级元数据覆写与
> deprecated 重声明复位与角色同纪律。声明面/管理面/多语言全景见 devkit 手册 §11.5。

### 3.2 但同名再装会被直接拒

安装前置校验有**方案名唯一**约束：同名方案已装 → 拒装并报占用者版本（`方案名已被已装方案「A@x.y.z」占用`）。只有升级 / 重装路径放行。这是第一道防线：从入口就不给你制造重复的机会。

### 3.3 真正的坑：两个来源抢同一个 name/path（遮蔽）

注意 §3.1 的 upsert 是**按 name/path** 而不是按来源。于是存在这种状态：

> 你源码里的 A（`src/A/api`，路由由 oj 扫描源码产生）和某次安装产物 `api/dist/A-0.1.0/` 同时存在。

表现是：路由与模块条目各自只有一份（不重复），但**哪一份生效取决于挂载命中顺序**——症状为「我改了源码却不生效」或「行为怎么都不对」。这是本主题下最难查的一类问题：没有报错、没有重复，只是「被另一个自己顶替了」。

**规避方式**：别让两个来源同时在场。日常开发不装；试装去隔离站点；本工程试过之后 `ojm uninstall A` 清干净再回到源码直跑。

## 4. 本地 CDN 演练场：把市场链路完整跑一遍

模板自带一个**本地模拟 CDN**（工程根 `cdn/` + 工程根 `config.yaml` 里的 `/cdn` 挂载），配上 `ojm market` 四条命令，就能在本地复刻「发包 → 上架 → 索引 → 安装」全链路。不需要外部服务。

### 4.1 全流程（五步，step 1 已省）

```bash
# 0) 起站点（dev 或 serve 均可）
ojm dev

# 1) 【免 setup】脚手架 seed 的 framework.market_cdn_url 缺省即 /cdn（本站点自供，
#    dev 形态 ojm 已把 /cdn 反代给 oj 子进程）。只有指向外部真 CDN 时才需要：
#    ojm market setup --user superadmin --pass aA123456 --new-pass <你的口令>

# 2) 发包：合成 fixture（或 --real 走 ojm build --bundle）→ 确定性 tgz → 包级签名
#    本机演练走本地落盘面；对真站点发布加 --site-url 即远端签名推送
ojm market publish --fixture demo-solution@0.1.0 --id <发布方id>

# 3) 离线验包：不起站点、不装、不要凭据
ojm market verify --file cdn/demo-solution-0.1.0.tgz

# 4) 浏览器打开市场页 → 看到卡片 → 点安装
#    首次遇陌生发布方会停在「待信任」→ ojm trust confirm --task <id> → 重试即成
```

每条命令的边界：

| 命令 | 做什么 | **不**做什么 |
|---|---|---|
| `market setup` | 写系统设置 `framework.market_cdn_url`（**外部真 CDN 场景才需要**；脚手架缺省 /cdn 免 setup） | 不改写工程根 `config.yaml`（`/cdn` 挂载由模板自带） |
| `market publish` | 本机演练：落 `<name>-<version>.tgz` + 包级 `.tgz.sig`；加 `--site-url` 则远端签名推送（`.sig`/`.tgz` 按序推，pair 约束） | 不经账号口令（签名头 + 信任库）；同字节重传幂等 |
| `market verify` | 单包校验：manifest 结构 / 包级签 / 契约-迁移一致性 | 不起站点、不装、不访问任何远端 |

### 4.2 为什么目录归站点库而不是共享索引文件

文件索引时代的教训：publish 读-改-写共享索引，后发者会覆盖前者的签名且有竞态；索引签名
只是完整性层不是信任锚。现在的答案是把目录降级成站点的**派生数据**：签名推送完成时由
服务端直写目录库（`market_release` 行），安装解析直读该库——没有共享可变文件，天然支持
多人并发，重放同字节幂等；存量包/灾备恢复由站点 `POST /api/oj-market/backfill` 扫描
`cdn/` 自愈。

### 4.3 信任模型（30 秒版）

- **包级签名**（`<tgz>.sig`，Ed25519）：信任锚。安装时逐字节验，不过即拒（fail-closed）。
- **索引签名**：完整性层。索引被改能发现，但**不背书内容安全**。
- **TOFU**：首次遇到未登记的发布方 key，安装停在待信任状态，管理员确认后写入信任库；首次绑定不可改。
- `market verify` 的结论恒带一句边界声明：**校验通过只说明来源与完整性，不构成内容安全性背书**——这不是免责套话，是信任模型的准确描述。

## 5. 两个已经踩过的坑（别再踩）

### 5.1 dev 形态下，`/cdn` 由 oj 子进程直出（ojm 已代为反代）

`ojm dev` 的 Node 服务在 **5174**，把 `/api` 与 `/cdn`（config 有 `/cdn` 挂载时）一并反代给 oj 子进程；`/cdn` 是 **oj 的挂载**，直出工程根 `cdn/`。`framework.market_cdn_url` 写成相对路径 `/cdn`（seed 缺省值）时，服务端按**请求源**补全同源绝对 URL 再拉取——dev 下请求走 5174，反代链路内透传，拿到的是真索引。2026-10-23 之前 dev 只反代 `/api`，相对基址会拿到静态层回落的 index.html（难懂的 YAML 解析错）——该坑已由 dev 反代 + 消费侧 `withSiteOrigin` 补全闭环。历史上下文：`market setup` 写绝对地址（`http://<host>:<config server.port>/cdn`）依旧兼容可用。

### 5.2 安装验签的数据源是站点目录行

安装器的验签段认目录库行里的签名四列（由签名推送完成时服务端从 `.sig` 旁车写入）。
CDN 目录里只摆 `.tgz.sig` 侧车、库里没有对应行，就是 `sig_missing` 硬拒——所以规范动作是
**publish 把 pair 推完整**（`.sig` 先行 `.tgz` 后至，服务端配对成功才写行）；
存量包/灾备恢复由站点 `POST /api/oj-market/backfill` 扫描 `cdn/` 把旁车读进库补齐。

> 附注：曾有一条「包内 `api/<mod>/manifest.yaml` 的 desc 必须逐字等于方案 summary」的校验，已于 2026-10-21 移除——那是构建期映射被当成安装期契约，而 desc 只是模块描述文本、非安全边界。现存相关校验只有：`summary` 必填、`desc` 必填非空。

## 6. 实战：发一个真方案，并躲开七个坑

上面的 fixture 路径能秒出可装包，但真实交付要么写方案工程、要么至少知道真构建长什么样。下面是
2026-10-21 一次**完整演练**（宿主 `ojm init` → 方案工程 → 打包签名 → 发布 → 安装 → TOFU → 装成）
沉淀下来的路径与坑。演练两轮全绿（换全新宿主零手工补丁复跑同样通过）。

### 6.1 方案工程最小形态

```text
solution-demo/
├── manifest.yaml                       # 方案契约清单（Form A，恒在工程根）
└── src/<name>/
    ├── api/
    │   ├── manifest.yaml               # oj 原生清单（name/desc/version/tables）
    │   ├── schema.yaml                 # 表结构真源（必须与 manifest.tables 对齐）
    │   ├── routes.js
    │   ├── migrations/0001__init.sql
    │   └── ping/api.ts                 # handler 必须是 .ts
    └── web/
        └── locales/{zh-CN,en-US}.json  # 引用 i18n key 时必需
```

> 历史布局把这棵树换成 `api/src/<name>/…` + `web/src/<name>/locales/…`，构建命令里的
> `--module-root src` 换成 `-d api/src`（两者互斥，都是「源码树根」）。布局判定看标记文件
> 而不是目录名：`src/<name>/api/manifest.yaml` 或 `src/<name>/web/entry.ts` 存在即成模块。
> 方案工程若由 `ojm init` 起（会带工程根 `config.yaml`），构建时加 `-c config.yaml`。

```bash
<host>/bin/oj build --module-root src -o api/dist   # 后端构建（只用宿主已装的 oj）
node "$CLI_PKG/bin/ojm.mjs" build --bundle          # 打包（构建即校验）
node "$CLI_PKG/bin/ojm.mjs" keygen --id demo.publisher --out ./keys --yes
node "$CLI_PKG/bin/ojm.mjs" sign dist/<name>-<version>.tgz --id demo.publisher --key ./keys/private.pem --check
```

### 6.2 发布与安装（release 形态）

```bash
cd <host>
node "$CLI_PKG/bin/ojm.mjs" market publish --real ../solution-demo --site-url http://127.0.0.1:9778 --id demo.publisher --registry-id <站点 registry_id>
node "$CLI_PKG/bin/ojm.mjs" market verify --file cdn/<name>-<version>.tgz

node "$CLI_PKG/bin/ojm.mjs" build                 # 生成 api/dist + web/dist（含 api/dist/versions.json）
# config：platform.root 改成 api/dist（安装目标恒为 release 部署，root 必须与 --api-path 同源）
(bin/oj serve -c config.yaml -b /api --api-path api/dist --console-log &)
node "$CLI_PKG/bin/ojm.mjs" market setup --site-url http://127.0.0.1:9778 --user superadmin --pass aA123456 --new-pass <新口令>
# 市场页点安装 → 首次停在「待信任」→ 核对指纹 → ojm trust confirm --task <id> → 重试 → done
```

### 6.3 七个坑（按撞见顺序）

| # | 现象 | 根因 / 正确做法 |
|---|---|---|
| ① | `oj build` 报 `tables 声明 "x" 不在 schema.yaml` | oj 用 `schema.yaml` 做表结构真源，`manifest.tables` 只是引用面；补 `schema.yaml`（`tables: {<t>: {pk, columns}}`），与迁移语句对齐 |
| ② | `oj build` 成功但 `routes.js` 是空表、dist 里没有 handler | **只编译 `.ts` handler**；写成 `ping/api.js` 会被静默丢弃 → 改 `api.ts`。另一同形坑（构建也零报错）：`api.ts` 写成裸具名导出（`export async function ping`）——oj 内省只读 **default export** 且链尾动词须在 METHODS 白名单（get/post/put/del/patch/head/options），裸导出的函数根本不在表里 → 改成 `const ping = { async get() {...} }; export default { ping }`（`ojm new --api` 骨架即此形状） |
| ③ | `build --bundle` 报 `缺少 src/<name>/web/locales/…`（历史布局是 `web/src/<name>/locales/…`） | manifest 一旦引用 `title_key`/`label_key` 就必须双语 locale（后端方案也要）；且 key 必须**嵌套** `{"menu":{"main":"…"}}`，平铺 `"menu.main"` 查不到 |
| ④ | 安装 POST 返回 200，但 `market/task` 恒 404 | 宿主 config 缺 `fs:` 段 → 安装器落盘被 jail 拒、失败发生在任务文件写入前；0.2.13 起模板自带，旧工程手补 |
| ⑤ | 安装卡 `preflight`：`无法读取宿主 runtime 版本` | 安装器读 `api/dist/versions.json`；0.2.13 起 `ojm build` 双落点（旧版手抄 `web/dist/versions.json`） |
| ⑥ | 安装卡 `reloading`：`NotCapable: module '_platform' is not platform-privileged` | 宿主 config 的 `platform.modules` 未列 `_platform`（0.2.13 起模板自带） |
| ⑦ | 安装卡 `reloading`：`reloadConfig 返回 unchanged` / 卡 `smoke`：探活 404 | 起站形态不对：`ojm preview` 服务派生 config（安装器热更写的是真实 config，派生文件没变）；dev 用 `--module-root src`（历史布局 `--api-path src`）读源码，装到 `api/dist` 的模块不被发现。**安装必须对真实 config 以 `--api-path api/dist`（历史布局 `--api-path dist`）起站** |

### 6.4 装成之后怎么确认

```bash
curl -s http://127.0.0.1:9778/api/<name>/ping        # {"code":0,...pong...}
cat api/dist/manifests.yaml | grep <name>            # <name>: <version>
ls api/dist/<name>-<version>/                        # 安装产物目录
```

## 7. 一页速查

```text
写模块      → 源码直跑（ojm dev），不要装
验证能装    → ojm market trial（隔离站点，12s），或 ojm install <tgz> 到另一个工程
重复？      → 不会。注册面全 upsert；同名再装被前置校验直接拒
市场链路    → setup（外部真 CDN 才需要）→ publish（远端签名推送）→ verify → 市场页安装（release 形态：--api-path api/dist）
绝对 URL    → 市场地址端口取自 config（9778），不是 dev server 的 5174
信任        → 包级签=锚，目录行签名四列=完整性，TOFU 管陌生发布方，verify 不背书内容安全
```

## 8. 延伸阅读

- 方案打包与分发全貌、签名与信任：本 skill 的 `manual.md` §11–§12
- 后端 handler 写法、站点挂载（`mounts`）等：`oj-api-dev` skill 手册
