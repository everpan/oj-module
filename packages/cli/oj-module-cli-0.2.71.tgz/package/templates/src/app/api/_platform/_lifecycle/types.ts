// 生命周期编排面类型收敛（P1-10）：InstallContext 自 steps/preflight.ts 迁入（含可选 hostVersions，
// C2-09 比对真源注入位）；StageResult 收敛为全 stage 通用结构形状（各 step 模块保留自己的字面量
// stage 窄类型，结构相容即可赋值）；十阶段 InstallStage 名 = 契约附录 A 逐字（lock_commit 为
// D11①扩展组）；TaskRecord = 注册设计 §10.2 形状 + stages 明细日志 + appliedSeq（对账 floor 依据）。

import type { StateStore } from "./state";

/** 安装上下文（各 step 模块 ctx 的公共基座；依赖注入面经各 step 的 ctx 扩展，见 steps/*） */
export interface InstallContext {
	/** 已解析的 manifest.yaml（安装器读盘解析产物） */
	manifest: unknown
	/**
	 * 包内 oj 原生清单（C2-31 复核解析产物；引用式 solution 的 tables/deps 真源）。
	 * web-only 包（无 api 段）保持 undefined；引用式方案的依赖装配据其回读（R2.2）。
	 */
	nativeManifest?: unknown
	/** 安装目标身份（与 manifest.name/version 同源；manifest 字段缺失/非字符串时兜底） */
	name: string
	version: string
	/** 站点 sidecar 状态（.solutions/state.yaml）；占用检测真源：solutions 键 = 已装方案名 */
	state: StateStore
	/** 宿主 versions.json（C2-09 peerRuntime 比对真源；键 = 包名，runtime 取 @oj-module/runtime） */
	hostVersions?: Record<string, string>
	/** 宿主平台编排面 API 版本（C2-11 peerPlatform 比对真源；镜像 GET /api/oj-market/meta 的 apiVersion，即 market/api.ts 的 API_VERSION 常量，与 _platform/manifest.yaml 版本手工同步） */
	hostApiVersion?: string
	/**
	 * 宿主能力集（P0 §3.9：ojInfo().capabilities，装配期冻结、任何模块可读）。由调用方从 ojInfo 注入；
	 * 与 manifest.requiresCapabilities 配对做写锁前门禁。缺省 undefined = 宿主未上报，
	 * 此时若模板声明了 requiresCapabilities 则 fail-closed（视为能力缺失）。
	 */
	capabilities?: string[]
	/**
	 * 站点 config.yaml 已存在的 auth.anonymous_paths（P0 §3.2 质辩1 / E8：装前残留匿名检测真源）。
	 * 由调用方在 preflight 前读 config 注入（preflight 保持只读 ctx 的纯校验段纪律）；缺省 [] 视为无残留。
	 */
	existingAnonymousPaths?: string[]
	/**
	 * 本次热更返回的待重启段（reloading 段捕获自 reloadAndAssert；非空 = 部分生效、需宿主重启后完全生效）。
	 * installer 终态判定据其标 partial + restartRequired（无守护形态，P0 §3.6 / 验收 15）。瞬态，不落盘。
	 */
	restartPending?: string[]
	/** 目标站点数据库句柄（本段不消费；P1-8 register 段起使用） */
	db?: unknown
	/**
	 * 同名重装/升级放行位（P1-10，AC-P1-3）：安装器检测到 sidecar 已有同名方案时置位——
	 * 同名命中是本方案自己的升级路径（升级/降级 = runInstall({version})，任务简报），
	 * 跨方案碰撞仍由 apiSeg/route_prefix 首段占用兜住；缺省 false 保持 P1-5「同名拒装」钉面。
	 */
	reinstall?: boolean
	/**
	 * 强制热更（oj 0.1.123+ reloadConfig(force)）：绕过「unchanged=已是最新装配」幂等短路，
	 * 强制触发一次重装配——运维显式重装配用，不依赖锁 diff / 文档 sha 变化。缺省 false。
	 * 仅供 install 路径消费（reloading 段透传给 reload 面）；uninstall 恒严格（忽略 force）。
	 */
	force?: boolean
}

/** 阶段结果（全 stage 通用结构形状；stage 取值为各 step 自己的字面量，编排层以 StageDef.name 为准） */
export interface StageResult {
	stage: string
	ok: boolean
	message: string
	retryable?: boolean
	/** 取消安装（U5，P3-8）：本 stage 被用户中止，运行器据其走「清场 + 锁/目录回退装前 + 审计末位」语义 */
	cancelled?: boolean
	/**
	 * 终止态错误码（installer 据此置 task.error.reason；各 step 自带字面量集合——签名六码见 SigCode、
	 * 保留名 reserved_name、体积闸 package_too_large 等；统一收敛为 string 供编排层记录与 i18n 兜底）
	 */
	code?: string
	/** 未知 key_id 待 TOFU 确认：任务停 needs_trust 终态，staging 不清场供确认后重试 */
	needsTrust?: boolean
	/** 待确认的发布方 key（TaskRecord.trust 同源；UI/CLI 展示指纹） */
	trust?: { key_id: string, public_key: string, fingerprint: string }
}

/**
 * 签名失败六码（契约 v1.3 附录 A.2，P2-3）：retryable 恒 false、零解压零落盘。
 * 文案 key = `lifecycle.stage.verifying.<code>`（双语值 P2-5 落 locales）。
 */
export type SigCode = "sig_missing" | "sig_alg" | "sig_key" | "tampered" | "signature_mismatch" | "canon_stale" | "canon_mismatch" | "unknown_key" | "sig_format";

/**
 * 安装阶段名（契约附录 A 十阶段逐字 + D11①扩展组 lock_commit + audit/done 终态）。
 * 附录 A 文案 key：`lifecycle.stage.<stage>.reason/.hint/.retryable`（audit 失败仅记日志不设 key）。
 */
export type InstallStage = "preflight" | "downloading" | "verifying" | "extracting" | "migrating" | "lock_commit" | "registering" | "deploying_web" | "reloading" | "smoke" | "audit" | "done";

/**
 * 任务状态（§10.2 三态 + partial：锁后失败部分生效——D11 失败语义② + needs_trust：
 * 未知发布方 key_id 待人工 TOFU 确认——P2-3 第五终态，预锁段停止、staging 不清场，
 * 确认入信任库后重试同一安装即可继续；一切消费面须把 needs_trust 当非成功态渲染）。
 */
export type TaskStatus = "running" | "done" | "failed" | "partial" | "needs_trust";

/** 安装任务记录（§10.2 + stages 明细日志；落 .install-tasks/<id>.json，800ms 轮询消费面） */
export interface TaskRecord {
	/**
	 * 记录 schema 版本（P2-10）：写方盖章（tasks.ts TASK_SCHEMA_VERSION）、读方回填（缺省=1，旧记录不炸）。
	 * 升版纪律——加字段=minor（兼容：读方忽略未知字段）；改语义/删字段=major（不认识的高版本，
	 * 读方须降级提示：人话提示 + 不误渲染成功）。与 CLI 侧 site.ts TASK_SCHEMA_VERSION_KNOWN 手工同步。
	 */
	schemaVersion?: number
	id: string
	name: string
	version: string
	status: TaskStatus
	stage: InstallStage | null
	/** 0-100 整体进度（按 STAGES 表完成数折算） */
	progress: number
	message: string
	/** 各 stage 明细日志（UI 详情日志区数据源；补偿子步形如 `compensate.<step>`，故 stage 为 string 而非窄类型 InstallStage） */
	stages: { stage: string, ok: boolean, message: string }[]
	/** 失败/partial 终态：reason + retryable + 指引文案 key（契约附录 A） */
	error?: { reason: string, retryable: boolean, hintKey?: string }
	/** needs_trust 终态：待确认的发布方 key（POST /market/trust {task_id} 消费；指纹供人确认） */
	trust?: { key_id: string, public_key: string, fingerprint: string }
	startedAt: number
	finishedAt?: number
	/** 本次迁移 applied max seq（migrating 段捕获；reconcile 账本对账 floor 依据） */
	appliedSeq?: number
	/** 取消安装标记（U5，P3-8）：用户中止触发的终态（status 仍取 failed/partial——D11 共用失败终态，此标记供 UI 区分「取消」与「失败」） */
	cancelled?: boolean
	/** 无守护形态部分生效标记（P0 §3.6 / 验收 15）：热更返回待重启段非空、且无 supervisor 自动换进程 → 装完仍须宿主重启才完全生效。UI 据其展示「重启提示」而非「成功」 */
	restartRequired?: boolean
}
