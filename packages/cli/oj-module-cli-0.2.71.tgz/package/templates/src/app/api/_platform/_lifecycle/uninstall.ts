// 卸载编排器（P1-15a，SRP/OCP）：与 installer.ts 对称——安装 = runInstall，卸载 = runUninstall。
// 端点（market/api.ts）只做门禁 + 取参 + 调本编排器，不重复编排（与 install 同纪律）。
// 删除纪律（D12 反向，与 setEnabled 四处同写对称）：①锁摘除 ②sidecar 删条目 ③sys_solution_route 删
// ④modules.json 删条目；另：权限唯一减法出口 uninstallSolution（双维度级联，solution-perms.ts）；
// 版本目录移除；终态审计 + 全用户失效（权限已变，D10 撤销即强退）+ market_history 留痕。
// 空锁拒启（S1-1.2）：摘除后锁为空 → 拒绝卸载最后一个模块（站点至少保留一个已锁模块）。
// 任一步失败返回 {ok:false, message}（与 setEnabled 同纪律）；部分残差由 admin 重试或重装自愈。
// SQL 全部参数化（与 audit.ts / setEnabled 同纪律，值不拼字符串）。

import type { OpEntry } from "../_shared/service/infra/audit";
import type { StateStore } from "./state";
import type { ReloadFace, ReloadResult } from "./steps/reload";
import { uninstallSolution } from "../_shared/service/domain/solution-perms";
import { invalidateAllUsers } from "../_shared/service/infra/access";
import { auditOp } from "../_shared/service/infra/audit";
import { atomicWriteText, fsFace } from "./atomic";
import { recordHistory } from "./history";
import { readLock, writeLock } from "./lock";
import { assertReloadApplied } from "./steps/reload";

// db 为 oj isolate 注入全局（同模板 service 层惯例，installer.ts 同款；测试由夹具装 globalThis.db）
declare const db: {
	/** 安全查询构造器（与 db.query 同返回行数组） */
	table: (name: string) => any
	/** 目录自省（v0.1.82）：当前库全部/前缀匹配的表名（方言无关；前缀 %/_ 由引擎转义） */
	listTables: (prefix?: string) => Promise<string[]>
	/** 单一 DB 事务包裹（P3-3）：回调内语句共享一个 BEGIN/COMMIT/ROLLBACK 边界，异常即整段回滚 */
	tx: <T>(fn: (t: { table: (name: string) => any }) => Promise<T>) => Promise<T>
};

function isObj(v: unknown): v is Record<string, unknown> {
	return typeof v === "object" && v !== null && !Array.isArray(v);
}

// P3-4（Q4 业务表保留提示）：卸载只删代码/锁/路由/sidecar/权限，绝不 DROP 业务数据；
// 受影响业务表经双重来源得到——① manifest.tables 声明式权威源 ② 模块 slug 规范化前缀兜底扫描——
// 仅回传「实际存在」的表名，供运维手工清理。检测全程失败静默兜底，不阻断卸载主流程。

/** 从 manifest 文本抽取顶层 `tables:` 标量列表（manifest 形态稳定，避免引入 yaml 全局依赖） */
function manifestTables(yamlText: string): string[] {
	const out: string[] = [];
	let inTables = false;
	for (const raw of yamlText.split("\n")) {
		const line = raw.replace(/\r$/, "");
		if (!inTables) {
			if (/^tables\s*:/.test(line)) {
				inTables = true;
				continue;
			}
			continue;
		}
		if (line.trim() === "")
			continue;
		const m = /^\s+-\s+(\S.*)$/.exec(line);
		if (m) {
			out.push(m[1].replace(/^['"]|['"]$/g, ""));
			continue;
		}
		if (/^\S/.test(line))
			break; // 顶层新键，tables 块结束
	}
	return out;
}

/** 模块 slug 规范化（连字符→下划线）作表前缀；db.listTables 内部按字面量前缀匹配（自动转义 %/_），无需手拼通配 */
export function moduleTablePrefix(name: string): string {
	return `${name.replace(/-/g, "_")}_`;
}

/**
 * 卸载期判断方案是否含 api 模块（决定 oj 是否产出 -name@ver 装配条目）：读版本目录内 C2 manifest.yaml
 * 的顶层 `api:` 段。reload 断言时版本目录仍在（删除在 reload 之后），故可读。读失败/无 api 段 → false
 * （web-only 方案 oj 不产模块条目，符号不强制，仅校验 reload 已探测锁变更）。
 */
async function uninstallHasApi(name: string, version: string, sharedRoot: string): Promise<boolean> {
	try {
		const text = new TextDecoder().decode(await fsFace().readFile(`${sharedRoot}/${name}-${version}/manifest.yaml`));
		return /^api\s*:/m.test(text);
	}
	catch {
		return false;
	}
}

/** 收集需保留的业务表（Q4）：声明 + 前缀兜底；仅返回实际存在的表名 */
export async function collectRetainedTables(name: string, manifestPath: string): Promise<string[]> {
	const candidates = new Set<string>();
	// ① 声明式权威源：manifest.tables（通知等模块已在 manifest 声明业务表归属）
	try {
		const text = new TextDecoder().decode(await fsFace().readFile(manifestPath));
		for (const t of manifestTables(text))
			candidates.add(t);
	}
	catch {
		// manifest 缺失（api-only 方案）→ 仅前缀兜底
	}
	// ② 前缀兜底：db.listTables（v0.1.82，方言无关，前缀转义引擎做）枚举当前库匹配模块前缀的
	//    实际表，覆盖未声明场景。listTables 已只返回存在的表，故前缀命中的候选天然存在。
	try {
		for (const t of await db.listTables(moduleTablePrefix(name)))
			candidates.add(t);
	}
	catch {
		// 兜底扫描失败不阻断卸载
	}
	// 仅回传实际存在的表（manifest 声明的表若物理不存在则不回传）
	const existing = new Set(await db.listTables());
	return [...candidates].filter(t => existing.has(t));
}

/**
 * 回退某方案的 DB 注册（P0 补偿清单 §3.5 复用）：单一事务内删 sys_solution_route + 级联清
 * 角色/权限（uninstallSolution 双维度级联）。与 runUninstall 的 DB 步同原语，避免两套 DB 回滚逻辑。
 * 行已不存在 = no-op（幂等安全）。
 */
export async function revertRegistrations(name: string): Promise<void> {
	await db.tx(async (t) => {
		await t.table("sys_solution_route").where({ field: "module", op: "eq", value: name }).delete().run();
		await uninstallSolution(name, t);
	});
}

/** 卸载影响面预检（GET uninstall-impact 消费面）：返回前端二次确认所需的影响计数 */
export interface UninstallImpact {
	name: string
	affectedRoles: number
	affectedUsers: number
}

export interface UninstallInput {
	name: string
	/** 可选显式版本；缺省回落锁/sidecar 版本 */
	version?: string
	sharedRoot: string
	lockPath: string
	state: StateStore
	modulesJsonPath: string
	/** 操作人（用户名，历史留痕；缺省 null） */
	operator?: string | null
	now?: number
	/** 审计出口（缺省 auditOp；测试注入记录器） */
	audit?: (entry: OpEntry) => void
	/** 热更面（P0 §3.4 第5步：卸载摘锁后 reload 触达装配以真正摘除模块；缺省不 reload——依赖 US-1 上游 manifests 摘要驱动才实际掉挂载）。reload 失败 → 锁写回 + 再 reload 回旧代（模块仍挂载、可重试） */
	reload?: ReloadFace
}

export interface UninstallResult {
	ok: boolean
	message: string
	/** P3-11 失败细分：not-installed = 方案已不存在（锁与 sidecar 均无记录）——端点据此回 404（资源缺失语义），其余拒绝仍 200 {ok:false} */
	reason?: "not-installed"
	/** P3-4（Q4）业务表保留清单：卸载不删业务数据，仅回传实际存在的业务表名供运维手工清理 */
	retained?: string[]
}

/** 计算卸载影响面（角色数 + 持有这些角色的用户数） */
export async function computeUninstallImpact(input: UninstallInput): Promise<UninstallImpact> {
	const { name } = input;
	const roles = await db.table("sys_role").select(["name"]).where({ field: "module", op: "eq", value: name }).all() as Array<{ name: string }>;
	const roleNames = roles.map(r => r.name);
	let affectedUsers = 0;
	if (roleNames.length > 0) {
		// 构造器（v0.1.82）：count(distinct) 聚合一行返回，不受 LIMIT 钳制——
		// 旧 distinct().all().length 因顶层隐式 LIMIT（默认 100）/ 显式 clamp（max_limit 默认 1000）
		// 在受影响用户 >1000 时静默漏算（今天就有正确性风险，须尽快迁移）。
		const rows = await db.table("sys_user_role")
			.select([{ fn: "count", distinct: true, field: "user_id", as: "c" }])
			.where({ field: "role_name", op: "in", value: roleNames })
			.all() as Array<{ c: number }>;
		affectedUsers = rows[0]?.c ?? 0;
	}
	return { name, affectedRoles: roleNames.length, affectedUsers };
}

/**
 * 卸载编排（四处同删 + 权限级联 + 版本目录移除 + 审计 + 全用户失效 + 历史留痕）。
 * 任一步失败返回 {ok:false, message}（操作已执行、被域逻辑拒绝，人话在 message，前端照 ok 位渲染，
 * 与 setEnabled 同纪律）；锁/sidecar/route/modules 可能留部分残差（admin 手动重试或重装自愈）。
 */
export async function runUninstall(input: UninstallInput): Promise<UninstallResult> {
	const { name } = input;
	const f = fsFace();
	const lock = await readLock(input.lockPath);
	const side = input.state.read().solutions[name];

	// 安装在哪：锁与 sidecar 均无记录 = 未安装（P3-11：细分 reason，端点据此回 404 资源缺失语义）
	if (lock[name] === undefined && side === undefined) {
		return { ok: false, reason: "not-installed", message: `卸载失败：「${name}」未安装（锁与 sidecar 均无记录）` };
	}
	// 安装在哪：锁与 sidecar 均无记录 = 未安装（P3-11：细分 reason，端点据此回 404 资源缺失语义）
	if (lock[name] === undefined && side === undefined) {
		return { ok: false, reason: "not-installed", message: `卸载失败：「${name}」未安装（锁与 sidecar 均无记录）` };
	}
	// 版本解析 sidecar 优先（2026-11-07 市场线演练实锤：双轨同名——第一方 web-only 方案的锁
	// 编排面）可能正占着锁的另一版本；「锁优先」会把内建版本当方案删，内建目录/锁条目被毁、
	// 编排端点全灭。sidecar 是方案轨唯一真相；锁仅作 sidecar 缺失（旧工程/半残态）的兜底）。
	const version = input.version ?? side?.version ?? lock[name];
	if (version === undefined) {
		return { ok: false, message: `卸载失败：「${name}」版本不可得（锁与 sidecar 均无版本）` };
	}
	// 锁条目归属裁决：sidecar 在 → 锁条目仅当与 sidecar 同版本才属本方案（api 轨锁随装写）；
	// sidecar 缺失（旧形态/半残）→ 锁条目按旧语义归属方案。同名不同轨的锁条目（内建模块）不摘。
	const lockEntryIsSolution = side !== undefined ? lock[name] === side.version : lock[name] !== undefined;
	const remaining = { ...lock };
	if (lockEntryIsSolution)
		delete remaining[name];
	if (Object.keys(remaining).length === 0) {
		return { ok: false, message: "卸载失败：摘除后锁为空（空锁拒启，S1-1.2）——站点至少保留一个已锁模块，不能卸载最后一个" };
	}

	const audit = (ok: boolean, detail: string): void =>
		(input.audit ?? auditOp)({ action: "solution.uninstall", module: name, target: name, detail: { ok, detail }, level: ok ? 6 : 4 });

	// ① DB 级联单一事务（P3-3）：route 删除 + 权限双维度级联（uninstallSolution）纳入同一 BEGIN/COMMIT/ROLLBACK
	// 边界。任一步失败 → 整段回滚（无角色/权限/路由半残），锁不摘（fail-closed：模块仍挂载、可重试或重装自愈）。
	try {
		await db.tx(async (t) => {
			await t.table("sys_solution_route").where({ field: "module", op: "eq", value: name }).delete().run();
			await uninstallSolution(name, t);
		});
	}
	catch (e) {
		audit(false, `权限级联清理失败：${String(e)}`);
		return { ok: false, message: `卸载失败：权限级联清理失败（${String(e)}）——事务已回滚，锁/路由/角色/权限未改动（fail-closed）` };
	}

	// ① 锁摘除（先失可达性：模块停止装配；在此之前任一失败锁均保留 = fail-closed）
	try {
		await writeLock(input.lockPath, remaining);
	}
	catch (e) {
		audit(false, `锁写失败：${String(e)}`);
		return { ok: false, message: `卸载失败：锁写失败（${String(e)}）——DB 级联已回滚、sidecar/modules 未动（fail-closed）` };
	}

	// ② reload 触达装配以真正摘除模块（P0 §3.4 第5步：先失可达性）；缺省无 reload 面则跳过（依赖
	// US-1 上游 manifests 摘要驱动才实际掉挂载）。reload 失败 / 返回 unchanged / 未真正摘除模块 →
	// 锁写回 + 再 reload 回旧代——模块仍挂载，且此时 sidecar/modules.json/版本目录均未删（下面才删），
	// 故锁写回即**一致回滚**，不残留半卸状态，返回失败可重试（fail-closed）。
	if (input.reload !== undefined) {
		let r: ReloadResult;
		try {
			r = await input.reload.reloadConfig();
		}
		catch (e) {
			try {
				await writeLock(input.lockPath, lock);
			}
			catch {
				// 锁写回失败不掩盖 reload 失败终态
			}
			try {
				await input.reload.reloadConfig();
			}
			catch {
				// 回滚 reload 也失败：模块仍按原锁挂载，下次卸载重试
			}
			audit(false, `reload 失败，已回写锁并恢复旧代：${String(e)}`);
			return { ok: false, message: `卸载失败：reload 失败（${String(e)}）——已回写锁恢复旧代（模块仍挂载、元数据未删），请稍后重试` };
		}
		// 卸载空转回归守卫（§2.7）：reload 须真实摘除模块——unchanged 即「锁摘了但装配没掉挂载」，
		// 正是本 PR 修复的回归；api 模块还须 applied 含 -name@ver（web-only 无 api 段，oj 不产模块条目，仅校验 unchanged）。
		const hasApi = await uninstallHasApi(name, version, input.sharedRoot);
		const a = assertReloadApplied(r, { hasApi, kind: "uninstall", name, version, lockRemoved: lockEntryIsSolution });
		if (!a.ok) {
			try {
				await writeLock(input.lockPath, lock);
			}
			catch {
				// 锁写回失败不掩盖 reload 断言失败终态
			}
			try {
				await input.reload.reloadConfig();
			}
			catch {
				// 回滚 reload 也失败：模块仍按原锁挂载，下次卸载重试
			}
			audit(false, `reload 未真正摘除模块，已回写锁并恢复旧代：${a.message}`);
			return { ok: false, message: `卸载失败：${a.message}——已回写锁恢复旧代（模块仍挂载、元数据未删），请稍后重试` };
		}
	}

	// ③ 再失文件前先清元数据：sidecar 删条目 / modules.json 删条目（reload 成功才走到这里，回滚已不可达）
	// sidecar 删条目（patch 值 null = 删除该方案键）
	try {
		await input.state.write({ solutions: { [name]: null } } as unknown as Parameters<typeof input.state.write>[0]);
	}
	catch (e) {
		audit(false, `sidecar 写失败：${String(e)}`);
		return { ok: false, message: `卸载失败：sidecar 写失败（${String(e)}）——锁已摘、reload 已生效，模块已停装配；sidecar 残留待重装自愈` };
	}

	// modules.json 删条目（条目不存在 = api-only 方案，天然一致）
	try {
		const list = JSON.parse(new TextDecoder().decode(await f.readFile(input.modulesJsonPath))) as unknown[];
		if (!Array.isArray(list)) {
			throw new TypeError("modules.json 顶层不是数组");
		}
		const next = list.filter(e => !(isObj(e) && e.name === name));
		await atomicWriteText(input.modulesJsonPath, `${JSON.stringify(next, null, 2)}\n`);
	}
	catch (e) {
		audit(false, `modules.json 写失败：${String(e)}`);
		return { ok: false, message: `卸载失败：modules.json 写失败（${String(e)}）——锁已摘、reload 已生效、sidecar 已删，modules.json 残留待重装自愈` };
	}

	// ④ 版本目录移除（缺失不报错，幂等）；再失文件（P0 §3.4：先失可达性再失文件）
	// —— 但 Q4 业务表清单须在版本目录移除前从 manifest 取得（manifest 在版本目录内）——
	let retained: string[] = [];
	try {
		retained = await collectRetainedTables(name, `${input.sharedRoot}/${name}-${version}/manifest.yaml`);
	}
	catch {
		retained = [];
	}
	try {
		await f.remove(`${input.sharedRoot}/${name}-${version}`, { recursive: true });
	}
	catch {
		// 目录缺失 = 已清理，忽略
	}

	// 权限已变 → 强退所有会话（D10：撤销即强退）
	invalidateAllUsers();

	// 终态审计
	audit(true, `卸载完成：${name}@${version}`);

	// 历史留痕（守卫式：表不存在/写失败静默，history.ts 同语义）
	await recordHistory({
		solution: name,
		version,
		action: "uninstall",
		status: "success",
		operator: input.operator ?? null,
		message: `卸载完成：${name}@${version}`,
	});

	return {
		ok: true,
		message: `卸载完成：锁摘除 + sidecar + sys_solution_route + modules.json 四处同删 + 权限级联清理 + 版本目录移除（${name}@${version}）；业务表 ${retained.length} 张已保留（未删除，需运维手工清理）`,
		retained,
	};
}
