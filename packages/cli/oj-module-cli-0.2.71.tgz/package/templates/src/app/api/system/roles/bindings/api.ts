import { respond } from "#/_platform/_shared/respond";
import { updateBindings } from "#/_platform/_shared/service/domain/roles";
// PUT /api/system/roles/bindings?name=xxx —— 整集替换角色绑定。
// AC1-18 声明角色绑定可调整；AC1-19 builtin 硬拒（service 层）；AC1-30 摘绑定 = 紧急吊销出口
// （service 内写后按持有者失效判权缓存）。
import { assertSystemAdmin } from "#/_platform/_shared/service/infra/access";

async function put() {
	await respond(async () => {
		await assertSystemAdmin();
		const name = String((http.query as Record<string, unknown>).name ?? "");
		const codes = Array.isArray(http.body?.permissions) ? http.body.permissions.map(String) : [];
		return updateBindings(name, codes);
	});
}
put.schema = {
	query: {
		type: "object",
		required: ["name"],
		properties: { name: { type: "string", minLength: 1 } },
	},
	body: {
		type: "object",
		required: ["permissions"],
		properties: { permissions: { type: "array", items: { type: "string" } } },
	},
};

// 出参无业务载荷（service 返回 void → data 为 null）
put.response = { type: "null" };

export default { put };
