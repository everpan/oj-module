// POST /api/home/line —— 首页折线（真实化 P4-1，AC-D9 apiPrefix=/home）。
// 窗口聚合 home_line：range(week/month/year) → 天数；在 [today-N+1, today] 内
// 逐日取 SUM(value)，缺失日补 0（F6 幂等补数）。返回 number[]（与日序对齐）。
const RANGE_DAYS: Record<string, number> = { week: 7, month: 30, year: 365 };

// 契约（v0.1.71「最新方式」）：动词挂 `.schema` 四通道。
const line = {
	async post() {
		try {
			const range = String((http.body && (http.body as Record<string, unknown>).range) ?? "week");
			const days = RANGE_DAYS[range] ?? 7;
			const today = Math.floor(Date.now() / 86400000);
			const start = today - days + 1;

			const rows = await db.table("home_line").select([
				"day",
				{ fn: "sum", field: "value", as: "v" },
			]).where({ field: "day", op: "gte", value: start }).where({ field: "day", op: "lte", value: today }).groupBy(["day"]).all();
			const map = new Map<number, number>();
			for (const r of rows)
				map.set(Number(r.day), Number(r.v));

			let out: number[] = Array.from({ length: today - start + 1 }, (_, i) => {
				const d = start + i;
				return map.get(d) ?? 0;
			});

			// 懒补数（F6）：窗口内完全无 seed（seed 随时间变旧）时，回落确定式趋势，
			// 保证图表非空；有 seed 时仅对缺失日补 0（上面 ?? 0 已处理）。
			if (out.every(v => v === 0)) {
				out = Array.from({ length: today - start + 1 }, (_, i) => {
					const d = start + i;
					return 50 + Math.round(40 * Math.sin(d / 3)) + (d % 7) * 3;
				});
			}
			json.ok(out);
		}
		catch (e) {
			json.fail(500, String(e));
		}
	},
};

line.post.schema = {
	body: {
		type: "object",
		required: ["range"],
		properties: { range: { type: "string" } },
	},
};

line.post.response = {
	type: "array",
	items: { type: "number" },
};

export default line;
