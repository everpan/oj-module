-- _platform 种子数据（只放数据，DDL 归 migrations/，S006 纪律）。
-- 方言覆盖：seed.mysql.sql / seed.pg.sql（INSERT OR IGNORE 为 sqlite 专属语法，方言文件必胜，同迁移约定）。
-- 注意：seed 按英文分号朴素切分语句，注释里也不要出现英文分号。
-- 账号生命周期 D12（2026-10-22 调整）：四个内置角色各一个开发账号，**账号名=角色名**
-- （superadmin/admin/editor/viewer，避免心智负担），口令均 aA123456（bcrypt cost=10、$2y$ 前缀，
-- 2026-11-01 由 123456 改来），must_change=0 免首登改密——
-- 纯开发便利（默认凭据不随机生成的取舍见计划 A2 阶段小结），生产部署须改密或删除
INSERT OR IGNORE INTO users (username, password_hash, must_change) VALUES ('superadmin', '$2y$10$9HEtASi9jG0VIBMMVqxAmOqrE4f6wiezhGmi50iPG1s1MXlncSO0e', 0);
INSERT OR IGNORE INTO users (username, password_hash, must_change) VALUES ('admin', '$2y$10$9HEtASi9jG0VIBMMVqxAmOqrE4f6wiezhGmi50iPG1s1MXlncSO0e', 0);
INSERT OR IGNORE INTO users (username, password_hash, must_change) VALUES ('editor', '$2y$10$9HEtASi9jG0VIBMMVqxAmOqrE4f6wiezhGmi50iPG1s1MXlncSO0e', 0);
INSERT OR IGNORE INTO users (username, password_hash, must_change) VALUES ('viewer', '$2y$10$9HEtASi9jG0VIBMMVqxAmOqrE4f6wiezhGmi50iPG1s1MXlncSO0e', 0);
-- 历史 seed 把 admin 绑在 superadmin 上；收敛为账号名=角色名（幂等 DELETE，每次重放生效）。
-- 已存在库中 admin 行可能残留 must_change=1，UPDATE 统一收敛为 0（四个均为 seed 自有开发账号）
DELETE FROM sys_user_role WHERE role_name = 'superadmin' AND user_id IN (SELECT id FROM users WHERE username = 'admin');
UPDATE users SET must_change = 0 WHERE username IN ('superadmin', 'admin', 'editor', 'viewer');
-- 框架内置角色（ROLES 单一真相：superadmin 安全敏感项 / admin 日常管理 / editor、viewer 页面门）
INSERT OR IGNORE INTO sys_role (name, module, title, builtin) VALUES ('superadmin', 'framework', '超级管理员', 1);
INSERT OR IGNORE INTO sys_role (name, module, title, builtin) VALUES ('admin', 'framework', '系统管理员', 1);
INSERT OR IGNORE INTO sys_role (name, module, title, builtin) VALUES ('editor', 'framework', '编辑', 1);
INSERT OR IGNORE INTO sys_role (name, module, title, builtin) VALUES ('viewer', 'framework', '访客', 1);
-- 角色绑定（sys_user_role 唯一权威源，D10）：账号名=角色名一一对应
INSERT OR IGNORE INTO sys_user_role (user_id, role_name) SELECT id, 'superadmin' FROM users WHERE username = 'superadmin';
INSERT OR IGNORE INTO sys_user_role (user_id, role_name) SELECT id, 'admin' FROM users WHERE username = 'admin';
INSERT OR IGNORE INTO sys_user_role (user_id, role_name) SELECT id, 'editor' FROM users WHERE username = 'editor';
INSERT OR IGNORE INTO sys_user_role (user_id, role_name) SELECT id, 'viewer' FROM users WHERE username = 'viewer';
-- 组织架构共享读面的全量权限点（方案 D5）：scope=all 挂它，没挂的人只能看自己的部门路径。
-- ⚡ 权限点**必须先落库**才能被管理员绑给 custom 角色（createRole/updateBindings 会校验 code 存在），
-- 只在端点里 assertPermission 而不落库 = 这个权限点永远绑不上，门禁形同虚设。
INSERT OR IGNORE INTO sys_permission (code, module, title_key, deprecated) VALUES ('platform.org.read.all', 'framework', 'system:perm.platform_org_read_all', 0);
-- 系统设置默认值（PRD §4.3；C4 设置页 / C5 登录方式发现的数据源；framework.market_cdn_url 安全组仅 superadmin 可改）
-- framework.market_cdn_url 缺省 /cdn = 本站点自供（config.yaml 的 /cdn 挂载直出工程根 cdn/），脚手架免 setup；外部真 CDN 才改指绝对地址
INSERT OR IGNORE INTO sys_setting (key, module, "group", type, value, default_value, label_key, secret, update_time) VALUES ('framework.site_title', 'framework', 'general', 'string', 'React Antd Admin', 'React Antd Admin', 'system:setting.site_title', 0, 0);
INSERT OR IGNORE INTO sys_setting (key, module, "group", type, value, default_value, label_key, secret, update_time) VALUES ('framework.market_cdn_url', 'framework', 'security', 'string', '/cdn', '/cdn', 'system:setting.market_cdn_url', 0, 0);
INSERT OR IGNORE INTO sys_setting (key, module, "group", type, value, default_value, label_key, secret, update_time) VALUES ('ldap.enabled', 'ldap', 'login', 'bool', '0', '0', 'system:setting.ldap_enabled', 0, 0);
INSERT OR IGNORE INTO sys_setting (key, module, "group", type, value, default_value, label_key, secret, update_time) VALUES ('sso.enabled', 'sso', 'login', 'bool', '0', '0', 'system:setting.sso_enabled', 0, 0);
-- 企微代开发（登录方式 + 代开发后台总开关）：默认关。开启前须先在 config.yaml vars 填 6 项部署常量，
-- 否则登录页会出现企微 tab 但点进去 400「企业微信未配置」（宁可报错也不静默隐藏，便于运维定位）。
INSERT OR IGNORE INTO sys_setting (key, module, "group", type, value, default_value, label_key, secret, update_time) VALUES ('wecom.enabled', 'wecom', 'login', 'bool', '0', '0', 'system:setting.wecom_enabled', 0, 0);
INSERT OR IGNORE INTO sys_setting (key, module, "group", type, value, default_value, label_key, secret, update_time) VALUES ('ldap_base_dn', 'ldap', 'ldap', 'string', '', '', 'system:setting.ldap_base_dn', 0, 0);
INSERT OR IGNORE INTO sys_setting (key, module, "group", type, value, default_value, label_key, secret, update_time) VALUES ('ldap_uid_attr', 'ldap', 'ldap', 'string', 'uid', 'uid', 'system:setting.ldap_uid_attr', 0, 0);
INSERT OR IGNORE INTO sys_setting (key, module, "group", type, value, default_value, label_key, secret, update_time) VALUES ('ldap_email_attr', 'ldap', 'ldap', 'string', 'mail', 'mail', 'system:setting.ldap_email_attr', 0, 0);
-- 企微组织架构同步（B2）：触发同步是打上游的动作，挂权限点；admin/superadmin 天然通过，
-- 只有自定义角色需要显式绑定（与 platform.org.read.all 同一条纪律：不落库就永远绑不上）。
INSERT OR IGNORE INTO sys_permission (code, module, title_key, deprecated) VALUES ('auth.wecom.sync', 'auth', 'system:perm.auth_wecom_sync', 0);
