// BDD：卸载编排（P1-15a，R9/AC-P1-6 反向/D12/AC2-6/S1-1.2）。
// 端点（createMarketApi 的 uninstall-impact / uninstall）只做门禁 + 取参 + 调 runUninstall；
// 编排器负责四处同删（锁/sidecar/sys_solution_route/modules.json）+ 权限级联 uninstallSolution
// + 版本目录移除 + 审计 + 全用户失效 + market_history 留痕。本规格为验收锚点。
// 夹具：本仓范式（node:sqlite 真实迁移建表 + 真实 fs 面 g.fs）；market_history 表由平台迁移
// 0012（IF NOT EXISTS）随 installDb 重放建立，守卫语义（表不存在静默跳过）单列一例。
/* eslint-disable test/prefer-lowercase-title -- 端点动词/路径是验收锚点，保留大写（market-api.spec 同约定） */
import type { FsFace } from "../../src/app/api/_platform/_lifecycle/atomic";
import type { MarketEnv } from "../../src/oj-market/api/api";
import * as fsp from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { readLock, writeLock } from "../../src/app/api/_platform/_lifecycle/lock";
import { createStateStore } from "../../src/app/api/_platform/_lifecycle/state";
import { collectRetainedTables, moduleTablePrefix } from "../../src/app/api/_platform/_lifecycle/uninstall";
import { invalidateAllUsers } from "../../src/app/api/_platform/_shared/service/infra/access";
import { createMarketApi } from "../../src/oj-market/api/api";
import { installDb } from "../fixture";

const g = globalThis as any;

let root: string;
let sharedRoot: string;
let statePath: string;
let modulesJsonPath: string;
let dbo: any;
let last: { status: number, msg?: string, data?: unknown } | null = null;

function nodeFsFace(): FsFace {
	return {
		writeFile: (path, data) => fsp.writeFile(path, data),
		readFile: path => fsp.readFile(path),
		mkdir: (path, opts) => fsp.mkdir(path, opts),
		remove: (path, opts) => fsp.rm(path, opts),
		rename: (oldPath, newPath) => fsp.rename(oldPath, newPath),
		copyFile: (src, dest) => fsp.copyFile(src, dest),
		readdir: path => fsp.readdir(path),
	};
}

function makeEnv(overrides: Partial<MarketEnv> = {}): MarketEnv {
	return {
		sharedRoot,
		staging: join(sharedRoot, ".staging"),
		taskDir: join(sharedRoot, ".install-tasks"),
		statePath,
		dbPath: join(root, "db.sqlite"),
		siteModulesDir: join(root, "dist", "modules"),
		modulesJsonPath,
		apiPrefix: "/api/demo-solution",
		...overrides,
	};
}

/** 预置「已装」形态：锁（含 other 以避开空锁拒启）+ sidecar + 版本目录 + modules.json + route + 角色/用户绑定 + market_history 表 */
async function seedInstalled(opts: { withOther?: boolean } = {}): Promise<void> {
	const withOther = opts.withOther !== false;
	const lock: Record<string, string> = { "demo-solution": "0.1.0" };
	if (withOther)
		lock.other = "1.0.0";
	await writeLock(join(sharedRoot, "manifests.yaml"), lock);
	const state = await createStateStore(statePath);
	await state.write({ solutions: { "demo-solution": { version: "0.1.0", enabled: true, installedAt: 1 } } });
	await fsp.mkdir(join(sharedRoot, "demo-solution-0.1.0"), { recursive: true });
	await fsp.writeFile(modulesJsonPath, JSON.stringify([
		{ name: "demo-solution", enabled: true, src: "modules/demo-solution/" },
		...(withOther ? [{ name: "other", enabled: true, src: "modules/other/" }] : []),
	]));
	dbo.prepare("INSERT INTO sys_solution_route (path, module, category) VALUES (?, ?, ?)").run("/demo-solution", "demo-solution", "main");
	dbo.prepare("INSERT INTO sys_role (name, module, title, builtin) VALUES (?, ?, ?, 0)").run("demo-solution.admin", "demo-solution", "管理员");
	dbo.prepare("INSERT INTO sys_role (name, module, title, builtin) VALUES (?, ?, ?, 0)").run("demo-solution.viewer", "demo-solution", "访客");
	dbo.prepare("INSERT INTO sys_user_role (user_id, role_name) VALUES (?, ?)").run(1, "demo-solution.admin");
	dbo.prepare("INSERT INTO sys_user_role (user_id, role_name) VALUES (?, ?)").run(2, "demo-solution.viewer");
}

/** 在 seedInstalled 之上：manifest.tables 声明业务表 + 实际建表（Q4 须保留、不删） */
async function seedInstalledWithTables(opts: { withOther?: boolean } = {}): Promise<void> {
	await seedInstalled(opts);
	await fsp.writeFile(
		join(sharedRoot, "demo-solution-0.1.0", "manifest.yaml"),
		"name: demo-solution\nversion: 0.1.0\ntables:\n  - demo_solution_notes\n  - demo_solution_tags\n",
	);
	dbo.exec("CREATE TABLE demo_solution_notes (id INTEGER PRIMARY KEY, body TEXT)");
	dbo.exec("CREATE TABLE demo_solution_tags (id INTEGER PRIMARY KEY, name TEXT)");
}

beforeEach(async () => {
	root = await fsp.mkdtemp(join(tmpdir(), "ojm-uninstall-"));
	sharedRoot = join(root, "modules");
	statePath = join(sharedRoot, ".solutions", "state.yaml");
	modulesJsonPath = join(root, "dist", "modules.json");
	await fsp.mkdir(sharedRoot, { recursive: true });
	await fsp.mkdir(dirname(modulesJsonPath), { recursive: true });
	g.fs = nodeFsFace();
	dbo = installDb();
	dbo.prepare("INSERT OR IGNORE INTO sys_user_role (user_id, role_name) VALUES (?, ?)").run(1, "superadmin");
	g.json = {
		ok: (data: unknown) => {
			last = { status: 200, data };
		},
		fail: (status: number, msg: string) => {
			last = { status, msg };
		},
	};
	last = null;
});

afterEach(async () => {
	g.fs = undefined;
	g.http = undefined;
	g.json = undefined;
	g.db = undefined;
	invalidateAllUsers();
	await fsp.rm(root, { recursive: true, force: true });
});

describe("GET uninstall-impact 影响面预检（superadmin，R9）", () => {
	it("返回受影响角色数与用户数（供前端二次确认）", async () => {
		await seedInstalled();
		const api = createMarketApi(makeEnv());
		g.http = { user: { id: 1 }, query: { name: "demo-solution" } };
		await api["uninstall-impact"].get();
		expect(last?.status).toBe(200);
		expect(last?.data).toMatchObject({ name: "demo-solution", affectedRoles: 2, affectedUsers: 2 });
	});

	it("未安装方案也返回 0/0（不报错）", async () => {
		const api = createMarketApi(makeEnv());
		g.http = { user: { id: 1 }, query: { name: "nope" } };
		await api["uninstall-impact"].get();
		expect(last?.status).toBe(200);
		expect(last?.data).toMatchObject({ name: "nope", affectedRoles: 0, affectedUsers: 0 });
	});
});

describe("POST uninstall 卸载编排（superadmin，R9）", () => {
	it("四处同删 + 权限级联 + 版本目录移除 + 历史留痕，返回 ok:true", async () => {
		await seedInstalled();
		const api = createMarketApi(makeEnv());
		g.http = { user: { id: 1 }, body: { name: "demo-solution" } };
		await api.uninstall.post();
		expect(last?.status).toBe(200);
		expect(last?.data).toMatchObject({ ok: true });
		// ① 锁摘除（other 条目保留——空锁拒启防线未被波及）
		expect(await readLock(join(sharedRoot, "manifests.yaml"))).toEqual({ other: "1.0.0" });
		// ② sidecar 删条目
		const state = await createStateStore(statePath);
		expect(state.read().solutions["demo-solution"]).toBeUndefined();
		// ③ sys_solution_route 删
		expect(Number(dbo.prepare("SELECT count(*) as c FROM sys_solution_route WHERE module = ?").get("demo-solution").c)).toBe(0);
		// ④ modules.json 删条目（other 保留）
		const list = JSON.parse(await fsp.readFile(modulesJsonPath, "utf8")) as Array<{ name: string }>;
		expect(list.find(e => e.name === "demo-solution")).toBeUndefined();
		expect(list.find(e => e.name === "other")).toBeDefined();
		// 权限唯一减法出口：双维度级联（角色 + 用户绑定 + 权限点）
		expect(Number(dbo.prepare("SELECT count(*) as c FROM sys_role WHERE module = ?").get("demo-solution").c)).toBe(0);
		expect(Number(dbo.prepare("SELECT count(*) as c FROM sys_user_role WHERE role_name = ?").get("demo-solution.admin").c)).toBe(0);
		// 版本目录移除（缺失即抛，断言 reject）
		await expect(fsp.readdir(join(sharedRoot, "demo-solution-0.1.0"))).rejects.toBeTruthy();
		// 历史留痕（第一方市场应用自身留痕；operator 反查 users 表）
		const hist = dbo.prepare("SELECT * FROM market_history WHERE solution = ? AND action = ?").all("demo-solution", "uninstall");
		expect(hist).toHaveLength(1);
		expect(String(hist[0].status)).toBe("success");
		expect(String(hist[0].operator)).toBe("admin");
	});

	it("双轨同名（web-only 方案 vs 同名内建模块锁条目）：版本以 sidecar 为准——只删方案版本目录，内建锁条目与目录保留", async () => {
		// 2026-11-07 市场线演练实锤：版本解析「锁优先」会把内建 oj-market 编排模块
		// （锁 oj-market: 0.1.0，平台 api 轨）当成方案版本删——内建目录被移除、编排端点全灭。
		// web-only 方案的真相在 sidecar（lock_commit 零锁变更），锁是 api 轨真源与方案版本可能同名不同轨。
		await writeLock(join(sharedRoot, "manifests.yaml"), { "oj-market": "0.1.0", "other": "1.0.0" });
		const st0 = await createStateStore(statePath);
		await st0.write({ solutions: { "oj-market": { version: "0.2.0", enabled: true, installedAt: 1 } } });
		await fsp.mkdir(join(sharedRoot, "oj-market-0.1.0"), { recursive: true }); // 内建编排模块目录（不可删）
		await fsp.mkdir(join(sharedRoot, "oj-market-0.2.0"), { recursive: true }); // 方案版本目录（该删）
		await fsp.writeFile(join(sharedRoot, "oj-market-0.2.0", "manifest.yaml"), "name: oj-market\nversion: 0.2.0\n");
		await fsp.writeFile(modulesJsonPath, JSON.stringify([{ name: "oj-market", enabled: true }, { name: "other", enabled: true }]));
		dbo.prepare("INSERT INTO sys_solution_route (path, module, category) VALUES (?, ?, ?)").run("/oj-market", "oj-market", "main");
		const api = createMarketApi(makeEnv({
			apiPrefix: "/api/oj-market",
			// 双轨同名：内建锁条目保留 → oj 装配面无锁 diff，reload 报 unchanged 属预期
			// （方案摘除发生在 modules.json/sidecar/route 面；断言不得按「卸载空转」拒）
			reload: { reloadConfig: async () => ({ generation: 2, unchanged: true, applied: [], restart_pending: [], kept_listener: [] }) },
		}));
		g.http = { user: { id: 1 }, body: { name: "oj-market" } };
		await api.uninstall.post();
		expect(last?.status).toBe(200);
		expect(last?.data).toMatchObject({ ok: true });
		// 内建锁条目保留（api 轨不被方案卸载波及），other 亦保留
		expect(await readLock(join(sharedRoot, "manifests.yaml"))).toEqual({ "oj-market": "0.1.0", "other": "1.0.0" });
		// 方案版本目录删除；内建目录完好
		await expect(fsp.readdir(join(sharedRoot, "oj-market-0.2.0"))).rejects.toBeTruthy();
		await fsp.access(join(sharedRoot, "oj-market-0.1.0"));
		// sidecar 删条目 + modules.json 删方案条目（other 保留）
		expect((await createStateStore(statePath)).read().solutions["oj-market"]).toBeUndefined();
		const list = JSON.parse(await fsp.readFile(modulesJsonPath, "utf8")) as Array<{ name: string }>;
		expect(list.find(e => e.name === "oj-market")).toBeUndefined();
		expect(list.find(e => e.name === "other")).toBeDefined();
	});

	it("未安装方案 → 404 资源缺失语义（P3-11：非 200 {ok:false}），人话在 message", async () => {
		const api = createMarketApi(makeEnv());
		g.http = { user: { id: 1 }, body: { name: "nope" } };
		await api.uninstall.post();
		expect(last?.status).toBe(404);
		expect(String(last?.msg)).toContain("未安装");
		// 资源缺失：锁/sidecar/目录零改动（404 即什么都没发生）
		expect(await readLock(join(sharedRoot, "manifests.yaml"))).toEqual({});
	});

	it("卸载最后一个模块 → ok:false（空锁拒启 S1-1.2），锁保持不变", async () => {
		await seedInstalled({ withOther: false });
		const api = createMarketApi(makeEnv());
		g.http = { user: { id: 1 }, body: { name: "demo-solution" } };
		await api.uninstall.post();
		expect(last?.status).toBe(200);
		expect(last?.data).toMatchObject({ ok: false });
		expect(await readLock(join(sharedRoot, "manifests.yaml"))).toEqual({ "demo-solution": "0.1.0" });
	});

	it("market_history 表不存在（站点未装市场方案）→ 卸载仍 ok:true（守卫式留痕静默跳过，缺口 A）", async () => {
		await seedInstalled();
		dbo.exec("DROP TABLE market_history");
		const api = createMarketApi(makeEnv());
		g.http = { user: { id: 1 }, body: { name: "demo-solution" } };
		await api.uninstall.post();
		expect(last?.status).toBe(200);
		expect(last?.data).toMatchObject({ ok: true });
	});
});

describe("Phase 4：卸载 reload 失败回滚（P0 §3.4 第5步，依赖 US-1 manifests 摘要驱动的装配面，本仓先落编排）", () => {
	it("卸载摘锁后 reload 失败 → 锁写回(模块仍挂载) + ok:false + 版本目录不删（fail-closed 一致回滚）", async () => {
		await seedInstalled();
		const api = createMarketApi(makeEnv({
			reload: {
				reloadConfig: async () => {
					throw new Error("reload boom");
				},
			},
		}));
		g.http = { user: { id: 1 }, body: { name: "demo-solution" } };
		await api.uninstall.post();
		// 锁写回：模块仍挂载（other 保留 + demo-solution 恢复）
		expect(await readLock(join(sharedRoot, "manifests.yaml"))).toEqual({ "demo-solution": "0.1.0", "other": "1.0.0" });
		// 版本目录未删（先失可达性再失文件；reload 失败即停，不删文件）
		await expect(fsp.readdir(join(sharedRoot, "demo-solution-0.1.0"))).resolves.toBeDefined();
		// sidecar 未删（元数据一致回滚，非半卸）
		const state = await createStateStore(statePath);
		expect(state.read().solutions["demo-solution"]).toBeDefined();
		expect(last?.status).toBe(200);
		expect(last?.data).toMatchObject({ ok: false });
		expect(String((last?.data as { message?: string } | undefined)?.message)).toContain("reload 失败");
	});

	it("卸载 reload 成功 → 版本目录正常移除、锁摘除（既有行为不破坏）", async () => {
		await seedInstalled();
		const api = createMarketApi(makeEnv({ reload: { reloadConfig: async () => ({ generation: 1, unchanged: false, applied: ["-demo-solution@0.1.0"], restart_pending: [] }) } }));
		g.http = { user: { id: 1 }, body: { name: "demo-solution" } };
		await api.uninstall.post();
		expect(last?.status).toBe(200);
		expect(last?.data).toMatchObject({ ok: true });
		expect(await readLock(join(sharedRoot, "manifests.yaml"))).toEqual({ other: "1.0.0" });
		await expect(fsp.readdir(join(sharedRoot, "demo-solution-0.1.0"))).rejects.toBeTruthy();
	});
});

describe("P3-3 卸载级联单一事务（fail-closed：中段失败整段回滚、锁不摘、无半残）", () => {
	it("权限级联中段失败 → 事务回滚（route/角色/权限零残）、锁/sidecar/modules/版本目录原样保留", async () => {
		await seedInstalled();
		// 注入：db.tx 内命中「delete from sys_role where module」时抛错，模拟级联中段失败；自建 BEGIN/ROLLBACK 保证回滚
		const origTx = g.db.tx;
		g.db.tx = async (fn: (t: { exec: (sql: string, params?: unknown[]) => unknown, query: (sql: string, params?: unknown[]) => unknown }) => unknown) => {
			dbo.exec("BEGIN");
			const t = {
				query: (sql: string, params: unknown[] = []) => dbo.prepare(sql).all(...(params as never[])),
				exec: (sql: string, params: unknown[] = []) => {
					if (/delete from sys_role where module/.test(sql))
						throw new Error("injected cascade failure");
					return Number(dbo.prepare(sql).run(...(params as never[])).changes);
				},
			};
			try {
				const r = await fn(t);
				dbo.exec("COMMIT");
				return r;
			}
			catch (e) {
				dbo.exec("ROLLBACK");
				throw e;
			}
		};
		const api = createMarketApi(makeEnv());
		g.http = { user: { id: 1 }, body: { name: "demo-solution" } };
		await api.uninstall.post();
		expect(last?.status).toBe(200);
		expect(last?.data).toMatchObject({ ok: false });
		// 锁仍在（fail-closed：模块仍挂载，可重试或重装自愈）
		expect(await readLock(join(sharedRoot, "manifests.yaml"))).toEqual({ "demo-solution": "0.1.0", "other": "1.0.0" });
		// 事务回滚：route / 角色 / 用户绑定 零残（全部回退到卸载前）
		expect(Number(dbo.prepare("SELECT count(*) as c FROM sys_solution_route WHERE module = ?").get("demo-solution").c)).toBe(1);
		expect(Number(dbo.prepare("SELECT count(*) as c FROM sys_role WHERE module = ?").get("demo-solution").c)).toBe(2);
		expect(Number(dbo.prepare("SELECT count(*) as c FROM sys_user_role WHERE role_name = ?").get("demo-solution.admin").c)).toBe(1);
		expect(Number(dbo.prepare("SELECT count(*) as c FROM sys_user_role WHERE role_name = ?").get("demo-solution.viewer").c)).toBe(1);
		// 文件操作未触发（级联失败在锁摘除之前返回）：sidecar / modules.json / 版本目录 原样保留
		const state = await createStateStore(statePath);
		expect(state.read().solutions["demo-solution"]).toMatchObject({ version: "0.1.0" });
		const list = JSON.parse(await fsp.readFile(modulesJsonPath, "utf8")) as Array<{ name: string }>;
		expect(list.find(e => e.name === "demo-solution")).toBeDefined();
		expect(list.find(e => e.name === "other")).toBeDefined();
		await fsp.access(join(sharedRoot, "demo-solution-0.1.0"));
		// 还原 tx（不影响后续用例）
		g.db.tx = origTx;
	});
});

describe("门禁（R9：卸载 superadmin 独占）", () => {
	it("非 superadmin 访问 uninstall / uninstall-impact → 403", async () => {
		await seedInstalled();
		const api = createMarketApi(makeEnv());
		g.http = { user: { id: 2 }, query: { name: "demo-solution" } };
		await api["uninstall-impact"].get();
		expect(last?.status).toBe(403);
		g.http = { user: { id: 2 }, body: { name: "demo-solution" } };
		await api.uninstall.post();
		expect(last?.status).toBe(403);
	});
});

describe("P3-4 业务表保留提示（Q4：不删业务数据，retained 回传 + 表仍在）", () => {
	it("卸载成功响应含 retained 非空，且业务表仍在（sqlite 直读）；代码/锁/路由已删", async () => {
		await seedInstalledWithTables();
		const api = createMarketApi(makeEnv());
		g.http = { user: { id: 1 }, body: { name: "demo-solution" } };
		await api.uninstall.post();
		expect(last?.status).toBe(200);
		const data = last?.data as { ok: boolean, retained?: string[] };
		expect(data).toMatchObject({ ok: true });
		expect(Array.isArray(data.retained)).toBe(true);
		expect(data.retained).toContain("demo_solution_notes");
		expect(data.retained).toContain("demo_solution_tags");
		// Q4：业务表未 DROP（sqlite_master 直读仍在）
		expect(Number(dbo.prepare("SELECT count(*) as c FROM sqlite_master WHERE type='table' AND name = ?").get("demo_solution_notes").c)).toBe(1);
		expect(Number(dbo.prepare("SELECT count(*) as c FROM sqlite_master WHERE type='table' AND name = ?").get("demo_solution_tags").c)).toBe(1);
		// 既有纪律：锁摘除 + sidecar + route + modules 已删（other 保留）
		expect(await readLock(join(sharedRoot, "manifests.yaml"))).toEqual({ other: "1.0.0" });
		const state = await createStateStore(statePath);
		expect(state.read().solutions["demo-solution"]).toBeUndefined();
		expect(Number(dbo.prepare("SELECT count(*) as c FROM sys_solution_route WHERE module = ?").get("demo-solution").c)).toBe(0);
	});

	it("manifest 缺失（api-only 方案）→ 前缀兜底仍能回传业务表", async () => {
		await seedInstalled();
		// 不写 manifest，但业务表名匹配模块前缀 demo_solution.*（兜底扫描命中）
		dbo.exec("CREATE TABLE demo_solution_orphan (id INTEGER)");
		const api = createMarketApi(makeEnv());
		g.http = { user: { id: 1 }, body: { name: "demo-solution" } };
		await api.uninstall.post();
		const data = last?.data as { ok: boolean, retained?: string[] };
		expect(data).toMatchObject({ ok: true });
		expect(data.retained).toContain("demo_solution_orphan");
		expect(Number(dbo.prepare("SELECT count(*) as c FROM sqlite_master WHERE type='table' AND name = ?").get("demo_solution_orphan").c)).toBe(1);
	});
});

describe("P4-1 卸载业务表保留清单（P3-4#2）：moduleTablePrefix + db.listTables 方言无关", () => {
	it("moduleTablePrefix 连字符→下划线作表前缀（listTables 内部按字面量前缀匹配，无需手拼 %）", () => {
		expect(moduleTablePrefix("demo-solution")).toBe("demo_solution_");
		expect(moduleTablePrefix("a!b%c_d")).toBe("a!b%c_d_");
	});

	it("manifest 声明 + 前缀兜底经 db.listTables 合并，仅回传实际存在的业务表", async () => {
		await seedInstalledWithTables();
		// manifest 追加「声明了但没建表」的幽灵条目，验证存在性过滤
		const manifestPath = join(sharedRoot, "demo-solution-0.1.0", "manifest.yaml");
		await fsp.writeFile(manifestPath, `${await fsp.readFile(manifestPath, "utf-8")}  - demo_solution_ghost\n`);
		// 真实 sqlite 目录：manifest 声明 notes/tags（seed 已建）+ 前缀扫描命中 orphan（未声明）
		dbo.exec("CREATE TABLE demo_solution_orphan (id INTEGER)");
		// L2：listTables 是 oj 运行时能力（纯 Rust 二进制内，vitest 无载体，见 devkit
		// oj-test-guide.md）——桩回放**真实 sqlite 目录**（sqlite_master 实查）并记录
		// 调用形态；被测的是合并/过滤编排，不是引擎的目录自省本身。
		const seen: Array<string | undefined> = [];
		g.db.listTables = async (prefix?: string) => {
			seen.push(prefix);
			const all = (dbo.prepare("SELECT name FROM sqlite_master WHERE type='table'").all() as Array<{ name: string }>).map(r => r.name);
			return prefix === undefined ? all : all.filter(t => t.startsWith(prefix));
		};
		const retained = await collectRetainedTables("demo-solution", manifestPath);
		expect(seen).toEqual(["demo_solution_", undefined]); // 前缀扫描 + 全量存在性过滤各一次
		expect(retained).toContain("demo_solution_notes"); // manifest 声明
		expect(retained).toContain("demo_solution_tags"); // manifest 声明
		expect(retained).toContain("demo_solution_orphan"); // 前缀兜底命中（未声明）
		expect(retained).not.toContain("demo_solution_ghost"); // 声明但物理不存在 → 不回传
	});
});
